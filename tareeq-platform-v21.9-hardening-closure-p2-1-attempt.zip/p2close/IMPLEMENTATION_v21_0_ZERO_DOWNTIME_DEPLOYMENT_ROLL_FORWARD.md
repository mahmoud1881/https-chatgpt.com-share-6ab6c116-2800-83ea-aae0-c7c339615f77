# v21.0 — Zero-Downtime Deployment & Automated Roll-Forward Recovery

Implemented an orchestration gate that separates **expand → deploy → contract** and fails closed until the actual hosting provider supplies traffic/deployment commands.

## Enforced sequence
1. Migration safety and backup/restore evidence.
2. Expand migrations before traffic movement.
3. Old and new release compatibility checks against expanded schema.
4. Deploy green with zero public traffic.
5. Readiness plus synthetic transaction.
6. Canary traffic shift and observation gate.
7. Full traffic cutover only after canary success.
8. Drain and prove old release drained.
9. Contract is optional/deferred by default; destructive contraction is never automatic without an explicit provider hook.
10. Post-deploy schema drift/fingerprint proof.

## Failure semantics
On any application/canary/probe failure, the orchestrator attempts to restore application traffic to `OLD_RELEASE`. It never rolls database migrations backward. An optional `rollForwardDatabase` hook can apply an operator/provider-defined forward repair migration.

## Provider integration
`deploy/scripts/zero-downtime-hook.sh` maps each phase to a `ZD_*_CMD` environment variable and exits 78 when missing. This prevents a false green deployment in an unconfigured environment.

Runtime PASS requires real production/staging DB URLs, backup evidence, Docker/Supabase prerequisites from earlier gates, and deployment-provider commands. Static checks do not claim those runtime proofs.
