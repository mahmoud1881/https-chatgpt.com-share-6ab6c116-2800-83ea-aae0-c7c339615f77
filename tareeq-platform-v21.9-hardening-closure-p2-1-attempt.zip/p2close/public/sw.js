/* Mawaslat SW — Offline + Persistent AI weights.
 * Strategy:
 *  - precache: manifest + core icons.
 *  - HTML/Navigation: network-first → cached fallback → home → offline shell.
 *  - Static (JS/CSS/IMG same-origin): stale-while-revalidate, per-country buckets.
 *  - AI weights (HuggingFace / MLC-AI CDNs): CacheFirst مع مدة صلاحية طويلة —
 *    الأوزان بالغيغابايت تُحمَّل مرة واحدة وتبقى في المتصفح للأبد.
 *  - APIs / Supabase / Realtime: bypass.
 */
const VERSION = "mawaslat-v4-ai";
const STATIC_CACHE = `${VERSION}-static`;
const RUNTIME_CACHE = `${VERSION}-runtime`;
const HTML_CACHE = `${VERSION}-html`;
const LY_CACHE = `${VERSION}-ly-data`;
const MA_CACHE = `${VERSION}-ma-data`;
const DZ_CACHE = `${VERSION}-dz-data`;
const TN_CACHE = `${VERSION}-tn-data`;
// كاش ثابت للأوزان — لا يُبنى فيه رقم إصدار لأننا لا نريد إلغاءه عند ترقية التطبيق.
const AI_WEIGHTS_CACHE = "mawaslat-ai-weights-v1";

const PRECACHE_URLS = ["/manifest.webmanifest", "/favicon.svg", "/icon-192.png", "/icon-512.png"];

const BACKGROUND_WARM_URLS = ["/", "/ma", "/dz", "/tn", "/ly"];

// نطاقات CDN التي تستضيف نماذج الذكاء الاصطناعي (WebLLM + Transformers.js).
const AI_CDN_HOSTS = [
  "huggingface.co",
  "cdn-lfs.huggingface.co",
  "cdn-lfs-us-1.huggingface.co",
  "cdn-lfs-eu-1.huggingface.co",
  "raw.githubusercontent.com", // wasm shards
];
const AI_WEIGHT_EXTENSIONS = /\.(?:bin|onnx|onnx_data|safetensors|wasm|json|gguf)(?:\?.*)?$/i;

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(STATIC_CACHE)
      .then((c) => c.addAll(PRECACHE_URLS))
      .catch(() => {}),
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            // احتفظ بكاش الأوزان — قد يزن غيغابايت ونعيد تحميله = مؤلم.
            .filter((k) => !k.startsWith(VERSION) && k !== AI_WEIGHTS_CACHE)
            .map((k) => caches.delete(k)),
        ),
      )
      .then(() => self.clients.claim())
      .then(() =>
        caches.open(HTML_CACHE).then((c) =>
          Promise.allSettled(
            BACKGROUND_WARM_URLS.map((url) =>
              fetch(url, { cache: "no-cache" })
                .then((r) => (r && r.ok ? c.put(url, r.clone()) : null))
                .catch(() => null),
            ),
          ),
        ),
      )
      .catch(() => {}),
  );
});

function isSameOrigin(url) {
  try {
    return new URL(url).origin === self.location.origin;
  } catch {
    return false;
  }
}

function isBypass(url) {
  return (
    url.includes("/api/") ||
    url.includes("supabase.co") ||
    url.includes("/auth/") ||
    url.includes("/realtime/")
  );
}

function isAIWeightRequest(url) {
  try {
    const u = new URL(url);
    if (!AI_CDN_HOSTS.includes(u.hostname)) return false;
    // ملفات النماذج فقط — لا نلتقط صفحات HTML من huggingface.co.
    return AI_WEIGHT_EXTENSIONS.test(u.pathname) || u.pathname.includes("/resolve/");
  } catch {
    return false;
  }
}

// CacheFirst بلا حد صلاحية — الأوزان محتوى ثابت (immutable) مرتبط بـ hash.
async function cacheFirstAIWeight(request) {
  const cache = await caches.open(AI_WEIGHTS_CACHE);
  const cached = await cache.match(request, { ignoreVary: true });
  if (cached) return cached;
  try {
    const res = await fetch(request);
    // نخزّن حتى الاستجابات الشفافة (opaque) — WebLLM يستخدم no-cors أحياناً.
    if (res && (res.status === 200 || res.type === "opaque")) {
      try {
        await cache.put(request, res.clone());
      } catch {
        /* quota */
      }
    }
    return res;
  } catch (err) {
    // آخر محاولة: أعد أي نسخة قديمة إن وُجدت.
    const stale = await cache.match(request, { ignoreVary: true, ignoreSearch: true });
    if (stale) return stale;
    throw err;
  }
}

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = req.url;

  // 1) أوزان الذكاء الاصطناعي — CacheFirst دائم (الأولوية القصوى، قبل bypass).
  if (isAIWeightRequest(url)) {
    event.respondWith(cacheFirstAIWeight(req));
    return;
  }

  if (isBypass(url)) return;

  // Offline Maps Support: Cache OpenStreetMap tiles
  if (url.includes("tile.openstreetmap.org")) {
    event.respondWith(
      caches.open("mawaslat-maps-v1").then(async (cache) => {
        const cached = await cache.match(req);
        if (cached) return cached;
        const network = await fetch(req);
        if (network && network.ok) {
          cache.put(req, network.clone());
        }
        return network;
      }),
    );
    return;
  }

  if (!isSameOrigin(url) && !url.match(/\.(?:js|css|png|jpg|jpeg|svg|webp|ico|woff2?)$/i)) return;

  // HTML navigation: network-first
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches
            .open(HTML_CACHE)
            .then((c) => c.put(req, copy))
            .catch(() => {});
          return res;
        })
        .catch(async () => {
          const cached = await caches.match(req);
          if (cached) return cached;
          const fallback = await caches.match("/");
          if (fallback) return fallback;
          return new Response(
            '<!doctype html><meta charset="utf-8"><title>أوفلاين</title><div style="font-family:sans-serif;direction:rtl;padding:2rem;text-align:center"><h1>📡 لا يوجد إنترنت</h1><p>افتح أي صفحة كنت زرتها قبل كده وستعمل من الكاش.</p></div>',
            { headers: { "Content-Type": "text/html; charset=utf-8" }, status: 200 },
          );
        }),
    );
    return;
  }

  // Static / runtime: stale-while-revalidate
  let targetCache = RUNTIME_CACHE;
  if (/\/ly[\/\.\-]|libya|tripoli|benghazi|misrata/i.test(url)) targetCache = LY_CACHE;
  else if (/\/ma[\/\.\-]|morocco|grandTaxi|tramways|oncf/i.test(url)) targetCache = MA_CACHE;
  else if (/\/dz[\/\.\-]|algeria|sntf|etusa/i.test(url)) targetCache = DZ_CACHE;
  else if (/\/tn[\/\.\-]|tunisia|transtu|sncft|louage/i.test(url)) targetCache = TN_CACHE;
  event.respondWith(
    caches.match(req).then((cached) => {
      const network = fetch(req)
        .then((res) => {
          if (res && res.status === 200 && res.type !== "opaque") {
            const copy = res.clone();
            caches
              .open(targetCache)
              .then((c) => c.put(req, copy))
              .catch(() => {});
          }
          return res;
        })
        .catch(() => cached);
      return cached || network;
    }),
  );
});

self.addEventListener("message", (event) => {
  if (event.data === "SKIP_WAITING") self.skipWaiting();
});
