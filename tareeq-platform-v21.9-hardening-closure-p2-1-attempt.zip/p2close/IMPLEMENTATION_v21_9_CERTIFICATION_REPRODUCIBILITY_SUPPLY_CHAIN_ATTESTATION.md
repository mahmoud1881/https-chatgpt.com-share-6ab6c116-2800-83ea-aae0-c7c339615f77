# v21.9 — Certification Reproducibility & Supply-Chain Attestation

v21.9 binds production certification to the exact OCI artifact and its software supply chain.

## Runtime certification chain

`production:certify` now begins with a fail-closed supply-chain attestation. It requires the published OCI reference and immutable digest, resolves the registry digest with `crane`, and rejects any mismatch before runtime certification proceeds.

The gate generates SPDX JSON and CycloneDX JSON SBOMs from the immutable image using Syft, scans the SBOM with Grype, scans the checked-out source for secrets with Gitleaks, signs the immutable OCI image with Cosign, verifies that signature, emits an in-toto/SLSA provenance predicate, attaches it as a signed OCI attestation, and verifies the attestation.

## Certification binding

The signed production certification contains SHA-256 hashes for both SBOM formats and provenance. The supply-chain evidence itself is also hashed in the v21.8/v21.9 evidence map. Because all later runtime gates use the same `RELEASE_IMAGE_DIGEST`, the image that passes database, rollout, telemetry, chaos and DR certification is the same immutable image that was resolved from the registry, scanned, signed and attested.

## Required runtime tooling / secrets

`syft`, `grype`, `gitleaks`, `cosign`, and `crane` must be installed. `RELEASE_IMAGE_REF`, `RELEASE_IMAGE_DIGEST`, `RELEASE_COMMIT`, `COSIGN_PRIVATE_KEY_FILE`, and `COSIGN_PUBLIC_KEY_FILE` are mandatory. The private signing key is external and is never written into release artifacts.

Static validation cannot issue a production or supply-chain certificate. Missing tools, registry access, keys, SBOM generation, scans, image signature, provenance attestation, or digest equality all fail closed.
