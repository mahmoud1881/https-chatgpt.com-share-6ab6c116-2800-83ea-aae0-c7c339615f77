# Hardening Wave 2

Implemented local contracts and tests for: default-deny Capability Broker; production sandbox certification contract (worker_threads explicitly cannot certify security isolation); signed audit checkpoints requiring an external anchor receipt; immutable content-addressed evidence registry; and a fail-closed runtime certification runner.

Runtime truth remains unverified until an external container/microVM/sandbox boundary, external audit anchor, and authoritative evidence backend are actually observed and independently verified by P3. Local files are test/dev storage only and are not declared authoritative production evidence.

Realtime verification tests now run through Node type stripping so the TypeScript source is tested directly instead of failing on the `.ts` extension.
