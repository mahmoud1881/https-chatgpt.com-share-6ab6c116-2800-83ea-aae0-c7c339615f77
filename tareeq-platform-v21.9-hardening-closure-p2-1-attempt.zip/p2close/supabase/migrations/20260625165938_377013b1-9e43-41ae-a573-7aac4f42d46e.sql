
REVOKE EXECUTE ON FUNCTION public.traffic_reports_rate_limit() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.bump_answers_count() FROM anon, authenticated, PUBLIC;
