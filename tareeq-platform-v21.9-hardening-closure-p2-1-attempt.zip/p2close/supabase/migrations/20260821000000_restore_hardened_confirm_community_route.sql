-- ============================================================================
-- RELEASE_READINESS fix: restore the hardened confirm_community_route().
--
-- Root cause: migration 20260625171148 hardened this function (SECURITY
-- DEFINER, requires auth.uid(), dedupes via the community_route_votes unique
-- constraint, caps confirmations at 10000). A later migration,
-- 20260702103316 (the "community Q&A" fresh-schema migration), did a
-- CREATE OR REPLACE FUNCTION that reintroduced the original naive version:
-- LANGUAGE sql, SECURITY INVOKER, no auth check, no dedup, no cap. Because
-- migrations apply in filename/timestamp order, that later, weaker
-- definition is the one actually active today, silently undoing the June 25
-- hardening. Two concrete consequences:
--
--   1. Self-confirmation abuse: because 20260702105659 added an
--      owner-scoped UPDATE policy ("owners update own routes", USING
--      auth.uid() = user_id), and this function is SECURITY INVOKER (so it
--      runs under RLS as the calling user), a user CAN successfully confirm
--      their own submitted route — repeatedly, with no cap and no dedup —
--      inflating its confirmation count/flipping it to "confirmed" status
--      arbitrarily.
--   2. Confirming someone else's route silently no-ops: RLS blocks the
--      UPDATE for any route the caller doesn't own, so the "confirm a route
--      someone else posted" flow — the actual point of this feature —
--      updates 0 rows. The RPC call still returns without a Postgres error,
--      so the client shows a false "تم التأكيد" success toast while nothing
--      changed. This is a broken core feature, not just a hardening gap.
--
-- This migration re-applies the June 25 hardened definition so it wins as
-- the final, currently-active version.
-- ============================================================================

-- 20260702103316 redefined this as `RETURNS int` (SECURITY INVOKER, no
-- self-vote check). CREATE OR REPLACE cannot change a function's return
-- type, so on a from-scratch replay this migration -- and the two later
-- hardening ones that build on it -- abort, leaving the weak July version
-- in place. Drop first so the hardened signature can be installed.
DROP FUNCTION IF EXISTS public.confirm_community_route(uuid);
CREATE OR REPLACE FUNCTION public.confirm_community_route(route_id UUID)
RETURNS public.community_routes
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updated public.community_routes;
  uid UUID := auth.uid();
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'auth_required: must be signed in to confirm';
  END IF;

  -- Enforce one vote per user per route (community_route_votes has a
  -- UNIQUE(route_id, voter_id) constraint from migration 20260625171148).
  BEGIN
    INSERT INTO public.community_route_votes (route_id, voter_id)
    VALUES (route_id, uid);
  EXCEPTION WHEN unique_violation THEN
    RAISE EXCEPTION 'duplicate_vote: you already confirmed this route';
  END;

  UPDATE public.community_routes
     SET confirmations = LEAST(confirmations + 1, 10000),
         status = CASE WHEN confirmations + 1 >= 5 THEN 'confirmed' ELSE status END
   WHERE id = route_id
  RETURNING * INTO updated;

  IF updated.id IS NULL THEN
    RAISE EXCEPTION 'not_found: route does not exist';
  END IF;

  RETURN updated;
END;
$$;

-- SECURITY DEFINER means this now bypasses the owner-scoped UPDATE policy by
-- design (that's the point — confirming someone else's route must not
-- require owning it), while the auth.uid() check + vote dedup above provide
-- the actual access control instead of relying on row ownership.
REVOKE ALL ON FUNCTION public.confirm_community_route(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.confirm_community_route(UUID) TO authenticated;
