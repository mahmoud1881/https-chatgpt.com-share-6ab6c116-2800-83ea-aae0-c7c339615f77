
CREATE TABLE public.ng_stations (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('park','stop')),
  state TEXT NOT NULL,
  city TEXT NOT NULL,
  name TEXT NOT NULL,
  park_id TEXT,
  mode TEXT,
  modes TEXT[] NOT NULL DEFAULT '{}',
  lat DOUBLE PRECISION NOT NULL,
  lng DOUBLE PRECISION NOT NULL,
  served_areas JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ng_stations_state_idx ON public.ng_stations (state);
CREATE INDEX ng_stations_kind_idx  ON public.ng_stations (kind);
CREATE INDEX ng_stations_mode_idx  ON public.ng_stations (mode);

GRANT SELECT ON public.ng_stations TO anon;
GRANT SELECT ON public.ng_stations TO authenticated;
GRANT ALL ON public.ng_stations TO service_role;

ALTER TABLE public.ng_stations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ng_stations public read"
  ON public.ng_stations FOR SELECT
  TO anon, authenticated
  USING (true);
