
CREATE UNIQUE INDEX IF NOT EXISTS stops_country_city_normalized_uniq
  ON public.stops (country, COALESCE(city, ''), normalized_name);

CREATE UNIQUE INDEX IF NOT EXISTS routes_country_code_uniq
  ON public.routes (country, COALESCE(city, ''), COALESCE(route_code, ''), route_name)
  WHERE route_code IS NOT NULL;
