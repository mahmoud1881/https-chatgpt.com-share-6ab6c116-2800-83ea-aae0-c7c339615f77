
CREATE OR REPLACE FUNCTION public.bulk_update_stop_embeddings(_payload jsonb)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _updated integer;
BEGIN
  WITH src AS (
    SELECT
      (elem->>'id')::uuid AS id,
      (elem->>'embedding')::public.vector(512) AS embedding,
      COALESCE((elem->>'embedding_updated_at')::timestamptz, now()) AS embedding_updated_at
    FROM jsonb_array_elements(_payload) elem
  ),
  upd AS (
    UPDATE public.stops s
       SET embedding = src.embedding,
           embedding_updated_at = src.embedding_updated_at
      FROM src
     WHERE s.id = src.id
    RETURNING s.id
  )
  SELECT count(*) INTO _updated FROM upd;
  RETURN _updated;
END;
$$;

-- Lock down: only service_role can invoke; do not expose to anon/authenticated.
REVOKE ALL ON FUNCTION public.bulk_update_stop_embeddings(jsonb) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.bulk_update_stop_embeddings(jsonb) FROM anon, authenticated;
GRANT EXECUTE ON FUNCTION public.bulk_update_stop_embeddings(jsonb) TO service_role;
