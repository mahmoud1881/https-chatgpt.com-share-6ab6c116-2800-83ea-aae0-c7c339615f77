
CREATE TABLE public.community_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  body text,
  author_name text,
  answers_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX community_questions_created_idx ON public.community_questions (created_at DESC);

GRANT SELECT, INSERT ON public.community_questions TO anon, authenticated;
GRANT ALL ON public.community_questions TO service_role;
ALTER TABLE public.community_questions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone can read questions"
  ON public.community_questions FOR SELECT USING (true);

CREATE POLICY "anyone can insert questions"
  ON public.community_questions FOR INSERT
  WITH CHECK (
    length(btrim(title)) BETWEEN 5 AND 140
    AND (body IS NULL OR length(body) <= 1000)
    AND (author_name IS NULL OR length(btrim(author_name)) BETWEEN 1 AND 40)
    AND answers_count = 0
  );

CREATE TABLE public.community_answers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id uuid NOT NULL REFERENCES public.community_questions(id) ON DELETE CASCADE,
  body text NOT NULL,
  author_name text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX community_answers_qid_idx ON public.community_answers (question_id, created_at);

GRANT SELECT, INSERT ON public.community_answers TO anon, authenticated;
GRANT ALL ON public.community_answers TO service_role;
ALTER TABLE public.community_answers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone can read answers"
  ON public.community_answers FOR SELECT USING (true);

CREATE POLICY "anyone can insert answers"
  ON public.community_answers FOR INSERT
  WITH CHECK (
    length(btrim(body)) BETWEEN 2 AND 1000
    AND (author_name IS NULL OR length(btrim(author_name)) BETWEEN 1 AND 40)
  );

CREATE OR REPLACE FUNCTION public.bump_answers_count()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.community_questions
     SET answers_count = answers_count + 1
   WHERE id = NEW.question_id;
  RETURN NEW;
END;
$$;

CREATE TRIGGER community_answers_bump
AFTER INSERT ON public.community_answers
FOR EACH ROW EXECUTE FUNCTION public.bump_answers_count();

ALTER PUBLICATION supabase_realtime ADD TABLE public.community_questions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.community_answers;
