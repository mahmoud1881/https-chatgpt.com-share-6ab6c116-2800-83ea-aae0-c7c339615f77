
CREATE TABLE public.geocode_failures (
  stop_id UUID PRIMARY KEY REFERENCES public.stops(id) ON DELETE CASCADE,
  tried_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  attempts INT NOT NULL DEFAULT 1,
  reason TEXT,
  last_query TEXT
);
CREATE INDEX geocode_failures_tried_at_idx ON public.geocode_failures(tried_at);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.geocode_failures TO authenticated;
GRANT ALL ON public.geocode_failures TO service_role;

ALTER TABLE public.geocode_failures ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins manage geocode_failures"
  ON public.geocode_failures FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));
