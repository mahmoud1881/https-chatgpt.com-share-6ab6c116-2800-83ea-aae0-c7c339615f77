-- ============================================================================
-- المرحلة 3 — الدوال المفقودة
--
-- (أ) log_ai_usage: توقيعها معروف بدقة — رسالة خطأ Postgres نفسها تكشف
--     الترتيب الدقيق للمعاملات، و types.ts المولَّد يكشف أسماءها. وجسمها
--     بديهي: إدخال سطر في ai_usage_log. فإعادة بنائها آمنة.
--
-- (ب) get_admin_stats: لوحة الإدارة تقرأ منها 18 حقلًا على الأقل (جلسات،
--     مستخدمون نشطون، استهلاك AI شهري/يومي، تسعير، ميزانية، أعلى
--     المستخدمين...). لا يمكن استرجاع جسمها الحقيقي من المستودع، وكتابة
--     نسخة مخمَّنة أسوأ من غيابها: ستبدو عاملة وتعطي أرقامًا إدارية خاطئة
--     بصمت. لذلك لا نخترعها — نجعل عبارات GRANT/REVOKE التي تشير إليها
--     تتسامح مع غيابها فقط، حتى لا توقف النشر من الصفر، مع إبقاء الفجوة
--     ظاهرة ومقصودة.
--
--     الإجراء المطلوب منكم: استخرجوا التعريف الحقيقي من الإنتاج:
--        SELECT pg_get_functiondef('public.get_admin_stats()'::regprocedure);
--     ثم أضيفوه كـ migration. هذه هي النسخة الوحيدة الموثوقة.
-- ============================================================================

-- (أ) --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.log_ai_usage(
  _model             text,
  _operation         text,
  _prompt_tokens     integer DEFAULT 0,
  _completion_tokens integer DEFAULT 0,
  _cached_tokens     integer DEFAULT 0,
  _cache_hit         boolean DEFAULT false,
  _duration_ms       integer DEFAULT NULL,
  _status            text    DEFAULT 'ok'
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.ai_usage_log (
    user_id, model, operation,
    prompt_tokens, completion_tokens, cached_tokens, total_tokens,
    cache_hit, duration_ms, status
  ) VALUES (
    auth.uid(), _model, _operation,
    COALESCE(_prompt_tokens, 0), COALESCE(_completion_tokens, 0), COALESCE(_cached_tokens, 0),
    COALESCE(_prompt_tokens, 0) + COALESCE(_completion_tokens, 0),
    COALESCE(_cache_hit, false), _duration_ms, COALESCE(_status, 'ok')
  );
END;
$$;

REVOKE ALL ON FUNCTION public.log_ai_usage(text, text, integer, integer, integer, boolean, integer, text)
  FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.log_ai_usage(text, text, integer, integer, integer, boolean, integer, text)
  TO authenticated, service_role;

-- (ب) --------------------------------------------------------------------
-- نُنشئ الدالة فقط إن لم تكن موجودة، وبجسم يرفض التنفيذ عمدًا.
--
-- لماذا stub يفشل بدل نسخة مخمَّنة؟ لأن أربع migrations لاحقة
-- (20260703161744، 20260708172409، 20260710192101، 20260718010045) تنفّذ
-- GRANT/REVOKE غير مشروط على هذه الدالة، فغيابها يوقف النشر من الصفر. وفي
-- الوقت نفسه، جسم مخمَّن سيُظهر للوحة الإدارة أرقامًا خاطئة وهي تبدو
-- سليمة — وهذا أسوأ من عطل واضح. فالـ stub يحل المشكلتين: الصلاحيات
-- تُضبط، وأي استدعاء فعلي يفشل برسالة صريحة تقول ما ينقص وكيف يُستخرج.
--
-- CREATE ... IF NOT EXISTS غير مدعومة للدوال، فنتحقق يدويًا حتى لا نطمس
-- التعريف الحقيقي في بيئة الإنتاج القائمة.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_proc p
      JOIN pg_namespace n ON n.oid = p.pronamespace
     WHERE n.nspname = 'public' AND p.proname = 'get_admin_stats'
  ) THEN
    EXECUTE $fn$
      CREATE FUNCTION public.get_admin_stats() RETURNS jsonb
      LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $body$
      BEGIN
        RAISE EXCEPTION
          'get_admin_stats() لم تُستعَد بعد في هذه البيئة. التعريف الحقيقي لم يُلتقط قط كـ migration؛ استخرجوه من الإنتاج: SELECT pg_get_functiondef(''public.get_admin_stats()''::regprocedure); ثم أضيفوه كـ migration يستبدل هذا الـ stub.';
      END;
      $body$;
    $fn$;
  END IF;
END $$;

REVOKE ALL ON FUNCTION public.get_admin_stats() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_admin_stats() TO authenticated, service_role;
