
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- GIN trigram indexes for ILIKE search on stops
CREATE INDEX IF NOT EXISTS idx_stops_name_ar_trgm
  ON public.stops USING gin (name_ar public.gin_trgm_ops);

CREATE INDEX IF NOT EXISTS idx_stops_name_en_trgm
  ON public.stops USING gin (name_en public.gin_trgm_ops);

CREATE INDEX IF NOT EXISTS idx_stops_normalized_name_trgm
  ON public.stops USING gin (normalized_name public.gin_trgm_ops);

-- Support (city, country) filters that commonly accompany search
CREATE INDEX IF NOT EXISTS idx_stops_country_city
  ON public.stops (country, city);

-- route_stops lookup by stop_id (used in ANY(...) queries)
CREATE INDEX IF NOT EXISTS idx_route_stops_stop_id
  ON public.route_stops (stop_id);
