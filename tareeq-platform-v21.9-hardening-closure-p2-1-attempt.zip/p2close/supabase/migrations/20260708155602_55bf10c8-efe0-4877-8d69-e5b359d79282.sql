
-- Public read tightening
DROP POLICY IF EXISTS "routes public read" ON public.routes;
DROP POLICY IF EXISTS "route_stops public read" ON public.route_stops;

DROP POLICY IF EXISTS "public read verified routes" ON public.routes;
CREATE POLICY "public read verified routes" ON public.routes
  FOR SELECT TO anon, authenticated
  USING (is_verified = true);

DROP POLICY IF EXISTS "public read verified route_stops" ON public.route_stops;
CREATE POLICY "public read verified route_stops" ON public.route_stops
  FOR SELECT TO anon, authenticated
  USING (EXISTS (
    SELECT 1 FROM public.routes r
    WHERE r.id = route_stops.route_id AND r.is_verified = true
  ));

-- Safe peer discovery view (no user_id)
CREATE OR REPLACE VIEW public.available_peers
WITH (security_invoker = true) AS
SELECT id, peer_id, tier, models, region, last_seen_at, requests_served, is_available, created_at
FROM public.peer_nodes
WHERE is_available = true;

GRANT SELECT ON public.available_peers TO authenticated, anon;
