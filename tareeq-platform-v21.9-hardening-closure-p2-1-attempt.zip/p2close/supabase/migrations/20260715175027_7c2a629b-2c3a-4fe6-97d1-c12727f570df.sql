-- Remove the short duplicate "3 ج" route from the DB so the authoritative
-- 18-stop version in bus-stations-extra.json is the only version of this
-- line surfaced across the app.
DELETE FROM public.route_stops WHERE route_id = 'b49f7ad6-f312-42e3-935c-d4f9e2ff54af';
DELETE FROM public.routes WHERE id = 'b49f7ad6-f312-42e3-935c-d4f9e2ff54af';