GRANT SELECT, INSERT, UPDATE, DELETE ON public.routes TO authenticated, service_role;
GRANT SELECT ON public.routes TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.route_stops TO authenticated, service_role;
GRANT SELECT ON public.route_stops TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.stops TO authenticated, service_role;
GRANT SELECT ON public.stops TO anon;