
-- live_vehicle_pings: revoke blanket SELECT, grant column-level SELECT on non-reporter columns
REVOKE SELECT ON public.live_vehicle_pings FROM authenticated;
REVOKE SELECT ON public.live_vehicle_pings FROM anon;
GRANT SELECT (id, route_id, session_id, lat, lng, heading, speed_kmh, country, created_at)
  ON public.live_vehicle_pings TO authenticated;

-- ma_grand_taxi_pings: hide user_id + reported_by
REVOKE SELECT ON public.ma_grand_taxi_pings FROM authenticated;
REVOKE SELECT ON public.ma_grand_taxi_pings FROM anon;
GRANT SELECT (id, route_id, seats_remaining, total_seats, country, reported_at, created_at, note, station_id)
  ON public.ma_grand_taxi_pings TO authenticated;

-- ma_tram_pings: hide user_id + reporter_id
REVOKE SELECT ON public.ma_tram_pings FROM authenticated;
REVOKE SELECT ON public.ma_tram_pings FROM anon;
GRANT SELECT (id, line, crowd_level, country, created_at, station_id, delay_minutes, note)
  ON public.ma_tram_pings TO authenticated;

-- service_role keeps full access (already granted, re-assert for safety)
GRANT ALL ON public.live_vehicle_pings TO service_role;
GRANT ALL ON public.ma_grand_taxi_pings TO service_role;
GRANT ALL ON public.ma_tram_pings TO service_role;
