
-- Hide raw submitter identifiers from broad reads by revoking column-level SELECT
-- while keeping row-level policies intact. Owner writes/updates still work
-- because policy expressions do not require caller SELECT privilege on columns.

REVOKE SELECT (user_id) ON public.community_answers FROM authenticated, anon;
REVOKE SELECT (user_id) ON public.community_questions FROM authenticated, anon;
REVOKE SELECT (user_id) ON public.community_routes FROM authenticated, anon;
REVOKE SELECT (user_id) ON public.live_vehicle_pings FROM authenticated, anon;
REVOKE SELECT (user_id) ON public.ma_tram_pings FROM authenticated, anon;
REVOKE SELECT (reported_by) ON public.ma_grand_taxi_pings FROM authenticated, anon;
REVOKE SELECT (user_id) ON public.traffic_reports FROM authenticated, anon;
