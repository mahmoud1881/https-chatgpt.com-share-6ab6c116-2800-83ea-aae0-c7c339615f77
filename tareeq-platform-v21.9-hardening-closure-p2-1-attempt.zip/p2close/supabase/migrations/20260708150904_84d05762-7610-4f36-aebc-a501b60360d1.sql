
-- Phase 2 prep: add missing GRANTs on Route Planner tables so PostgREST
-- can serve public reads and anon inserts as the policies already allow.

-- Public read tables
GRANT SELECT ON public.stops TO anon, authenticated;
GRANT SELECT ON public.routes TO anon, authenticated;
GRANT SELECT ON public.route_stops TO anon, authenticated;
GRANT SELECT ON public.stop_aliases TO anon, authenticated;
GRANT SELECT ON public.transport_types TO anon, authenticated;

-- Anon/authenticated inserts (policies already scope them)
GRANT INSERT ON public.search_logs TO anon, authenticated;
GRANT SELECT ON public.search_logs TO authenticated;
GRANT INSERT, SELECT, UPDATE ON public.missing_searches TO anon, authenticated;

-- Authenticated-only inserts + owner reads (policies enforce ownership)
GRANT INSERT, SELECT ON public.route_corrections TO authenticated;
GRANT INSERT, SELECT ON public.user_route_suggestions TO authenticated;
GRANT INSERT, SELECT ON public.alias_suggestions TO authenticated;

-- Admin writes are enforced by RLS policies; grant privileges on the tables
GRANT INSERT, UPDATE, DELETE ON public.stops TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.routes TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.route_stops TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.stop_aliases TO authenticated;
GRANT UPDATE ON public.route_corrections TO authenticated;
GRANT UPDATE ON public.user_route_suggestions TO authenticated;
GRANT UPDATE ON public.alias_suggestions TO authenticated;

-- Service role full access
GRANT ALL ON public.stops, public.routes, public.route_stops, public.stop_aliases,
             public.transport_types, public.search_logs, public.missing_searches,
             public.route_corrections, public.user_route_suggestions, public.alias_suggestions
      TO service_role;
