CREATE TABLE IF NOT EXISTS public._eg_city_fix (
  id uuid PRIMARY KEY,
  city text NOT NULL,
  area text
);
GRANT ALL ON public._eg_city_fix TO service_role;
GRANT SELECT, INSERT ON public._eg_city_fix TO authenticated;
ALTER TABLE public._eg_city_fix ENABLE ROW LEVEL SECURITY;