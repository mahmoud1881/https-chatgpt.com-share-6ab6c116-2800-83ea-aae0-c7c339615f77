
-- Harden SECURITY DEFINER functions: revoke public EXECUTE, grant narrowly.

-- log_ai_usage: only server (service_role) should insert cost logs.
REVOKE ALL ON FUNCTION public.log_ai_usage(text, text, integer, integer, integer, boolean, integer, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.log_ai_usage(text, text, integer, integer, integer, boolean, integer, text) TO service_role;

-- get_admin_stats: internal admin check already; keep authenticated (function itself throws if not admin).
REVOKE ALL ON FUNCTION public.get_admin_stats() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_admin_stats() TO authenticated, service_role;

-- Session lifecycle: only authenticated users.
REVOKE ALL ON FUNCTION public.start_session(text, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.start_session(text, text) TO authenticated, service_role;

REVOKE ALL ON FUNCTION public.end_session(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.end_session(uuid) TO authenticated, service_role;

REVOKE ALL ON FUNCTION public.heartbeat_session(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.heartbeat_session(uuid) TO authenticated, service_role;

-- has_role: used by RLS policies; keep executable but not to anon at large.
REVOKE ALL ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO authenticated, service_role;

-- handle_new_user: trigger function, no direct callers.
REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO service_role, supabase_auth_admin;
