
DROP POLICY IF EXISTS "Public view can read non-identity columns" ON public.live_vehicle_pings;
DROP POLICY IF EXISTS "Public view can read grand taxi non-identity" ON public.ma_grand_taxi_pings;
DROP POLICY IF EXISTS "Public view can read tram non-identity" ON public.ma_tram_pings;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='ma_grand_taxi_pings' AND cmd='SELECT') THEN
    CREATE POLICY "Reporters and admins can read grand taxi pings"
      ON public.ma_grand_taxi_pings FOR SELECT
      USING (auth.uid() = reported_by OR public.has_role(auth.uid(), 'admin'));
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='ma_tram_pings' AND cmd='SELECT') THEN
    CREATE POLICY "Reporters and admins can read tram pings"
      ON public.ma_tram_pings FOR SELECT
      USING (
        (user_id IS NOT NULL AND auth.uid() = user_id)
        OR (reporter_id IS NOT NULL AND auth.uid()::text = reporter_id)
        OR public.has_role(auth.uid(), 'admin')
      );
  END IF;
END $$;

GRANT SELECT ON public.live_vehicle_pings_public TO anon, authenticated;
GRANT SELECT ON public.ma_grand_taxi_pings_public TO anon, authenticated;
GRANT SELECT ON public.ma_tram_pings_public TO anon, authenticated;
