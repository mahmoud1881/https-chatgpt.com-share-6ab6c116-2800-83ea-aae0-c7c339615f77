-- ============================================================================
-- Fix a regression introduced by 20260904000000_reject_self_vote_confirm_
-- community_route.sql.
--
-- That migration (correctly) added a self-vote check, but its existence
-- check has a bug:
--
--   SELECT user_id INTO owner_id FROM public.community_routes WHERE id = route_id;
--   IF owner_id IS NULL THEN
--     RAISE EXCEPTION 'not_found: route does not exist';
--   END IF;
--
-- `owner_id` ends up NULL in TWO different cases that this treats as one:
--   1. No row matched route_id at all (route genuinely doesn't exist).
--   2. The row exists, but community_routes.user_id is legitimately NULL —
--      which happens for any real, valid, publicly-visible route whose
--      original submitter later deleted their account, because the column
--      is `REFERENCES auth.users(id) ON DELETE SET NULL`
--      (see 20260702103316_44a9dead-....sql).
--
-- Net effect of the bug: the moment a route's submitter deletes their
-- account, that route becomes permanently unconfirmable by anyone —
-- forever, with a misleading "route does not exist" error — even though
-- the route itself is completely valid and still shown in the public list.
-- This is exactly the kind of regression the project's own migrations-guard
-- CI job doesn't catch (it only asserts confirm_community_route is still
-- SECURITY DEFINER, not that its branching logic is correct), which is why
-- this needed a manual pass rather than being caught automatically.
--
-- Fix: use PL/pgSQL's FOUND to distinguish "no row" from "row found, column
-- is NULL", exactly like resolving the same ambiguity anywhere else a
-- SELECT ... INTO is used for an existence check. An orphaned route (no
-- owner left) legitimately has no one to reject as a self-voter, so it
-- correctly falls through to the normal vote path for every real user.
-- ============================================================================

CREATE OR REPLACE FUNCTION public.confirm_community_route(route_id UUID)
RETURNS public.community_routes
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updated public.community_routes;
  uid UUID := auth.uid();
  owner_id UUID;
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'auth_required: must be signed in to confirm';
  END IF;

  SELECT user_id INTO owner_id FROM public.community_routes WHERE id = route_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'not_found: route does not exist';
  END IF;

  -- owner_id can legitimately be NULL here (submitter's account was
  -- deleted) — that's not "not found", and an orphaned route has no owner
  -- to protect from self-voting, so only reject when they actually match.
  IF owner_id IS NOT NULL AND owner_id = uid THEN
    RAISE EXCEPTION 'cannot_vote_own_route: لا يمكنك تأكيد خطك الخاص';
  END IF;

  BEGIN
    INSERT INTO public.community_route_votes (route_id, voter_id)
    VALUES (route_id, uid);
  EXCEPTION WHEN unique_violation THEN
    RAISE EXCEPTION 'duplicate_vote: you already confirmed this route';
  END;

  UPDATE public.community_routes
     SET confirmations = LEAST(confirmations + 1, 10000),
         status = CASE WHEN confirmations + 1 >= 5 THEN 'confirmed' ELSE status END
   WHERE id = route_id
  RETURNING * INTO updated;

  RETURN updated;
END;
$$;

REVOKE ALL ON FUNCTION public.confirm_community_route(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.confirm_community_route(UUID) TO authenticated;
