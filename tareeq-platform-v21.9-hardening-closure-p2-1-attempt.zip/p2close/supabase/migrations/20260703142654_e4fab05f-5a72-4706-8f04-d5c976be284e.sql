
-- Shared AI + trip-plan cache (public across all users/devices)
CREATE TABLE public.ai_cache_shared (
  cache_key TEXT PRIMARY KEY,
  scope TEXT NOT NULL,               -- 'ai' | 'trip' | ...
  model TEXT,
  value JSONB NOT NULL,
  hits INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX ai_cache_shared_expires_idx ON public.ai_cache_shared (expires_at);
CREATE INDEX ai_cache_shared_scope_idx ON public.ai_cache_shared (scope);

GRANT SELECT ON public.ai_cache_shared TO anon, authenticated;
GRANT INSERT, UPDATE ON public.ai_cache_shared TO authenticated;
GRANT ALL ON public.ai_cache_shared TO service_role;

ALTER TABLE public.ai_cache_shared ENABLE ROW LEVEL SECURITY;

-- Anyone can read non-expired entries
CREATE POLICY "shared cache read" ON public.ai_cache_shared
  FOR SELECT TO anon, authenticated
  USING (expires_at > now());

-- Any signed-in user can write / refresh entries (values are non-personal derived data)
CREATE POLICY "shared cache write" ON public.ai_cache_shared
  FOR INSERT TO authenticated
  WITH CHECK (expires_at > now());

CREATE POLICY "shared cache update" ON public.ai_cache_shared
  FOR UPDATE TO authenticated
  USING (true)
  WITH CHECK (true);


-- Per-user AI + trip-plan cache (syncs across a user's own devices)
CREATE TABLE public.ai_cache_user (
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  cache_key TEXT NOT NULL,
  scope TEXT NOT NULL,
  model TEXT,
  value JSONB NOT NULL,
  hits INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL,
  PRIMARY KEY (user_id, cache_key)
);
CREATE INDEX ai_cache_user_expires_idx ON public.ai_cache_user (expires_at);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.ai_cache_user TO authenticated;
GRANT ALL ON public.ai_cache_user TO service_role;

ALTER TABLE public.ai_cache_user ENABLE ROW LEVEL SECURITY;

CREATE POLICY "user cache own" ON public.ai_cache_user
  FOR ALL TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);
