-- P2: bound user-generated community content and reject exact spam duplicates.

CREATE OR REPLACE FUNCTION public.harden_community_content()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  recent_count integer;
  body_hash text;
BEGIN
  IF TG_TABLE_NAME = 'community_questions' THEN
    IF length(trim(coalesce(NEW.title, ''))) < 3 OR length(NEW.title) > 180 THEN
      RAISE EXCEPTION 'question title must be 3..180 characters';
    END IF;
    IF NEW.body IS NOT NULL AND length(NEW.body) > 5000 THEN
      RAISE EXCEPTION 'question body exceeds 5000 characters';
    END IF;
    NEW.title := trim(NEW.title);
    NEW.body := NULLIF(trim(NEW.body), '');
    body_hash := md5(lower(regexp_replace(NEW.title || E'\n' || coalesce(NEW.body, ''), '\s+', ' ', 'g')));
    PERFORM pg_advisory_xact_lock(hashtext('community-question:' || coalesce(NEW.user_id::text, 'anon'))::bigint);
    SELECT count(*) INTO recent_count FROM public.community_questions q
      WHERE q.user_id = NEW.user_id
        AND md5(lower(regexp_replace(q.title || E'\n' || coalesce(q.body, ''), '\s+', ' ', 'g'))) = body_hash
        AND q.created_at > now() - interval '10 minutes';
    IF recent_count > 0 THEN RAISE EXCEPTION 'duplicate question: please wait before reposting'; END IF;
  ELSIF TG_TABLE_NAME = 'community_answers' THEN
    IF length(trim(coalesce(NEW.body, ''))) < 1 OR length(NEW.body) > 5000 THEN
      RAISE EXCEPTION 'answer body must be 1..5000 characters';
    END IF;
    NEW.body := trim(NEW.body);
    body_hash := md5(lower(regexp_replace(NEW.body, '\s+', ' ', 'g')));
    PERFORM pg_advisory_xact_lock(hashtext('community-answer:' || coalesce(NEW.user_id::text, 'anon'))::bigint);
    SELECT count(*) INTO recent_count FROM public.community_answers a
      WHERE a.user_id = NEW.user_id
        AND a.question_id = NEW.question_id
        AND md5(lower(regexp_replace(a.body, '\s+', ' ', 'g'))) = body_hash
        AND a.created_at > now() - interval '10 minutes';
    IF recent_count > 0 THEN RAISE EXCEPTION 'duplicate answer: please wait before reposting'; END IF;
  ELSIF TG_TABLE_NAME = 'community_routes' THEN
    IF length(trim(coalesce(NEW.title, ''))) < 2 OR length(NEW.title) > 180 THEN
      RAISE EXCEPTION 'route title must be 2..180 characters';
    END IF;
    IF NEW.from_area IS NOT NULL AND length(NEW.from_area) > 180 THEN RAISE EXCEPTION 'from_area too long'; END IF;
    IF NEW.to_area IS NOT NULL AND length(NEW.to_area) > 180 THEN RAISE EXCEPTION 'to_area too long'; END IF;
    IF NEW.price_egp IS NOT NULL AND (NEW.price_egp < 0 OR NEW.price_egp > 100000) THEN RAISE EXCEPTION 'invalid route price'; END IF;
    IF NEW.duration_min IS NOT NULL AND (NEW.duration_min < 1 OR NEW.duration_min > 1440) THEN RAISE EXCEPTION 'invalid route duration'; END IF;
    NEW.title := trim(NEW.title);
    PERFORM pg_advisory_xact_lock(hashtext('community-route:' || coalesce(NEW.user_id::text, 'anon'))::bigint);
    SELECT count(*) INTO recent_count FROM public.community_routes r
      WHERE r.user_id = NEW.user_id
        AND lower(trim(r.title)) = lower(trim(NEW.title))
        AND coalesce(lower(trim(r.from_area)), '') = coalesce(lower(trim(NEW.from_area)), '')
        AND coalesce(lower(trim(r.to_area)), '') = coalesce(lower(trim(NEW.to_area)), '')
        AND r.created_at > now() - interval '10 minutes';
    IF recent_count > 0 THEN RAISE EXCEPTION 'duplicate community route: please wait before reposting'; END IF;
  END IF;
  NEW.created_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_harden_community_questions ON public.community_questions;
CREATE TRIGGER trg_harden_community_questions BEFORE INSERT ON public.community_questions
FOR EACH ROW EXECUTE FUNCTION public.harden_community_content();

DROP TRIGGER IF EXISTS trg_harden_community_answers ON public.community_answers;
CREATE TRIGGER trg_harden_community_answers BEFORE INSERT ON public.community_answers
FOR EACH ROW EXECUTE FUNCTION public.harden_community_content();

DROP TRIGGER IF EXISTS trg_harden_community_routes ON public.community_routes;
CREATE TRIGGER trg_harden_community_routes BEFORE INSERT ON public.community_routes
FOR EACH ROW EXECUTE FUNCTION public.harden_community_content();

CREATE INDEX IF NOT EXISTS idx_community_questions_user_created ON public.community_questions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_community_answers_user_question_created ON public.community_answers(user_id, question_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_community_routes_user_created ON public.community_routes(user_id, created_at DESC);
