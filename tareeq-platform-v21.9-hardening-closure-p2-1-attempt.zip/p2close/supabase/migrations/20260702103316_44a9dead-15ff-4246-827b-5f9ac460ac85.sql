-- Fix (2026-09): this migration re-CREATEs 6 tables that a June 25
-- migration already created with a narrower schema (missing columns like
-- user_id/country, different types). On a fresh from-empty bootstrap this
-- bare CREATE TABLE fails with "relation already exists" the moment it
-- reaches the first one. `IF NOT EXISTS` would be the wrong fix here — it
-- would silently keep the OLDER, narrower June 25 schema and skip this
-- file's columns entirely, breaking every later migration that depends on
-- e.g. community_routes.user_id. DROP + CASCADE is safe specifically
-- because, on a fresh bootstrap, the June 25 version of each of these 6
-- tables is guaranteed empty at this point in the migration sequence — this
-- file immediately re-creates each one (with its final schema) and its own
-- RLS/policies right below, so nothing is left in a dropped state.
-- Already-migrated environments never re-run this file's contents (Supabase
-- tracks applied migrations by version, not content), so this only changes
-- behavior for a fresh install — which is exactly the case that was broken.

-- community Q&A
DROP TABLE IF EXISTS public.community_questions CASCADE;
CREATE TABLE public.community_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  title text NOT NULL,
  body text,
  author_name text,
  answers_count int NOT NULL DEFAULT 0,
  country text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.community_questions TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.community_questions TO authenticated;
GRANT ALL ON public.community_questions TO service_role;
ALTER TABLE public.community_questions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read all questions" ON public.community_questions FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "signed-in can post questions" ON public.community_questions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "owner update questions" ON public.community_questions FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP TABLE IF EXISTS public.community_answers CASCADE;
CREATE TABLE public.community_answers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id uuid NOT NULL REFERENCES public.community_questions(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  body text NOT NULL,
  author_name text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.community_answers TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.community_answers TO authenticated;
GRANT ALL ON public.community_answers TO service_role;
ALTER TABLE public.community_answers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read all answers" ON public.community_answers FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "signed-in can post answers" ON public.community_answers FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP TABLE IF EXISTS public.community_routes CASCADE;
CREATE TABLE public.community_routes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  title text NOT NULL,
  from_area text,
  to_area text,
  price_egp numeric,
  duration_min int,
  status text NOT NULL DEFAULT 'pending',
  confirmations int NOT NULL DEFAULT 0,
  country text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.community_routes TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.community_routes TO authenticated;
GRANT ALL ON public.community_routes TO service_role;
ALTER TABLE public.community_routes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read all community routes" ON public.community_routes FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "signed-in can post community routes" ON public.community_routes FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.confirm_community_route(route_id uuid)
RETURNS int LANGUAGE sql SECURITY INVOKER SET search_path = public AS $$
  UPDATE public.community_routes
    SET confirmations = confirmations + 1
    WHERE id = route_id
  RETURNING confirmations;
$$;
GRANT EXECUTE ON FUNCTION public.confirm_community_route(uuid) TO authenticated;

-- live vehicle pings
DROP TABLE IF EXISTS public.live_vehicle_pings CASCADE;
CREATE TABLE public.live_vehicle_pings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  route_id text NOT NULL,
  session_id text NOT NULL,
  lat double precision NOT NULL,
  lng double precision NOT NULL,
  heading numeric,
  speed_kmh numeric,
  country text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.live_vehicle_pings TO anon;
GRANT SELECT, INSERT ON public.live_vehicle_pings TO authenticated;
GRANT ALL ON public.live_vehicle_pings TO service_role;
ALTER TABLE public.live_vehicle_pings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read live pings" ON public.live_vehicle_pings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "signed-in can post pings" ON public.live_vehicle_pings FOR INSERT TO authenticated WITH CHECK (true);

-- traffic reports
DROP TABLE IF EXISTS public.traffic_reports CASCADE;
CREATE TABLE public.traffic_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  area text NOT NULL,
  severity text NOT NULL,
  lat double precision,
  lng double precision,
  country text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.traffic_reports TO anon;
GRANT SELECT, INSERT ON public.traffic_reports TO authenticated;
GRANT ALL ON public.traffic_reports TO service_role;
ALTER TABLE public.traffic_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read traffic reports" ON public.traffic_reports FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "signed-in can post traffic reports" ON public.traffic_reports FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- morocco transit signals
DROP TABLE IF EXISTS public.ma_tram_pings CASCADE;
CREATE TABLE public.ma_tram_pings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  line text NOT NULL,
  crowd_level text,
  country text NOT NULL DEFAULT 'ma',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.ma_tram_pings TO anon;
GRANT SELECT, INSERT ON public.ma_tram_pings TO authenticated;
GRANT ALL ON public.ma_tram_pings TO service_role;
ALTER TABLE public.ma_tram_pings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read tram pings" ON public.ma_tram_pings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "signed-in can post tram pings" ON public.ma_tram_pings FOR INSERT TO authenticated WITH CHECK (true);

DROP TABLE IF EXISTS public.ma_grand_taxi_pings CASCADE;
CREATE TABLE public.ma_grand_taxi_pings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  route_id text NOT NULL,
  seats_remaining int,
  total_seats int,
  country text NOT NULL DEFAULT 'ma',
  reported_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.ma_grand_taxi_pings TO anon;
GRANT SELECT, INSERT ON public.ma_grand_taxi_pings TO authenticated;
GRANT ALL ON public.ma_grand_taxi_pings TO service_role;
ALTER TABLE public.ma_grand_taxi_pings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read grand taxi pings" ON public.ma_grand_taxi_pings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "signed-in can post grand taxi pings" ON public.ma_grand_taxi_pings FOR INSERT TO authenticated WITH CHECK (true);

-- transit reference
CREATE TABLE public.transit_routes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  route_code text,
  name text,
  country text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.transit_routes TO anon, authenticated;
GRANT ALL ON public.transit_routes TO service_role;
ALTER TABLE public.transit_routes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read transit routes" ON public.transit_routes FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.route_stops_full (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  route_id uuid REFERENCES public.transit_routes(id) ON DELETE CASCADE,
  stop_name text,
  stop_order int,
  lat double precision,
  lng double precision,
  country text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.route_stops_full TO anon, authenticated;
GRANT ALL ON public.route_stops_full TO service_role;
ALTER TABLE public.route_stops_full ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read route stops" ON public.route_stops_full FOR SELECT TO anon, authenticated USING (true);

-- user favorite stations
CREATE TABLE IF NOT EXISTS public.user_stations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  station_id text NOT NULL,
  label text,
  country text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_stations TO authenticated;
GRANT ALL ON public.user_stations TO service_role;
ALTER TABLE public.user_stations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "manage own stations" ON public.user_stations FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);