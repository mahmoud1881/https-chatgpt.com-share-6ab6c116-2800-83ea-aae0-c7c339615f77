ALTER TABLE public.stops
  ADD COLUMN IF NOT EXISTS source_file text;

ALTER TABLE public.routes
  ADD COLUMN IF NOT EXISTS source_file text,
  ADD COLUMN IF NOT EXISTS has_intermediate_stops boolean NOT NULL DEFAULT true;

CREATE INDEX IF NOT EXISTS idx_stops_source_file ON public.stops(source_file) WHERE source_file IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_routes_source_file ON public.routes(source_file) WHERE source_file IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_stops_country_city ON public.stops(country, city);
CREATE INDEX IF NOT EXISTS idx_stops_normalized_name ON public.stops(normalized_name);

-- Unique key for idempotent stop upserts (country + normalized_name + city coalesced)
CREATE UNIQUE INDEX IF NOT EXISTS uniq_stops_norm_city_country
  ON public.stops (country, coalesce(city, ''), normalized_name)
  WHERE normalized_name IS NOT NULL;

-- Unique key for idempotent route upserts
CREATE UNIQUE INDEX IF NOT EXISTS uniq_routes_code_country_city
  ON public.routes (country, coalesce(city, ''), route_code)
  WHERE route_code IS NOT NULL;