-- Dedicated staging-load cleanup RPC. Do not grant to anon/authenticated/service_role by this migration.
-- Production deployment should grant EXECUTE only to the dedicated staging-load cleanup DB identity
-- represented by TAREEQ_STAGING_LOAD_CLEANUP_TOKEN/API_KEY.
CREATE OR REPLACE FUNCTION public.cleanup_staging_load_routes(p_ids uuid[], p_marker text)
RETURNS TABLE(removed_count bigint)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE n bigint;
BEGIN
  IF current_setting('app.environment', true) NOT IN ('staging','test','certification') THEN
    RAISE EXCEPTION 'staging cleanup forbidden outside staging/test/certification';
  END IF;
  IF p_marker IS NULL OR p_marker !~ '^load-' OR coalesce(array_length(p_ids,1),0) = 0 OR array_length(p_ids,1) > 50 THEN
    RAISE EXCEPTION 'invalid cleanup scope';
  END IF;
  DELETE FROM public.community_routes
   WHERE id = ANY(p_ids)
     AND title LIKE p_marker || '-%';
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN QUERY SELECT n;
END;
$$;
REVOKE ALL ON FUNCTION public.cleanup_staging_load_routes(uuid[], text) FROM PUBLIC, anon, authenticated;
