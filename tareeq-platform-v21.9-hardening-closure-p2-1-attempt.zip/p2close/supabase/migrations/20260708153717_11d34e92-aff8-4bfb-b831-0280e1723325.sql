ALTER TABLE public.admin_config ADD COLUMN IF NOT EXISTS use_structured_search boolean NOT NULL DEFAULT false;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='admin_config' AND policyname='public read structured flag') THEN
    CREATE POLICY "public read structured flag" ON public.admin_config FOR SELECT USING (true);
  END IF;
END $$;

GRANT SELECT ON public.admin_config TO anon;

-- Public route detail policy: anyone can read verified routes and their stops
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='routes' AND policyname='public read verified routes') THEN
    CREATE POLICY "public read verified routes" ON public.routes FOR SELECT TO anon USING (is_verified = true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='route_stops' AND policyname='public read verified route_stops') THEN
    CREATE POLICY "public read verified route_stops" ON public.route_stops FOR SELECT TO anon USING (
      EXISTS (SELECT 1 FROM public.routes r WHERE r.id = route_stops.route_id AND r.is_verified = true)
    );
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='stops' AND policyname='public read stops') THEN
    CREATE POLICY "public read stops" ON public.stops FOR SELECT TO anon USING (true);
  END IF;
END $$;

GRANT SELECT ON public.routes TO anon;
GRANT SELECT ON public.route_stops TO anon;
GRANT SELECT ON public.stops TO anon;