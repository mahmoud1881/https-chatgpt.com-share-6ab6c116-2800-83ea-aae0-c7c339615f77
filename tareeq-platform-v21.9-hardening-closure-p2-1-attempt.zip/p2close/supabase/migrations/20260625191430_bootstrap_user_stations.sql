-- ============================================================================
-- A from-scratch replay of the full migration chain (verified by actually
-- running all 108 files against an empty Postgres 16 instance, not just
-- reading them) fails at 20260625191431, which does
-- `ALTER TABLE public.user_stations ADD COLUMN ... country ...` before that
-- table exists anywhere in the tracked migrations — it's only CREATEd later,
-- in 20260702103316 (a week later). Same root cause as the missing
-- has_role/app_role/user_roles bootstrap found earlier in this audit: the
-- table was created directly in Supabase Studio at some point, and no
-- migration ever captured its origin — later migrations both assume it
-- exists (this one) and later still "formally" create it (20260702103316),
-- with nobody noticing the ordering gap in between.
--
-- Fix: a minimal shell here, just the columns that predate 20260625191431
-- (i.e. everything 20260702103316 defines except `country`, which
-- 20260625191431 adds itself right after this). 20260702103316's own
-- `CREATE TABLE public.user_stations` is changed to
-- `CREATE TABLE IF NOT EXISTS` (companion change, same migration file) so it
-- no-ops once the table already exists with this shape — final column set
-- ends up identical either way, so no data/shape difference for a real
-- environment where the table already existed outside of migrations either.
-- ============================================================================

CREATE TABLE IF NOT EXISTS public.user_stations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  station_id text NOT NULL,
  label text,
  created_at timestamptz NOT NULL DEFAULT now()
);
