DROP VIEW IF EXISTS public.traffic_reports_public;

DROP POLICY IF EXISTS "Users can read their own traffic reports" ON public.traffic_reports;

CREATE POLICY "Authenticated can read traffic reports"
ON public.traffic_reports
FOR SELECT
TO authenticated
USING (true);

-- Column-level privileges: hide the reporter's identity from readers.
REVOKE SELECT ON public.traffic_reports FROM authenticated;
GRANT SELECT (id, area, severity, lat, lng, country, created_at, notes, expires_at)
  ON public.traffic_reports TO authenticated;
REVOKE SELECT ON public.traffic_reports FROM anon;
GRANT INSERT, UPDATE, DELETE ON public.traffic_reports TO authenticated;
GRANT ALL ON public.traffic_reports TO service_role;