-- Wave 3: bind certification evidence to an immutable execution identity and expose only a dedicated RPC.
ALTER TABLE public.ai_certification_journey_runs
  ADD COLUMN IF NOT EXISTS release_id text,
  ADD COLUMN IF NOT EXISTS commit_sha text,
  ADD COLUMN IF NOT EXISTS environment_id text,
  ADD COLUMN IF NOT EXISTS config_hash text,
  ADD COLUMN IF NOT EXISTS evidence_digest text;

CREATE UNIQUE INDEX IF NOT EXISTS ai_certification_journey_runs_identity_uq
ON public.ai_certification_journey_runs(certification_run_id, release_id, commit_sha, environment_id, config_hash, evidence_digest);

CREATE OR REPLACE FUNCTION public.record_ai_certification_journey(
  p_certification_run_id text, p_place_id text, p_route_ref text, p_geo_ref text,
  p_release_id text, p_commit_sha text, p_environment_id text, p_config_hash text,
  p_evidence_digest text, p_dry_run boolean DEFAULT true
) RETURNS public.ai_certification_journey_runs
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE r public.ai_certification_journey_runs;
BEGIN
  IF p_certification_run_id IS NULL OR p_release_id IS NULL OR p_commit_sha IS NULL OR
     p_environment_id IS NULL OR p_config_hash IS NULL OR p_evidence_digest IS NULL THEN
    RAISE EXCEPTION 'missing certification identity';
  END IF;
  INSERT INTO public.ai_certification_journey_runs
    (certification_run_id,place_id,route_ref,geo_ref,dry_run,release_id,commit_sha,environment_id,config_hash,evidence_digest)
  VALUES
    (p_certification_run_id,p_place_id,p_route_ref,p_geo_ref,p_dry_run,p_release_id,p_commit_sha,p_environment_id,p_config_hash,p_evidence_digest)
  RETURNING * INTO r;
  RETURN r;
END $$;
REVOKE ALL ON FUNCTION public.record_ai_certification_journey(text,text,text,text,text,text,text,text,text,boolean) FROM PUBLIC, anon, authenticated;
-- Grant EXECUTE only to the dedicated certification DB role used to mint TAREEQ_JOURNEY_EVIDENCE_RPC_TOKEN.
