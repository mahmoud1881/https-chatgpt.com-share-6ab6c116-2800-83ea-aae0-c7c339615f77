BEGIN;
ALTER TABLE public.community_routes ALTER COLUMN user_id SET DEFAULT auth.uid();
-- Restrictive: additional permissive policies cannot bypass these invariants.
CREATE POLICY community_route_insert_integrity
ON public.community_routes AS RESTRICTIVE FOR INSERT TO authenticated
WITH CHECK (
  user_id = auth.uid()
  AND status = 'pending'
  AND confirmations = 0
);
COMMIT;
