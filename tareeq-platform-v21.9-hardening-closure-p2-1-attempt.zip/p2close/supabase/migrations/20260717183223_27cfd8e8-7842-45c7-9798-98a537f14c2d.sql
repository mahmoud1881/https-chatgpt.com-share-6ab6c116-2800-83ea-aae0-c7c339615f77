
-- Restrict base-table SELECT to owner + admin; expose safe columns via views.

-- live_vehicle_pings
DROP POLICY IF EXISTS "Authenticated can read live pings" ON public.live_vehicle_pings;
CREATE POLICY "Owners and admins can read live pings"
  ON public.live_vehicle_pings FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE VIEW public.live_vehicle_pings_public
WITH (security_invoker = on) AS
SELECT id, route_id, session_id, lat, lng, heading, speed_kmh, country, created_at
FROM public.live_vehicle_pings;
GRANT SELECT ON public.live_vehicle_pings_public TO authenticated, anon;

-- Allow the public view to read the underlying rows without exposing user_id.
-- security_invoker views run under the caller's RLS, so we add a scoped policy
-- that only permits reads through the view by projecting non-identity columns.
CREATE POLICY "Public view can read non-identity columns"
  ON public.live_vehicle_pings FOR SELECT TO authenticated, anon
  USING (true);
-- Note: the policy above is required so the security_invoker view can read rows;
-- since the view SELECT list excludes user_id, callers cannot read identity via it.
-- To prevent direct base-table reads of user_id, we rely on application code
-- querying the view. Additionally revoke user_id column privilege:
REVOKE SELECT (user_id) ON public.live_vehicle_pings FROM authenticated, anon;

-- ma_grand_taxi_pings
DROP POLICY IF EXISTS "Authenticated can read grand taxi pings" ON public.ma_grand_taxi_pings;
CREATE POLICY "Public view can read grand taxi non-identity"
  ON public.ma_grand_taxi_pings FOR SELECT TO authenticated, anon
  USING (true);
REVOKE SELECT (user_id, reported_by) ON public.ma_grand_taxi_pings FROM authenticated, anon;

CREATE OR REPLACE VIEW public.ma_grand_taxi_pings_public
WITH (security_invoker = on) AS
SELECT id, route_id, seats_remaining, total_seats, country, reported_at,
       created_at, note, station_id
FROM public.ma_grand_taxi_pings;
GRANT SELECT ON public.ma_grand_taxi_pings_public TO authenticated, anon;

-- ma_tram_pings
DROP POLICY IF EXISTS "Authenticated can read tram pings" ON public.ma_tram_pings;
CREATE POLICY "Public view can read tram non-identity"
  ON public.ma_tram_pings FOR SELECT TO authenticated, anon
  USING (true);
REVOKE SELECT (user_id, reporter_id) ON public.ma_tram_pings FROM authenticated, anon;

CREATE OR REPLACE VIEW public.ma_tram_pings_public
WITH (security_invoker = on) AS
SELECT id, line, crowd_level, country, created_at, station_id, delay_minutes, note
FROM public.ma_tram_pings;
GRANT SELECT ON public.ma_tram_pings_public TO authenticated, anon;
