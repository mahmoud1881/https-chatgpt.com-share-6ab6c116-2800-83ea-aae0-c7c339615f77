-- v20.6: close PostgreSQL's implicit PUBLIC EXECUTE path for SECURITY DEFINER
-- routines and pin their lookup path. Explicit anon/authenticated/service_role
-- grants from earlier migrations remain authoritative.
DO $hardening$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS sig
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.prosecdef
  LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC', r.sig);
    EXECUTE format('ALTER FUNCTION %s SET search_path = public, pg_temp', r.sig);
  END LOOP;
END
$hardening$;
