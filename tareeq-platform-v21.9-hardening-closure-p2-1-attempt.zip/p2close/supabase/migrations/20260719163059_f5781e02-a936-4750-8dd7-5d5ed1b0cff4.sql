
-- Trigram index for ILIKE '%...%' on stop_aliases.normalized_alias
CREATE INDEX IF NOT EXISTS stop_aliases_normalized_trgm
  ON public.stop_aliases USING gin (normalized_alias gin_trgm_ops);

-- Drop duplicate index on route_stops(stop_id) — keep route_stops_stop_idx
DROP INDEX IF EXISTS public.idx_route_stops_stop_id;

-- Drop duplicate unique index on stops(country, coalesce(city,''), normalized_name)
-- keep the NULLS NOT DISTINCT variant which is stricter
DROP INDEX IF EXISTS public.stops_country_city_normalized_uniq;

-- Drop redundant plain btree on country,city (kept idx_stops_country_city)
DROP INDEX IF EXISTS public.stops_country_city_idx;

ANALYZE public.stop_aliases;
ANALYZE public.route_stops;
ANALYZE public.stops;
