-- Add missing columns
ALTER TABLE public.traffic_reports ADD COLUMN IF NOT EXISTS notes text;
ALTER TABLE public.traffic_reports ADD COLUMN IF NOT EXISTS expires_at timestamptz;
ALTER TABLE public.ma_grand_taxi_pings ADD COLUMN IF NOT EXISTS note text;
ALTER TABLE public.ma_tram_pings ADD COLUMN IF NOT EXISTS station_id text;
ALTER TABLE public.ma_tram_pings ADD COLUMN IF NOT EXISTS reporter_id text;
-- crowd_level in ma_tram_pings was text but code inserts number; change to int
ALTER TABLE public.ma_tram_pings ALTER COLUMN crowd_level TYPE int USING NULLIF(crowd_level, '')::int;

-- Tighten always-true INSERT policies
DROP POLICY IF EXISTS "signed-in can post pings" ON public.live_vehicle_pings;
CREATE POLICY "signed-in can post pings" ON public.live_vehicle_pings
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "signed-in can post tram pings" ON public.ma_tram_pings;
CREATE POLICY "signed-in can post tram pings" ON public.ma_tram_pings
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "signed-in can post grand taxi pings" ON public.ma_grand_taxi_pings;
CREATE POLICY "signed-in can post grand taxi pings" ON public.ma_grand_taxi_pings
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);