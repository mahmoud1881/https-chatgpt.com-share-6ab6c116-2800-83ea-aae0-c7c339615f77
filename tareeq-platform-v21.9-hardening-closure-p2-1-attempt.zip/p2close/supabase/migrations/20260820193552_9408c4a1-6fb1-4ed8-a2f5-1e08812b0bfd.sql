-- 1) Hide the account-identifying user_id column from community reads
REVOKE SELECT ON public.community_questions FROM anon, authenticated;
REVOKE SELECT ON public.community_answers FROM anon, authenticated;
REVOKE SELECT ON public.community_routes FROM anon, authenticated;

GRANT SELECT (id, title, body, author_name, answers_count, country, created_at)
  ON public.community_questions TO authenticated;
GRANT SELECT (id, question_id, body, author_name, country, created_at)
  ON public.community_answers TO authenticated;
GRANT SELECT (id, title, from_area, to_area, price_egp, duration_min, status, confirmations, country, created_at, provenance)
  ON public.community_routes TO authenticated;

GRANT ALL ON public.community_questions TO service_role;
GRANT ALL ON public.community_answers TO service_role;
GRANT ALL ON public.community_routes TO service_role;

-- 2) Standardize tram ping ownership checks on the uuid user_id column
UPDATE public.ma_tram_pings
SET user_id = reporter_id::uuid
WHERE user_id IS NULL
  AND reporter_id ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$';

DROP POLICY IF EXISTS "Reporters and admins can read tram pings" ON public.ma_tram_pings;
CREATE POLICY "Reporters and admins can read tram pings"
  ON public.ma_tram_pings FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'::app_role));