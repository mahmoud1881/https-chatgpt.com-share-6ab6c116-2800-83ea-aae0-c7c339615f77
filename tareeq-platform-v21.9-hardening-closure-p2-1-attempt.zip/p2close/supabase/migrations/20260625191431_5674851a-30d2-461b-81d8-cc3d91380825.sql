
ALTER TABLE public.traffic_reports        ADD COLUMN IF NOT EXISTS country text NOT NULL DEFAULT 'eg';
ALTER TABLE public.community_questions    ADD COLUMN IF NOT EXISTS country text NOT NULL DEFAULT 'eg';
ALTER TABLE public.community_answers      ADD COLUMN IF NOT EXISTS country text NOT NULL DEFAULT 'eg';
ALTER TABLE public.community_routes       ADD COLUMN IF NOT EXISTS country text NOT NULL DEFAULT 'eg';
ALTER TABLE public.community_route_votes  ADD COLUMN IF NOT EXISTS country text NOT NULL DEFAULT 'eg';
ALTER TABLE public.live_vehicle_pings     ADD COLUMN IF NOT EXISTS country text NOT NULL DEFAULT 'eg';
ALTER TABLE public.user_stations          ADD COLUMN IF NOT EXISTS country text NOT NULL DEFAULT 'eg';

CREATE INDEX IF NOT EXISTS idx_traffic_reports_country       ON public.traffic_reports(country);
CREATE INDEX IF NOT EXISTS idx_community_questions_country   ON public.community_questions(country);
CREATE INDEX IF NOT EXISTS idx_community_routes_country      ON public.community_routes(country);
CREATE INDEX IF NOT EXISTS idx_live_vehicle_pings_country    ON public.live_vehicle_pings(country);
CREATE INDEX IF NOT EXISTS idx_user_stations_country         ON public.user_stations(country);
