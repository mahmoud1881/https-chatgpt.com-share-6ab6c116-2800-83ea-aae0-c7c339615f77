
DO $$
BEGIN
  BEGIN ALTER TABLE public.community_questions ADD CONSTRAINT community_questions_title_len CHECK (char_length(title) BETWEEN 3 AND 200); EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER TABLE public.community_questions ADD CONSTRAINT community_questions_body_len  CHECK (body IS NULL OR char_length(body) <= 2000); EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER TABLE public.community_questions ADD CONSTRAINT community_questions_author_len CHECK (author_name IS NULL OR char_length(author_name) <= 60); EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER TABLE public.community_answers   ADD CONSTRAINT community_answers_body_len    CHECK (char_length(body) BETWEEN 1 AND 2000); EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER TABLE public.community_answers   ADD CONSTRAINT community_answers_author_len  CHECK (author_name IS NULL OR char_length(author_name) <= 60); EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER TABLE public.traffic_reports     ADD CONSTRAINT traffic_reports_notes_len     CHECK (notes IS NULL OR char_length(notes) <= 500); EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER TABLE public.traffic_reports     ADD CONSTRAINT traffic_reports_severity_chk  CHECK (severity IN ('low','medium','high')); EXCEPTION WHEN duplicate_object THEN NULL; END;
END $$;

CREATE OR REPLACE FUNCTION public.traffic_reports_rate_limit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE same_area_recent INT; global_recent INT;
BEGIN
  SELECT count(*) INTO same_area_recent FROM public.traffic_reports
   WHERE lower(area)=lower(NEW.area) AND created_at > now() - interval '30 seconds';
  IF same_area_recent >= 1 THEN
    RAISE EXCEPTION 'rate_limit: same area reported too recently (wait 30s)';
  END IF;
  SELECT count(*) INTO global_recent FROM public.traffic_reports
   WHERE created_at > now() - interval '1 minute';
  IF global_recent >= 30 THEN
    RAISE EXCEPTION 'rate_limit: too many reports this minute';
  END IF;
  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.traffic_reports_rate_limit() FROM PUBLIC;

DROP TRIGGER IF EXISTS trg_traffic_reports_rate_limit ON public.traffic_reports;
CREATE TRIGGER trg_traffic_reports_rate_limit
BEFORE INSERT ON public.traffic_reports
FOR EACH ROW EXECUTE FUNCTION public.traffic_reports_rate_limit();

CREATE INDEX IF NOT EXISTS idx_traffic_reports_area_created
  ON public.traffic_reports (lower(area), created_at DESC);
