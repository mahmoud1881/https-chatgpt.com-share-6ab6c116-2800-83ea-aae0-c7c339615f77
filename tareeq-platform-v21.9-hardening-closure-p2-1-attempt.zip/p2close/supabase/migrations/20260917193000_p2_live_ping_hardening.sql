-- P2: harden live location writes against malformed/replayed client timestamps.
-- The public view already hides user identity; this migration adds server-side
-- validation and makes created_at authoritative.

CREATE OR REPLACE FUNCTION public.harden_live_vehicle_ping()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.lat IS NULL OR NEW.lng IS NULL
     OR NEW.lat < -90 OR NEW.lat > 90
     OR NEW.lng < -180 OR NEW.lng > 180 THEN
    RAISE EXCEPTION 'invalid coordinates';
  END IF;

  IF NEW.heading IS NOT NULL AND (NEW.heading < 0 OR NEW.heading >= 360) THEN
    RAISE EXCEPTION 'invalid heading';
  END IF;

  IF NEW.speed_kmh IS NOT NULL AND (NEW.speed_kmh < 0 OR NEW.speed_kmh > 250) THEN
    RAISE EXCEPTION 'invalid speed';
  END IF;

  IF NEW.session_id IS NULL OR length(trim(NEW.session_id)) < 8 OR length(NEW.session_id) > 128 THEN
    RAISE EXCEPTION 'invalid session id';
  END IF;

  -- Never trust a browser-supplied event timestamp.
  NEW.created_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_harden_live_vehicle_ping ON public.live_vehicle_pings;
CREATE TRIGGER trg_harden_live_vehicle_ping
BEFORE INSERT ON public.live_vehicle_pings
FOR EACH ROW EXECUTE FUNCTION public.harden_live_vehicle_ping();

CREATE INDEX IF NOT EXISTS idx_live_vehicle_pings_route_created
  ON public.live_vehicle_pings(route_id, created_at DESC);

-- Keep stale tracking data bounded; this is intentionally conservative and
-- only removes records older than 24 hours when the function is invoked.
CREATE OR REPLACE FUNCTION public.cleanup_stale_live_vehicle_pings()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE deleted_count integer;
BEGIN
  DELETE FROM public.live_vehicle_pings WHERE created_at < now() - interval '24 hours';
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$;

REVOKE ALL ON FUNCTION public.cleanup_stale_live_vehicle_pings() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cleanup_stale_live_vehicle_pings() TO service_role;
