REVOKE ALL ON FUNCTION public.bulk_update_stop_embeddings(jsonb) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.bulk_update_stop_embeddings(jsonb) FROM anon, authenticated;
GRANT EXECUTE ON FUNCTION public.bulk_update_stop_embeddings(jsonb) TO service_role;