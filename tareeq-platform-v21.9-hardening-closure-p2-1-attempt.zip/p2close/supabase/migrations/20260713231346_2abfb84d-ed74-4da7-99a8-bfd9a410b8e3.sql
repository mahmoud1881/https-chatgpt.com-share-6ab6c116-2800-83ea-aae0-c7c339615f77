
-- 1) train_lines
CREATE TABLE public.train_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name_ar text NOT NULL,
  name_en text,
  from_city text NOT NULL,
  to_city text NOT NULL,
  image_path text,
  description text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.train_lines TO anon, authenticated;
GRANT ALL ON public.train_lines TO service_role;
ALTER TABLE public.train_lines ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read train_lines" ON public.train_lines FOR SELECT USING (true);
CREATE POLICY "admin manage train_lines" ON public.train_lines FOR ALL
  USING (public.has_role(auth.uid(),'admin'))
  WITH CHECK (public.has_role(auth.uid(),'admin'));

-- 2) train_line_stations (ordered stations along a line)
CREATE TABLE public.train_line_stations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  line_id uuid NOT NULL REFERENCES public.train_lines(id) ON DELETE CASCADE,
  station_name text NOT NULL,
  station_name_en text,
  city text,
  sort_order int NOT NULL,
  is_major boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (line_id, sort_order)
);
CREATE INDEX ON public.train_line_stations (line_id);
CREATE INDEX ON public.train_line_stations (station_name);
GRANT SELECT ON public.train_line_stations TO anon, authenticated;
GRANT ALL ON public.train_line_stations TO service_role;
ALTER TABLE public.train_line_stations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read train_line_stations" ON public.train_line_stations FOR SELECT USING (true);
CREATE POLICY "admin manage train_line_stations" ON public.train_line_stations FOR ALL
  USING (public.has_role(auth.uid(),'admin'))
  WITH CHECK (public.has_role(auth.uid(),'admin'));

-- 3) trains
CREATE TABLE public.trains (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  line_id uuid NOT NULL REFERENCES public.train_lines(id) ON DELETE CASCADE,
  train_number text NOT NULL,
  train_type text NOT NULL,
  direction text NOT NULL DEFAULT 'forward',
  departure_time time,
  arrival_time time,
  duration_minutes int,
  stops_count int,
  runs_days text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (line_id, train_number, direction)
);
CREATE INDEX ON public.trains (line_id);
CREATE INDEX ON public.trains (train_number);
GRANT SELECT ON public.trains TO anon, authenticated;
GRANT ALL ON public.trains TO service_role;
ALTER TABLE public.trains ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read trains" ON public.trains FOR SELECT USING (true);
CREATE POLICY "admin manage trains" ON public.trains FOR ALL
  USING (public.has_role(auth.uid(),'admin'))
  WITH CHECK (public.has_role(auth.uid(),'admin'));

-- 4) train_schedule (per-stop timing for a train)
CREATE TABLE public.train_schedule (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  train_id uuid NOT NULL REFERENCES public.trains(id) ON DELETE CASCADE,
  station_name text NOT NULL,
  sort_order int NOT NULL,
  arrival_time time,
  departure_time time,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (train_id, sort_order)
);
CREATE INDEX ON public.train_schedule (train_id);
CREATE INDEX ON public.train_schedule (station_name);
GRANT SELECT ON public.train_schedule TO anon, authenticated;
GRANT ALL ON public.train_schedule TO service_role;
ALTER TABLE public.train_schedule ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read train_schedule" ON public.train_schedule FOR SELECT USING (true);
CREATE POLICY "admin manage train_schedule" ON public.train_schedule FOR ALL
  USING (public.has_role(auth.uid(),'admin'))
  WITH CHECK (public.has_role(auth.uid(),'admin'));

-- updated_at triggers
CREATE TRIGGER trg_train_lines_updated BEFORE UPDATE ON public.train_lines
  FOR EACH ROW EXECUTE FUNCTION public.tg_touch_updated_at();
CREATE TRIGGER trg_trains_updated BEFORE UPDATE ON public.trains
  FOR EACH ROW EXECUTE FUNCTION public.tg_touch_updated_at();
