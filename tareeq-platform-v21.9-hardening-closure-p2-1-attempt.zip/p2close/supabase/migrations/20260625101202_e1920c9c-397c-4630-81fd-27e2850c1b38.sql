DROP POLICY "Anyone can submit a traffic report" ON public.traffic_reports;

CREATE POLICY "Anyone can submit a valid traffic report"
  ON public.traffic_reports FOR INSERT
  WITH CHECK (
    severity IN ('clear','medium','heavy','stuck')
    AND char_length(area) BETWEEN 1 AND 120
    AND (notes IS NULL OR char_length(notes) <= 280)
    AND expires_at > now()
    AND expires_at <= (now() + interval '6 hours')
  );