
-- Scope owner/admin policies to the authenticated role for defense-in-depth.
-- missing_searches INSERT stays open to public because anonymous search logging is allowed (user_id may be NULL).

-- user_route_suggestions
DROP POLICY IF EXISTS "user_route_suggestions owner read" ON public.user_route_suggestions;
DROP POLICY IF EXISTS "user_route_suggestions insert" ON public.user_route_suggestions;
DROP POLICY IF EXISTS "user_route_suggestions admin update" ON public.user_route_suggestions;
CREATE POLICY "user_route_suggestions owner read" ON public.user_route_suggestions FOR SELECT TO authenticated USING ((auth.uid() = user_id) OR has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "user_route_suggestions insert" ON public.user_route_suggestions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "user_route_suggestions admin update" ON public.user_route_suggestions FOR UPDATE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- alias_suggestions
DROP POLICY IF EXISTS "alias_suggestions owner read" ON public.alias_suggestions;
DROP POLICY IF EXISTS "alias_suggestions insert" ON public.alias_suggestions;
DROP POLICY IF EXISTS "alias_suggestions admin update" ON public.alias_suggestions;
CREATE POLICY "alias_suggestions owner read" ON public.alias_suggestions FOR SELECT TO authenticated USING ((auth.uid() = user_id) OR has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "alias_suggestions insert" ON public.alias_suggestions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "alias_suggestions admin update" ON public.alias_suggestions FOR UPDATE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- route_corrections
DROP POLICY IF EXISTS "route_corrections owner read" ON public.route_corrections;
DROP POLICY IF EXISTS "route_corrections insert" ON public.route_corrections;
DROP POLICY IF EXISTS "route_corrections admin update" ON public.route_corrections;
CREATE POLICY "route_corrections owner read" ON public.route_corrections FOR SELECT TO authenticated USING ((auth.uid() = user_id) OR has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "route_corrections insert" ON public.route_corrections FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "route_corrections admin update" ON public.route_corrections FOR UPDATE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- missing_searches (SELECT + UPDATE scoped to authenticated; INSERT stays open for anon logging)
DROP POLICY IF EXISTS "missing_searches admin read" ON public.missing_searches;
DROP POLICY IF EXISTS "missing_searches admin update" ON public.missing_searches;
CREATE POLICY "missing_searches admin read" ON public.missing_searches FOR SELECT TO authenticated USING (has_role(auth.uid(), 'admin'::app_role) OR (auth.uid() = user_id));
CREATE POLICY "missing_searches admin update" ON public.missing_searches FOR UPDATE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
