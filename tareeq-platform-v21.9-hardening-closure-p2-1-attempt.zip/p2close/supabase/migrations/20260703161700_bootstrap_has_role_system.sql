-- ============================================================================
-- Bootstrap the admin-role system: app_role, user_roles, has_role().
--
-- 20 migrations (starting with 20260703161744, the very next file
-- chronologically) call public.has_role(uuid, app_role), GRANT/REVOKE
-- EXECUTE on it, or reference app_role directly — but none of them, nor any
-- earlier migration, ever creates the enum, the backing table, or the
-- function. `supabase db reset` against a genuinely empty database fails at
-- 20260703161744's `REVOKE EXECUTE ON FUNCTION public.has_role(uuid,
-- app_role) ...` with "function does not exist", before that migration
-- does anything else.
--
-- This is the same class of gap as 20260708000000_bootstrap_admin_config
-- (an object created directly in Supabase Studio's SQL editor during early
-- development, never captured as a migration) — except this one is far
-- more central: has_role() gates /admin/* and dozens of RLS policies
-- across routes/stops/trains/community_routes/etc. A production database
-- keeps working today because the objects already exist there outside the
-- tracked history, but any true from-scratch replay (a new self-host
-- deploy, a new contributor's local Supabase, or CI's migrations-guard job
-- if it's ever actually run end-to-end) fails immediately here.
--
-- Shape reconstructed from src/integrations/supabase/types.ts — the only
-- remaining source of truth for the real, currently-running schema:
--   Enums.app_role = "admin" | "moderator" | "user"
--   user_roles.Row = { id, user_id, role, created_at }
--   has_role.Args = { _user_id: string, _role: app_role }, Returns: boolean
-- SECURITY DEFINER is required (not just reconstructed convention): this is
-- Supabase's own documented pattern for role-checks inside RLS policies —
-- an RLS policy on user_roles that queries user_roles itself would recurse
-- infinitely, so the check has to happen in a function that bypasses RLS.
-- ============================================================================

DO $$ BEGIN
  CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

CREATE TABLE IF NOT EXISTS public.user_roles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT user_roles_user_id_role_key UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles FORCE ROW LEVEL SECURITY;

-- Only has_role() (SECURITY DEFINER below) and service_role ever need to
-- read/write this table directly; app code always goes through has_role().
REVOKE ALL ON public.user_roles FROM PUBLIC, anon, authenticated;
GRANT ALL ON public.user_roles TO service_role;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  );
$$;

-- 20260703161744 immediately does its own REVOKE/GRANT on this exact
-- signature right after; granting to authenticated here too so this
-- migration is independently correct even if run in isolation.
REVOKE ALL ON FUNCTION public.has_role(UUID, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(UUID, public.app_role) TO authenticated, service_role;

-- ----------------------------------------------------------------------------
-- This bootstrap cannot know who your admins actually are — that
-- information only ever existed in the untracked production database.
-- Seed at least one admin manually after this migration runs on a fresh
-- database, e.g.:
--   insert into public.user_roles (user_id, role)
--   values ('<your-auth-user-uuid>', 'admin');
-- Without this, every /admin/* route and every has_role()-gated policy
-- will correctly deny everyone — safe by default, but yields a database
-- with no way to log into the admin panel until seeded.
-- ----------------------------------------------------------------------------
