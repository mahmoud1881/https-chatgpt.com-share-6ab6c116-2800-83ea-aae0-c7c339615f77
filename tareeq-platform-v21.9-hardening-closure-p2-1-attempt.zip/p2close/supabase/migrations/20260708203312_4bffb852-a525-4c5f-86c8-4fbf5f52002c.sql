
-- Add plain-column unique constraints (NULLS NOT DISTINCT) that match the
-- onConflict targets used by importEgyptFile. The existing expression indexes
-- on COALESCE(city, '') cannot be referenced by PostgREST/PostgREST upsert,
-- which caused every import to abort with SQLSTATE 42P10.

-- stops: (country, city, normalized_name)
ALTER TABLE public.stops
  ADD CONSTRAINT stops_country_city_normname_ndistinct_uniq
  UNIQUE NULLS NOT DISTINCT (country, city, normalized_name);

-- routes: (country, city, route_code)
ALTER TABLE public.routes
  ADD CONSTRAINT routes_country_city_code_ndistinct_uniq
  UNIQUE NULLS NOT DISTINCT (country, city, route_code);
