-- 1) Tighten community_routes INSERT policy: only allow 'pending' on insert
DROP POLICY IF EXISTS "anyone can insert pending route" ON public.community_routes;
DROP POLICY IF EXISTS "Anyone can insert pending route" ON public.community_routes;
DROP POLICY IF EXISTS "community_routes_insert" ON public.community_routes;
DROP POLICY IF EXISTS "Insert community routes" ON public.community_routes;

CREATE POLICY "Insert community routes as pending only"
ON public.community_routes
FOR INSERT
TO authenticated, anon
WITH CHECK (status = 'pending');

-- 2) Lock down SECURITY DEFINER functions: revoke from PUBLIC, grant to intended roles only
REVOKE EXECUTE ON FUNCTION public.confirm_community_route(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.confirm_community_route(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.bump_answers_count() FROM PUBLIC;
-- bump_answers_count is a trigger function; no role needs EXECUTE

REVOKE EXECUTE ON FUNCTION public.traffic_reports_rate_limit() FROM PUBLIC;
-- traffic_reports_rate_limit is a trigger function; no role needs EXECUTE
