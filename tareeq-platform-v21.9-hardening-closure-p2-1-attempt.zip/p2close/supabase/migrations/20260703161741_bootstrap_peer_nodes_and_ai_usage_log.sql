-- ============================================================================
-- المرحلة 2 من علاج فجوات الـ bootstrap
--
-- جدولان تشير إليهما migrations لاحقة (GRANT/POLICY/VIEW) لكن لا يُنشئهما أي
-- ملف في السلسلة — نفس نمط has_role/user_stations: أُنشئا يدويًا في Supabase
-- Studio ولم يُلتقطا قط كـ migration. أي نشر من الصفر يتوقف عندهما.
--
-- الأعمدة هنا ليست تخمينًا: منسوخة حرفيًا من
-- src/integrations/supabase/types.ts، وهو مولَّد آليًا من قاعدة الإنتاج
-- الفعلية، فهو أدق مصدر متاح لشكلهما الحقيقي.
--
-- IF NOT EXISTS مقصودة: البيئات القائمة (الإنتاج الحالي) لديها الجدولان
-- بالفعل، فتتجاوزهما بلا أثر؛ والبيئات الجديدة تنشئهما.
-- ============================================================================

CREATE TABLE IF NOT EXISTS public.peer_nodes (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  peer_id         text NOT NULL,
  tier            text NOT NULL,
  models          text[] NOT NULL DEFAULT '{}',
  region          text,
  is_available     boolean NOT NULL DEFAULT false,
  requests_served  integer NOT NULL DEFAULT 0,
  last_seen_at     timestamptz NOT NULL DEFAULT now(),
  created_at       timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.peer_nodes ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.peer_nodes TO authenticated;
GRANT ALL ON public.peer_nodes TO service_role;

-- سياسة المالك فقط. 20260708184057 يعيد تعريف سياسة SELECT لاحقًا
-- (read own peer) — وهو ما يقصده فعلًا، فنترك هذه للكتابة فقط حتى لا
-- نتعارض معه.
DROP POLICY IF EXISTS "manage own peer node" ON public.peer_nodes;
CREATE POLICY "manage own peer node" ON public.peer_nodes
  FOR ALL TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS public.ai_usage_log (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  model             text NOT NULL,
  operation         text NOT NULL,
  prompt_tokens     integer NOT NULL DEFAULT 0,
  completion_tokens integer NOT NULL DEFAULT 0,
  cached_tokens     integer NOT NULL DEFAULT 0,
  total_tokens      integer NOT NULL DEFAULT 0,
  cache_hit         boolean NOT NULL DEFAULT false,
  duration_ms       integer,
  status            text NOT NULL DEFAULT 'ok',
  created_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ai_usage_log_created_at_idx ON public.ai_usage_log (created_at DESC);
CREATE INDEX IF NOT EXISTS ai_usage_log_user_idx       ON public.ai_usage_log (user_id, created_at DESC);

-- سجل استهلاك داخلي: لا قراءة ولا كتابة مباشرة من المتصفح إطلاقًا.
-- الكتابة تمر حصريًا عبر log_ai_usage() (SECURITY DEFINER)، والقراءة عبر
-- لوحة الإدارة. RLS مفعّلة بلا أي سياسة = مغلق تمامًا لغير service_role.
ALTER TABLE public.ai_usage_log ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.ai_usage_log FROM PUBLIC, anon, authenticated;
GRANT ALL ON public.ai_usage_log TO service_role;
