
DROP POLICY IF EXISTS "anyone can confirm community routes" ON public.community_routes;
REVOKE UPDATE ON public.community_routes FROM anon, authenticated;

CREATE OR REPLACE FUNCTION public.confirm_community_route(route_id uuid)
RETURNS public.community_routes
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updated public.community_routes;
BEGIN
  UPDATE public.community_routes
     SET confirmations = LEAST(confirmations + 1, 10000),
         status = CASE WHEN confirmations + 1 >= 5 THEN 'confirmed' ELSE status END
   WHERE id = route_id
  RETURNING * INTO updated;
  RETURN updated;
END;
$$;

GRANT EXECUTE ON FUNCTION public.confirm_community_route(uuid) TO anon, authenticated;
