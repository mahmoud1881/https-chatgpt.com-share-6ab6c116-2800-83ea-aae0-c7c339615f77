-- 1. Remove the overly broad public read policy on traffic_reports
DROP POLICY IF EXISTS "Anyone can read anonymized traffic reports" ON public.traffic_reports;

-- Revoke any direct column privileges granted to public roles on the base table
REVOKE ALL ON public.traffic_reports FROM anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.traffic_reports TO authenticated;
GRANT ALL ON public.traffic_reports TO service_role;

-- 2. Anonymized public view: no user_id, no precise lat/lng
DROP VIEW IF EXISTS public.traffic_reports_public;
CREATE VIEW public.traffic_reports_public AS
SELECT
  id,
  area,
  severity,
  notes,
  country,
  lat_coarse,
  lng_coarse,
  created_at,
  expires_at
FROM public.traffic_reports;

GRANT SELECT ON public.traffic_reports_public TO anon, authenticated;
