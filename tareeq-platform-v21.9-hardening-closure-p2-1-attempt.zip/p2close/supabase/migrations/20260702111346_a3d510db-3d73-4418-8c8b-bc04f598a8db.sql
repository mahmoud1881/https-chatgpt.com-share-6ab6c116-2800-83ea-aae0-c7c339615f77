-- Drop the security-definer views created in the prior migration
DROP VIEW IF EXISTS public.live_vehicle_pings_public;
DROP VIEW IF EXISTS public.ma_grand_taxi_pings_public;
DROP VIEW IF EXISTS public.ma_tram_pings_public;
DROP VIEW IF EXISTS public.traffic_reports_public;
DROP VIEW IF EXISTS public.community_questions_public;
DROP VIEW IF EXISTS public.community_answers_public;
DROP VIEW IF EXISTS public.community_routes_public;

-- Restore permissive public SELECT policies (anon may read rows again)
-- but column privileges below prevent anon from reading identity columns.

-- live_vehicle_pings
DROP POLICY IF EXISTS "Owners can read own live pings" ON public.live_vehicle_pings;
CREATE POLICY "read live pings" ON public.live_vehicle_pings
  FOR SELECT TO anon, authenticated USING (true);

REVOKE SELECT ON public.live_vehicle_pings FROM anon;
GRANT SELECT (id, route_id, session_id, lat, lng, heading, speed_kmh, country, created_at)
  ON public.live_vehicle_pings TO anon;

-- ma_grand_taxi_pings
DROP POLICY IF EXISTS "Reporters can read own grand taxi pings" ON public.ma_grand_taxi_pings;
CREATE POLICY "read grand taxi pings" ON public.ma_grand_taxi_pings
  FOR SELECT TO anon, authenticated USING (true);

REVOKE SELECT ON public.ma_grand_taxi_pings FROM anon;
GRANT SELECT (id, route_id, seats_remaining, total_seats, note, station_id,
              country, reported_at, created_at)
  ON public.ma_grand_taxi_pings TO anon;

-- ma_tram_pings
DROP POLICY IF EXISTS "Reporters can read own tram pings" ON public.ma_tram_pings;
CREATE POLICY "read tram pings" ON public.ma_tram_pings
  FOR SELECT TO anon, authenticated USING (true);

REVOKE SELECT ON public.ma_tram_pings FROM anon;
GRANT SELECT (id, line, station_id, crowd_level, delay_minutes, note,
              country, created_at)
  ON public.ma_tram_pings TO anon;

-- traffic_reports
DROP POLICY IF EXISTS "Owners can read own traffic reports" ON public.traffic_reports;
CREATE POLICY "read traffic reports" ON public.traffic_reports
  FOR SELECT TO anon, authenticated USING (true);

REVOKE SELECT ON public.traffic_reports FROM anon;
GRANT SELECT (id, area, severity, lat, lng, notes, country, created_at, expires_at)
  ON public.traffic_reports TO anon;

-- community_questions
DROP POLICY IF EXISTS "Owners can read own questions" ON public.community_questions;
CREATE POLICY "read all questions" ON public.community_questions
  FOR SELECT TO anon, authenticated USING (true);

REVOKE SELECT ON public.community_questions FROM anon;
GRANT SELECT (id, title, body, author_name, answers_count, country, created_at)
  ON public.community_questions TO anon;

-- community_answers
DROP POLICY IF EXISTS "Owners can read own answers" ON public.community_answers;
CREATE POLICY "read all answers" ON public.community_answers
  FOR SELECT TO anon, authenticated USING (true);

REVOKE SELECT ON public.community_answers FROM anon;
GRANT SELECT (id, question_id, body, author_name, country, created_at)
  ON public.community_answers TO anon;

-- community_routes
DROP POLICY IF EXISTS "Owners can read own community routes" ON public.community_routes;
CREATE POLICY "read all community routes" ON public.community_routes
  FOR SELECT TO anon, authenticated USING (true);

REVOKE SELECT ON public.community_routes FROM anon;
GRANT SELECT (id, title, from_area, to_area, price_egp, duration_min,
              status, confirmations, country, created_at)
  ON public.community_routes TO anon;
