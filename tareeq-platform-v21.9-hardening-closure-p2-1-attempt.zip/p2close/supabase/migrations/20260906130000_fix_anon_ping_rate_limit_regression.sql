-- ============================================================================
-- Fix a regression in 20260906120000_rate_limit_client_direct_inserts.sql.
--
-- That migration's comment claims: "Both require `authenticated`, so
-- auth.uid() is a solid, unspoofable identifier". True for traffic_reports
-- and community_routes, but FALSE for live_vehicle_pings:
--
--   - 20260625141142 created live_vehicle_pings with an unrestricted
--     "anyone can insert pings" INSERT policy (no `TO <role>` clause, so it
--     applies to PUBLIC — anon included) plus `GRANT INSERT ... TO anon`.
--     Neither was ever dropped or revoked by any later migration.
--   - 20260702103316 later added a second, narrower INSERT policy
--     ("signed-in can post pings", TO authenticated) — but PostgreSQL RLS
--     combines multiple PERMISSIVE policies with OR. Adding a stricter
--     policy alongside an existing permissive one does not narrow access;
--     the original unrestricted policy still allows anon inserts today.
--   - src/lib/transit/live-tracking.ts confirms this is intentional design,
--     not an oversight: "مشاركة opt-in فقط... session_id عشوائي مجهول"
--     (opt-in sharing, anonymous random session_id) — no auth gate before
--     sending a ping; `user_id` is set from `supabase.auth.getUser()` only
--     when a session happens to exist, and is null otherwise.
--
-- enforce_rate_limit() reading auth.uid() internally and raising
-- 'auth_required' when it's null therefore breaks live location sharing
-- for every anonymous user, immediately upon this migration applying —
-- the exact audience the feature was built for.
--
-- Fix: enforce_rate_limit() takes an explicit identifier instead of
-- deriving one internally. Each trigger passes what's actually correct for
-- its table: auth.uid() for the two auth-required tables, and
-- COALESCE(auth.uid(), session_id) for live_vehicle_pings — real rate
-- limiting either way, without requiring a login the feature never asked
-- for. A ping row's session_id is still attacker-controlled (any client
-- can generate a fresh one to reset its own limit), but that's no weaker
-- than the anonymous design already accepted at the RLS/GRANT level above;
-- this trigger's job is to stop a runaway loop/bot on one session, not to
-- provide identity assurance the table was never designed to have.
-- ============================================================================

DROP FUNCTION IF EXISTS public.enforce_rate_limit(text, integer, interval);

CREATE OR REPLACE FUNCTION public.enforce_rate_limit(
  p_bucket text,
  p_identifier text,
  p_max_count integer,
  p_window interval
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_count integer;
BEGIN
  IF p_identifier IS NULL OR p_identifier = '' THEN
    RAISE EXCEPTION 'identifier_required: rate limiting requires a non-empty identifier';
  END IF;

  DELETE FROM public.rate_limit_events
   WHERE bucket = p_bucket
     AND identifier = p_identifier
     AND created_at < now() - p_window;

  SELECT count(*) INTO v_count
    FROM public.rate_limit_events
   WHERE bucket = p_bucket
     AND identifier = p_identifier
     AND created_at >= now() - p_window;

  IF v_count >= p_max_count THEN
    RAISE EXCEPTION 'rate_limited: too many "%" actions, try again later', p_bucket;
  END IF;

  INSERT INTO public.rate_limit_events (bucket, identifier) VALUES (p_bucket, p_identifier);
END;
$$;

REVOKE ALL ON FUNCTION public.enforce_rate_limit(text, text, integer, interval) FROM PUBLIC, anon, authenticated;

-- --- traffic_reports: authenticated-only table, identifier unchanged ---
CREATE OR REPLACE FUNCTION public.rl_traffic_reports() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.enforce_rate_limit('traffic_reports', auth.uid()::text, 20, interval '10 minutes');
  RETURN NEW;
END;
$$;

-- --- live_vehicle_pings: anonymous-friendly by design — fall back to the
-- ping's own session_id when there's no signed-in user ---
CREATE OR REPLACE FUNCTION public.rl_live_vehicle_pings() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.enforce_rate_limit(
    'live_vehicle_pings',
    COALESCE(auth.uid()::text, NEW.session_id),
    40,
    interval '60 seconds'
  );
  RETURN NEW;
END;
$$;

-- --- community_routes: authenticated-only table, identifier unchanged ---
CREATE OR REPLACE FUNCTION public.rl_community_routes_insert() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.enforce_rate_limit('community_routes_insert', auth.uid()::text, 10, interval '1 day');
  RETURN NEW;
END;
$$;

-- Triggers themselves are unchanged (same names, same tables, same timing)
-- — CREATE OR REPLACE FUNCTION above already updates what they run without
-- needing to DROP/CREATE the triggers again.
