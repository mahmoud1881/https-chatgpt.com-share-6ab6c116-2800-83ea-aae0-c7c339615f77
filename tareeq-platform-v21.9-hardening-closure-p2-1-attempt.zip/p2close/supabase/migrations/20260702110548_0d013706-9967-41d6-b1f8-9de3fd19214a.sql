-- Owner-scoped UPDATE/DELETE policies for ping/report tables

-- live_vehicle_pings (user_id)
CREATE POLICY "Users can update their own live vehicle pings"
  ON public.live_vehicle_pings FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own live vehicle pings"
  ON public.live_vehicle_pings FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- ma_grand_taxi_pings (reported_by)
CREATE POLICY "Reporters can update their own grand taxi pings"
  ON public.ma_grand_taxi_pings FOR UPDATE
  TO authenticated
  USING (auth.uid() = reported_by)
  WITH CHECK (auth.uid() = reported_by);

CREATE POLICY "Reporters can delete their own grand taxi pings"
  ON public.ma_grand_taxi_pings FOR DELETE
  TO authenticated
  USING (auth.uid() = reported_by);

-- ma_tram_pings (user_id)
CREATE POLICY "Users can update their own tram pings"
  ON public.ma_tram_pings FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own tram pings"
  ON public.ma_tram_pings FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- traffic_reports (user_id)
CREATE POLICY "Users can update their own traffic reports"
  ON public.traffic_reports FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own traffic reports"
  ON public.traffic_reports FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);
