ALTER TABLE public.community_answers ADD COLUMN IF NOT EXISTS country text;
ALTER TABLE public.ma_grand_taxi_pings ADD COLUMN IF NOT EXISTS station_id text;
ALTER TABLE public.ma_grand_taxi_pings ADD COLUMN IF NOT EXISTS reported_by uuid;
ALTER TABLE public.ma_tram_pings ADD COLUMN IF NOT EXISTS delay_minutes int;