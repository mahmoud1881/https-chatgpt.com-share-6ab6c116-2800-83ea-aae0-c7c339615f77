-- M12: جدول تجميع الحوادث القادمة من العميل عبر server function موثوق
CREATE TABLE IF NOT EXISTS public.api_incidents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  at timestamptz NOT NULL DEFAULT now(),
  source text NOT NULL,             -- مثال: 'metro-lines', 'trains', 'brt', 'stops'
  kind text NOT NULL,               -- 'api_error' | 'timeout' | 'unexpected_zero' | 'cache_fail' | 'js_error' | 'other'
  message text,
  url text,
  user_agent text,
  ip_hash text,                     -- تجزئة IP فقط (لا نُخزّن IP خام)
  session_id text,                  -- معرّف جلسة عابر من العميل (اختياري)
  meta jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT api_incidents_meta_is_object CHECK (jsonb_typeof(meta) = 'object'),
  CONSTRAINT api_incidents_kind_valid CHECK (kind IN
    ('api_error','timeout','unexpected_zero','cache_fail','js_error','other')),
  CONSTRAINT api_incidents_source_len CHECK (char_length(source) BETWEEN 1 AND 80),
  CONSTRAINT api_incidents_message_len CHECK (message IS NULL OR char_length(message) <= 2000)
);

-- الصلاحيات: العميل لا يكتب مباشرة (يمر عبر server fn بمفتاح service_role).
-- نمنح service_role كامل، وauthenticated فقط SELECT (يقيّده RLS للـ admin).
GRANT SELECT ON public.api_incidents TO authenticated;
GRANT ALL ON public.api_incidents TO service_role;

ALTER TABLE public.api_incidents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins can read incidents"
  ON public.api_incidents FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- لا سياسة INSERT/UPDATE/DELETE للعموم → الكتابة تمر عبر service_role فقط.

CREATE INDEX IF NOT EXISTS api_incidents_at_desc
  ON public.api_incidents (at DESC);
CREATE INDEX IF NOT EXISTS api_incidents_source_at
  ON public.api_incidents (source, at DESC);
CREATE INDEX IF NOT EXISTS api_incidents_kind_at
  ON public.api_incidents (kind, at DESC);
CREATE INDEX IF NOT EXISTS api_incidents_meta_gin
  ON public.api_incidents USING gin (meta jsonb_path_ops);

COMMENT ON TABLE public.api_incidents IS
  'حوادث/أعطال يُبلّغ بها العميل عبر server function آمن. لا يكتب فيها المستخدم مباشرة.';