
-- Fix 1: admin_config — remove broad public read policy.
-- The flag view/table has no consumers in the app. Drop public policy and column grants.
DROP POLICY IF EXISTS "public read admin_config for flag view" ON public.admin_config;
REVOKE SELECT ON public.admin_config FROM anon;
REVOKE SELECT (id, use_structured_search) ON public.admin_config FROM anon;
DROP VIEW IF EXISTS public.admin_public_flags;

-- If public flag reads are needed later, expose via a SECURITY DEFINER RPC returning only the flag.
CREATE OR REPLACE FUNCTION public.get_public_flags()
RETURNS jsonb
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT jsonb_build_object('use_structured_search', COALESCE(use_structured_search, false))
  FROM public.admin_config
  WHERE id = 1
$$;
REVOKE EXECUTE ON FUNCTION public.get_public_flags() FROM public;
GRANT EXECUTE ON FUNCTION public.get_public_flags() TO anon, authenticated;

-- Fix 2: route_stops_full — restrict public read to stops of verified routes only.
DROP POLICY IF EXISTS "read route stops" ON public.route_stops_full;
CREATE POLICY "public read verified route stops" ON public.route_stops_full
  FOR SELECT TO anon, authenticated
  USING (EXISTS (
    SELECT 1 FROM public.routes r
    WHERE r.id = route_stops_full.route_id AND r.is_verified = true
  ));
