DROP VIEW IF EXISTS public.traffic_reports_public;

-- Coarse (~100m) coordinates safe to expose publicly
ALTER TABLE public.traffic_reports
  ADD COLUMN IF NOT EXISTS lat_coarse double precision
    GENERATED ALWAYS AS (round(lat::numeric, 3)::double precision) STORED,
  ADD COLUMN IF NOT EXISTS lng_coarse double precision
    GENERATED ALWAYS AS (round(lng::numeric, 3)::double precision) STORED;

-- Column-level privileges: identity and precise coordinates are never selectable
REVOKE SELECT ON public.traffic_reports FROM anon, authenticated;
GRANT SELECT (id, area, severity, notes, country, created_at, expires_at, lat_coarse, lng_coarse)
  ON public.traffic_reports TO anon, authenticated;

CREATE POLICY "Anyone can read anonymized traffic reports"
ON public.traffic_reports
FOR SELECT
TO anon, authenticated
USING (true);