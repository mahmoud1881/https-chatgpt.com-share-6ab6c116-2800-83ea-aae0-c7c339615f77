-- Fix 1: Revoke anon/authenticated EXECUTE on cleanup_old_data (maintenance only)
REVOKE EXECUTE ON FUNCTION public.cleanup_old_data() FROM anon, authenticated, public;

-- Fix 2: Restrict peer_nodes SELECT to owner only (prevents leaking peer network metadata)
DROP POLICY IF EXISTS "read available peers" ON public.peer_nodes;
CREATE POLICY "read own peer" ON public.peer_nodes
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);