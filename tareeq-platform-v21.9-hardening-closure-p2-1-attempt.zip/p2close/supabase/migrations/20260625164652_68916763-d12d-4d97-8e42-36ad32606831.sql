-- Lock down SECURITY DEFINER functions: revoke broad EXECUTE, grant only where needed.

-- Trigger function: not meant to be called via Data API at all.
REVOKE EXECUTE ON FUNCTION public.bump_answers_count() FROM PUBLIC, anon, authenticated;

-- RPC used by signed-in users to confirm a community route: allow authenticated only.
REVOKE EXECUTE ON FUNCTION public.confirm_community_route(uuid) FROM PUBLIC, anon;
GRANT  EXECUTE ON FUNCTION public.confirm_community_route(uuid) TO authenticated;