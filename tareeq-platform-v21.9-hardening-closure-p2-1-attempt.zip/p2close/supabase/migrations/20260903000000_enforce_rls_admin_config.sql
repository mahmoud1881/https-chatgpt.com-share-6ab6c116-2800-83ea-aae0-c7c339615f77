-- Safety net: admin_config was created outside the migration history (no
-- CREATE TABLE for it exists in this repo), so we cannot confirm from the
-- migrations alone whether ROW LEVEL SECURITY was ever enabled on it.
--
-- The existing policy "admins read admin_config" (see
-- 20260708160453_...) only takes effect if RLS is enabled — otherwise any
-- role with a base-table SELECT grant (e.g. `authenticated`, which Supabase
-- grants by default unless explicitly revoked) can read every row,
-- regardless of the has_role() check.
--
-- Enabling RLS is idempotent and safe to run whether or not it is already
-- enabled — it does not change behavior for callers who were already
-- correctly restricted by a policy, it only removes the silent bypass for
-- roles that still hold a base-table grant.
ALTER TABLE public.admin_config ENABLE ROW LEVEL SECURITY;

-- Also force it for the table owner / superuser-run backends, so a
-- misconfigured service role connection can't accidentally bypass RLS
-- either. Comment out if this app relies on the table owner reading
-- admin_config directly without going through has_role().
ALTER TABLE public.admin_config FORCE ROW LEVEL SECURITY;

-- Verification query (run manually against the live DB to confirm):
--   SELECT relrowsecurity, relforcerowsecurity
--   FROM pg_class WHERE relname = 'admin_config';
-- Expect: relrowsecurity = true, relforcerowsecurity = true
