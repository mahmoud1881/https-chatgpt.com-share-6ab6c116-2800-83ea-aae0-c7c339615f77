
-- Revoke direct EXECUTE on privileged SECURITY DEFINER helpers so they can only
-- be invoked by the service role (server-side) or via triggers. The helpers
-- that must stay callable by authenticated users (has_role, session helpers,
-- log_ai_usage, get_public_flags for anon flags) are left untouched.

REVOKE EXECUTE ON FUNCTION public.cleanup_old_data()             FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.bulk_update_stop_embeddings(jsonb) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.get_admin_stats()              FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user()              FROM PUBLIC, anon, authenticated;

GRANT EXECUTE ON FUNCTION public.cleanup_old_data()              TO service_role;
GRANT EXECUTE ON FUNCTION public.bulk_update_stop_embeddings(jsonb) TO service_role;
GRANT EXECUTE ON FUNCTION public.get_admin_stats()               TO service_role, authenticated;
GRANT EXECUTE ON FUNCTION public.handle_new_user()               TO service_role;
