
DROP INDEX IF EXISTS public.stops_embedding_idx;
ALTER TABLE public.stops DROP COLUMN IF EXISTS embedding;
ALTER TABLE public.stops ADD COLUMN embedding vector(512);
CREATE INDEX stops_embedding_idx ON public.stops USING hnsw (embedding vector_cosine_ops);

DROP FUNCTION IF EXISTS public.match_stops_semantic(vector, text, int, float);

CREATE OR REPLACE FUNCTION public.match_stops_semantic(
  query_embedding vector(512),
  match_country text DEFAULT NULL,
  match_count int DEFAULT 8,
  min_similarity float DEFAULT 0.35
)
RETURNS TABLE (
  id uuid,
  name_ar text,
  name_en text,
  city text,
  country text,
  is_verified boolean,
  similarity float
)
LANGUAGE sql STABLE
SET search_path = public
AS $$
  SELECT
    s.id, s.name_ar, s.name_en, s.city, s.country, s.is_verified,
    1 - (s.embedding <=> query_embedding) AS similarity
  FROM public.stops s
  WHERE s.embedding IS NOT NULL
    AND (match_country IS NULL OR s.country = match_country)
    AND 1 - (s.embedding <=> query_embedding) >= min_similarity
  ORDER BY s.embedding <=> query_embedding
  LIMIT match_count;
$$;

GRANT EXECUTE ON FUNCTION public.match_stops_semantic(vector, text, int, float) TO anon, authenticated, service_role;
