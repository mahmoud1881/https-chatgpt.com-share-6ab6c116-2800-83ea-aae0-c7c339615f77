BEGIN;
-- Retain historical storage for recovery, but remove client API access.
REVOKE SELECT (price_egp), INSERT (price_egp), UPDATE (price_egp)
  ON public.community_routes FROM PUBLIC, anon, authenticated;
REVOKE INSERT, UPDATE ON public.community_routes FROM PUBLIC, anon, authenticated;
GRANT INSERT (id, user_id, title, from_area, to_area, duration_min, status, confirmations, country, created_at, provenance)
  ON public.community_routes TO authenticated;
GRANT UPDATE (title, from_area, to_area, duration_min, country, provenance)
  ON public.community_routes TO authenticated;
REVOKE SELECT ON public.community_routes_public FROM PUBLIC, anon, authenticated;
REVOKE SELECT (price_egp) ON public.community_routes_public FROM PUBLIC, anon, authenticated;
GRANT SELECT (id, title, from_area, to_area, duration_min, status, confirmations, country, created_at)
  ON public.community_routes_public TO anon, authenticated;
-- Some existing deployments have this legacy view; fresh migrations do not.
DO $$ BEGIN
  IF to_regclass('public.my_community_routes') IS NOT NULL THEN
    REVOKE ALL ON public.my_community_routes FROM PUBLIC, anon, authenticated;
    REVOKE SELECT (price_egp), INSERT (price_egp), UPDATE (price_egp)
      ON public.my_community_routes FROM PUBLIC, anon, authenticated;
    GRANT SELECT (id, title, from_area, to_area, duration_min, status, confirmations, country, created_at)
      ON public.my_community_routes TO authenticated;
  END IF;
END $$;
COMMIT;
