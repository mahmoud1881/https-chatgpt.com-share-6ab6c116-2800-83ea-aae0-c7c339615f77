
-- Track unique voters for community_routes to prevent spam
CREATE TABLE IF NOT EXISTS public.community_route_votes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  route_id UUID NOT NULL REFERENCES public.community_routes(id) ON DELETE CASCADE,
  voter_id UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (route_id, voter_id)
);

GRANT SELECT, INSERT ON public.community_route_votes TO authenticated;
GRANT ALL ON public.community_route_votes TO service_role;

ALTER TABLE public.community_route_votes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "users_view_own_votes" ON public.community_route_votes
  FOR SELECT TO authenticated USING (auth.uid() = voter_id);

CREATE POLICY "users_insert_own_votes" ON public.community_route_votes
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = voter_id);

-- Harden the confirm function: require auth + dedupe per voter
CREATE OR REPLACE FUNCTION public.confirm_community_route(route_id UUID)
RETURNS public.community_routes
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updated public.community_routes;
  uid UUID := auth.uid();
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'auth_required: must be signed in to confirm';
  END IF;

  -- Enforce one vote per user per route
  BEGIN
    INSERT INTO public.community_route_votes (route_id, voter_id)
    VALUES (route_id, uid);
  EXCEPTION WHEN unique_violation THEN
    RAISE EXCEPTION 'duplicate_vote: you already confirmed this route';
  END;

  UPDATE public.community_routes
     SET confirmations = LEAST(confirmations + 1, 10000),
         status = CASE WHEN confirmations + 1 >= 5 THEN 'confirmed' ELSE status END
   WHERE id = route_id
  RETURNING * INTO updated;
  RETURN updated;
END;
$$;

REVOKE ALL ON FUNCTION public.confirm_community_route(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.confirm_community_route(UUID) TO authenticated;
