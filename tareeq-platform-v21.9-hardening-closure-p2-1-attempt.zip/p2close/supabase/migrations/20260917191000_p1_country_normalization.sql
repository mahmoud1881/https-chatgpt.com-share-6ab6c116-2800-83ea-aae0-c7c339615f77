-- P1: canonicalize ISO-like country codes at the database boundary.
-- This removes eg/EG mismatches that otherwise make unique keys and lookups
-- disagree across importers and admin tools.
CREATE OR REPLACE FUNCTION public.normalize_country_code()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.country IS NOT NULL THEN NEW.country := lower(trim(NEW.country)); END IF;
  RETURN NEW;
END;
$$;

UPDATE public.routes SET country = lower(trim(country)) WHERE country IS NOT NULL;
UPDATE public.stops SET country = lower(trim(country)) WHERE country IS NOT NULL;

DROP TRIGGER IF EXISTS trg_routes_normalize_country ON public.routes;
CREATE TRIGGER trg_routes_normalize_country
BEFORE INSERT OR UPDATE OF country ON public.routes
FOR EACH ROW EXECUTE FUNCTION public.normalize_country_code();

DROP TRIGGER IF EXISTS trg_stops_normalize_country ON public.stops;
CREATE TRIGGER trg_stops_normalize_country
BEFORE INSERT OR UPDATE OF country ON public.stops
FOR EACH ROW EXECUTE FUNCTION public.normalize_country_code();

ALTER TABLE public.routes DROP CONSTRAINT IF EXISTS routes_country_lowercase_ck;
ALTER TABLE public.routes ADD CONSTRAINT routes_country_lowercase_ck
  CHECK (country = lower(country));

ALTER TABLE public.stops DROP CONSTRAINT IF EXISTS stops_country_lowercase_ck;
ALTER TABLE public.stops ADD CONSTRAINT stops_country_lowercase_ck
  CHECK (country = lower(country));
