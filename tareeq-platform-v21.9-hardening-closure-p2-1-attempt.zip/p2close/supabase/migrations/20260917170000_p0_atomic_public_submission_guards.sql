-- P0 hardening: atomic rate limiting and route-verification submission.
-- All operations are serialized at the database boundary so concurrent
-- requests cannot bypass quotas or duplicate corroboration updates.

CREATE OR REPLACE FUNCTION public.enforce_rate_limit(
  p_bucket text,
  p_identifier text,
  p_max_count integer,
  p_window interval
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_count integer;
  v_lock_key bigint;
BEGIN
  IF NULLIF(trim(p_bucket), '') IS NULL THEN
    RAISE EXCEPTION 'bucket_required: rate limiting requires a bucket';
  END IF;
  IF NULLIF(trim(p_identifier), '') IS NULL THEN
    RAISE EXCEPTION 'identifier_required: rate limiting requires a non-empty identifier';
  END IF;
  IF p_max_count IS NULL OR p_max_count < 1 THEN
    RAISE EXCEPTION 'invalid_limit: p_max_count must be >= 1';
  END IF;
  IF p_window IS NULL OR p_window <= interval '0 seconds' THEN
    RAISE EXCEPTION 'invalid_window: p_window must be positive';
  END IF;

  -- Serialize the check+insert for this bucket/identifier. The previous
  -- implementation performed SELECT count(*) followed by INSERT without a
  -- lock, allowing concurrent requests to all observe the same count.
  v_lock_key := hashtextextended(p_bucket || ':' || p_identifier, 0);
  PERFORM pg_advisory_xact_lock(v_lock_key);

  DELETE FROM public.rate_limit_events
   WHERE bucket = p_bucket
     AND identifier = p_identifier
     AND created_at < now() - p_window;

  SELECT count(*) INTO v_count
    FROM public.rate_limit_events
   WHERE bucket = p_bucket
     AND identifier = p_identifier
     AND created_at >= now() - p_window;

  IF v_count >= p_max_count THEN
    RAISE EXCEPTION 'rate_limited: too many "%" actions, try again later', p_bucket;
  END IF;

  INSERT INTO public.rate_limit_events (bucket, identifier) VALUES (p_bucket, p_identifier);
END;
$$;

REVOKE ALL ON FUNCTION public.enforce_rate_limit(text, text, integer, interval) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.enforce_rate_limit(text, text, integer, interval) TO service_role;

-- Atomic route-verification submission. The function owns the quota check,
-- duplicate lookup, corroboration update, and rate-counter increment.
CREATE OR REPLACE FUNCTION public.submit_route_verification_atomic(
  p_route_reference text,
  p_route_id uuid,
  p_verification_type public.route_verification_type,
  p_proposed_value_json jsonb,
  p_note text,
  p_source text,
  p_locale text,
  p_duplicate_key text,
  p_user_id uuid,
  p_fingerprint text,
  p_bucket_day date,
  p_rate_limit integer DEFAULT 20
) RETURNS TABLE (id uuid, duplicate boolean)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_existing public.route_verifications%ROWTYPE;
  v_count integer;
  v_increment integer := 1;
  v_new_count integer;
  v_next_status public.route_verification_status;
BEGIN
  IF NULLIF(trim(p_duplicate_key), '') IS NULL THEN
    RAISE EXCEPTION 'invalid_duplicate_key';
  END IF;
  IF NULLIF(trim(p_fingerprint), '') IS NULL THEN
    RAISE EXCEPTION 'invalid_fingerprint';
  END IF;
  IF p_bucket_day IS NULL THEN
    RAISE EXCEPTION 'invalid_bucket_day';
  END IF;
  IF p_rate_limit < 1 THEN
    RAISE EXCEPTION 'invalid_rate_limit';
  END IF;

  -- Lock the contributor's daily quota first. Every path increments it only
  -- after a successful insert or duplicate corroboration.
  PERFORM pg_advisory_xact_lock(
    hashtextextended('rv-rate:' || p_fingerprint || ':' || p_bucket_day::text, 0)
  );

  SELECT count INTO v_count
    FROM public.route_verifications_rate
   WHERE fingerprint = p_fingerprint
     AND bucket_day = p_bucket_day;

  IF COALESCE(v_count, 0) >= p_rate_limit THEN
    RAISE EXCEPTION 'rate_limited: daily route verification quota exceeded';
  END IF;

  -- Serialize all submissions for the same dedup key. This closes the
  -- SELECT-then-UPDATE/INSERT race that existed in the server function.
  PERFORM pg_advisory_xact_lock(hashtextextended('rv-dup:' || p_duplicate_key, 0));

  -- Re-check the duplicate after acquiring the lock.
  SELECT * INTO v_existing
    FROM public.route_verifications
   WHERE duplicate_key = p_duplicate_key
     AND status IN ('pending', 'corroborated')
   ORDER BY created_at DESC
   LIMIT 1;

  IF FOUND THEN
    IF p_user_id IS NOT NULL AND public.has_role(p_user_id, 'moderator'::public.app_role) THEN
      v_increment := 3;
    END IF;

    v_new_count := v_existing.corroboration_count + v_increment;
    v_next_status := v_existing.status;
    IF v_new_count >= 3 AND v_existing.status = 'pending' THEN
      v_next_status := 'corroborated';
    END IF;

    UPDATE public.route_verifications
       SET corroboration_count = v_new_count,
           status = v_next_status
     WHERE id = v_existing.id;

    INSERT INTO public.route_verifications_rate (fingerprint, bucket_day, count, updated_at)
    VALUES (p_fingerprint, p_bucket_day, 1, now())
    ON CONFLICT (fingerprint, bucket_day)
    DO UPDATE SET count = public.route_verifications_rate.count + 1,
                  updated_at = now();

    id := v_existing.id;
    duplicate := true;
    RETURN NEXT;
    RETURN;
  END IF;

  IF p_route_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM public.routes WHERE routes.id = p_route_id
  ) THEN
    RAISE EXCEPTION 'invalid_route: route does not exist';
  END IF;

  INSERT INTO public.route_verifications (
    route_reference,
    route_id,
    verification_type,
    proposed_value_json,
    note,
    source,
    locale,
    duplicate_key,
    created_by
  ) VALUES (
    p_route_reference,
    p_route_id,
    p_verification_type,
    p_proposed_value_json,
    p_note,
    p_source,
    p_locale,
    p_duplicate_key,
    p_user_id
  )
  RETURNING route_verifications.id INTO id;

  INSERT INTO public.route_verifications_rate (fingerprint, bucket_day, count, updated_at)
  VALUES (p_fingerprint, p_bucket_day, 1, now())
  ON CONFLICT (fingerprint, bucket_day)
  DO UPDATE SET count = public.route_verifications_rate.count + 1,
                updated_at = now();

  duplicate := false;
  RETURN NEXT;
END;
$$;

REVOKE ALL ON FUNCTION public.submit_route_verification_atomic(
  text, uuid, public.route_verification_type, jsonb, text, text, text, text, uuid, text, date, integer
) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.submit_route_verification_atomic(
  text, uuid, public.route_verification_type, jsonb, text, text, text, text, uuid, text, date, integer
) TO service_role;
