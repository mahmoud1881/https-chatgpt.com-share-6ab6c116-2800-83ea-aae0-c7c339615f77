-- ============================================================================
-- 20260906130000 fixed live_vehicle_pings but reasoned "traffic_reports:
-- authenticated-only table, identifier unchanged" — the same incorrect
-- assumption this migration's own regression was about, just applied to a
-- different table. A full-history scan (not a point-in-time grep, which is
-- exactly what missed this the first two times) shows TWO more tables with
-- a surviving PUBLIC/anon-permissive INSERT policy alongside a later
-- `TO authenticated` one — RLS OR-combines permissive policies, so anon can
-- still insert either way:
--
--   - public.traffic_reports:  "Anyone can submit a valid traffic report"
--     (20260625101202, no TO clause = PUBLIC) never dropped, alongside
--     "signed-in can post traffic reports" (TO authenticated).
--   - public.community_routes: "Insert community routes as pending only"
--     (20260625172011, TO authenticated, anon, WITH CHECK status='pending')
--     never dropped — this one reads as an *intentional* anonymous
--     "submit as pending for review" path, not leftover debris.
--
-- rl_traffic_reports() and rl_community_routes_insert() both call
-- enforce_rate_limit() with auth.uid()::text as the identifier, which is
-- NULL for these anon submitters — since 20260906130000, that raises
-- 'identifier_required' and hard-rejects every anonymous traffic report and
-- every anonymous pending-route suggestion. Live regression, right now.
--
-- Fix: same shape as the live_vehicle_pings fix — fall back to a
-- non-identity value when there's no session. Neither table has a
-- client-generated session_id column (unlike live_vehicle_pings), so we
-- fall back to the request's forwarded IP when PostgREST exposes it, and
-- to a single shared bucket as a last resort. That shared bucket still
-- caps *total* anonymous volume for the action even when no per-client
-- signal is available at all — coarser than per-client limiting, but
-- strictly better than either hard-rejecting real anonymous users (today's
-- bug) or having no limit at all (the original audit finding).
-- ============================================================================

CREATE OR REPLACE FUNCTION public.rate_limit_anon_fallback_identifier()
RETURNS text
LANGUAGE sql
STABLE
SET search_path = public
AS $$
  SELECT COALESCE(
    NULLIF(current_setting('request.headers', true)::json ->> 'x-forwarded-for', ''),
    'anon-shared'
  );
$$;

-- --- traffic_reports: authenticated users limited per-account; anonymous
-- submitters limited per forwarded-IP (or a shared bucket if unavailable) ---
CREATE OR REPLACE FUNCTION public.rl_traffic_reports() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.enforce_rate_limit(
    'traffic_reports',
    COALESCE(auth.uid()::text, public.rate_limit_anon_fallback_identifier()),
    20,
    interval '10 minutes'
  );
  RETURN NEW;
END;
$$;

-- --- community_routes: same pattern — the "pending only" anon path keeps
-- working, just rate-limited by forwarded-IP/shared bucket instead of
-- account ---
CREATE OR REPLACE FUNCTION public.rl_community_routes_insert() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.enforce_rate_limit(
    'community_routes_insert',
    COALESCE(auth.uid()::text, public.rate_limit_anon_fallback_identifier()),
    10,
    interval '1 day'
  );
  RETURN NEW;
END;
$$;

-- Triggers already point at these function names (created in 20260906120000,
-- untouched since) — CREATE OR REPLACE above is sufficient, no DROP/CREATE
-- TRIGGER needed.

REVOKE ALL ON FUNCTION public.rate_limit_anon_fallback_identifier() FROM PUBLIC, anon, authenticated;

-- ============================================================================
-- Same systematic scan also found community_questions/community_answers
-- carrying an equivalent surviving anon-permissive INSERT policy
-- ("anyone can insert questions"/"answers", no TO clause, never dropped)
-- with NO rate-limit trigger at all yet (not a regression — this one was
-- simply missed by every prior pass, mine included). Closing it now with
-- the same identifier strategy.
-- ============================================================================

CREATE OR REPLACE FUNCTION public.rl_community_questions_insert() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.enforce_rate_limit(
    'community_questions_insert',
    COALESCE(auth.uid()::text, public.rate_limit_anon_fallback_identifier()),
    10,
    interval '1 hour'
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_rate_limit_community_questions_insert ON public.community_questions;
CREATE TRIGGER trg_rate_limit_community_questions_insert
  BEFORE INSERT ON public.community_questions
  FOR EACH ROW EXECUTE FUNCTION public.rl_community_questions_insert();

CREATE OR REPLACE FUNCTION public.rl_community_answers_insert() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.enforce_rate_limit(
    'community_answers_insert',
    COALESCE(auth.uid()::text, public.rate_limit_anon_fallback_identifier()),
    20,
    interval '1 hour'
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_rate_limit_community_answers_insert ON public.community_answers;
CREATE TRIGGER trg_rate_limit_community_answers_insert
  BEFORE INSERT ON public.community_answers
  FOR EACH ROW EXECUTE FUNCTION public.rl_community_answers_insert();

