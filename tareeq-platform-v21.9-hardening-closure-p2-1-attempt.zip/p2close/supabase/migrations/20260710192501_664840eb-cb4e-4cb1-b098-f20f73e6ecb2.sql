REVOKE EXECUTE ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.get_public_flags() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_public_flags() TO authenticated, service_role;
