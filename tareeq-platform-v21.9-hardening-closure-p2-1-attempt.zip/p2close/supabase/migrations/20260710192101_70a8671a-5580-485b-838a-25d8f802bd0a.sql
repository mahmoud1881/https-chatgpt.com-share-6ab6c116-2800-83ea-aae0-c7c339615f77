-- Revoke public EXECUTE on sensitive SECURITY DEFINER functions and grant only to appropriate roles.
-- has_role and get_public_flags remain public (used by RLS / public config).

REVOKE EXECUTE ON FUNCTION public.cleanup_old_data() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cleanup_old_data() TO service_role;

REVOKE EXECUTE ON FUNCTION public.heartbeat_session(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.heartbeat_session(uuid) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.end_session(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.end_session(uuid) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.start_session(text, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.start_session(text, text) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.log_ai_usage(text, text, integer, integer, integer, boolean, integer, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.log_ai_usage(text, text, integer, integer, integer, boolean, integer, text) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.get_admin_stats() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_admin_stats() TO authenticated, service_role;
