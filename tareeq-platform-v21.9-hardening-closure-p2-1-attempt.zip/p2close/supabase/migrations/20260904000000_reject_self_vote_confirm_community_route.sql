-- ============================================================================
-- RELEASE_READINESS fix: reject self-votes in confirm_community_route().
--
-- 20260821000000_restore_hardened_confirm_community_route.sql fixed
-- authentication, per-user dedup, and the confirmation cap, but never
-- checked that the voter isn't the route's own submitter. Combined with the
-- client's SELECT on community_routes never including user_id (that column
-- is intentionally column-privilege-revoked from anon/authenticated as of
-- 20260820193552 — "hide the account-identifying user_id column from
-- community reads"), the UI has no way to hide or disable the confirm
-- button on a user's own submission either. Net effect: any user can add a
-- route and immediately self-confirm it — one legitimate vote (it passes
-- every existing check) that measurably moves it toward the 5-confirmation
-- threshold for "confirmed" status.
--
-- The fix belongs here, not in the client: confirm_community_route is
-- SECURITY DEFINER, so it can read community_routes.user_id internally to
-- make this check even though that column is unreadable to the client
-- directly. This is the only layer that can enforce it.
-- ============================================================================

CREATE OR REPLACE FUNCTION public.confirm_community_route(route_id UUID)
RETURNS public.community_routes
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updated public.community_routes;
  uid UUID := auth.uid();
  owner_id UUID;
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'auth_required: must be signed in to confirm';
  END IF;

  SELECT user_id INTO owner_id FROM public.community_routes WHERE id = route_id;

  IF owner_id IS NULL THEN
    RAISE EXCEPTION 'not_found: route does not exist';
  END IF;

  IF owner_id = uid THEN
    RAISE EXCEPTION 'cannot_vote_own_route: لا يمكنك تأكيد خطك الخاص';
  END IF;

  -- Enforce one vote per user per route (community_route_votes has a
  -- UNIQUE(route_id, voter_id) constraint from migration 20260625171148).
  BEGIN
    INSERT INTO public.community_route_votes (route_id, voter_id)
    VALUES (route_id, uid);
  EXCEPTION WHEN unique_violation THEN
    RAISE EXCEPTION 'duplicate_vote: you already confirmed this route';
  END;

  UPDATE public.community_routes
     SET confirmations = LEAST(confirmations + 1, 10000),
         status = CASE WHEN confirmations + 1 >= 5 THEN 'confirmed' ELSE status END
   WHERE id = route_id
  RETURNING * INTO updated;

  RETURN updated;
END;
$$;

REVOKE ALL ON FUNCTION public.confirm_community_route(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.confirm_community_route(UUID) TO authenticated;
