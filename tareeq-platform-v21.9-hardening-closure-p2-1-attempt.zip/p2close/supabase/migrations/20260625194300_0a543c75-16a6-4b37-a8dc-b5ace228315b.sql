
CREATE TABLE public.ma_tram_pings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  line TEXT NOT NULL,
  station_id TEXT NOT NULL,
  crowd_level SMALLINT NOT NULL CHECK (crowd_level BETWEEN 1 AND 5),
  delay_minutes SMALLINT DEFAULT 0,
  note TEXT,
  reporter_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  country TEXT NOT NULL DEFAULT 'ma',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_ma_tram_pings_station ON public.ma_tram_pings(station_id, created_at DESC);
CREATE INDEX idx_ma_tram_pings_line ON public.ma_tram_pings(line, created_at DESC);

GRANT SELECT, INSERT ON public.ma_tram_pings TO authenticated;
GRANT SELECT ON public.ma_tram_pings TO anon;
GRANT ALL ON public.ma_tram_pings TO service_role;

ALTER TABLE public.ma_tram_pings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone can read tram pings"
  ON public.ma_tram_pings FOR SELECT
  USING (true);

CREATE POLICY "authenticated can report tram pings"
  ON public.ma_tram_pings FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = reporter_id);

ALTER PUBLICATION supabase_realtime ADD TABLE public.ma_tram_pings;
