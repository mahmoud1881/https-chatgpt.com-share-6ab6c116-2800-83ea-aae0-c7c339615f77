GRANT SELECT, INSERT, UPDATE, DELETE ON public.routes TO sandbox_exec;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.route_stops TO sandbox_exec;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.stops TO sandbox_exec;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.stop_aliases TO sandbox_exec;