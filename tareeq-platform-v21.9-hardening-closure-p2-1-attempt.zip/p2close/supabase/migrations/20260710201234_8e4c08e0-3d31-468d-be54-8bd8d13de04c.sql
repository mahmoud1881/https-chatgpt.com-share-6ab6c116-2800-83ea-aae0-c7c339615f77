DROP POLICY IF EXISTS "authenticated can insert questions" ON public.community_questions;
DROP POLICY IF EXISTS "authenticated can insert answers" ON public.community_answers;