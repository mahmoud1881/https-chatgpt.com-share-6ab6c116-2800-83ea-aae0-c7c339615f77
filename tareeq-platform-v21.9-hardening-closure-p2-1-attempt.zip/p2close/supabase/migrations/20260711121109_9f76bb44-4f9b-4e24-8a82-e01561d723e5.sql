-- Restrict access to user_id column on live_vehicle_pings to prevent linking identities to real-time locations.
REVOKE SELECT ON public.live_vehicle_pings FROM authenticated, anon;
GRANT SELECT (id, route_id, session_id, lat, lng, heading, speed_kmh, country, created_at) ON public.live_vehicle_pings TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.live_vehicle_pings TO authenticated;