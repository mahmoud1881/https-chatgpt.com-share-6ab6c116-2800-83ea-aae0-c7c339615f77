
-- 1) Extend search_logs with diagnostic columns
ALTER TABLE public.search_logs
  ADD COLUMN IF NOT EXISTS normalized_from text,
  ADD COLUMN IF NOT EXISTS normalized_to text,
  ADD COLUMN IF NOT EXISTS matched_from_stop_id uuid,
  ADD COLUMN IF NOT EXISTS matched_to_stop_id uuid,
  ADD COLUMN IF NOT EXISTS direct_routes_count int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS transfer_routes_count int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS fallback_used boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS no_result_reason text,
  ADD COLUMN IF NOT EXISTS source text;

CREATE INDEX IF NOT EXISTS idx_search_logs_created_at ON public.search_logs (created_at DESC);

-- 2) Restrict admin_config: drop wide public policy, expose flag via view
DROP POLICY IF EXISTS "public read structured flag" ON public.admin_config;

CREATE OR REPLACE VIEW public.admin_public_flags
WITH (security_invoker = true) AS
SELECT id, use_structured_search
FROM public.admin_config;

GRANT SELECT ON public.admin_public_flags TO anon, authenticated;

-- Keep an admin-only SELECT policy so admins still read the full row
DROP POLICY IF EXISTS "admins read admin_config" ON public.admin_config;
CREATE POLICY "admins read admin_config" ON public.admin_config
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- Allow the view (security_invoker) to work for anon by adding a narrow policy on the flag column-scope.
-- Since RLS is row-level, we allow reading the single-row admin_config to anon but the view exposes only safe cols.
CREATE POLICY "public read admin_config for flag view" ON public.admin_config
  FOR SELECT TO anon, authenticated
  USING (true);
-- The view projects only id + use_structured_search, so notes/budget remain hidden at the API layer.
-- Direct table reads by anon are still possible in theory; PostgREST will only expose the view when clients query
-- the view. To fully hide sensitive columns, revoke column privileges from anon:
REVOKE SELECT ON public.admin_config FROM anon;
GRANT SELECT (id, use_structured_search) ON public.admin_config TO anon;

-- 3) Test data: Alexandria pilot route (idempotent — skip if names already exist)
DO $$
DECLARE
  v_stop_sidi_bishr uuid;
  v_stop_victoria uuid;
  v_stop_roushdi uuid;
  v_stop_sidi_gaber uuid;
  v_stop_raml uuid;
  v_route_id uuid;
BEGIN
  -- Stops
  INSERT INTO public.stops (name_ar, normalized_name, country, city, is_verified, source)
  VALUES ('سيدي بشر', 'سيدي بشر', 'EG', 'الإسكندرية', true, 'seed')
  ON CONFLICT DO NOTHING;
  SELECT id INTO v_stop_sidi_bishr FROM public.stops WHERE normalized_name='سيدي بشر' AND country='EG' LIMIT 1;

  INSERT INTO public.stops (name_ar, normalized_name, country, city, is_verified, source)
  VALUES ('فيكتوريا', 'فيكتوريا', 'EG', 'الإسكندرية', true, 'seed')
  ON CONFLICT DO NOTHING;
  SELECT id INTO v_stop_victoria FROM public.stops WHERE normalized_name='فيكتوريا' AND country='EG' LIMIT 1;

  INSERT INTO public.stops (name_ar, normalized_name, country, city, is_verified, source)
  VALUES ('رشدي', 'رشدي', 'EG', 'الإسكندرية', true, 'seed')
  ON CONFLICT DO NOTHING;
  SELECT id INTO v_stop_roushdi FROM public.stops WHERE normalized_name='رشدي' AND country='EG' LIMIT 1;

  INSERT INTO public.stops (name_ar, normalized_name, country, city, is_verified, source)
  VALUES ('سيدي جابر', 'سيدي جابر', 'EG', 'الإسكندرية', true, 'seed')
  ON CONFLICT DO NOTHING;
  SELECT id INTO v_stop_sidi_gaber FROM public.stops WHERE normalized_name='سيدي جابر' AND country='EG' LIMIT 1;

  INSERT INTO public.stops (name_ar, normalized_name, country, city, is_verified, source)
  VALUES ('محطة الرمل', 'رمل', 'EG', 'الإسكندرية', true, 'seed')
  ON CONFLICT DO NOTHING;
  SELECT id INTO v_stop_raml FROM public.stops WHERE normalized_name='رمل' AND country='EG' LIMIT 1;

  -- Alias "الرمل" -> محطة الرمل (normalized already 'رمل' from stopword strip)
  INSERT INTO public.stop_aliases (stop_id, alias, normalized_alias, source)
  VALUES (v_stop_raml, 'الرمل', 'رمل', 'seed')
  ON CONFLICT DO NOTHING;

  -- Route
  INSERT INTO public.routes (route_code, route_name, country, city, start_stop_id, end_stop_id,
    price_min, price_max, currency, estimated_duration, is_verified, status, source, notes)
  VALUES ('ALX-TEST-01', 'اختبار سيدي بشر إلى محطة الرمل', 'EG', 'الإسكندرية',
    v_stop_sidi_bishr, v_stop_raml, 5, 8, 'EGP', 25, true, 'active', 'seed',
    'خط اختبار مؤكد لتشخيص نظام البحث الجديد.')
  ON CONFLICT DO NOTHING
  RETURNING id INTO v_route_id;

  IF v_route_id IS NULL THEN
    SELECT id INTO v_route_id FROM public.routes WHERE route_code='ALX-TEST-01' LIMIT 1;
  END IF;

  -- Route stops (delete + insert to keep order consistent)
  DELETE FROM public.route_stops WHERE route_id = v_route_id;
  INSERT INTO public.route_stops (route_id, stop_id, stop_order, direction) VALUES
    (v_route_id, v_stop_sidi_bishr, 1, 'forward'),
    (v_route_id, v_stop_victoria,   2, 'forward'),
    (v_route_id, v_stop_roushdi,    3, 'forward'),
    (v_route_id, v_stop_sidi_gaber, 4, 'forward'),
    (v_route_id, v_stop_raml,       5, 'forward');
END $$;
