create table public.ma_grand_taxi_pings (
  id uuid primary key default gen_random_uuid(),
  route_id text not null,
  station_id text not null,
  seats_remaining smallint not null check (seats_remaining between 0 and 6),
  total_seats smallint not null default 6 check (total_seats between 4 and 6),
  note text,
  reported_by uuid references auth.users(id) on delete set null,
  reported_at timestamptz not null default now(),
  country text not null default 'ma' check (country = 'ma')
);

create index ma_grand_taxi_pings_route_time_idx on public.ma_grand_taxi_pings (route_id, reported_at desc);
create index ma_grand_taxi_pings_station_time_idx on public.ma_grand_taxi_pings (station_id, reported_at desc);

grant select on public.ma_grand_taxi_pings to anon;
grant select, insert on public.ma_grand_taxi_pings to authenticated;
grant all on public.ma_grand_taxi_pings to service_role;

alter table public.ma_grand_taxi_pings enable row level security;

create policy "ma_gt_pings_select_all"
  on public.ma_grand_taxi_pings
  for select
  to anon, authenticated
  using (true);

create policy "ma_gt_pings_insert_auth"
  on public.ma_grand_taxi_pings
  for insert
  to authenticated
  with check (reported_by = auth.uid() and country = 'ma');