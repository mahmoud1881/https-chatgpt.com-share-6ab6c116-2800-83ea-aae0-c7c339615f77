-- ============================================================================
-- Close a real gap found during a full-system audit: src/lib/rate-limit.ts
-- only runs inside TanStack server functions (it reads request headers via
-- @tanstack/react-start/server). Two tables are written directly from
-- client-side browser code via the Supabase client, bypassing that limiter
-- entirely:
--   - public.traffic_reports  (src/routes/live.tsx)
--   - public.live_vehicle_pings (src/lib/transit/live-tracking.ts)
-- Both require `authenticated`, so auth.uid() is a solid, unspoofable
-- identifier for a Postgres-native limiter — no IP/fingerprint needed here.
--
-- This adds a small generic primitive (table + SECURITY DEFINER function)
-- and BEFORE INSERT triggers on the two exposed tables, plus a lighter cap
-- on community_routes submissions (also a direct client insert, see
-- src/routes/community-routes.tsx). Thresholds are a starting point — tune
-- based on real traffic once deployed.
-- ============================================================================

CREATE TABLE IF NOT EXISTS public.rate_limit_events (
  id          bigserial PRIMARY KEY,
  bucket      text NOT NULL,
  identifier  text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS rate_limit_events_lookup_idx
  ON public.rate_limit_events (bucket, identifier, created_at DESC);

-- No policies at all: this table is never read or written directly by
-- anon/authenticated, only through enforce_rate_limit() below (SECURITY
-- DEFINER). service_role keeps full access for maintenance/cleanup jobs.
ALTER TABLE public.rate_limit_events ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.rate_limit_events FROM PUBLIC, anon, authenticated;
GRANT ALL ON public.rate_limit_events TO service_role;
GRANT USAGE, SELECT ON SEQUENCE public.rate_limit_events_id_seq TO service_role;

-- Generic check-and-record: raises if the caller already hit `p_max_count`
-- inserts in bucket `p_bucket` within `p_window`, otherwise records this
-- attempt and returns. Called from BEFORE INSERT triggers, never directly
-- by client roles (see REVOKE below) — it runs with the trigger's definer
-- rights either way, but keeping EXECUTE off anon/authenticated avoids any
-- accidental direct call from a future RPC that forgets to check auth.uid().
CREATE OR REPLACE FUNCTION public.enforce_rate_limit(
  p_bucket text,
  p_max_count integer,
  p_window interval
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_identifier text := auth.uid()::text;
  v_count integer;
BEGIN
  IF v_identifier IS NULL THEN
    RAISE EXCEPTION 'auth_required: rate limiting requires an authenticated caller';
  END IF;

  -- Opportunistic cleanup of this identifier's own expired rows in this
  -- bucket — cheap, keeps the table bounded without a separate cron job.
  DELETE FROM public.rate_limit_events
   WHERE bucket = p_bucket
     AND identifier = v_identifier
     AND created_at < now() - p_window;

  SELECT count(*) INTO v_count
    FROM public.rate_limit_events
   WHERE bucket = p_bucket
     AND identifier = v_identifier
     AND created_at >= now() - p_window;

  IF v_count >= p_max_count THEN
    RAISE EXCEPTION 'rate_limited: too many "%" actions, try again later', p_bucket;
  END IF;

  INSERT INTO public.rate_limit_events (bucket, identifier) VALUES (p_bucket, v_identifier);
END;
$$;

REVOKE ALL ON FUNCTION public.enforce_rate_limit(text, integer, interval) FROM PUBLIC, anon, authenticated;

-- --- traffic_reports: max 20 reports / 10 minutes per user ---
CREATE OR REPLACE FUNCTION public.rl_traffic_reports() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.enforce_rate_limit('traffic_reports', 20, interval '10 minutes');
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_rate_limit_traffic_reports ON public.traffic_reports;
CREATE TRIGGER trg_rate_limit_traffic_reports
  BEFORE INSERT ON public.traffic_reports
  FOR EACH ROW EXECUTE FUNCTION public.rl_traffic_reports();

-- --- live_vehicle_pings: max 40 pings / 60 seconds per user ---
-- (a real active session pinging every few seconds should comfortably fit;
-- this only stops a runaway loop/bot from flooding the table)
CREATE OR REPLACE FUNCTION public.rl_live_vehicle_pings() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.enforce_rate_limit('live_vehicle_pings', 40, interval '60 seconds');
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_rate_limit_live_vehicle_pings ON public.live_vehicle_pings;
CREATE TRIGGER trg_rate_limit_live_vehicle_pings
  BEFORE INSERT ON public.live_vehicle_pings
  FOR EACH ROW EXECUTE FUNCTION public.rl_live_vehicle_pings();

-- --- community_routes: max 10 new submissions / day per user ---
-- (confirm_community_route already has its own per-user vote dedup via the
-- UNIQUE(route_id, voter_id) constraint on community_route_votes, so this
-- trigger only covers the INSERT path, not confirmations.)
CREATE OR REPLACE FUNCTION public.rl_community_routes_insert() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.enforce_rate_limit('community_routes_insert', 10, interval '1 day');
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_rate_limit_community_routes_insert ON public.community_routes;
CREATE TRIGGER trg_rate_limit_community_routes_insert
  BEFORE INSERT ON public.community_routes
  FOR EACH ROW EXECUTE FUNCTION public.rl_community_routes_insert();

-- ============================================================================
-- Section 1.3 fix: community_routes still carried a table-level GRANT INSERT
-- to `anon` from the very first migration (20260625102011), even though the
-- RLS INSERT policy has been scoped to `authenticated` only since
-- 20260702103316 ("signed-in can post community routes"). Not exploitable
-- today (RLS blocks it regardless of the grant), but it's excess privilege
-- that a future policy change could silently reactivate. Revoke it
-- explicitly so the grant matches the policy's actual intent.
-- ============================================================================
REVOKE INSERT ON public.community_routes FROM anon;
