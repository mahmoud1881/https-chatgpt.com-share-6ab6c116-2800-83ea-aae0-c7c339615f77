ALTER POLICY "routes admin write"
ON public.routes
TO authenticated;

ALTER POLICY "route_stops admin write"
ON public.route_stops
TO authenticated;

ALTER POLICY "stops admin write"
ON public.stops
TO authenticated;

ALTER POLICY "stop_aliases admin write"
ON public.stop_aliases
TO authenticated;