
-- Restrict EXECUTE on newly created trigger-only functions so they can't be called directly via the API.
REVOKE EXECUTE ON FUNCTION public.tg_ai_cache_shared_size_guard() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.tg_live_pings_rate_limit()      FROM PUBLIC, anon, authenticated;
