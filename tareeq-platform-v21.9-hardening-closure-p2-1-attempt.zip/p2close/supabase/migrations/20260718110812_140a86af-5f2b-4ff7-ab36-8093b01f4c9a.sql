-- ============================================================
-- Route Requests (Growth Loop Engine #2) — reversible migration
-- Down migration:
--   DROP TABLE IF EXISTS public.route_requests;
--   DROP TYPE  IF EXISTS public.route_request_status;
-- ============================================================

-- 1) Enum for status
DO $$ BEGIN
  CREATE TYPE public.route_request_status AS ENUM
    ('pending','under_review','published','rejected','duplicate');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- 2) Table
CREATE TABLE public.route_requests (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_text         text NOT NULL,
  to_text           text NOT NULL,
  normalized_key    text NOT NULL,
  area_hint         text,
  details           text,
  status            public.route_request_status NOT NULL DEFAULT 'pending',
  source            text NOT NULL DEFAULT 'web',
  locale            text NOT NULL DEFAULT 'ar',
  hit_count         integer NOT NULL DEFAULT 1,
  created_by        uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  duplicate_of      uuid REFERENCES public.route_requests(id) ON DELETE SET NULL,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT route_requests_from_len    CHECK (char_length(from_text) BETWEEN 1 AND 120),
  CONSTRAINT route_requests_to_len      CHECK (char_length(to_text)   BETWEEN 1 AND 120),
  CONSTRAINT route_requests_details_len CHECK (details    IS NULL OR char_length(details)   <= 300),
  CONSTRAINT route_requests_area_len    CHECK (area_hint  IS NULL OR char_length(area_hint) <= 80),
  CONSTRAINT route_requests_source_len  CHECK (char_length(source) <= 40),
  CONSTRAINT route_requests_locale_len  CHECK (char_length(locale) <= 8),
  CONSTRAINT route_requests_hit_positive CHECK (hit_count >= 1)
);

-- 3) Indexes
CREATE INDEX idx_route_requests_normalized_key ON public.route_requests(normalized_key);
CREATE INDEX idx_route_requests_created_at     ON public.route_requests(created_at DESC);
CREATE INDEX idx_route_requests_status         ON public.route_requests(status);
CREATE INDEX idx_route_requests_created_by     ON public.route_requests(created_by)
  WHERE created_by IS NOT NULL;

-- 4) Grants — NO anon grant. Anonymous inserts go via server function (service role).
GRANT SELECT, INSERT ON public.route_requests TO authenticated;
GRANT ALL ON public.route_requests TO service_role;

-- 5) RLS
ALTER TABLE public.route_requests ENABLE ROW LEVEL SECURITY;

-- Owner can read own rows
CREATE POLICY "route_requests: owner reads own"
  ON public.route_requests
  FOR SELECT
  TO authenticated
  USING (auth.uid() IS NOT NULL AND auth.uid() = created_by);

-- Admin can read all
CREATE POLICY "route_requests: admin reads all"
  ON public.route_requests
  FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- Authenticated user can insert ONLY their own pending row.
-- status is forced to 'pending' and duplicate_of must be NULL, blocking mass assignment.
CREATE POLICY "route_requests: authenticated inserts own pending"
  ON public.route_requests
  FOR INSERT
  TO authenticated
  WITH CHECK (
    created_by = auth.uid()
    AND status = 'pending'::public.route_request_status
    AND duplicate_of IS NULL
    AND hit_count = 1
  );

-- Admin full management (update/delete/select-all covered).
CREATE POLICY "route_requests: admin manages all"
  ON public.route_requests
  FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 6) Touch updated_at trigger (reuses existing helper)
CREATE TRIGGER trg_route_requests_touch_updated
  BEFORE UPDATE ON public.route_requests
  FOR EACH ROW EXECUTE FUNCTION public.tg_touch_updated_at();
