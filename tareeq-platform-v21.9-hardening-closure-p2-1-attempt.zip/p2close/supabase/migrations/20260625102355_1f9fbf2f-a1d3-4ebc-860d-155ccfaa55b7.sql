
REVOKE EXECUTE ON FUNCTION public.bump_answers_count() FROM anon, authenticated, public;
