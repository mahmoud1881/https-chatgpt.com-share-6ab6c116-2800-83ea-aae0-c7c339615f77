-- 1) Remove the broad public read policy on the base table
DROP POLICY IF EXISTS "Active reports are publicly readable" ON public.traffic_reports;

-- 2) Ensure anon has no direct read access to the reports table at all
REVOKE ALL ON public.traffic_reports FROM anon;

-- 3) Public feed is served by a coarse-only, definer-scoped function
CREATE OR REPLACE FUNCTION public.get_public_traffic_reports(p_country text DEFAULT NULL, p_limit integer DEFAULT 200)
RETURNS TABLE (
  id uuid,
  area text,
  severity text,
  notes text,
  country text,
  lat_coarse double precision,
  lng_coarse double precision,
  created_at timestamptz,
  expires_at timestamptz
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT t.id, t.area, t.severity, t.notes, t.country,
         t.lat_coarse, t.lng_coarse, t.created_at, t.expires_at
  FROM public.traffic_reports t
  WHERE t.expires_at > now()
    AND (p_country IS NULL OR t.country = p_country)
  ORDER BY t.created_at DESC
  LIMIT LEAST(GREATEST(COALESCE(p_limit, 200), 1), 500)
$$;

REVOKE ALL ON FUNCTION public.get_public_traffic_reports(text, integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_public_traffic_reports(text, integer) TO anon, authenticated;
GRANT ALL ON public.traffic_reports TO service_role;