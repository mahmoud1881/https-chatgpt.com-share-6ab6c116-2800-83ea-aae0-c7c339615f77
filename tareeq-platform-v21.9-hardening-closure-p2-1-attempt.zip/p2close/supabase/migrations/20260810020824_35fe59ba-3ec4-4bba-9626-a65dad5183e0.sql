ALTER VIEW public.traffic_reports_public SET (security_invoker = on);

REVOKE SELECT ON public.traffic_reports FROM anon;
REVOKE SELECT ON public.traffic_reports FROM authenticated;

GRANT SELECT (id, area, severity, notes, country, lat_coarse, lng_coarse, created_at, expires_at)
  ON public.traffic_reports TO anon, authenticated;

DROP POLICY IF EXISTS "Active reports are publicly readable" ON public.traffic_reports;
CREATE POLICY "Active reports are publicly readable"
  ON public.traffic_reports
  FOR SELECT
  TO anon, authenticated
  USING (expires_at > now());

DO $$
BEGIN
  BEGIN
    EXECUTE 'ALTER TABLE public.spatial_ref_sys ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS "spatial_ref_sys is read-only reference data" ON public.spatial_ref_sys';
    EXECUTE 'CREATE POLICY "spatial_ref_sys is read-only reference data" ON public.spatial_ref_sys FOR SELECT TO anon, authenticated USING (true)';
  EXCEPTION WHEN insufficient_privilege THEN
    RAISE NOTICE 'skipping spatial_ref_sys: owned by extension superuser';
  END;
END $$;