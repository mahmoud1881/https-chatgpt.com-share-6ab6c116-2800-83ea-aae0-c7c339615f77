CREATE TABLE public.live_vehicle_pings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  route_id text NOT NULL,
  session_id text NOT NULL,
  lat double precision NOT NULL,
  lng double precision NOT NULL,
  heading double precision,
  speed_kmh double precision,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX live_vehicle_pings_route_recent
  ON public.live_vehicle_pings (route_id, created_at DESC);

GRANT SELECT, INSERT ON public.live_vehicle_pings TO anon;
GRANT SELECT, INSERT ON public.live_vehicle_pings TO authenticated;
GRANT ALL ON public.live_vehicle_pings TO service_role;

ALTER TABLE public.live_vehicle_pings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone can read recent pings"
  ON public.live_vehicle_pings FOR SELECT
  USING (created_at > now() - interval '15 minutes');

CREATE POLICY "anyone can insert pings"
  ON public.live_vehicle_pings FOR INSERT
  WITH CHECK (
    lat BETWEEN -90 AND 90
    AND lng BETWEEN -180 AND 180
    AND char_length(route_id) BETWEEN 1 AND 64
    AND char_length(session_id) BETWEEN 4 AND 64
  );

ALTER PUBLICATION supabase_realtime ADD TABLE public.live_vehicle_pings;