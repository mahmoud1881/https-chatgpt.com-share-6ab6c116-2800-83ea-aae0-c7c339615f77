CREATE POLICY "public read active routes"
ON public.routes
FOR SELECT
TO anon, authenticated
USING (status = 'active');

CREATE POLICY "public read active route_stops"
ON public.route_stops
FOR SELECT
TO anon, authenticated
USING (
  EXISTS (
    SELECT 1
    FROM public.routes r
    WHERE r.id = route_stops.route_id
      AND r.status = 'active'
  )
);