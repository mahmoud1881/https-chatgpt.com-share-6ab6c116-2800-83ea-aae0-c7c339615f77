
-- Route Verifications: نظام مساهمات المستخدمين لتصحيح بيانات الرحلات
-- لا يعدّل جداول النقل الحالية. مساهمات تدخل pending، لا كتابة عامة مباشرة.

-- 1) Enums
DO $$ BEGIN
  CREATE TYPE public.route_verification_type AS ENUM (
    'confirmed', 'fare_changed', 'pickup_changed',
    'line_stopped', 'better_alternative', 'not_tried'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.route_verification_status AS ENUM (
    'pending', 'corroborated', 'approved', 'rejected', 'duplicate', 'expired'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- 2) Main table
CREATE TABLE IF NOT EXISTS public.route_verifications (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  route_reference       text NOT NULL,
  route_id              uuid REFERENCES public.routes(id) ON DELETE SET NULL,
  verification_type     public.route_verification_type NOT NULL,
  proposed_value_json   jsonb,
  note                  text,
  status                public.route_verification_status NOT NULL DEFAULT 'pending',
  source                text NOT NULL DEFAULT 'search_result',
  locale                text NOT NULL DEFAULT 'ar',
  duplicate_key         text NOT NULL,
  corroboration_count   integer NOT NULL DEFAULT 1,
  created_by            uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at            timestamptz NOT NULL DEFAULT now(),
  expires_at            timestamptz NOT NULL DEFAULT (now() + interval '90 days'),
  reviewer_id           uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  reviewed_at           timestamptz,
  review_note           text,
  CONSTRAINT rv_note_len CHECK (note IS NULL OR char_length(note) <= 300),
  CONSTRAINT rv_locale_ck CHECK (locale IN ('ar','en')),
  CONSTRAINT rv_route_ref_len CHECK (char_length(route_reference) BETWEEN 3 AND 200)
);

CREATE INDEX IF NOT EXISTS idx_rv_route_ref_type_status
  ON public.route_verifications (route_reference, verification_type, status);
CREATE INDEX IF NOT EXISTS idx_rv_status_created
  ON public.route_verifications (status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_rv_created_by
  ON public.route_verifications (created_by) WHERE created_by IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uniq_rv_active_duplicate_key
  ON public.route_verifications (duplicate_key)
  WHERE status IN ('pending','corroborated');

GRANT SELECT, INSERT, UPDATE ON public.route_verifications TO authenticated;
GRANT ALL ON public.route_verifications TO service_role;
-- لا GRANT للـ anon مباشرة؛ الإدخال العام يمر عبر server function

ALTER TABLE public.route_verifications ENABLE ROW LEVEL SECURITY;

-- SELECT: صاحب المساهمة يرى مساهمته، الأدمن يرى الكل
CREATE POLICY "rv owner or admin read"
  ON public.route_verifications FOR SELECT TO authenticated
  USING (
    (created_by IS NOT NULL AND created_by = auth.uid())
    OR public.has_role(auth.uid(), 'admin'::public.app_role)
  );

-- INSERT: أدمن فقط عبر client مباشرة. الإدخال العام يتم عبر server function
-- (server function يستخدم supabaseAdmin بعد validation صارم)
CREATE POLICY "rv admin insert"
  ON public.route_verifications FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));

-- UPDATE: أدمن فقط (لتغيير status/reviewer)
CREATE POLICY "rv admin update"
  ON public.route_verifications FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));

-- 3) Audit log للإجراءات الإدارية (rollback source of truth)
CREATE TABLE IF NOT EXISTS public.route_verifications_audit (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  verification_id  uuid NOT NULL REFERENCES public.route_verifications(id) ON DELETE CASCADE,
  from_status      public.route_verification_status,
  to_status        public.route_verification_status NOT NULL,
  actor_id         uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  reason           text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT rva_reason_len CHECK (reason IS NULL OR char_length(reason) <= 500)
);

CREATE INDEX IF NOT EXISTS idx_rva_verification ON public.route_verifications_audit (verification_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_rva_actor ON public.route_verifications_audit (actor_id, created_at DESC);

GRANT SELECT, INSERT ON public.route_verifications_audit TO authenticated;
GRANT ALL ON public.route_verifications_audit TO service_role;

ALTER TABLE public.route_verifications_audit ENABLE ROW LEVEL SECURITY;

CREATE POLICY "rva admin read" ON public.route_verifications_audit
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "rva admin insert" ON public.route_verifications_audit
  FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role) AND actor_id = auth.uid());

-- 4) Trigger: تسجيل تلقائي لتغيير الحالة في audit
CREATE OR REPLACE FUNCTION public.tg_rv_audit_status_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO public.route_verifications_audit
      (verification_id, from_status, to_status, actor_id, reason)
    VALUES
      (NEW.id, OLD.status, NEW.status, auth.uid(), NEW.review_note);
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_rv_audit_status_change ON public.route_verifications;
CREATE TRIGGER trg_rv_audit_status_change
  AFTER UPDATE ON public.route_verifications
  FOR EACH ROW EXECUTE FUNCTION public.tg_rv_audit_status_change();

-- 5) Rate limiting counter per contributor fingerprint (hashed, no raw IP)
CREATE TABLE IF NOT EXISTS public.route_verifications_rate (
  fingerprint   text NOT NULL,
  bucket_day    date NOT NULL DEFAULT (now() AT TIME ZONE 'UTC')::date,
  count         integer NOT NULL DEFAULT 0,
  updated_at    timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (fingerprint, bucket_day)
);

GRANT ALL ON public.route_verifications_rate TO service_role;
ALTER TABLE public.route_verifications_rate ENABLE ROW LEVEL SECURITY;
-- لا policies: فقط service_role يصل عبر server function

-- 6) has_role مسموح للـ authenticated (تأكيد؛ لا يغير أي RLS قائم)
