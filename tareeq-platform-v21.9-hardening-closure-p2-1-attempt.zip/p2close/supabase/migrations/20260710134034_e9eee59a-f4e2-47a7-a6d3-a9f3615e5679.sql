
-- ============================================================
-- 1) ai_cache_shared: admin-only writes + value size cap
-- ============================================================
DROP POLICY IF EXISTS "shared cache write" ON public.ai_cache_shared;
DROP POLICY IF EXISTS "shared cache update" ON public.ai_cache_shared;

CREATE POLICY "shared cache admin insert"
  ON public.ai_cache_shared
  FOR INSERT
  TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin') AND expires_at > now());

CREATE POLICY "shared cache admin update"
  ON public.ai_cache_shared
  FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') AND expires_at > now());

-- Cap serialized value size at ~200KB even for admin writes.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'ai_cache_shared_value_size_chk'
  ) THEN
    -- Use trigger instead of CHECK because pg_column_size is not immutable-safe in all versions.
    CREATE OR REPLACE FUNCTION public.tg_ai_cache_shared_size_guard()
    RETURNS trigger
    LANGUAGE plpgsql
    SET search_path = public
    AS $fn$
    BEGIN
      IF pg_column_size(NEW.value) > 204800 THEN
        RAISE EXCEPTION 'ai_cache_shared.value exceeds 200KB size limit';
      END IF;
      RETURN NEW;
    END;
    $fn$;

    DROP TRIGGER IF EXISTS ai_cache_shared_size_guard ON public.ai_cache_shared;
    CREATE TRIGGER ai_cache_shared_size_guard
      BEFORE INSERT OR UPDATE ON public.ai_cache_shared
      FOR EACH ROW EXECUTE FUNCTION public.tg_ai_cache_shared_size_guard();
  END IF;
END $$;

-- ============================================================
-- 2) community_questions & community_answers: no anon INSERTs
-- ============================================================
REVOKE INSERT ON public.community_questions FROM anon;
REVOKE INSERT ON public.community_answers   FROM anon;

-- Drop any anon INSERT policies if they exist, then reinstate as authenticated-only.
DO $$
DECLARE p RECORD;
BEGIN
  FOR p IN
    SELECT policyname, tablename FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename IN ('community_questions', 'community_answers')
      AND cmd = 'INSERT'
      AND 'anon' = ANY(roles)
  LOOP
    EXECUTE format('DROP POLICY %I ON public.%I', p.policyname, p.tablename);
  END LOOP;
END $$;

-- Ensure a clean authenticated INSERT policy exists for both.
DROP POLICY IF EXISTS "authenticated can insert questions" ON public.community_questions;
CREATE POLICY "authenticated can insert questions"
  ON public.community_questions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "authenticated can insert answers" ON public.community_answers;
CREATE POLICY "authenticated can insert answers"
  ON public.community_answers
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

-- ============================================================
-- 3) live_vehicle_pings: per-session rate limit (1 ping / second)
-- ============================================================
CREATE OR REPLACE FUNCTION public.tg_live_pings_rate_limit()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM public.live_vehicle_pings
    WHERE session_id = NEW.session_id
      AND created_at > now() - interval '1 second'
  ) THEN
    RAISE EXCEPTION 'rate_limited: max 1 ping per second per session';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS live_pings_rate_limit ON public.live_vehicle_pings;
CREATE TRIGGER live_pings_rate_limit
  BEFORE INSERT ON public.live_vehicle_pings
  FOR EACH ROW EXECUTE FUNCTION public.tg_live_pings_rate_limit();

CREATE INDEX IF NOT EXISTS live_vehicle_pings_session_created_idx
  ON public.live_vehicle_pings (session_id, created_at DESC);

-- ============================================================
-- 4) missing_searches: revoke anon UPDATE
-- ============================================================
REVOKE UPDATE ON public.missing_searches FROM anon;

-- ============================================================
-- 5) routes: public view shows verified only
-- ============================================================
DROP POLICY IF EXISTS "public read active routes" ON public.routes;
CREATE POLICY "public read verified active routes"
  ON public.routes
  FOR SELECT
  TO anon, authenticated
  USING (status = 'active' AND is_verified = true);

-- Admin path to see unverified routes too.
DROP POLICY IF EXISTS "admin read all routes" ON public.routes;
CREATE POLICY "admin read all routes"
  ON public.routes
  FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- ============================================================
-- 6) Performance: partial index on active routes
-- ============================================================
CREATE INDEX IF NOT EXISTS routes_status_active_idx
  ON public.routes (status)
  WHERE status = 'active';
