-- Fix search performance with better trigram indexes on routes
CREATE INDEX IF NOT EXISTS idx_routes_route_name_trgm 
  ON public.routes USING gin (route_name public.gin_trgm_ops);

CREATE INDEX IF NOT EXISTS idx_routes_route_code_trgm 
  ON public.routes USING gin (route_code public.gin_trgm_ops);

GRANT SELECT ON public.routes TO authenticated, anon;
