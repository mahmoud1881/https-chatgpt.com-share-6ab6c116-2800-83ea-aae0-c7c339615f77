-- P1: make admin manual route publication atomic across routes + route_stops.
-- Stop geocoding/upserts happen before this boundary; the route publication
-- itself is all-or-nothing, so an existing route can never be left with an
-- empty/partial stop list after a failed write.
CREATE OR REPLACE FUNCTION public.upsert_route_with_stops_atomic(
  p_route_code text,
  p_route_name text,
  p_transport_type_id text,
  p_country text,
  p_city text,
  p_start_stop_id uuid,
  p_end_stop_id uuid,
  p_is_verified boolean,
  p_status text,
  p_source text,
  p_source_file text,
  p_has_intermediate_stops boolean,
  p_notes text,
  p_stop_ids uuid[]
) RETURNS TABLE (route_id uuid, action text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_route_id uuid;
  v_action text;
  v_existing boolean;
BEGIN
  IF NULLIF(trim(p_route_code), '') IS NULL THEN RAISE EXCEPTION 'route_code_required'; END IF;
  IF NULLIF(trim(p_route_name), '') IS NULL THEN RAISE EXCEPTION 'route_name_required'; END IF;
  IF NULLIF(trim(p_country), '') IS NULL THEN RAISE EXCEPTION 'country_required'; END IF;
  IF NULLIF(trim(p_city), '') IS NULL THEN RAISE EXCEPTION 'city_required'; END IF;
  IF p_stop_ids IS NULL OR cardinality(p_stop_ids) < 2 THEN RAISE EXCEPTION 'at_least_two_stops_required'; END IF;

  PERFORM pg_advisory_xact_lock(
    hashtextextended('admin-route:' || lower(p_country) || ':' || p_city || ':' || p_route_code, 0)
  );

  SELECT id INTO v_route_id
  FROM public.routes
  WHERE country = lower(p_country) AND city = p_city AND route_code = p_route_code
  LIMIT 1;
  v_existing := v_route_id IS NOT NULL;

  IF v_existing THEN
    UPDATE public.routes
       SET route_name = p_route_name,
           transport_type_id = p_transport_type_id,
           start_stop_id = p_start_stop_id,
           end_stop_id = p_end_stop_id,
           country = lower(p_country),
           city = p_city,
           is_verified = p_is_verified,
           status = p_status,
           source = p_source,
           source_file = p_source_file,
           has_intermediate_stops = p_has_intermediate_stops,
           notes = p_notes,
           updated_at = now()
     WHERE id = v_route_id;
    v_action := 'updated';
  ELSE
    INSERT INTO public.routes (
      route_code, route_name, transport_type_id, start_stop_id, end_stop_id,
      country, city, is_verified, status, source, source_file,
      has_intermediate_stops, notes
    ) VALUES (
      p_route_code, p_route_name, p_transport_type_id, p_start_stop_id, p_end_stop_id,
      lower(p_country), p_city, p_is_verified, p_status, p_source, p_source_file,
      p_has_intermediate_stops, p_notes
    ) RETURNING id INTO v_route_id;
    v_action := 'created';
  END IF;

  DELETE FROM public.route_stops WHERE route_id = v_route_id;

  INSERT INTO public.route_stops (route_id, stop_id, stop_order, direction)
  SELECT v_route_id, sid, ord - 1, 'forward'::text
  FROM unnest(p_stop_ids) WITH ORDINALITY AS t(sid, ord);

  route_id := v_route_id;
  action := v_action;
  RETURN NEXT;
END;
$$;

REVOKE ALL ON FUNCTION public.upsert_route_with_stops_atomic(
  text, text, text, text, text, uuid, uuid, boolean, text, text, text, boolean, text, uuid[]
) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.upsert_route_with_stops_atomic(
  text, text, text, text, text, uuid, uuid, boolean, text, text, text, boolean, text, uuid[]
) TO service_role;
