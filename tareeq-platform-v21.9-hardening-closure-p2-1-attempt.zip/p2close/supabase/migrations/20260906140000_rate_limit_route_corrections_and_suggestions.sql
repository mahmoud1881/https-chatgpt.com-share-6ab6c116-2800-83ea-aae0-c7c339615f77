-- ============================================================================
-- Full-system audit finding: 20260906120000_rate_limit_client_direct_inserts
-- covered traffic_reports, live_vehicle_pings, and community_routes, but two
-- more tables are written directly from the browser via the Supabase client
-- (bypassing src/lib/rate-limit.ts the same way) and were missed:
--   - public.route_corrections      (src/routes/planner.tsx)
--   - public.user_route_suggestions (src/routes/planner.tsx)
-- Both are authenticated-only (WITH CHECK (auth.uid() = user_id), no anon
-- grant) — unlike live_vehicle_pings, there is no anonymous-access nuance
-- here, so auth.uid() is a safe, unspoofable identifier directly.
-- ============================================================================

-- --- route_corrections: max 20 corrections / hour per user ---
CREATE OR REPLACE FUNCTION public.rl_route_corrections_insert() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.enforce_rate_limit('route_corrections_insert', auth.uid()::text, 20, interval '1 hour');
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_rate_limit_route_corrections_insert ON public.route_corrections;
CREATE TRIGGER trg_rate_limit_route_corrections_insert
  BEFORE INSERT ON public.route_corrections
  FOR EACH ROW EXECUTE FUNCTION public.rl_route_corrections_insert();

-- --- user_route_suggestions: max 20 suggestions / hour per user ---
CREATE OR REPLACE FUNCTION public.rl_user_route_suggestions_insert() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.enforce_rate_limit('user_route_suggestions_insert', auth.uid()::text, 20, interval '1 hour');
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_rate_limit_user_route_suggestions_insert ON public.user_route_suggestions;
CREATE TRIGGER trg_rate_limit_user_route_suggestions_insert
  BEFORE INSERT ON public.user_route_suggestions
  FOR EACH ROW EXECUTE FUNCTION public.rl_user_route_suggestions_insert();
