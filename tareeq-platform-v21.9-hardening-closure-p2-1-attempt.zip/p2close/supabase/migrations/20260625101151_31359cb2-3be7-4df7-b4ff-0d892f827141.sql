CREATE TABLE public.traffic_reports (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  area TEXT NOT NULL,
  severity TEXT NOT NULL,
  notes TEXT,
  lat DOUBLE PRECISION,
  lng DOUBLE PRECISION,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (now() + interval '4 hours'),
  CONSTRAINT traffic_reports_area_len CHECK (char_length(area) BETWEEN 1 AND 120),
  CONSTRAINT traffic_reports_notes_len CHECK (notes IS NULL OR char_length(notes) <= 280),
  CONSTRAINT traffic_reports_severity_chk CHECK (severity IN ('clear','medium','heavy','stuck'))
);

CREATE INDEX traffic_reports_expires_at_idx ON public.traffic_reports (expires_at DESC);

GRANT SELECT, INSERT ON public.traffic_reports TO anon;
GRANT SELECT, INSERT ON public.traffic_reports TO authenticated;
GRANT ALL ON public.traffic_reports TO service_role;

ALTER TABLE public.traffic_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read active traffic reports"
  ON public.traffic_reports FOR SELECT
  USING (expires_at > now());

CREATE POLICY "Anyone can submit a traffic report"
  ON public.traffic_reports FOR INSERT
  WITH CHECK (true);