-- M11: إضافة عمود `provenance` (JSONB) لتتبع مصدر البيانات وتاريخ التحقق
-- على الجداول الحساسة: stops, routes, community_routes.
--
-- شكل الحمولة المتوقّع (غير مُلزم على مستوى القاعدة، مُوثَّق فقط):
-- {
--   "source": "gtfs" | "osm" | "official" | "community" | "ai" | "manual" | "import:<name>",
--   "source_url": "https://...",         -- اختياري
--   "verified_by": "<uuid|handle>",       -- اختياري
--   "verified_at": "2026-07-12T10:00:00Z",-- اختياري
--   "confidence": 0.0..1.0,               -- اختياري
--   "notes": "..."                        -- اختياري
-- }

ALTER TABLE public.stops
  ADD COLUMN IF NOT EXISTS provenance jsonb NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE public.routes
  ADD COLUMN IF NOT EXISTS provenance jsonb NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE public.community_routes
  ADD COLUMN IF NOT EXISTS provenance jsonb NOT NULL DEFAULT '{}'::jsonb;

-- قيود شكل خفيفة: لا نُلزم بمفاتيح محددة، لكن نمنع أنواعاً غير كائن.
ALTER TABLE public.stops
  DROP CONSTRAINT IF EXISTS stops_provenance_is_object;
ALTER TABLE public.stops
  ADD CONSTRAINT stops_provenance_is_object
  CHECK (jsonb_typeof(provenance) = 'object');

ALTER TABLE public.routes
  DROP CONSTRAINT IF EXISTS routes_provenance_is_object;
ALTER TABLE public.routes
  ADD CONSTRAINT routes_provenance_is_object
  CHECK (jsonb_typeof(provenance) = 'object');

ALTER TABLE public.community_routes
  DROP CONSTRAINT IF EXISTS community_routes_provenance_is_object;
ALTER TABLE public.community_routes
  ADD CONSTRAINT community_routes_provenance_is_object
  CHECK (jsonb_typeof(provenance) = 'object');

-- فهارس GIN لتسريع الاستعلامات على المفاتيح (source, verified_at ...)
CREATE INDEX IF NOT EXISTS stops_provenance_gin
  ON public.stops USING gin (provenance jsonb_path_ops);

CREATE INDEX IF NOT EXISTS routes_provenance_gin
  ON public.routes USING gin (provenance jsonb_path_ops);

CREATE INDEX IF NOT EXISTS community_routes_provenance_gin
  ON public.community_routes USING gin (provenance jsonb_path_ops);

COMMENT ON COLUMN public.stops.provenance IS
  'مصدر البيانات: {source, source_url, verified_by, verified_at, confidence, notes}';
COMMENT ON COLUMN public.routes.provenance IS
  'مصدر البيانات: {source, source_url, verified_by, verified_at, confidence, notes}';
COMMENT ON COLUMN public.community_routes.provenance IS
  'مصدر البيانات: {source, source_url, verified_by, verified_at, confidence, notes}';