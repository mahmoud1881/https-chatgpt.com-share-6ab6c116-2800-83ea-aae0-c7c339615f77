-- 1) Real-time pings tables: authenticated SELECT only.
DROP POLICY IF EXISTS "read live pings" ON public.live_vehicle_pings;
CREATE POLICY "Authenticated can read live pings"
  ON public.live_vehicle_pings FOR SELECT TO authenticated USING (true);
REVOKE SELECT ON public.live_vehicle_pings FROM anon;

DROP POLICY IF EXISTS "read grand taxi pings" ON public.ma_grand_taxi_pings;
CREATE POLICY "Authenticated can read grand taxi pings"
  ON public.ma_grand_taxi_pings FOR SELECT TO authenticated USING (true);
REVOKE SELECT ON public.ma_grand_taxi_pings FROM anon;

DROP POLICY IF EXISTS "read tram pings" ON public.ma_tram_pings;
CREATE POLICY "Authenticated can read tram pings"
  ON public.ma_tram_pings FOR SELECT TO authenticated USING (true);
REVOKE SELECT ON public.ma_tram_pings FROM anon;

DROP POLICY IF EXISTS "read traffic reports" ON public.traffic_reports;
CREATE POLICY "Authenticated can read traffic reports"
  ON public.traffic_reports FOR SELECT TO authenticated USING (true);
REVOKE SELECT ON public.traffic_reports FROM anon;

-- 2) Shared AI cache: authenticated only.
DROP POLICY IF EXISTS "shared cache read" ON public.ai_cache_shared;
CREATE POLICY "Authenticated read shared cache"
  ON public.ai_cache_shared FOR SELECT TO authenticated USING (expires_at > now());
REVOKE SELECT ON public.ai_cache_shared FROM anon;

-- 3) Community tables: SECURITY INVOKER views omitting user_id.
CREATE OR REPLACE VIEW public.community_questions_public
  WITH (security_invoker=on) AS
  SELECT id, title, body, author_name, answers_count, country, created_at
  FROM public.community_questions;
CREATE OR REPLACE VIEW public.community_answers_public
  WITH (security_invoker=on) AS
  SELECT id, question_id, body, author_name, country, created_at
  FROM public.community_answers;
CREATE OR REPLACE VIEW public.community_routes_public
  WITH (security_invoker=on) AS
  SELECT id, title, from_area, to_area, price_egp, duration_min, status, confirmations, country, created_at
  FROM public.community_routes;

GRANT SELECT ON public.community_questions_public TO anon, authenticated;
GRANT SELECT ON public.community_answers_public   TO anon, authenticated;
GRANT SELECT ON public.community_routes_public    TO anon, authenticated;

-- Restrict base table SELECT to authenticated (so anon must go via views).
DROP POLICY IF EXISTS "read all questions" ON public.community_questions;
CREATE POLICY "Authenticated read questions"
  ON public.community_questions FOR SELECT TO authenticated USING (true);
REVOKE SELECT ON public.community_questions FROM anon;

DROP POLICY IF EXISTS "read all answers" ON public.community_answers;
CREATE POLICY "Authenticated read answers"
  ON public.community_answers FOR SELECT TO authenticated USING (true);
REVOKE SELECT ON public.community_answers FROM anon;

DROP POLICY IF EXISTS "read all community routes" ON public.community_routes;
CREATE POLICY "Authenticated read community routes"
  ON public.community_routes FOR SELECT TO authenticated USING (true);
REVOKE SELECT ON public.community_routes FROM anon;

-- 4) SECURITY DEFINER helpers: revoke public EXECUTE.
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.get_admin_stats() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_admin_stats() TO authenticated;

REVOKE EXECUTE ON FUNCTION public.start_session(text, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.start_session(text, text) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.end_session(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.end_session(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.heartbeat_session(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.heartbeat_session(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.log_ai_usage(text, text, integer, integer, integer, boolean, integer, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.log_ai_usage(text, text, integer, integer, integer, boolean, integer, text) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;