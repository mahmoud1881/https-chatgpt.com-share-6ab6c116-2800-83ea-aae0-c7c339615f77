
-- Add user_id to live_vehicle_pings for ownership binding
ALTER TABLE public.live_vehicle_pings ADD COLUMN IF NOT EXISTS user_id uuid;

-- Tighten INSERT policies to bind row ownership to auth.uid()
DROP POLICY IF EXISTS "signed-in can post pings" ON public.live_vehicle_pings;
CREATE POLICY "signed-in can post pings" ON public.live_vehicle_pings
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "signed-in can post grand taxi pings" ON public.ma_grand_taxi_pings;
CREATE POLICY "signed-in can post grand taxi pings" ON public.ma_grand_taxi_pings
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = reported_by);

DROP POLICY IF EXISTS "signed-in can post tram pings" ON public.ma_tram_pings;
CREATE POLICY "signed-in can post tram pings" ON public.ma_tram_pings
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Owner-scoped UPDATE/DELETE for community tables
CREATE POLICY "owners update own answers" ON public.community_answers
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "owners delete own answers" ON public.community_answers
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "owners delete own questions" ON public.community_questions
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "owners update own routes" ON public.community_routes
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "owners delete own routes" ON public.community_routes
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);
