-- ============================================================================
-- Remove the platform-wide global cap in traffic_reports_rate_limit()
-- (20260625165930): no more than 30 INSERTs per minute across every user
-- and every area combined. Triggers execute unconditionally alongside each
-- other (unlike RLS policies, which OR-combine) — this fires on every
-- insert together with the per-user (20/10min, authenticated) and per-IP/
-- shared-bucket (anonymous) limits added on 2026-09-06, and any one of the
-- three rejecting blocks the whole insert.
--
-- The global cap protected against exactly the two attack shapes the newer
-- per-identity limits already cover directly (many accounts, many anon
-- IPs), but does so by capping *total legitimate traffic* instead of any
-- single bad actor. During a real shared incident (flooding, a protest
-- blocking a route) where dozens of distinct real users each send one or
-- two genuine reports within the same minute, this rejects the 31st
-- legitimate report with no way to distinguish it from abuse — the exact
-- audience the feature exists for.
--
-- Kept as-is: the same-area 30-second duplicate throttle. That one solves a
-- different problem (decluttering repeated pins for the same spot) and
-- isn't a per-user/per-volume limit, so it doesn't have this failure mode.
-- ============================================================================

CREATE OR REPLACE FUNCTION public.traffic_reports_rate_limit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE same_area_recent INT;
BEGIN
  SELECT count(*) INTO same_area_recent FROM public.traffic_reports
   WHERE lower(area)=lower(NEW.area) AND created_at > now() - interval '30 seconds';
  IF same_area_recent >= 1 THEN
    RAISE EXCEPTION 'rate_limit: same area reported too recently (wait 30s)';
  END IF;
  RETURN NEW;
END;
$$;

-- Trigger already points at this function name (unchanged) — CREATE OR
-- REPLACE above is sufficient, no DROP/CREATE TRIGGER needed.
