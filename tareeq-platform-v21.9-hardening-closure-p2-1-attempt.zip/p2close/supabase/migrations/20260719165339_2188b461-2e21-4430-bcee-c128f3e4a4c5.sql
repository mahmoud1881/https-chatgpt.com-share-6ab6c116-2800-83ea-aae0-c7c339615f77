ALTER TABLE public.route_requests
  ADD COLUMN IF NOT EXISTS internal_note text,
  ADD COLUMN IF NOT EXISTS reviewed_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS reviewed_at timestamptz,
  ADD COLUMN IF NOT EXISTS linked_route_id uuid REFERENCES public.routes(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS route_requests_status_created_idx
  ON public.route_requests (status, created_at DESC);

CREATE INDEX IF NOT EXISTS route_requests_normalized_key_idx
  ON public.route_requests (normalized_key);