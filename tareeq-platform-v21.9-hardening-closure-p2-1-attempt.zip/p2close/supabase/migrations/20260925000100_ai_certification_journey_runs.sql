-- Runtime certification evidence sink. Not a user journey table.
CREATE TABLE IF NOT EXISTS public.ai_certification_journey_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  certification_run_id text NOT NULL,
  place_id text NOT NULL,
  route_ref text NOT NULL,
  geo_ref text NOT NULL,
  dry_run boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.ai_certification_journey_runs ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.ai_certification_journey_runs FROM anon, authenticated;
CREATE INDEX IF NOT EXISTS ai_certification_journey_runs_run_idx ON public.ai_certification_journey_runs(certification_run_id, created_at DESC);
