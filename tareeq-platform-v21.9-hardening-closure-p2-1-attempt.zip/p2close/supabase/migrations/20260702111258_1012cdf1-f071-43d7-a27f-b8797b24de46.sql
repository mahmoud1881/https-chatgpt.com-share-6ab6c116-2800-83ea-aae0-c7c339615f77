-- Privacy hardening: expose only non-identifying columns to public reads,
-- and restrict base-table SELECT to the row owner.
-- Uses default (security_invoker=off) views so anon reads bypass base RLS
-- via the view; base tables no longer have anon SELECT policies.

-- ============ live_vehicle_pings ============
CREATE OR REPLACE VIEW public.live_vehicle_pings_public AS
  SELECT id, route_id, session_id, lat, lng, heading, speed_kmh, country, created_at
  FROM public.live_vehicle_pings;
GRANT SELECT ON public.live_vehicle_pings_public TO anon, authenticated;

DROP POLICY IF EXISTS "read live pings" ON public.live_vehicle_pings;
CREATE POLICY "Owners can read own live pings"
  ON public.live_vehicle_pings FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- ============ ma_grand_taxi_pings ============
CREATE OR REPLACE VIEW public.ma_grand_taxi_pings_public AS
  SELECT id, route_id, seats_remaining, total_seats, note, station_id,
         country, reported_at, created_at
  FROM public.ma_grand_taxi_pings;
GRANT SELECT ON public.ma_grand_taxi_pings_public TO anon, authenticated;

DROP POLICY IF EXISTS "read grand taxi pings" ON public.ma_grand_taxi_pings;
CREATE POLICY "Reporters can read own grand taxi pings"
  ON public.ma_grand_taxi_pings FOR SELECT
  TO authenticated
  USING (auth.uid() = reported_by);

-- ============ ma_tram_pings ============
CREATE OR REPLACE VIEW public.ma_tram_pings_public AS
  SELECT id, line, station_id, crowd_level, delay_minutes, note,
         country, created_at
  FROM public.ma_tram_pings;
GRANT SELECT ON public.ma_tram_pings_public TO anon, authenticated;

DROP POLICY IF EXISTS "read tram pings" ON public.ma_tram_pings;
CREATE POLICY "Reporters can read own tram pings"
  ON public.ma_tram_pings FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- ============ traffic_reports ============
CREATE OR REPLACE VIEW public.traffic_reports_public AS
  SELECT id, area, severity, lat, lng, notes, country,
         created_at, expires_at
  FROM public.traffic_reports;
GRANT SELECT ON public.traffic_reports_public TO anon, authenticated;

DROP POLICY IF EXISTS "read traffic reports" ON public.traffic_reports;
CREATE POLICY "Owners can read own traffic reports"
  ON public.traffic_reports FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- ============ community_questions ============
CREATE OR REPLACE VIEW public.community_questions_public AS
  SELECT id, title, body, author_name, answers_count, country, created_at
  FROM public.community_questions;
GRANT SELECT ON public.community_questions_public TO anon, authenticated;

DROP POLICY IF EXISTS "read all questions" ON public.community_questions;
CREATE POLICY "Owners can read own questions"
  ON public.community_questions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- ============ community_answers ============
CREATE OR REPLACE VIEW public.community_answers_public AS
  SELECT id, question_id, body, author_name, country, created_at
  FROM public.community_answers;
GRANT SELECT ON public.community_answers_public TO anon, authenticated;

DROP POLICY IF EXISTS "read all answers" ON public.community_answers;
CREATE POLICY "Owners can read own answers"
  ON public.community_answers FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- ============ community_routes ============
CREATE OR REPLACE VIEW public.community_routes_public AS
  SELECT id, title, from_area, to_area, price_egp, duration_min,
         status, confirmations, country, created_at
  FROM public.community_routes;
GRANT SELECT ON public.community_routes_public TO anon, authenticated;

DROP POLICY IF EXISTS "read all community routes" ON public.community_routes;
CREATE POLICY "Owners can read own community routes"
  ON public.community_routes FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);
