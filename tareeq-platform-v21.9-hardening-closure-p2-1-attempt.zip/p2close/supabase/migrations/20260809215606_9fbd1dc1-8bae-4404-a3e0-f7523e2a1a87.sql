-- 1. Enable PostGIS extension
CREATE EXTENSION IF NOT EXISTS postgis;

-- 2. Add geography column to stops table 
ALTER TABLE public.stops ADD COLUMN IF NOT EXISTS location geography(Point, 4326) 
GENERATED ALWAYS AS (ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)::geography) STORED;

-- 3. Create GIST index for spatial queries
CREATE INDEX IF NOT EXISTS stops_location_gist_idx ON public.stops USING GIST (location);

-- 4. Add the same to live_vehicle_pings
ALTER TABLE public.live_vehicle_pings ADD COLUMN IF NOT EXISTS location geography(Point, 4326) 
GENERATED ALWAYS AS (ST_SetSRID(ST_MakePoint(lng, lat), 4326)::geography) STORED;

CREATE INDEX IF NOT EXISTS live_vehicle_pings_location_gist_idx ON public.live_vehicle_pings USING GIST (location);

-- 5. Grant permissions
GRANT SELECT (location) ON public.stops TO authenticated, anon;
GRANT SELECT (location) ON public.live_vehicle_pings TO authenticated, anon;

-- 6. Add helper function
CREATE OR REPLACE FUNCTION public.get_nearby_stops(user_lat float8, user_lng float8, max_dist_meters float8, max_results int DEFAULT 10)
RETURNS TABLE (
    id uuid,
    name_ar text,
    latitude float8,
    longitude float8,
    distance_meters float8
) 
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
    SELECT 
        s.id, 
        s.name_ar, 
        s.latitude, 
        s.longitude,
        ST_Distance(s.location, ST_SetSRID(ST_Point(user_lng, user_lat), 4326)::geography) as distance_meters
    FROM public.stops s
    WHERE ST_DWithin(s.location, ST_SetSRID(ST_Point(user_lng, user_lat), 4326)::geography, max_dist_meters)
    ORDER BY s.location <-> ST_SetSRID(ST_Point(user_lng, user_lat), 4326)::geography
    LIMIT max_results;
$$;

GRANT EXECUTE ON FUNCTION public.get_nearby_stops TO authenticated, anon;
