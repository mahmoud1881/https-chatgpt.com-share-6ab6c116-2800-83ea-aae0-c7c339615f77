DROP POLICY IF EXISTS "Authenticated can read traffic reports" ON public.traffic_reports;

CREATE POLICY "Users can read their own traffic reports"
ON public.traffic_reports
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE OR REPLACE VIEW public.traffic_reports_public
WITH (security_invoker = off) AS
SELECT id, area, severity, notes, lat, lng, country, created_at, expires_at
FROM public.traffic_reports;

GRANT SELECT ON public.traffic_reports_public TO anon, authenticated;
GRANT ALL ON public.traffic_reports_public TO service_role;