-- ============================================================================
-- المرحلة 5 — آخر مسارَي كتابة مفتوحَين لغير المسجّلين
--
-- استعلام على قاعدة البيانات المستعادة كاملةً (وليس بحثًا نصيًا في الملفات)
-- أثبت أن جدولين فقط في السكيما كلها يقبلان كتابة من anon:
--
--   SELECT table_name, privilege_type FROM information_schema.role_table_grants
--    WHERE table_schema='public' AND grantee='anon'
--      AND privilege_type IN ('INSERT','UPDATE','DELETE');
--   -> missing_searches | INSERT
--      search_logs      | INSERT
--
-- وكلاهما كان بلا أي trigger لتحديد المعدل، بينما السبعة الأخرى
-- (traffic_reports, live_vehicle_pings, community_*, route_corrections,
-- user_route_suggestions) محمية منذ migrations 20260906.
--
-- محدّد المعدل الموجود في src/lib/rate-limit.ts لا يغطيهما: فهو يعمل داخل
-- TanStack server functions فقط، ويقرأ ترويسات الطلب عبر
-- @tanstack/react-start/server. وهو يحمي مسار البحث العادي فعلًا (100
-- طلب/يوم)، لكنه يُتجاوَز كليًا بإرسال INSERT مباشرة إلى PostgREST من أي
-- عميل — وهو ما تسمح به منحة anon أعلاه.
--
-- الحدود هنا سخية عمدًا: هذان جدولا تحليلات (بحث فاشل / سجل بحث) يكتب
-- فيهما المستخدم العادي مرة لكل عملية بحث، فالسقف يوقف الإغراق الآلي دون
-- أن يمسّ استخدامًا بشريًا واقعيًا.
-- ============================================================================

CREATE OR REPLACE FUNCTION public.rl_search_logs_insert() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.enforce_rate_limit(
    'search_logs_insert',
    COALESCE(auth.uid()::text, public.rate_limit_anon_fallback_identifier()),
    120,
    interval '10 minutes'
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_rate_limit_search_logs_insert ON public.search_logs;
CREATE TRIGGER trg_rate_limit_search_logs_insert
  BEFORE INSERT ON public.search_logs
  FOR EACH ROW EXECUTE FUNCTION public.rl_search_logs_insert();

CREATE OR REPLACE FUNCTION public.rl_missing_searches_insert() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.enforce_rate_limit(
    'missing_searches_insert',
    COALESCE(auth.uid()::text, public.rate_limit_anon_fallback_identifier()),
    60,
    interval '10 minutes'
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_rate_limit_missing_searches_insert ON public.missing_searches;
CREATE TRIGGER trg_rate_limit_missing_searches_insert
  BEFORE INSERT ON public.missing_searches
  FOR EACH ROW EXECUTE FUNCTION public.rl_missing_searches_insert();
