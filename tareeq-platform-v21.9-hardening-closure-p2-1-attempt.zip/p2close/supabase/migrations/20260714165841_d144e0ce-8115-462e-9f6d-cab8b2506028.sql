-- Re-lock log_ai_usage to service_role only (was accidentally re-granted to authenticated)
REVOKE EXECUTE ON FUNCTION public.log_ai_usage(text, text, integer, integer, integer, boolean, integer, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.log_ai_usage(text, text, integer, integer, integer, boolean, integer, text) TO service_role;

-- Restore anon execute on get_public_flags (returns only a non-sensitive boolean)
GRANT EXECUTE ON FUNCTION public.get_public_flags() TO anon;