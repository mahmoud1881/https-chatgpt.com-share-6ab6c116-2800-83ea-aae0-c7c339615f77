-- Bootstrap migration for admin_config.
--
-- This table was originally created directly in Supabase Studio, never via
-- a tracked migration (see 20260903000000_enforce_rls_admin_config.sql,
-- which found the same gap from the RLS side). The first migration that
-- references it, 20260708153717_..., only does
-- `ALTER TABLE public.admin_config ADD COLUMN ... use_structured_search`,
-- which assumes the table already exists. On a truly fresh database (e.g.
-- `supabase db reset` in CI, or any new self-host deploy applying the full
-- migration history from scratch) that ALTER TABLE fails with
-- "relation admin_config does not exist", breaking migration replay.
--
-- Column set below is reconstructed from src/integrations/supabase/types.ts
-- (the generated Row type), which is the only remaining source of truth for
-- its original shape: id, monthly_credit_budget, notes, updated_at are
-- never added via ALTER TABLE anywhere in this history, so they must be
-- part of the original untracked CREATE TABLE. `use_structured_search` is
-- deliberately NOT included here — it's added by the very next migration
-- via ADD COLUMN IF NOT EXISTS, exactly as it originally happened.
--
-- Note: as of this writing, no application code queries admin_config or
-- its admin_public_flags view at all (grep across src/ finds zero
-- references) — this table is currently dead schema. It's bootstrapped
-- here anyway so migration history is internally consistent and replayable
-- from empty, which is a prerequisite for the migrations-guard CI check.
CREATE TABLE IF NOT EXISTS public.admin_config (
  id BIGINT PRIMARY KEY DEFAULT 1,
  monthly_credit_budget NUMERIC NOT NULL DEFAULT 0,
  notes TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE public.admin_config IS
  'Singleton admin/ops config row. Bootstrapped by this migration for '
  'schema-history consistency — see the long comment above for why. '
  'Currently unused by application code as of 2026-08.';
