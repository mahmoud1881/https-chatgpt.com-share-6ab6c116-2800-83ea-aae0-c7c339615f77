
-- ============================================================
-- Tareeq.world — Structured Route Planner Layer (Phase 1)
-- New tables sit alongside existing platform, non-destructive.
-- ============================================================

-- 1) transport_types -----------------------------------------
CREATE TABLE public.transport_types (
  id           TEXT PRIMARY KEY,           -- 'bus', 'minibus', 'microbus', 'metro', 'tram', 'train', 'brt', 'shared_taxi', ...
  name_ar      TEXT NOT NULL,
  name_en      TEXT NOT NULL,
  icon         TEXT,
  color        TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.transport_types TO anon, authenticated;
GRANT ALL ON public.transport_types TO service_role;
ALTER TABLE public.transport_types ENABLE ROW LEVEL SECURITY;
CREATE POLICY "transport_types public read" ON public.transport_types FOR SELECT USING (true);
CREATE POLICY "transport_types admin write" ON public.transport_types FOR ALL
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 2) stops ---------------------------------------------------
CREATE TABLE public.stops (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name_ar          TEXT NOT NULL,
  name_en          TEXT,
  normalized_name  TEXT NOT NULL,
  latitude         DOUBLE PRECISION,
  longitude        DOUBLE PRECISION,
  country          TEXT NOT NULL DEFAULT 'eg',
  city             TEXT,
  area             TEXT,
  is_verified      BOOLEAN NOT NULL DEFAULT false,
  source           TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX stops_normalized_idx ON public.stops (normalized_name);
CREATE INDEX stops_country_city_idx ON public.stops (country, city);
CREATE INDEX stops_verified_idx ON public.stops (is_verified);
GRANT SELECT ON public.stops TO anon, authenticated;
GRANT ALL ON public.stops TO service_role;
ALTER TABLE public.stops ENABLE ROW LEVEL SECURITY;
CREATE POLICY "stops public read" ON public.stops FOR SELECT USING (true);
CREATE POLICY "stops admin write" ON public.stops FOR ALL
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 3) stop_aliases --------------------------------------------
CREATE TABLE public.stop_aliases (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stop_id           UUID NOT NULL REFERENCES public.stops(id) ON DELETE CASCADE,
  alias             TEXT NOT NULL,
  normalized_alias  TEXT NOT NULL,
  source            TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (stop_id, normalized_alias)
);
CREATE INDEX stop_aliases_normalized_idx ON public.stop_aliases (normalized_alias);
CREATE INDEX stop_aliases_stop_idx ON public.stop_aliases (stop_id);
GRANT SELECT ON public.stop_aliases TO anon, authenticated;
GRANT ALL ON public.stop_aliases TO service_role;
ALTER TABLE public.stop_aliases ENABLE ROW LEVEL SECURITY;
CREATE POLICY "stop_aliases public read" ON public.stop_aliases FOR SELECT USING (true);
CREATE POLICY "stop_aliases admin write" ON public.stop_aliases FOR ALL
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 4) routes --------------------------------------------------
CREATE TABLE public.routes (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  route_code          TEXT,
  route_name          TEXT NOT NULL,
  transport_type_id   TEXT REFERENCES public.transport_types(id),
  start_stop_id       UUID REFERENCES public.stops(id) ON DELETE SET NULL,
  end_stop_id         UUID REFERENCES public.stops(id) ON DELETE SET NULL,
  country             TEXT NOT NULL DEFAULT 'eg',
  city                TEXT,
  price_min           NUMERIC,
  price_max           NUMERIC,
  currency            TEXT,
  estimated_duration  INTEGER,   -- minutes
  is_verified         BOOLEAN NOT NULL DEFAULT false,
  status              TEXT NOT NULL DEFAULT 'active', -- active | inactive | under_review
  source              TEXT,
  notes               TEXT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX routes_country_city_idx ON public.routes (country, city);
CREATE INDEX routes_verified_idx ON public.routes (is_verified);
CREATE INDEX routes_type_idx ON public.routes (transport_type_id);
CREATE INDEX routes_start_end_idx ON public.routes (start_stop_id, end_stop_id);
GRANT SELECT ON public.routes TO anon, authenticated;
GRANT ALL ON public.routes TO service_role;
ALTER TABLE public.routes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "routes public read" ON public.routes FOR SELECT USING (true);
CREATE POLICY "routes admin write" ON public.routes FOR ALL
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 5) route_stops ---------------------------------------------
CREATE TABLE public.route_stops (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  route_id    UUID NOT NULL REFERENCES public.routes(id) ON DELETE CASCADE,
  stop_id     UUID NOT NULL REFERENCES public.stops(id) ON DELETE CASCADE,
  stop_order  INTEGER NOT NULL,
  direction   TEXT NOT NULL DEFAULT 'forward', -- forward | backward | both
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (route_id, stop_order, direction)
);
CREATE INDEX route_stops_route_idx ON public.route_stops (route_id, stop_order);
CREATE INDEX route_stops_stop_idx ON public.route_stops (stop_id);
GRANT SELECT ON public.route_stops TO anon, authenticated;
GRANT ALL ON public.route_stops TO service_role;
ALTER TABLE public.route_stops ENABLE ROW LEVEL SECURITY;
CREATE POLICY "route_stops public read" ON public.route_stops FOR SELECT USING (true);
CREATE POLICY "route_stops admin write" ON public.route_stops FOR ALL
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 6) search_logs ---------------------------------------------
CREATE TABLE public.search_logs (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  from_query     TEXT,
  to_query       TEXT,
  city           TEXT,
  country        TEXT,
  result_status  TEXT,  -- success | no_result | needs_clarification
  result_count   INTEGER,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX search_logs_status_idx ON public.search_logs (result_status);
CREATE INDEX search_logs_user_idx ON public.search_logs (user_id);
GRANT SELECT, INSERT ON public.search_logs TO authenticated;
GRANT INSERT ON public.search_logs TO anon;
GRANT ALL ON public.search_logs TO service_role;
ALTER TABLE public.search_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "search_logs owner read" ON public.search_logs FOR SELECT
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "search_logs anyone insert" ON public.search_logs FOR INSERT
  WITH CHECK (user_id IS NULL OR user_id = auth.uid());

-- 7) missing_searches ----------------------------------------
CREATE TABLE public.missing_searches (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  from_query     TEXT NOT NULL,
  to_query       TEXT NOT NULL,
  from_stop_id   UUID REFERENCES public.stops(id) ON DELETE SET NULL,
  to_stop_id     UUID REFERENCES public.stops(id) ON DELETE SET NULL,
  city           TEXT,
  country        TEXT,
  hits           INTEGER NOT NULL DEFAULT 1,
  status         TEXT NOT NULL DEFAULT 'pending', -- pending | linked | ignored | resolved
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX missing_searches_status_idx ON public.missing_searches (status);
CREATE INDEX missing_searches_hits_idx ON public.missing_searches (hits DESC);
GRANT SELECT, INSERT ON public.missing_searches TO authenticated;
GRANT INSERT ON public.missing_searches TO anon;
GRANT UPDATE ON public.missing_searches TO authenticated;
GRANT ALL ON public.missing_searches TO service_role;
ALTER TABLE public.missing_searches ENABLE ROW LEVEL SECURITY;
CREATE POLICY "missing_searches admin read" ON public.missing_searches FOR SELECT
  USING (public.has_role(auth.uid(), 'admin') OR auth.uid() = user_id);
CREATE POLICY "missing_searches insert" ON public.missing_searches FOR INSERT
  WITH CHECK (user_id IS NULL OR user_id = auth.uid());
CREATE POLICY "missing_searches admin update" ON public.missing_searches FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 8) route_corrections ---------------------------------------
CREATE TABLE public.route_corrections (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  route_id      UUID REFERENCES public.routes(id) ON DELETE CASCADE,
  from_stop_id  UUID REFERENCES public.stops(id) ON DELETE SET NULL,
  to_stop_id    UUID REFERENCES public.stops(id) ON DELETE SET NULL,
  user_id       UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  user_comment  TEXT,
  status        TEXT NOT NULL DEFAULT 'pending', -- pending | reviewed | applied | rejected
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.route_corrections TO authenticated;
GRANT UPDATE ON public.route_corrections TO authenticated;
GRANT ALL ON public.route_corrections TO service_role;
ALTER TABLE public.route_corrections ENABLE ROW LEVEL SECURITY;
CREATE POLICY "route_corrections owner read" ON public.route_corrections FOR SELECT
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "route_corrections insert" ON public.route_corrections FOR INSERT
  WITH CHECK (auth.uid() = user_id);
CREATE POLICY "route_corrections admin update" ON public.route_corrections FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 9) user_route_suggestions ----------------------------------
CREATE TABLE public.user_route_suggestions (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  from_text         TEXT NOT NULL,
  to_text           TEXT NOT NULL,
  transport_type_id TEXT REFERENCES public.transport_types(id),
  route_name        TEXT,
  boarding_point    TEXT,
  drop_point        TEXT,
  notes             TEXT,
  city              TEXT,
  country           TEXT,
  status            TEXT NOT NULL DEFAULT 'pending', -- pending | accepted | rejected
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.user_route_suggestions TO authenticated;
GRANT ALL ON public.user_route_suggestions TO service_role;
ALTER TABLE public.user_route_suggestions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "user_route_suggestions owner read" ON public.user_route_suggestions FOR SELECT
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "user_route_suggestions insert" ON public.user_route_suggestions FOR INSERT
  WITH CHECK (auth.uid() = user_id);
CREATE POLICY "user_route_suggestions admin update" ON public.user_route_suggestions FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 10) alias_suggestions --------------------------------------
CREATE TABLE public.alias_suggestions (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stop_id       UUID REFERENCES public.stops(id) ON DELETE CASCADE,
  suggested_alias TEXT NOT NULL,
  user_id       UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  status        TEXT NOT NULL DEFAULT 'pending', -- pending | accepted | rejected
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.alias_suggestions TO authenticated;
GRANT ALL ON public.alias_suggestions TO service_role;
ALTER TABLE public.alias_suggestions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "alias_suggestions owner read" ON public.alias_suggestions FOR SELECT
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "alias_suggestions insert" ON public.alias_suggestions FOR INSERT
  WITH CHECK (auth.uid() = user_id);
CREATE POLICY "alias_suggestions admin update" ON public.alias_suggestions FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Updated_at triggers ----------------------------------------
CREATE OR REPLACE FUNCTION public.tg_touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER stops_touch BEFORE UPDATE ON public.stops
  FOR EACH ROW EXECUTE FUNCTION public.tg_touch_updated_at();
CREATE TRIGGER routes_touch BEFORE UPDATE ON public.routes
  FOR EACH ROW EXECUTE FUNCTION public.tg_touch_updated_at();
CREATE TRIGGER missing_searches_touch BEFORE UPDATE ON public.missing_searches
  FOR EACH ROW EXECUTE FUNCTION public.tg_touch_updated_at();

-- Seed transport_types ---------------------------------------
INSERT INTO public.transport_types (id, name_ar, name_en, icon, color) VALUES
  ('bus',         'أتوبيس',        'Bus',           '🚌', '#0ea5e9'),
  ('minibus',     'ميني باص',      'Minibus',       '🚐', '#10b981'),
  ('microbus',    'ميكروباص',      'Microbus',      '🚐', '#22c55e'),
  ('metro',       'مترو',          'Metro',         '🚇', '#6366f1'),
  ('tram',        'ترام',          'Tram',          '🚊', '#8b5cf6'),
  ('train',       'قطار',          'Train',         '🚆', '#f59e0b'),
  ('brt',         'أتوبيس ترددي',  'BRT',           '🚌', '#0284c7'),
  ('shared_taxi', 'تاكسي مشترك',   'Shared Taxi',   '🚕', '#eab308'),
  ('lrt',         'قطار خفيف',     'Light Rail',    '🚈', '#a855f7'),
  ('cableway',    'تلفريك',        'Cableway',      '🚡', '#14b8a6'),
  ('ferry',       'عبّارة',         'Ferry',         '⛴️', '#0891b2')
ON CONFLICT (id) DO NOTHING;
