
DROP POLICY IF EXISTS "shared cache update" ON public.ai_cache_shared;

CREATE POLICY "shared cache update" ON public.ai_cache_shared
  FOR UPDATE TO authenticated
  USING (expires_at > now())
  WITH CHECK (expires_at > now());
