
CREATE TABLE public.community_routes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  from_area text NOT NULL,
  to_area text NOT NULL,
  price_egp integer,
  duration_min integer,
  status text NOT NULL DEFAULT 'pending',
  confirmations integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX community_routes_created_idx ON public.community_routes (created_at DESC);

GRANT SELECT, INSERT ON public.community_routes TO anon, authenticated;
GRANT UPDATE (confirmations, status) ON public.community_routes TO anon, authenticated;
GRANT ALL ON public.community_routes TO service_role;

ALTER TABLE public.community_routes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone can read community routes"
  ON public.community_routes FOR SELECT
  USING (true);

CREATE POLICY "anyone can insert community routes"
  ON public.community_routes FOR INSERT
  WITH CHECK (
    length(btrim(from_area)) BETWEEN 1 AND 60
    AND length(btrim(to_area)) BETWEEN 1 AND 60
    AND length(btrim(title)) BETWEEN 1 AND 140
    AND status IN ('pending','confirmed')
    AND confirmations = 0
    AND (price_egp IS NULL OR price_egp BETWEEN 0 AND 500)
    AND (duration_min IS NULL OR duration_min BETWEEN 0 AND 300)
  );

CREATE POLICY "anyone can confirm community routes"
  ON public.community_routes FOR UPDATE
  USING (true)
  WITH CHECK (
    confirmations BETWEEN 0 AND 10000
    AND status IN ('pending','confirmed')
  );

ALTER PUBLICATION supabase_realtime ADD TABLE public.community_routes;
