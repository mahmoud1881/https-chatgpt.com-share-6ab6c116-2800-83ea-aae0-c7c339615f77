-- Enable pg_cron for scheduled maintenance
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Cleanup function: purge old AI cache and search logs
CREATE OR REPLACE FUNCTION public.cleanup_old_data()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Purge expired / stale shared AI cache (>30 days old)
  DELETE FROM public.ai_cache_shared
   WHERE (expires_at IS NOT NULL AND expires_at < now())
      OR created_at < now() - interval '30 days';

  -- Purge old search logs (>30 days)
  DELETE FROM public.search_logs
   WHERE created_at < now() - interval '30 days';
END;
$$;

REVOKE ALL ON FUNCTION public.cleanup_old_data() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.cleanup_old_data() TO service_role;

-- Unschedule previous job if it exists, then reschedule
DO $$
BEGIN
  PERFORM cron.unschedule('cleanup-old-data-daily')
    WHERE EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'cleanup-old-data-daily');
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

SELECT cron.schedule(
  'cleanup-old-data-daily',
  '0 3 * * *',
  $$ SELECT public.cleanup_old_data(); $$
);