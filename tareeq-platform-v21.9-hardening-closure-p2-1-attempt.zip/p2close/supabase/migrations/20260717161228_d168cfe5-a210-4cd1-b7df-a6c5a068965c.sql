
-- Layer 4C — Review Queue (staging only)
CREATE TABLE public.data_quality_review_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  issue_type TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'medium',
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  entity_label TEXT,
  current_snapshot JSONB,
  proposed_fix JSONB,
  source TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  review_note TEXT,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  reviewed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  reviewed_at TIMESTAMPTZ,
  CONSTRAINT dqri_status_check CHECK (status IN ('pending','needs_info','approved','rejected')),
  CONSTRAINT dqri_severity_check CHECK (severity IN ('low','medium','high','critical'))
);

CREATE INDEX idx_dqri_status ON public.data_quality_review_items(status);
CREATE INDEX idx_dqri_issue_type ON public.data_quality_review_items(issue_type);
CREATE INDEX idx_dqri_entity ON public.data_quality_review_items(entity_type, entity_id);
CREATE INDEX idx_dqri_created_at ON public.data_quality_review_items(created_at DESC);

-- Grants — admin-only via RLS; authenticated needs table-level grant to reach RLS.
GRANT SELECT, INSERT, UPDATE ON public.data_quality_review_items TO authenticated;
GRANT ALL ON public.data_quality_review_items TO service_role;
-- No anon grant.

ALTER TABLE public.data_quality_review_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can select review items"
  ON public.data_quality_review_items FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can insert review items"
  ON public.data_quality_review_items FOR INSERT
  TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin') AND created_by = auth.uid());

CREATE POLICY "Admins can update review items"
  ON public.data_quality_review_items FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Explicitly no DELETE policy — audit trail preserved.

CREATE TRIGGER trg_dqri_touch_updated
  BEFORE UPDATE ON public.data_quality_review_items
  FOR EACH ROW
  EXECUTE FUNCTION public.tg_touch_updated_at();
