CREATE TABLE IF NOT EXISTS public._ing_master (
  ext_route_stop_id text,
  ext_route_id text,
  route_code text,
  route_name text,
  transport_type text,
  country text,
  city text,
  direction text,
  stop_order integer,
  ext_stop_id text,
  stop_name_ar text,
  stop_name_en text,
  normalized_name text,
  latitude double precision,
  longitude double precision,
  price_min numeric,
  price_max numeric,
  currency text,
  estimated_duration integer,
  route_is_verified boolean,
  route_status text,
  data_source text
);
CREATE INDEX IF NOT EXISTS _ing_master_ext_stop_id_idx ON public._ing_master(ext_stop_id);
CREATE INDEX IF NOT EXISTS _ing_master_ext_route_id_idx ON public._ing_master(ext_route_id);
GRANT ALL ON public._ing_master TO service_role;