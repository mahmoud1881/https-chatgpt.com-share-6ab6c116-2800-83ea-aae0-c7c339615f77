-- ============================================================================
-- المرحلة 4 — منظومة تتبّع الجلسات كاملةً مفقودة
--
-- الجدول public.user_sessions والدوال start_session / heartbeat_session /
-- end_session: صفر تعريف في كل ملفات الـ migrations، رغم أن
-- 20260703161744 و20260708172409 و20260710192101 تنفّذ GRANT/REVOKE عليها.
-- نفس نمط has_role/user_stations/peer_nodes.
--
-- درجة الثقة هنا أعلى من get_admin_stats: أعمدة الجدول منسوخة حرفيًا من
-- types.ts المولَّد من الإنتاج، وسلوك الدوال الثلاث محدَّد تمامًا بأسمائها
-- وتواقيعها (بدء جلسة تُعيد معرّفها، نبضة تحدّث آخر ظهور، إنهاء يضبط
-- وقت الانتهاء).
--
-- ip_hash يبقى NULL: start_session لا تستقبله ضمن معاملاتها، فمصدره
-- الحقيقي غير معروف من المستودع. إن كان الإنتاج يملؤه فعلًا، فذلك فرق
-- سلوكي وحيد يستحق المراجعة.
-- ============================================================================

CREATE TABLE IF NOT EXISTS public.user_sessions (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  user_agent   text,
  platform     text,
  ip_hash      text,
  started_at   timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  ended_at     timestamptz
);

CREATE INDEX IF NOT EXISTS user_sessions_user_idx    ON public.user_sessions (user_id, started_at DESC);
CREATE INDEX IF NOT EXISTS user_sessions_active_idx  ON public.user_sessions (last_seen_at DESC) WHERE ended_at IS NULL;

-- بيانات تحليلية حساسة (user_agent/platform/ip_hash): لا وصول مباشر من
-- المتصفح إطلاقًا. الكتابة حصرًا عبر الدوال الثلاث أدناه (SECURITY DEFINER)،
-- والقراءة عبر لوحة الإدارة. RLS مفعّلة بلا سياسات = مغلق لغير service_role.
ALTER TABLE public.user_sessions ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.user_sessions FROM PUBLIC, anon, authenticated;
GRANT ALL ON public.user_sessions TO service_role;

CREATE OR REPLACE FUNCTION public.start_session(
  _user_agent text DEFAULT NULL,
  _platform   text DEFAULT NULL
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'auth_required: start_session تتطلب مستخدمًا مسجّلًا';
  END IF;
  INSERT INTO public.user_sessions (user_id, user_agent, platform)
  VALUES (auth.uid(), _user_agent, _platform)
  RETURNING id INTO v_id;
  RETURN v_id;
END;
$$;

-- التحقق من auth.uid() داخل كل دالة يمنع مستخدمًا من تحديث/إنهاء جلسة
-- مستخدم آخر لو خمّن معرّفها — مهم لأن الدوال SECURITY DEFINER.
CREATE OR REPLACE FUNCTION public.heartbeat_session(_session_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE public.user_sessions
     SET last_seen_at = now()
   WHERE id = _session_id AND user_id = auth.uid() AND ended_at IS NULL;
END;
$$;

CREATE OR REPLACE FUNCTION public.end_session(_session_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE public.user_sessions
     SET ended_at = now(), last_seen_at = now()
   WHERE id = _session_id AND user_id = auth.uid() AND ended_at IS NULL;
END;
$$;

REVOKE ALL ON FUNCTION public.start_session(text, text)     FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.heartbeat_session(uuid)       FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.end_session(uuid)             FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.start_session(text, text)  TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.heartbeat_session(uuid)    TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.end_session(uuid)          TO authenticated, service_role;
