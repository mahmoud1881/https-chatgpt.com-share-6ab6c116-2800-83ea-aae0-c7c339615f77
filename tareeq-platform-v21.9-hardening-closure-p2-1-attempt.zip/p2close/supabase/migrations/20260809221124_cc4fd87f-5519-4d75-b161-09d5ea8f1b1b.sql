-- 1) Tighten traffic_reports full-row reads
DROP POLICY IF EXISTS "Authenticated can read traffic reports" ON public.traffic_reports;

CREATE POLICY "Owners and admins can read traffic reports"
ON public.traffic_reports
FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

-- 2) Anonymized public view (no user_id, coarse coordinates ~100m)
CREATE OR REPLACE VIEW public.traffic_reports_public
WITH (security_invoker = off) AS
SELECT
  id,
  area,
  severity,
  notes,
  round(lat::numeric, 3)::double precision AS lat,
  round(lng::numeric, 3)::double precision AS lng,
  country,
  created_at,
  expires_at
FROM public.traffic_reports;

REVOKE ALL ON public.traffic_reports_public FROM anon, authenticated;
GRANT SELECT ON public.traffic_reports_public TO anon, authenticated;

-- 3) PostGIS metadata table must not be reachable through the Data API
REVOKE ALL ON TABLE public.spatial_ref_sys FROM anon, authenticated;