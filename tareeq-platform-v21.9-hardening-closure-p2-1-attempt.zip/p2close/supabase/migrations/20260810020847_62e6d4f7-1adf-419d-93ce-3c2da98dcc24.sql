DO $$
BEGIN
  BEGIN
    EXECUTE 'ALTER TABLE public.spatial_ref_sys ENABLE ROW LEVEL SECURITY';
  EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'cannot enable RLS on spatial_ref_sys: %', SQLERRM;
  END;
  BEGIN
    EXECUTE 'REVOKE SELECT ON public.spatial_ref_sys FROM anon, authenticated';
  EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'cannot revoke on spatial_ref_sys: %', SQLERRM;
  END;
END $$;