# v20.9 — Production Deployment Transaction & Migration Safety

Implemented a fail-closed production migration safety layer.

- Classifies only **pending production migrations** as backward-compatible, lock-sensitive, or destructive.
- Lock-sensitive/destructive migrations require a content-bound SHA-256 approval with approver, ticket, and rollback/roll-forward plan.
- Production migration execution sets PostgreSQL `lock_timeout=5s`, `statement_timeout=120s`, and `idle_in_transaction_session_timeout=60s` through `PGOPTIONS`.
- Production deploy requires fresh backup + successful restore evidence. Evidence is bound to backup identity/timestamps/schema fingerprint and defaults to a 24-hour maximum age.
- `deploy:db:production` runs safety + backup proof, applies pending migrations **before traffic cutover**, and then runs the v20.8 staging/production ledger + canonical schema fingerprint gate.
- Traffic cutover is allowed only after the post-migration drift proof succeeds.
- The generated production transaction artifact records pre-deploy evidence and post-deploy migration count.

## Approval record
Add an entry to `supabase/destructive-migration-approvals.json` keyed by exact migration filename. It must contain the exact migration SHA-256 plus `approvedBy`, `ticket`, and `rollbackOrRollforwardPlan`. Changing the migration invalidates approval.

## Backup evidence
Provide `artifacts/backup-restore-evidence.json` (or `BACKUP_RESTORE_EVIDENCE_FILE`) containing production backup identity, completion timestamps, restore target, verifier, identical source/restored schema SHA-256 values, and `evidenceSha256 = sha256(backupId|backupCompletedAt|restoreTestCompletedAt|sourceSchemaSha256)`.

The gate intentionally does not manufacture backup evidence or approvals. Those must come from the production operator/backup system.
