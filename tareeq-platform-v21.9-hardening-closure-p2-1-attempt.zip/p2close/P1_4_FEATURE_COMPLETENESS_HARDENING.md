# P1-4 Feature Completeness Hardening

P1-4 is layered on P1-3. Every user-facing route is explicitly classified as working, coming_soon, or hidden. Known incomplete Wallet and Challenge-start actions are explicitly disabled and labelled rather than presented as successful actions. Dead `href="#"` legal links were replaced with real internal routes.

Evidence remains separated: IMPLEMENTED does not imply runtime EXECUTED or PASSED. Runtime Playwright remains required for browser certification.
