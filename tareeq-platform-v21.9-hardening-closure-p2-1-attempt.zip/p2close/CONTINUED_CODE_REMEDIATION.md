# Continued code remediation

## Completed
- Kept portable source/security/data validation runnable on Node without Bun.
- Added `data:review:gate`, a fail-closed release control for quarantined transport records.
- The gate requires every quarantined record to have an explicit `approved` or `rejected` decision plus `reviewedBy`, `reviewedAt`, and `reviewEvidence`.
- The gate writes `artifacts/data-review-gate.json` with a SHA-256 of the reviewed source and reason/status counts.
- Added quarantine regression tests to `quality:portable`.
- Added the data-review gate to the front of `release:gate`; unresolved real-world route conflicts can no longer be silently released.

## Current factual blocker
196 records require independent evidence: 193 duplicate-route-id conflict records and 3 unknown-stop-reference records. The duplicate groups are not byte-identical, so automatically selecting one would fabricate transport truth. The three unknown-stop records contain placeholder stops (`—` / null IDs), so they also require source evidence rather than an invented mapping.

## Commands
- `npm run quality:portable`
- `npm run data:review:gate`
- `npm run quality:app` once dependencies are installed
- `npm run quality:full` on the CI runner with browser/runtime dependencies
