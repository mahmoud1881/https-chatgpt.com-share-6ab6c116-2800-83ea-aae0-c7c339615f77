# Full Platform AI Journey Runtime Gateway — Wave 3

Production-like certification is fail-closed and requires:

- `TAREEQ_DEVICE_ATTESTATION_PUBLIC_KEY`: server-side trusted Ed25519 public key (or verifier key exposed by the attestation broker).
- `TAREEQ_DEVICE_ATTESTATION_SIGNER_URL`: device/attestation-broker endpoint used by the runner after it obtains a one-time challenge. The private key never belongs in the gateway or repository.
- Challenge contract: `nonce + certification_run_id + audience + expiry`. Signed payload must bind the nonce, run id, issuer/audience, fresh GPS sample, consent, and capture time. Nonces are one-use and replay-protected.
- `TAREEQ_OSRM_BASE_URL` and `TAREEQ_OVERPASS_URL`: capacity-backed/self-hosted endpoints. Public demo/community endpoints are rejected in production-like environments.
- `SUPABASE_URL`, `TAREEQ_JOURNEY_EVIDENCE_API_KEY`, `TAREEQ_JOURNEY_EVIDENCE_RPC_TOKEN`: dedicated least-privilege identity allowed to execute only `record_ai_certification_journey`; the gateway no longer accepts `SUPABASE_SERVICE_ROLE_KEY`.
- `RELEASE_ID`, `COMMIT_SHA`, `ENVIRONMENT_ID`, `CONFIG_HASH`: required execution identity. Journey rows also persist `evidence_digest` and have a uniqueness constraint over the proof identity.

Apply migrations `20260925000100_ai_certification_journey_runs.sql` and `20260925000200_ai_certification_journey_hardening.sql`. Grant EXECUTE on the dedicated RPC only to the certification database role used to mint the RPC token.

Local contract PASS does not imply runtime trust. Real attestation, provider capacity, DB-role isolation and runtime evidence remain `observed=null` until executed in the production-like environment.
