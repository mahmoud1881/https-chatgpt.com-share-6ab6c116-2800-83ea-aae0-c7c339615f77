# v21.2 — Adaptive Progressive Delivery & Automated Promotion Controller

Production traffic promotion is now staged at **1% → 5% → 25% → 50% → 100%**. Each stage is observed independently and records an immutable deployment-decision artifact.

The stage gate measures candidate and stable concurrently, enforcing absolute candidate limits plus relative error-rate and p95 regression limits, error-budget burn rate, readiness/database health, and minimum sample confidence. A failed observation causes a bounded **hold/retry**; repeated failure causes **abort**, which propagates to the v21.0 recovery path and restores stable application traffic. Passing stages are automatically promoted.

Evidence is written to `artifacts/progressive-delivery-evidence.json` and per-stage SLO reports to `artifacts/canary-stage-<percent>.json`. Database recovery remains roll-forward-only; this controller never rolls migrations backward.

The self-host Caddy provider now supports 0/1/5/25/50/100 traffic weights. Runtime production success still requires the real Docker/Caddy stack, production credentials, traffic, and database gates; static checks do not claim live production proof.
