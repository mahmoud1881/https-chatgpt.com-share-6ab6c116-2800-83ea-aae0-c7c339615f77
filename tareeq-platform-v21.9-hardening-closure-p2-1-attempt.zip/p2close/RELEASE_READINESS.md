# Release Readiness — Strict Client-Side AI

## AI architecture

The release enforces:

`Browser → Google Gemini → Browser`

for every Gemini interaction. All embedding work is browser-local.

## Removed

- Server-side AI gateway integration
- Server-side AI provider secrets
- Server-side OpenAI embeddings
- Server-side Gemini reranking
- Server-side semantic embedding fallback
- Public server-side embedding warmup
- Unused AI SDK gateway dependencies

## Retained server functionality

Normal backend functions remain for authentication, Supabase/database operations, administration, logging and rate limiting. These functions contain no AI provider calls.

## Release gates

A release must contain no server-side AI provider URL, provider secret, AI gateway SDK, or server-side embedding call.

It must also pass package-lock consistency checks.

## Strict AI planner contract (2026-08-24)

- `/ai-planner` does not import or call the platform transit graph.
- `/ai-planner` does not import local embeddings or a local LLM.
- `/ai-planner` sends the user's prompt directly from the browser to the Gemini Interactions API.
- Gemini built-in tools enabled: Google Search, URL Context, and Code Execution.
- `store: false` is used for interactions; conversation context is kept in browser session storage.
- The platform supplies no Gemini API key and buys no AI tokens.
- No Lovable AI gateway is used by the user-facing AI planner.

## Client-Side Gemini decision
- The AI Planner calls Google Gemini directly from the browser with the user's own Gemini API key.
- The platform does not provide, store, proxy, or pay for a Gemini API key.
- The key is stored only in the user's browser localStorage for convenience and can be deleted from the UI.
- No platform route is used as an AI proxy for the planner.
- Gemini tools are requested from the direct browser call: Google Search, URL Context, and Code Execution.
- The planner does not use the platform's route engine or transit data to answer the user's question.

## P1 hardening applied — 2026-09-17

The P1 code hardening pass adds:
- PostgreSQL-backed distributed rate limiting for TanStack server functions; no in-memory-only limiter remains on those paths.
- Explicit trusted-proxy handling and privacy-preserving rate-limit identifiers.
- 16 KiB / 50-key bounds on incident metadata.
- Atomic admin route publication for `routes` + ordered `route_stops`.
- Database-side country-code normalization for `routes` and `stops`.
- Build-time `VITE_SITE_URL` configuration for self-hosted canonical/share URLs.
- Supabase GoTrue OAuth adapter for self-hosted deployments, with Lovable Auth retained as an explicit opt-in.
- CI typecheck, lint, production E2E smoke, and Docker image build checks.
- `scripts/production-release-gate.mjs` and `scripts/verify-p1-hardening.mjs`.

The repository still requires real deployment verification for PostgreSQL, Docker runtime, Realtime, SMTP/OAuth providers, TLS/DNS, backups/restore, and load/concurrency testing before public launch.

The staging verification and recovery scripts now cover a database query,
Realtime channel join, Auth login, SMTP recovery request with observed inbox
delivery, OAuth redirect with observed callback, DNS/TLS, encrypted SSH offsite
backup, and isolated full-stack restore with measured duration. Their presence
is not a passing result: run `deploy/STAGING_RUNBOOK.md` against real staging
and attach the exit codes and restore report. Docker, SMTP/OAuth credentials,
DNS and an independent backup host are unavailable in this workspace.

## Deployment gate improvements

- CI boots the production Docker image and requires its HTTP endpoint to respond.
- `release:gate` fails if Docker is unavailable or the production image does not boot.
- `deploy.sh` fails on an uninitialized Realtime schema or failed stack probes.
- `deploy/scripts/health.sh` returns a failure exit code for failed container,
  database, app, Auth, or REST probes.
- `deploy/scripts/staging-verify.sh` probes the public HTTPS app and API after a
  clean staging deployment. This must still be run on a real staging host;
  passing code and CI checks does not establish operational readiness.

## Transit data gate

- The line 3 metro dataset now separates the shared trunk (23 stations), Rod
  El Farag branch (6), and Cairo University branch (5). A planner cannot
  traverse directly from one western branch to the other; it changes at
  Kit-Kat. The local pathfinder matches all eight operator-documented
  station-hop reference cases in `benchmarks/trips/metro-operator.v2.json`.
- `benchmarks/trips/core-eg.v1.json` contains 20 broader trip probes. The
  static Egyptian master graph finds the candidate on 17/18 forward cases;
  the Ramses alias discrepancy still needs real boarding-point review.
- The client-side Egyptian master now excludes records with fewer than two
  ordered stops or unknown stop IDs. The supplied snapshot has 2,189 such
  routable records out of 3,807 raw route records. Duplicate IDs can now
  retain separate modes and stop sequences during matching. This quarantine
  does not certify the surviving routes as correct in the field.
- An actual staging run and independent review of informal boarding points are
  still required before the data gate can be marked passed.


## P2 hardening (2026-09-17)
- OpenStreetMap is now the generated external map-link provider; legacy Google map URLs are rejected by the UI fallback helper.
- Live vehicle pings receive server-side coordinate/heading/speed/session validation and server-authoritative timestamps.
- Community questions, answers and routes have bounded content fields, server-authoritative timestamps, and exact-duplicate suppression windows.
- Public MQTT remains an untrusted hint transport; broker selection is configurable with `VITE_MQTT_BROKER`.
- Smart-card UI no longer presents the demo amount as a real balance and privacy/terms links are real routes.
- Canonical redirect derives its host from `VITE_SITE_URL`, improving self-host portability.

## Trip pricing removed (2026-09-22)

Trip search, route details, train and LRT pages, sharing, community submissions,
route corrections, admin editing, reference cases, and the imported public train
datasets no longer display, calculate, collect, or publish trip fares. The old
budget URL redirects to the journey planner. CI and `release:gate` run
`node scripts/check-no-transit-pricing.mjs` to catch regressions. Historical
nullable database fields remain in existing migrations for compatibility;
new route reads, edits, and imports do not use them. The local static benchmark
and reference freshness checks pass. A full application build, production image
and staging deployment still require an environment with dependencies, Docker,
and the actual database.
