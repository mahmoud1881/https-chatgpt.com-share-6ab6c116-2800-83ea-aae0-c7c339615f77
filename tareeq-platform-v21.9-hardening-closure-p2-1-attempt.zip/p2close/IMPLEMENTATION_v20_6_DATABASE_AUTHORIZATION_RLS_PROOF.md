# v20.6 — Database Authorization & RLS Proof

## Implemented
- Added a migration that revokes implicit `PUBLIC EXECUTE` from every `public` `SECURITY DEFINER` routine and pins each routine to `search_path = public, pg_temp`. Existing explicit role grants remain in force.
- Added a deployed-catalog audit that fails if a public application table lacks RLS, a `SECURITY DEFINER` routine lacks a pinned `search_path`, or such a routine remains executable by `PUBLIC`.
- Added transaction-wrapped negative authorization probes for `anon` and non-admin `authenticated` roles against core/admin tables. The transaction always rolls back.
- Added a `service_role` boundary sanity check.
- Added `security:db:static` to the normal release gate and `security:db:proof` for a real PostgreSQL/Supabase database.

## Proof levels
`npm run security:db:static` is repository/static proof and requires no database. `npm run security:db:proof` is the runtime proof and intentionally **fails closed** when no `DATABASE_URL`/`SUPABASE_DB_URL` is supplied; it never reports a database PASS without executing PostgreSQL.

## CI / local command
After starting an ephemeral Supabase stack and applying all migrations:

```sh
DATABASE_URL='postgresql://...' npm run security:db:proof
```

A production database may be audited with the catalog script, but the negative suite is intended for ephemeral/local CI because authorization tests should not rely on production state.

The runtime matrix explicitly covers `anon`, ordinary `authenticated`, a disposable `admin` membership evaluated through `has_role(auth.uid(),'admin')`, and `service_role` access to the otherwise protected role table.
