# v21.6 — Production Runtime Certification & Chaos/Failure Injection Gate

This release adds a fail-closed runtime certification harness on top of v21.5.

- Runs the existing end-to-end telemetry certification first (OTLP ingestion, Tempo retrieval, Prometheus span metrics, PostgreSQL exporter).
- Injects four controlled faults into the **candidate only**: HTTP 5xx, latency, simulated DB dependency outage, and simulated external-service failure.
- Fault injection requires `RELEASE_CHANNEL=candidate`, an operator-provided `CHAOS_CERTIFICATION_TOKEN` of at least 24 characters, and matching per-request headers. Stable never accepts the injection path.
- For every scenario, the canary SLO gate must fail. A false negative fails certification.
- An `abort` incident evidence bundle must be created, then traffic must be restored to stable and the persisted routing state must prove `percent=0`.
- Database migrations are never rolled back by this harness.

Run with the full Docker/telemetry stack available:

`CHAOS_CERTIFICATION_TOKEN='<secret >=24 chars>' npm run runtime:certify`

Evidence: `artifacts/runtime-chaos-certification.json` plus the incident bundles under `artifacts/incidents/<deploymentId>/`.

The normal `release:gate` includes the v21.6 **static** invariant check. Runtime certification is intentionally separate because it requires live containers, telemetry ingestion, and traffic routing; production certification must not be claimed until `runtime:certify` passes in the target environment.
