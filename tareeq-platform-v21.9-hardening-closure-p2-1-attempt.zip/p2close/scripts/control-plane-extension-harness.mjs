import {Worker} from 'node:worker_threads';
import crypto from 'node:crypto';
import {validateManifest,createExtensionContext} from './control-plane-v1-sdk.mjs';
const sha=v=>crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');
const FORBIDDEN_KEYS=new Set(['status','accepted','closed','verified_pass','VERIFIED_PASS','CLOSED']);
export function validateExtensionOutput(kind,value){
 if(!value||typeof value!=='object'||Array.isArray(value)) return {valid:false,reason:'MALFORMED_OUTPUT'};
 if([...FORBIDDEN_KEYS].some(k=>Object.hasOwn(value,k))) return {valid:false,reason:'CORE_TRUTH_FIELD_FORBIDDEN'};
 if(kind==='evidence' && (!value.id||!value.kind||value.observed===undefined)) return {valid:false,reason:'MALFORMED_EVIDENCE'};
 return {valid:true};
}
export async function runExtension({manifest,entrypoint,input=null,sinks={}}){
 const mv=validateManifest(manifest); if(!mv.valid) return {status:'REJECTED',reason:'INVALID_MANIFEST',details:mv.errors};
 const events=[]; let settled=false;
 const worker=new Worker(new URL('./control-plane-extension-worker.mjs',import.meta.url),{workerData:{entrypoint,input,capabilities:manifest.capabilities||[]},resourceLimits:{maxOldGenerationSizeMb:manifest.resources.memory_mb}});
 return await new Promise(resolve=>{
  const finish=async result=>{if(settled)return;settled=true;clearTimeout(timer); await worker.terminate().catch(()=>{}); resolve(Object.freeze({...result,events:Object.freeze(events),manifest_hash:sha(manifest)}));};
  const timer=setTimeout(()=>finish({status:'FAILED',reason:'TIMEOUT'}),manifest.timeout_ms);
  worker.on('message',m=>{
   if(m?.type==='action'){
    const check=validateExtensionOutput(m.kind,m.value); if(!check.valid) return finish({status:'FAILED',reason:check.reason});
    events.push(Object.freeze({kind:m.kind,value:Object.freeze({...m.value,extension_id:manifest.id})}));
    const sink={signal:'emitSignal',evidence:'submitEvidence',verification:'submitVerificationObservation',remediation:'proposeRemediation',deployment:'proposeDeployment'}[m.kind];
    sinks[sink]?.(events.at(-1).value);
   } else if(m?.type==='done') finish({status:'PASSED',result:m.result??null});
   else if(m?.type==='denied') finish({status:'FAILED',reason:'CAPABILITY_DENIED'});
  });
  worker.on('error',e=>finish({status:'FAILED',reason:'CRASH',error:e.message}));
  worker.on('exit',code=>{if(!settled) finish({status:code===0?'PASSED':'FAILED',reason:code===0?undefined:'CRASH'});});
 });
}
