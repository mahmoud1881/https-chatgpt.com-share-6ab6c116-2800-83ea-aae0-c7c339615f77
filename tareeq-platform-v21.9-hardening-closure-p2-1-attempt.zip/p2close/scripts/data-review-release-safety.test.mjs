import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read=p=>JSON.parse(readFileSync(new URL('../'+p, import.meta.url),'utf8'));
test('every quarantined route id is absent from the published production dataset',()=>{
 const q=read('data-review/eg-route-quarantine.v1.json').quarantined;
 const a=read('public/data/eg/routes_master.json').routes;
 const ids=new Set(a.map(r=>r.route_id));
 assert.equal(q.filter(x=>ids.has(x.route.route_id)).length,0);
});
test('published route ids are unique',()=>{
 const a=read('public/data/eg/routes_master.json').routes;
 assert.equal(new Set(a.map(r=>r.route_id)).size,a.length);
});
test('quarantine plus active dataset exactly accounts for source record count',()=>{
 const q=read('data-review/eg-route-quarantine.v1.json');
 const a=read('public/data/eg/routes_master.json');
 assert.equal(a.routes.length,q.activeCount);
 assert.equal(a.routes.length+q.quarantined.length,q.sourceCount);
});
