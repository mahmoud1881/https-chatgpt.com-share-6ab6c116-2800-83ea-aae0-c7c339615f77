import { test } from "node:test";
import assert from "node:assert/strict";
import { parseHint, verifiedHint } from "../src/lib/realtime-verification.ts";
const id = "12345678-1234-1234-1234-123456789abc";
test("forged content is replaced by authoritative row", async () => {
  const row = { id, country: "eg", status: "pending", confirmations: 0 };
  assert.equal(
    await verifiedHint(
      "community_routes/eg",
      "insert",
      { id, status: "confirmed", confirmations: 999 },
      async () => row,
    ),
    row,
  );
});
test("phantom record is not delivered", async () => {
  assert.equal(await verifiedHint("community_routes/eg", "insert", { id }, async () => null), null);
});
test("backend errors fail closed", async () => {
  assert.equal(
    await verifiedHint("community_routes/eg", "insert", { id }, async () => {
      throw Error();
    }),
    null,
  );
});
test("cross-country and mismatched records are rejected", async () => {
  for (const row of [
    { id, country: "xx" },
    { id: "other", country: "eg" },
  ]) {
    assert.equal(
      await verifiedHint("community_routes/eg", "insert", { id }, async () => row),
      null,
    );
  }
});
test("malformed IDs, unexpected events and tables never cause reads", async () => {
  for (const [topic, event, payload] of [
    ["community_routes/eg", "insert", { id: "fake" }],
    ["community_routes/eg", "delete", { id }],
    ["users/eg", "insert", { id }],
    ["__proto__/eg", "insert", { id }],
    ["community_routes/xx", "insert", { id }],
    ["community_routes/eg/extra", "insert", { id }],
  ]) {
    assert.equal(
      await verifiedHint(topic, event, payload, async () => assert.fail("unexpected read")),
      null,
    );
  }
});
test("all supported public feeds accept UUID hints", () => {
  for (const topic of [
    "community_routes/eg",
    "community_questions/eg",
    "community_answers/eg",
    "traffic_reports",
    "traffic_reports/eg",
  ]) {
    assert.equal(parseHint(topic, "insert", { id }).id, id);
  }
});
