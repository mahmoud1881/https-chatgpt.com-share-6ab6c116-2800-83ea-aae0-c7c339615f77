// Offline diagnostic of the exact alias/index/route-order logic in eg-master.
// This is NOT a user-facing planner result or an independent accuracy score.
import { readFileSync } from "node:fs";

const read = (p) => JSON.parse(readFileSync(p, "utf8"));
const base = "public/data/eg/";
const cases = read("benchmarks/trips/core-eg.v1.json").cases;
const aliases = read(`${base}aliases.json`);
const index = read(`${base}stop_routes_index.json`);
const validStops = new Set(read(`${base}stops_master.json`).stops.map((s) => s.stop_id));
const routes = new Map();
for (const route of read(`${base}routes_master.json`).routes) {
  if (route.stops.length < 2 || route.stops.some((s) => !validStops.has(s.stop_id))) continue;
  const key = `${route.route_id}|${route.mode}`;
  routes.set(key, [...(routes.get(key) ?? []), route]);
}
function normalize(name) {
  return name
    .normalize("NFKD")
    .replace(/[\u064B-\u0655\u0670\u0640]/g, "")
    .replace(/[إأآا]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ؤ/g, "و")
    .replace(/ئ/g, "ي")
    .replace(/ة/g, "ه")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]+/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

const rows = [];
for (const c of cases) {
  const from = aliases[normalize(c.from_query)];
  const to = aliases[normalize(c.to_query)];
  const hits = [];
  for (const ref of index[from] ?? []) {
    for (const route of routes.get(`${ref.route_id}|${ref.mode}`) ?? []) {
      const i = route.stops.findIndex((s) => s.stop_id === from);
      if (i >= 0 && route.stops.some((s, j) => j > i && s.stop_id === to))
        hits.push(route.route_id);
    }
  }
  const row = {
    id: c.id,
    category: c.category,
    from_resolved: from ?? null,
    to_resolved: to ?? null,
    candidate_found: c.candidate_route_ids.some((id) => hits.includes(id)),
    direct_hit_count: hits.length,
  };
  rows.push(row);
  console.log(
    `${row.candidate_found ? "CANDIDATE" : "NO_CANDIDATE"} ${c.id}: ${from ?? "?"} → ${to ?? "?"}; direct=${hits.length}`,
  );
}
const directCases = rows.filter((r) => !["reverse_direction", "transfer"].includes(r.category));
console.log(
  `\nForward candidate found ${directCases.filter((r) => r.candidate_found).length}/${directCases.length}; ` +
    "T19 is a reverse-direction sentinel, T20 requires transfer review. " +
    "This is static graph coverage, not trip correctness or the 95% release gate.",
);
if (process.argv[2] === "--json") console.log(JSON.stringify(rows, null, 2));
