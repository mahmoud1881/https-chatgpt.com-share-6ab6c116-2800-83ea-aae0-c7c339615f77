import crypto from 'node:crypto';

const sha=v=>crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');
export const HARNESS_MODE='CERTIFICATION_ONLY';
export const FORBIDDEN_HARNESS_CAPABILITIES=Object.freeze([
  'serve:production-traffic','evidence:mutate-production','truth:verified-pass',
  'incident:close','authorization:bypass','deployment:approve','provider-policy:manage'
]);

export const DEFAULT_AI_SCENARIOS=Object.freeze([
  {id:'deterministic-solved',signals:{deterministicSolved:true},expect:'DETERMINISTIC'},
  {id:'local-solved',signals:{localAvailable:true,localSolved:true},expect:'LOCAL'},
  {id:'jev-normal',signals:{jevConfidence:.94},expect:'JEV'},
  {id:'jev-low-confidence',signals:{jevConfidence:.51},expect:'GPT_OSS_120B'},
  {id:'reasoning-required',signals:{jevConfidence:.95,reasoningRequired:true},expect:'GPT_OSS_120B'},
  {id:'semantic-conflict',signals:{semanticConflict:true},expect:'GEMINI_3_8'},
  {id:'critical-risk',risk:'CRITICAL',signals:{jevConfidence:.99},expect:'GEMINI_3_8'},
  {id:'nano-unavailable',signals:{localAvailable:false,localSolved:false,jevConfidence:.93},expect:'JEV'},
  {id:'jev-timeout',fault:{provider:'jev',type:'TIMEOUT'},expect:'GPT_OSS_120B'},
  {id:'jev-malformed',fault:{provider:'jev',type:'MALFORMED'},expect:'GPT_OSS_120B'},
  {id:'gpt-timeout',fault:{provider:'gpt-oss-120b',type:'TIMEOUT'},expect:'GEMINI_3_8'},
  {id:'gpt-unsupported-claim',fault:{provider:'gpt-oss-120b',type:'UNSUPPORTED_CLAIM'},expect:'GEMINI_3_8'},
  {id:'gemini-disagreement',fault:{provider:'gemini-3.8',type:'DISAGREEMENT'},expect:'UNVERIFIED'},
  {id:'provider-outage',fault:{provider:'cloud',type:'OUTAGE'},expect:'UNAVAILABLE'},
  {id:'rate-limit',fault:{provider:'cloud',type:'RATE_LIMIT'},expect:'RETRY_OR_FALLBACK'},
  {id:'budget-exceeded',fault:{provider:'cost-governor',type:'HARD_CAP'},expect:'BUDGET_DENIED'},
  {id:'stale-evidence',fault:{provider:'evidence',type:'STALE'},expect:'UNVERIFIED'},
  {id:'malicious-truth-write',fault:{provider:'extension',type:'WRITE_VERIFIED_PASS'},expect:'DENIED'},
]);

function routeScenario(s){
  if(s.fault){
    const k=`${s.fault.provider}:${s.fault.type}`;
    return ({
      'jev:TIMEOUT':'GPT_OSS_120B','jev:MALFORMED':'GPT_OSS_120B',
      'gpt-oss-120b:TIMEOUT':'GEMINI_3_8','gpt-oss-120b:UNSUPPORTED_CLAIM':'GEMINI_3_8',
      'gemini-3.8:DISAGREEMENT':'UNVERIFIED','cloud:OUTAGE':'UNAVAILABLE',
      'cloud:RATE_LIMIT':'RETRY_OR_FALLBACK','cost-governor:HARD_CAP':'BUDGET_DENIED',
      'evidence:STALE':'UNVERIFIED','extension:WRITE_VERIFIED_PASS':'DENIED'
    })[k]??'UNVERIFIED';
  }
  const x={deterministicSolved:false,localAvailable:false,localSolved:false,jevConfidence:null,reasoningRequired:false,semanticConflict:false,...s.signals};
  const risk=s.risk??'LOW';
  if(x.deterministicSolved)return 'DETERMINISTIC';
  if(x.localAvailable&&x.localSolved)return 'LOCAL';
  if(risk==='CRITICAL'||x.semanticConflict)return 'GEMINI_3_8';
  if(x.reasoningRequired||(x.jevConfidence!==null&&x.jevConfidence<.82))return 'GPT_OSS_120B';
  return 'JEV';
}

export function runAICertificationHarness({scenarios=DEFAULT_AI_SCENARIOS}={}){
  const results=scenarios.map(s=>{const observed=routeScenario(s);return Object.freeze({id:s.id,expected:s.expect,observed,passed:observed===s.expect,synthetic:true});});
  const counts={DETERMINISTIC:0,LOCAL:0,JEV:0,GPT_OSS_120B:0,GEMINI_3_8:0};
  for(const r of results) if(Object.hasOwn(counts,r.observed)) counts[r.observed]++;
  return Object.freeze({
    mode:HARNESS_MODE,productionTraffic:false,synthetic:true,
    runId:`harness-${sha(results).slice(0,16)}`,executed:true,
    passed:results.every(r=>r.passed),results:Object.freeze(results),routeCounts:Object.freeze(counts),
    invariants:Object.freeze({production_path_injection:0,authoritative_truth_write:0,production_evidence_mutation:0,authorization_bypass:0}),
    runtimeCertificationGranted:false
  });
}
