import fs from 'node:fs';
import crypto from 'node:crypto';

const sha=v=>crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');
const now=()=>new Date().toISOString();
const out='artifacts/control-plane/ai-runtime-real-provider-certification.json';

async function postJson(url,{headers={},body,timeoutMs=20000}={}){
  const c=new AbortController(); const t=setTimeout(()=>c.abort(),timeoutMs); const started=Date.now();
  try{
    const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json',...headers},body:JSON.stringify(body),signal:c.signal});
    const text=await r.text();
    if(!r.ok) throw new Error(`http_${r.status}:${text.slice(0,160)}`);
    return {data:JSON.parse(text),latency_ms:Date.now()-started};
  } finally {clearTimeout(t)}
}
const redactedError=e=>String(e?.name==='AbortError'?'timeout':e?.message??e).replace(/Bearer\s+\S+/gi,'Bearer [REDACTED]').replace(/[A-Za-z0-9_-]{24,}/g,'[REDACTED]');

async function probeJev(){
  if(!process.env.TYPESAFE_API_KEY)return {configured:false,executed:false,observed:null,passed:null};
  try{
    const r=await postJson(`${process.env.TYPESAFE_BASE_URL??'https://api.typesafe.ai'}/v1/systemone`,{headers:{authorization:`Bearer ${process.env.TYPESAFE_API_KEY}`},body:{model:process.env.TYPESAFE_MODEL??'jev-latest',state:{request:'certification probe',risk:'LOW'},questions:{route:{type:'string',enum:['SIMPLE','COMPLEX']}}}});
    return {configured:true,executed:true,observed:{reachable:true,latency_ms:r.latency_ms,response_shape:typeof r.data==='object'&&r.data!==null},passed:typeof r.data==='object'&&r.data!==null};
  }catch(e){return {configured:true,executed:true,observed:{reachable:false,error:redactedError(e)},passed:false}}
}
async function probeGroq(){
  if(!process.env.GROQ_API_KEY)return {configured:false,executed:false,observed:null,passed:null};
  try{
    const r=await postJson(`${process.env.GROQ_BASE_URL??'https://api.groq.com/openai/v1'}/chat/completions`,{headers:{authorization:`Bearer ${process.env.GROQ_API_KEY}`},body:{model:process.env.GROQ_MODEL??'openai/gpt-oss-120b',messages:[{role:'system',content:'Return JSON only.'},{role:'user',content:'{"probe":"return ok true"}'}],response_format:{type:'json_object'},temperature:0}});
    const raw=r.data?.choices?.[0]?.message?.content; let parsed=null; try{parsed=JSON.parse(raw)}catch{}
    return {configured:true,executed:true,observed:{reachable:true,latency_ms:r.latency_ms,json_output:Boolean(parsed),model:r.data?.model??null},passed:Boolean(parsed)};
  }catch(e){return {configured:true,executed:true,observed:{reachable:false,error:redactedError(e)},passed:false}}
}
async function probeGemini(){
  if(!process.env.GEMINI_API_KEY)return {configured:false,executed:false,observed:null,passed:null};
  try{
    const model=process.env.GEMINI_MODEL??'gemini-3.8-flash';
    const r=await postJson(`${process.env.GEMINI_BASE_URL??'https://generativelanguage.googleapis.com/v1beta'}/models/${encodeURIComponent(model)}:generateContent`,{headers:{'x-goog-api-key':process.env.GEMINI_API_KEY},body:{contents:[{parts:[{text:'Return only JSON: {"supported":true,"reason":"probe"}'}]}],generationConfig:{responseMimeType:'application/json'}}});
    const raw=r.data?.candidates?.[0]?.content?.parts?.map(p=>p?.text??'').join(''); let parsed=null; try{parsed=JSON.parse(raw)}catch{}
    const valid=typeof parsed?.supported==='boolean'&&typeof parsed?.reason==='string';
    return {configured:true,executed:true,observed:{reachable:true,latency_ms:r.latency_ms,json_output:valid,model},passed:valid};
  }catch(e){return {configured:true,executed:true,observed:{reachable:false,error:redactedError(e)},passed:false}}
}

const providers={jev:await probeJev(),gpt_oss_120b:await probeGroq(),gemini_3_8:await probeGemini(),local_device_ai:{configured:false,executed:false,observed:null,passed:null,note:'requires supported real device bridge'}};
const required=['jev','gpt_oss_120b','gemini_3_8'];
const allExecuted=required.every(k=>providers[k].executed===true); const allPassed=required.every(k=>providers[k].passed===true);
const artifact={stage:'AI_RUNTIME_REAL_PROVIDER_CERTIFICATION',mode:'REAL_PROVIDER',run_id:`real-${sha({providers,at:now()}).slice(0,16)}`,generated_at:now(),status:allExecuted?(allPassed?'PROVIDERS_VERIFIED':'PROVIDER_FAILURE'):'RUNTIME_PENDING',accepted:false,providers,end_to_end_evidence:{executed:false,observed:null,passed:null},invariants:{mock_evidence_promoted_to_runtime:{required:0,observed:0,passed:true},secret_leakage:{required:0,observed:null,passed:null},unsupported_claim_as_verified:{required:0,observed:null,passed:null},provider_bypass:{required:0,observed:null,passed:null}},p2_1:'NOT_CERTIFIED',notes:['Provider reachability is not end-to-end certification.','Synthetic evidence is never promoted to runtime evidence.','accepted remains false until E2E evidence, required invariants, and prerequisite policy pass.']};
fs.mkdirSync('artifacts/control-plane',{recursive:true}); fs.writeFileSync(out,JSON.stringify(artifact,null,2)+'\n'); console.log(`${artifact.status} -> ${out}`);
