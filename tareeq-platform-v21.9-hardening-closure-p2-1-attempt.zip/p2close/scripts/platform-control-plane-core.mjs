import crypto from 'node:crypto';

export const TERMINAL = new Set(['VERIFIED_PASS','CONFIRMED_FAIL','INVALID','BLOCKED']);
export function executionIdentity(input={}) {
  const required=['release_id','commit_sha','environment_id','config_hash'];
  for (const k of required) if (!input[k]) throw new Error(`missing identity field: ${k}`);
  return Object.freeze({...input, identity_hash: crypto.createHash('sha256').update(required.map(k=>`${k}=${input[k]}`).join('\n')).digest('hex')});
}
export function evidenceDigest(e) {
  const copy={...e}; delete copy.digest;
  return crypto.createHash('sha256').update(JSON.stringify(copy)).digest('hex');
}
export function registerEvidence(e, identity) {
  if (!e || !e.stage || !e.status) throw new Error('invalid evidence');
  const bound={...e, identity, recorded_at:new Date().toISOString()};
  return Object.freeze({...bound,digest:evidenceDigest(bound)});
}
export function verifyEvidence(e, expected) {
  const reasons=[];
  if (!e?.digest || evidenceDigest(e)!==e.digest) reasons.push('DIGEST_MISMATCH');
  for (const k of ['release_id','commit_sha','environment_id','config_hash']) if (e?.identity?.[k]!==expected?.[k]) reasons.push(`IDENTITY_MISMATCH:${k}`);
  if (e?.executed===false || e?.status==='NOT_EXECUTED') reasons.push('NOT_EXECUTED');
  if (e?.skipped===true) reasons.push('SKIPPED');
  if (e?.status==='PASS' && !e?.evidence) reasons.push('PASS_WITHOUT_EVIDENCE');
  if (reasons.length) return {status:'INVALID',verified:false,reasons};
  if (e.status==='PASS') return {status:'VERIFIED_PASS',verified:true,reasons:[]};
  if (e.status==='FAIL') return {status:'CONFIRMED_FAIL',verified:true,reasons:[]};
  return {status:'UNVERIFIED',verified:false,reasons:['NON_TERMINAL_RESULT']};
}
export function orchestrate(stages, identity) {
  const out=[];
  let blocked=false;
  for (const stage of stages) {
    if (blocked) { out.push({stage:stage.stage,status:'BLOCKED',reason:'UPSTREAM_NOT_VERIFIED'}); continue; }
    const v=verifyEvidence(stage,identity); out.push({stage:stage.stage,...v});
    if (v.status!=='VERIFIED_PASS') blocked=true;
  }
  return {accepted:out.length>0 && out.every(x=>x.status==='VERIFIED_PASS'), stages:out};
}
