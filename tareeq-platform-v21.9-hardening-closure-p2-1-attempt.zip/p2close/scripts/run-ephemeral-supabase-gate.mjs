import { spawnSync } from 'node:child_process';

const DB_URL = process.env.EPHEMERAL_DATABASE_URL || 'postgresql://postgres:postgres@127.0.0.1:54322/postgres';

function run(cmd, args, opts = {}) {
  console.log(`\n> ${cmd} ${args.join(' ')}`);
  const r = spawnSync(cmd, args, { stdio: 'inherit', env: process.env, ...opts });
  if (r.error) throw new Error(`${cmd} unavailable: ${r.error.message}`);
  if (r.status !== 0) throw new Error(`${cmd} exited with ${r.status}`);
}

function available(cmd, args = ['--version']) {
  const r = spawnSync(cmd, args, { stdio: 'ignore' });
  return !r.error && r.status === 0;
}

if (!available('docker')) {
  console.error('v20.7 FAIL: Docker is required for the ephemeral Supabase integration gate.');
  process.exit(2);
}
if (!available('supabase')) {
  console.error('v20.7 FAIL: Supabase CLI is required. Install it in CI/local release environments.');
  process.exit(2);
}
if (!available('psql')) {
  console.error('v20.7 FAIL: psql is required for runtime authorization probes.');
  process.exit(2);
}

let started = false;
try {
  // Always start from an empty local database. `db stop --no-backup` makes
  // stale volumes incapable of turning a broken from-scratch replay green.
  spawnSync('supabase', ['db', 'stop', '--no-backup'], { stdio: 'inherit' });
  run('supabase', ['db', 'start']);
  started = true;

  // db start applies the complete migration ledger. Verify the expected count
  // before authorization probes so accidental migration omissions fail closed.
  run('node', ['scripts/verify-ephemeral-migration-ledger.mjs', DB_URL]);
  run('node', ['scripts/run-db-authorization-proof.mjs'], {
    env: { ...process.env, DATABASE_URL: DB_URL },
  });
  console.log('\n✅ v20.7 ephemeral Supabase integration gate: PASS');
} catch (error) {
  console.error(`\n❌ v20.7 ephemeral Supabase integration gate: FAIL — ${error.message}`);
  process.exitCode = 1;
} finally {
  if (started) spawnSync('supabase', ['db', 'stop', '--no-backup'], { stdio: 'inherit' });
}
