import fs from 'node:fs';
const files=['e2e/p1-2-failure-recovery.e2e.ts','scripts/p1-2-failure-recovery-contract.test.mjs','src/hooks/use-async-timeout.ts','src/components/shared/AsyncState.tsx'];
const missing=files.filter(x=>!fs.existsSync(x)); if(missing.length){console.error('P1-2 static gate: FAIL missing '+missing.join(', '));process.exit(2)}
const s=fs.readFileSync(files[0],'utf8');
const scenarios=['API timeout','network/backend outage','malformed response','empty result','transient failure','admin mutation dependency failure'];
for(const x of scenarios) if(!s.includes(x)){console.error('P1-2 static gate: FAIL missing '+x);process.exit(2)}
if(/test\.skip\(/.test(s)){console.error('P1-2 static gate: FAIL silent skip forbidden');process.exit(2)}
console.log(`P1-2 static gate: PASS (${scenarios.length}/${scenarios.length} failure/recovery scenarios implemented; runtime execution still required)`);
