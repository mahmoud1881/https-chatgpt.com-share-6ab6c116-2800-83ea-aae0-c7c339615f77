import fs from 'node:fs';
const required=['e2e/p1-1-data-lifecycle.e2e.ts','scripts/p1-1-data-lifecycle-contract.test.mjs','src/lib/journey/canonical.ts','scripts/data-review-gate.mjs'];
const missing=required.filter(p=>!fs.existsSync(p));
if(missing.length){console.error('P1-1 static gate: FAIL missing '+missing.join(', '));process.exit(2)}
const s=fs.readFileSync('e2e/p1-1-data-lifecycle.e2e.ts','utf8');
for(const x of ['pending is absent','rejected is absent','approved but unpublished is absent','published active route is visible','provenance and trust survive publication','revoked route disappears']) if(!s.includes(x)){console.error('P1-1 static gate: FAIL missing '+x);process.exit(2)}
console.log('P1-1 static gate: PASS (6/6 lifecycle scenarios implemented; runtime execution still required)');
