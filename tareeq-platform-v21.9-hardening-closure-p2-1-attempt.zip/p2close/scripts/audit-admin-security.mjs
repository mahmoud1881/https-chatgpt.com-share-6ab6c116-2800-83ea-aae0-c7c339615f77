import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const src = path.join(root, 'src');
const exts = new Set(['.ts', '.tsx']);
const files = [];
function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { if (e.name !== '__tests__') walk(p); } else if (exts.has(path.extname(e.name))) files.push(p);
  }
}
walk(src);
const rel = p => path.relative(root,p).replaceAll('\\\\','/');
const findings = [];
const inventory = [];

for (const file of files) {
  const text = fs.readFileSync(file,'utf8');
  const r = rel(file);
  if (r !== 'src/integrations/supabase/client.server.ts' && text.includes('SUPABASE_SERVICE_ROLE_KEY')) {
    findings.push(`${r}: direct SUPABASE_SERVICE_ROLE_KEY access outside canonical server client`);
  }
  if (/^import .*client\.server/m.test(text) && r.endsWith('.functions.ts')) {
    findings.push(`${r}: static client.server import from client-shippable *.functions.ts`);
  }
  if (!text.includes('createServerFn')) continue;
  const exportRe = /export const\s+(\w+)\s*=\s*createServerFn\(\{\s*method:\s*["'](GET|POST|PUT|PATCH|DELETE)["']/g;
  const matches=[...text.matchAll(exportRe)];
  for (let i=0;i<matches.length;i++) {
    const m=matches[i]; const start=m.index; const end=i+1<matches.length?matches[i+1].index:text.length;
    const block=text.slice(start,end); const name=m[1]; const method=m[2];
    const admin = block.includes('.middleware([requireSupabaseAdmin])');
    const auth = admin || block.includes('.middleware([requireSupabaseAuth])');
    const serviceRole = block.includes('supabaseAdmin') || block.includes('client.server');
    const adminSensitive = /(^|\/)(admin[^/]*|route-planner\/admin[^/]*)/.test(r) || /^admin|Admin|moderate|rollback|seed|importOsm|previewOsm|resolveMissing|mergeStops|deleteRoute|bulkVerify|updateStop|reorderRoute|updateRouteMeta|runOsm|submitBusLine/.test(name);
    inventory.push({file:r,name,method,gate:admin?'admin':auth?'auth':'public',serviceRole,adminSensitive});
    if (adminSensitive && !admin) findings.push(`${r}#${name}: admin-sensitive endpoint missing requireSupabaseAdmin`);
  }
}

// Raw HTTP/session guards must share the canonical role decision.
const verify = path.join(src,'integrations/supabase/verify-admin-session.server.ts');
if (fs.existsSync(verify)) {
  const t=fs.readFileSync(verify,'utf8');
  if (!t.includes('hasAdminRole')) findings.push('verify-admin-session.server.ts: raw request guard does not use canonical hasAdminRole');
}

const migrations=path.join(root,'supabase','migrations');
let sql='';
if (fs.existsSync(migrations)) for (const f of fs.readdirSync(migrations).filter(x=>x.endsWith('.sql'))) sql += '\n'+fs.readFileSync(path.join(migrations,f),'utf8');
const cleanSql = sql.replace(/--.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '');
const tables=[...cleanSql.matchAll(/CREATE TABLE(?: IF NOT EXISTS)?\s+public\.([a-zA-Z0-9_]+)/gi)].map(m=>m[1]);
const rls=new Set([...cleanSql.matchAll(/ALTER TABLE\s+public\.([a-zA-Z0-9_]+)\s+ENABLE ROW LEVEL SECURITY/gi)].map(m=>m[1]));
const dropped=new Set([...cleanSql.matchAll(/DROP TABLE(?: IF EXISTS)?\s+public\.([a-zA-Z0-9_]+)/gi)].map(m=>m[1]));
const noRls=[...new Set(tables)].filter(t=>!dropped.has(t) && !rls.has(t));
if (noRls.length) findings.push(`RLS: created public tables without observed ENABLE ROW LEVEL SECURITY: ${noRls.join(', ')}`);

fs.mkdirSync(path.join(root,'artifacts'),{recursive:true});
fs.writeFileSync(path.join(root,'artifacts','endpoint-security-inventory.json'), JSON.stringify({generatedAt:new Date().toISOString(),inventory,rls:{createdTables:[...new Set(tables)],enabled:[...rls],missing:noRls}},null,2));
console.log(`Security inventory: ${inventory.length} server functions; ${inventory.filter(x=>x.gate==='admin').length} admin; ${inventory.filter(x=>x.gate==='auth').length} authenticated; ${inventory.filter(x=>x.gate==='public').length} public.`);
if (findings.length) { console.error('\nSECURITY AUDIT FAILED\n- '+findings.join('\n- ')); process.exit(1); }
console.log(`Admin authorization + service-role boundary + RLS static audit: PASS`);
