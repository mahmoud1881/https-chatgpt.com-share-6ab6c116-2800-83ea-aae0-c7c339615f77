#!/usr/bin/env python3
"""Rebuild metro-station 'nearby' with real bus/microbus/landmark data.

Strategy:
  1) Load real bus/microbus/informal stops (with coords) from project data.
  2) For each metro line, run ONE Overpass query over the line's bbox
     (padded ~1km) fetching named amenities / public-transport nodes.
  3) For each station, combine local stops + line's OSM pool, filter out
     any name that matches an existing metro station, dedupe by name,
     keep the 8 closest within RADIUS_M.
"""
import json, math, re, time, urllib.parse, urllib.request

METRO_PATH = "public/data/metro-stations.json"
STOP_SOURCES = [
    ("public/data/cairo-stations.json", "name"),
    ("public/data/eg-governorate-stations.json", "name_ar"),
    ("public/data/eg-informal-stops.json", "name_ar"),
]
RADIUS_M = 1000
LIMIT = 8

def hav(a1, o1, a2, o2):
    from math import radians, sin, cos, asin, sqrt
    dl = radians(a2 - a1); do = radians(o2 - o1)
    x = sin(dl/2)**2 + cos(radians(a1))*cos(radians(a2))*sin(do/2)**2
    return 2*6371.0*asin(sqrt(x))

metro = json.load(open(METRO_PATH, encoding="utf-8"))

def norm(s: str) -> str:
    return re.sub(r"\s+", " ", s or "").replace("أ", "ا").replace("إ", "ا").replace("آ", "ا").replace("ى", "ي").replace("ة", "ه").strip().lower()

banned = set()
for s in metro:
    for n in [s.get("name"), s.get("name_en"), *(s.get("aliases") or [])]:
        if n: banned.add(norm(n))

def is_metro_name(n: str) -> bool:
    if not n: return True
    k = norm(n)
    if k in banned: return True
    if "مترو" in k or "metro station" in k: return True
    return False

def is_bad_osm(tags) -> bool:
    if tags.get("station") == "subway": return True
    if tags.get("subway") == "yes": return True
    if tags.get("railway") in {"station", "halt", "subway_entrance"}: return True
    if tags.get("route") == "subway": return True
    return False

# --- Local real stops
local = []
for path, key in STOP_SOURCES:
    try:
        rows = json.load(open(path, encoding="utf-8"))
    except FileNotFoundError:
        continue
    for r in rows:
        lat, lng = r.get("lat"), r.get("lng")
        n = r.get(key) or r.get("name") or r.get("name_ar")
        if lat is None or lng is None or not n or is_metro_name(n): continue
        local.append({"name": n, "lat": float(lat), "lng": float(lng), "kind": "stop"})
print(f"[local] {len(local)} stops")

OVERPASS = [
    "https://overpass.kumi.systems/api/interpreter",
    "https://overpass-api.de/api/interpreter",
    "https://overpass.private.coffee/api/interpreter",
]

def overpass_bbox(south, west, north, east):
    q = f"""
[out:json][timeout:180];
(
  node["amenity"~"hospital|clinic|pharmacy|university|college|school|place_of_worship|marketplace|bank|bus_station|police|fire_station|library|post_office|cinema|courthouse|fuel"]["name"]({south},{west},{north},{east});
  node["shop"~"mall|supermarket|department_store"]["name"]({south},{west},{north},{east});
  node["tourism"~"museum|attraction|hotel"]["name"]({south},{west},{north},{east});
  node["public_transport"~"station|stop_position|platform"]["name"]({south},{west},{north},{east});
  node["highway"="bus_stop"]["name"]({south},{west},{north},{east});
  way["amenity"~"hospital|university|college|school|place_of_worship|marketplace|bus_station|stadium"]["name"]({south},{west},{north},{east});
  way["shop"~"mall|supermarket|department_store"]["name"]({south},{west},{north},{east});
);
out center 2000;
""".strip()
    body = ("data=" + urllib.parse.quote(q)).encode()
    for url in OVERPASS:
        for attempt in range(3):
            try:
                req = urllib.request.Request(url, data=body, headers={"User-Agent":"tareeq/1.0"})
                with urllib.request.urlopen(req, timeout=180) as r:
                    return json.loads(r.read().decode()).get("elements", [])
            except Exception as e:
                print(f"  {url} try{attempt+1}: {e}")
                time.sleep(5*(attempt+1))
    return []

def pick_name(tags):
    for k in ("name:ar","name","name:en"):
        v = tags.get(k)
        if v: return v.strip()
    return None

# --- Per line bbox
lines = {}
for s in metro:
    lines.setdefault(s["line"], []).append(s)

osm_pool_by_line = {}
for ln, sts in lines.items():
    lats = [s["lat"] for s in sts if s.get("lat") is not None]
    lngs = [s["lng"] for s in sts if s.get("lng") is not None]
    pad = 0.012  # ~1.3 km
    bbox = (min(lats)-pad, min(lngs)-pad, max(lats)+pad, max(lngs)+pad)
    print(f"[line {ln}] {len(sts)} stations bbox={bbox}")
    els = overpass_bbox(*bbox)
    pool = []
    for el in els:
        tags = el.get("tags",{})
        if is_bad_osm(tags): continue
        name = pick_name(tags)
        if not name or is_metro_name(name): continue
        elat = el.get("lat") or (el.get("center") or {}).get("lat")
        elng = el.get("lon") or (el.get("center") or {}).get("lon")
        if elat is None or elng is None: continue
        cat = tags.get("amenity") or tags.get("shop") or tags.get("tourism") or tags.get("public_transport") or tags.get("highway") or "landmark"
        pool.append({"name": name, "lat": elat, "lng": elng, "kind": cat})
    print(f"  overpass returned {len(pool)} named POIs")
    osm_pool_by_line[ln] = pool
    time.sleep(3)

# --- Assign per station
updated = 0
for s in metro:
    lat, lng = s.get("lat"), s.get("lng")
    if lat is None or lng is None: continue
    cands = []
    for x in local + osm_pool_by_line.get(s["line"], []):
        d = hav(lat,lng,x["lat"],x["lng"])
        if d*1000 <= RADIUS_M:
            cands.append({**x, "km": round(d,2)})
    dedup = {}
    for c in cands:
        k = norm(c["name"])
        if k in dedup and dedup[k]["km"] <= c["km"]: continue
        dedup[k] = c
    picked = sorted(dedup.values(), key=lambda x: x["km"])[:LIMIT]
    if picked:
        s["nearby"] = [{"name":p["name"],"km":p["km"],"lat":p["lat"],"lng":p["lng"],"kind":p["kind"]} for p in picked]
        updated += 1
    else:
        s["nearby"] = []
    print(f"{s['line']}/{s['seq']:02d} {s['name']}: {len(picked)}")

json.dump(metro, open(METRO_PATH,"w",encoding="utf-8"), ensure_ascii=False)
print(f"done. updated {updated}/{len(metro)}")
