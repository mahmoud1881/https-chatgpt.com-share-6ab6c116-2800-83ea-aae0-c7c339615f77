import fs from 'node:fs';
import path from 'node:path';

const ROOT=process.cwd();
const executableRoots=['src','scripts','deploy'];
const files=[];
const SELF='scripts/hardening-closure-gate.mjs';
function walk(p){if(!fs.existsSync(p))return;for(const ent of fs.readdirSync(p,{withFileTypes:true})){const f=path.join(p,ent.name);if(ent.isDirectory()){if(['node_modules','dist','artifacts','.git'].includes(ent.name))continue;walk(f)}else if(/\.(?:[cm]?[jt]sx?)$/.test(ent.name)&&!ent.name.endsWith('.test.mjs')&&!ent.name.endsWith('.test.ts')&&!ent.name.endsWith('.test.tsx'))files.push(f)}}
for(const r of executableRoots) walk(path.join(ROOT,r));
const rel=f=>path.relative(ROOT,f).replaceAll('\\','/');
const read=f=>fs.readFileSync(f,'utf8');
const violations=[];
const add=(rule,file,detail)=>violations.push({rule,file:rel(file),detail});

// 1) Service-role secret may only be read by the canonical server-only Supabase client.
for(const f of files){const r=rel(f),s=read(f);if(r===SELF)continue;const direct=/process\.env\.SUPABASE_SERVICE_ROLE_KEY|env\.SUPABASE_SERVICE_ROLE_KEY|env\[['\"]SUPABASE_SERVICE_ROLE_KEY['\"]\]/.test(s);if(direct&&r!=='src/integrations/supabase/client.server.ts')add('DIRECT_SERVICE_ROLE_SECRET',f,'service-role secret consumed outside canonical server boundary');}

// 2) Legacy static GPS HMAC trust must not return in executable runtime code.
for(const f of files){if(rel(f)===SELF)continue;const s=read(f);if(/TAREEQ_LOCATION_EVIDENCE_HMAC_KEY|createHmac\([^)]*location|device[_-]?gps[^\n]{0,100}hmac/i.test(s))add('STATIC_GPS_HMAC',f,'legacy shared-secret GPS trust detected');}

// 3) Production-like Geo must explicitly reject public community/demo endpoints.
const gateway=path.join(ROOT,'deploy/scripts/ai-journey-runtime-gateway.mjs');
if(!fs.existsSync(gateway)) violations.push({rule:'GEO_GATEWAY_MISSING',file:'deploy/scripts/ai-journey-runtime-gateway.mjs',detail:'gateway missing'});
else {const s=read(gateway);for(const token of ['PRODUCTION_LIKE','public_osrm_forbidden_in_production','public_overpass_forbidden_in_production','enforceProductionProviders'])if(!s.includes(token))add('PUBLIC_GEO_PRODUCTION_GUARD',gateway,`missing ${token}`);}

// 4) Extensions may propose deployment, never execute/request broad deployment actions.
for(const f of files){const r=rel(f),s=read(f);if(r==='scripts/control-plane-v1-sdk.mjs')continue;if(/\brequestDeploymentAction\s*\(|\bexecuteDeployment\s*\(/.test(s))add('BROAD_EXTENSION_DEPLOYMENT',f,'broad deployment execution/request API detected');}
const sdk=path.join(ROOT,'scripts/control-plane-v1-sdk.mjs');
if(fs.existsSync(sdk)){const s=read(sdk);if(!s.includes("proposeDeployment(v)"))add('DEPLOYMENT_PROPOSAL_MISSING',sdk,'proposal-only deployment API missing');if(!s.includes("deployment:propose"))add('DEPLOYMENT_SCOPE_MISSING',sdk,'deployment:propose permission missing');}

// 5) Authoritative truth is derived: reject direct assignments to terminal truth in executable code.
const authorityAssignment=/(?:\.state|\[['\"]state['\"]\]|\bstatus)\s*=\s*['\"](?:CLOSED|VERIFIED_PASS|CERTIFIED)['\"]/g;
const authorityAllow=new Set(['scripts/platform-control-plane-core.mjs','scripts/platform-control-plane-remediation.mjs']);
for(const f of files){const r=rel(f),s=read(f);if(authorityAllow.has(r))continue;if(authorityAssignment.test(s))add('DIRECT_AUTHORITATIVE_STATE_WRITE',f,'terminal authoritative state assigned directly');authorityAssignment.lastIndex=0;}

// 6) Incident updates must remain immutable reducers.
const rem=path.join(ROOT,'scripts/platform-control-plane-remediation.mjs');
if(fs.existsSync(rem)){const s=read(rem);for(const fn of ['recordRemediation','recordTestResult','recordReverification','applyOverride']){const start=s.indexOf(`export function ${fn}`);if(start<0){add('IMMUTABLE_REDUCER_MISSING',rem,`${fn} missing`);continue;}const chunk=s.slice(start,s.indexOf('\nexport function ',start+20)>0?s.indexOf('\nexport function ',start+20):s.length);if(!chunk.includes('immutableIncidentUpdate'))add('DIRECT_INCIDENT_MUTATION',rem,`${fn} does not use immutableIncidentUpdate`);}}

// 7) Journey gateway must use dedicated RPC credentials, not service role.
if(fs.existsSync(gateway)){const s=read(gateway);for(const token of ['TAREEQ_JOURNEY_EVIDENCE_RPC_TOKEN','TAREEQ_JOURNEY_EVIDENCE_API_KEY','record_ai_certification_journey'])if(!s.includes(token))add('JOURNEY_LEAST_PRIVILEGE',gateway,`missing ${token}`);if(s.includes('SUPABASE_SERVICE_ROLE_KEY'))add('JOURNEY_SERVICE_ROLE',gateway,'journey gateway must not use service role');}

const result={gate:'HARDENING_CLOSURE_SWEEP',scanned_files:files.length,passed:violations.length===0,violations};
fs.mkdirSync(path.join(ROOT,'artifacts/control-plane'),{recursive:true});
fs.writeFileSync(path.join(ROOT,'artifacts/control-plane/hardening-closure-sweep.json'),JSON.stringify(result,null,2)+'\n');
if(violations.length){console.error(JSON.stringify(result,null,2));process.exit(1)}
console.log(`✓ hardening closure sweep passed (${files.length} executable files scanned)`);
