import fs from 'node:fs';
import path from 'node:path';
const dir='supabase/migrations';
const files=fs.readdirSync(dir).filter(f=>f.endsWith('.sql')).sort();
const all=files.map(f=>fs.readFileSync(path.join(dir,f),'utf8')).join('\n');
const failures=[];
if (!all.includes('v20.6: close PostgreSQL')) failures.push('v20.6 SECURITY DEFINER hardening migration missing');
for (const f of ['scripts/db-authorization-catalog-audit.sql','scripts/db-authorization-negative-proof.sql','scripts/run-db-authorization-proof.mjs']) if(!fs.existsSync(f)) failures.push(`${f} missing`);
const definer=[...all.matchAll(/SECURITY\s+DEFINER/gi)].length;
const grants=[...all.matchAll(/GRANT\s+EXECUTE/gi)].length;
const revokes=[...all.matchAll(/REVOKE\s+EXECUTE/gi)].length;
fs.mkdirSync('artifacts',{recursive:true});
fs.writeFileSync('artifacts/database-authorization-static.json',JSON.stringify({generatedAt:new Date().toISOString(),migrationFiles:files.length,securityDefinerOccurrences:definer,grantExecuteOccurrences:grants,revokeExecuteOccurrences:revokes,proofSuite:['catalog','negative-role-boundary']},null,2));
if(failures.length){console.error('DB AUTHORIZATION STATIC AUDIT FAILED\n- '+failures.join('\n- '));process.exit(1)}
console.log(`DB authorization static audit: PASS (${files.length} migrations; ${definer} SECURITY DEFINER occurrences)`);
