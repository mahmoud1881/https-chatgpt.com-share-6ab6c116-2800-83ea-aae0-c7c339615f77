#!/usr/bin/env -S node --experimental-strip-types
/** Structural validation only; independent route review remains a release requirement. */

import { readFile, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";

const DATA_DIR = path.join(import.meta.dirname, "..", "public", "data", "eg");

type Stop = {
  stop_id: string;
  canonical: string;
  normalized?: string;
  aliases?: string[];
  lat: number | null;
  lng: number | null;
  governorate?: string | null;
  area?: string;
  modes?: string[];
  sources?: string[];
  has_coords?: boolean;
};

type RouteStopRef = { name: string; stop_id: string };
type Route = {
  route_id: string;
  code?: string | null;
  mode?: string;
  origin?: string;
  destination?: string;
  governorate?: string | null;
  operator?: string | null;
  stop_count?: number;
  stops: RouteStopRef[];
};

async function loadJson<T>(filename: string): Promise<T> {
  const full = path.join(DATA_DIR, filename);
  if (!existsSync(full)) {
    throw new Error(`missing required data file: ${full}`);
  }
  return JSON.parse(await readFile(full, "utf-8")) as T;
}

// Roughly Egypt's bounding box, generous on all sides to avoid false
// positives near borders (Sudan/Libya/Israel/Gaza land crossings, Red Sea
// islands) — this is a sanity check for "obviously wrong" coordinates
// (e.g. swapped lat/lng, 0/0, or a stray digit), not a precise border.
const EGYPT_BOUNDS = { minLat: 20, maxLat: 33, minLng: 23, maxLng: 38 };

async function main() {
  const errors: string[] = [];
  const warnings: string[] = [];

  const stopsMaster = await loadJson<{ count: number; stops: Stop[] }>("stops_master.json");
  const routesMaster = await loadJson<{ count: number; routes: Route[] }>("routes_master.json");
  const aliases = await loadJson<Record<string, string>>("aliases.json");

  const stops = stopsMaster.stops;
  const routes = routesMaster.routes;
  if (routesMaster.count !== routes.length) errors.push("routes count metadata mismatch");
  if (stopsMaster.count !== stops.length) errors.push("stops count metadata mismatch");

  // --- core counts (match the historical validation_report.json shape) ---
  const stopsTotal = stops.length;
  const stopsWithCoords = stops.filter(
    (s) => s.has_coords ?? (s.lat != null && s.lng != null),
  ).length;
  const routesTotal = routes.length;
  const aliasCount = Object.keys(aliases).length;

  // --- new hard-error checks: duplicate IDs ---
  const stopIdCounts = new Map<string, number>();
  for (const s of stops) stopIdCounts.set(s.stop_id, (stopIdCounts.get(s.stop_id) ?? 0) + 1);
  for (const [id, count] of stopIdCounts) {
    if (count > 1)
      errors.push(`duplicate stop_id "${id}" appears ${count} times in stops_master.json`);
  }

  const routeIdCounts = new Map<string, number>();
  for (const r of routes) routeIdCounts.set(r.route_id, (routeIdCounts.get(r.route_id) ?? 0) + 1);
  for (const [id, count] of routeIdCounts) {
    if (count > 1)
      errors.push(`duplicate route_id "${id}" appears ${count} times in routes_master.json`);
  }

  // --- new hard-error check: out-of-bounds coordinates ---
  let outOfBounds = 0;
  for (const s of stops) {
    if (s.lat == null || s.lng == null) continue;
    const inBounds =
      s.lat >= EGYPT_BOUNDS.minLat &&
      s.lat <= EGYPT_BOUNDS.maxLat &&
      s.lng >= EGYPT_BOUNDS.minLng &&
      s.lng <= EGYPT_BOUNDS.maxLng;
    if (!inBounds) {
      outOfBounds++;
      if (outOfBounds <= 10) {
        errors.push(
          `stop "${s.stop_id}" (${s.canonical}) has out-of-Egypt coordinates: ${s.lat}, ${s.lng}`,
        );
      }
    }
  }
  if (outOfBounds > 10) errors.push(`… and ${outOfBounds - 10} more out-of-bounds stops`);

  // --- hard error: declared stop_count vs actual stops[].length ---
  let stopCountMismatches = 0;
  for (const r of routes) {
    if (typeof r.stop_count === "number" && r.stop_count !== r.stops.length) {
      stopCountMismatches++;
      if (stopCountMismatches <= 5) {
        errors.push(
          `route "${r.route_id}" declares stop_count=${r.stop_count} but has ${r.stops.length} stops`,
        );
      }
    }
  }
  if (stopCountMismatches > 5)
    errors.push(`… and ${stopCountMismatches - 5} more stop_count mismatches`);

  // --- orphan route→stop references (matches historical report) ---
  const validStopIds = new Set(stops.map((s) => s.stop_id));
  const orphanRefsByName = new Map<string, number>();
  let orphanTotalRefs = 0;
  for (const r of routes) {
    for (const ref of r.stops) {
      if (!validStopIds.has(ref.stop_id)) {
        orphanTotalRefs++;
        orphanRefsByName.set(ref.name, (orphanRefsByName.get(ref.name) ?? 0) + 1);
      }
    }
  }
  if (orphanTotalRefs) errors.push(`${orphanTotalRefs} unresolved stop references`);
  const reviewPath = path.join(DATA_DIR, "../../..", "data-review", "eg-route-quarantine.v1.json");
  const pendingReview = existsSync(reviewPath)
    ? JSON.parse(await readFile(reviewPath, "utf-8")).quarantined.filter(
        (entry: { reviewStatus: string }) => entry.reviewStatus === "pending",
      ).length
    : 0;
  if (pendingReview) warnings.push(`${pendingReview} quarantined records await independent review`);
  const topOrphans = [...orphanRefsByName.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([name, refs]) => ({ name, refs }));

  // --- external OSM enrichment file: basic stats only (see header comment
  // for why the historical new_stops/added_aliases/added_routes deltas
  // aren't reproduced here) ---
  let external: Record<string, unknown> = {
    note: "external/osm-relations.json not found — skipped",
  };
  const externalPath = path.join(DATA_DIR, "external", "osm-relations.json");
  if (existsSync(externalPath)) {
    const osmRelations = JSON.parse(await readFile(externalPath, "utf-8")) as {
      relation_count?: number;
      node_count?: number;
      fetched_at?: string;
    };
    external = {
      relation_count: osmRelations.relation_count ?? null,
      node_count: osmRelations.node_count ?? null,
      fetched_at: osmRelations.fetched_at ?? null,
      note: "basic stats only — see script header for why merge-delta counts aren't reproduced",
    };
  }

  const report = {
    scope: "structural_only_not_release_approval",
    structural_errors: errors.length,
    quarantined_pending_review: pendingReview,
    stops_total: stopsTotal,
    stops_with_coords: stopsWithCoords,
    routes_total: routesTotal,
    alias_count: aliasCount,
    orphan_unique_names: orphanRefsByName.size,
    orphan_total_refs: orphanTotalRefs,
    top_orphans: topOrphans,
    external,
  };

  const reportPath = path.join(DATA_DIR, "validation_report.json");
  await writeFile(reportPath, JSON.stringify(report, null, 2) + "\n", "utf-8");

  console.log("📊 Data validation report");
  console.log(`   stops: ${stopsTotal} total, ${stopsWithCoords} with coords`);
  console.log(`   routes: ${routesTotal} total`);
  console.log(`   aliases: ${aliasCount}`);
  console.log(
    `   orphan stop refs: ${orphanTotalRefs} refs across ${orphanRefsByName.size} distinct name(s)`,
  );
  console.log(`   report written to ${path.relative(process.cwd(), reportPath)}`);

  if (warnings.length > 0) {
    console.warn(`\n⚠️  ${warnings.length} warning(s):`);
    for (const w of warnings) console.warn(`   - ${w}`);
  }

  if (errors.length > 0) {
    console.error(`\n❌ ${errors.length} error(s):`);
    for (const e of errors) console.error(`   - ${e}`);
    process.exit(1);
  }

  console.log(
    "\n✅ Structural data validation passed; this does not certify route accuracy or release readiness.",
  );
}

main().catch((err) => {
  console.error("❌ validate:data crashed:", err instanceof Error ? err.message : err);
  process.exit(1);
});
