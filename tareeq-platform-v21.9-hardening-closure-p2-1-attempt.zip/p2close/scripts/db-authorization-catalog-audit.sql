\set ON_ERROR_STOP on
-- Fails when the deployed database violates v20.6 invariants.
DO $audit$
DECLARE problems text;
BEGIN
  SELECT string_agg(format('%I.%I', n.nspname, c.relname), ', ')
    INTO problems
  FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
  WHERE n.nspname='public' AND c.relkind IN ('r','p')
    AND NOT c.relrowsecurity
    AND c.relname NOT IN ('spatial_ref_sys');
  IF problems IS NOT NULL THEN
    RAISE EXCEPTION 'RLS disabled on public tables: %', problems;
  END IF;

  SELECT string_agg(p.oid::regprocedure::text, ', ')
    INTO problems
  FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
  WHERE n.nspname='public' AND p.prosecdef
    AND (p.proconfig IS NULL OR NOT EXISTS (
      SELECT 1 FROM unnest(p.proconfig) cfg WHERE cfg LIKE 'search_path=%'
    ));
  IF problems IS NOT NULL THEN
    RAISE EXCEPTION 'SECURITY DEFINER without pinned search_path: %', problems;
  END IF;

  SELECT string_agg(p.oid::regprocedure::text, ', ')
    INTO problems
  FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
  WHERE n.nspname='public' AND p.prosecdef
    AND has_function_privilege('public', p.oid, 'EXECUTE');
  IF problems IS NOT NULL THEN
    RAISE EXCEPTION 'SECURITY DEFINER executable by PUBLIC: %', problems;
  END IF;
END $audit$;

SELECT 'database authorization catalog audit: PASS' AS result;
