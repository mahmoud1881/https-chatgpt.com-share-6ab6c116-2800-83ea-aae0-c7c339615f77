-- Run only against disposable CI/staging DB. All fixtures are rolled back.
\set ON_ERROR_STOP on
BEGIN;
INSERT INTO auth.users (id, email) VALUES
('11111111-1111-4111-8111-111111111111', 'route-security-one@example.invalid'),
('22222222-2222-4222-8222-222222222222', 'route-security-two@example.invalid');
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub', '11111111-1111-4111-8111-111111111111', true);
SELECT set_config('request.jwt.claims', '{"sub":"11111111-1111-4111-8111-111111111111","role":"authenticated"}', true);
-- Omitted owner must be assigned by the DB, not rejected.
INSERT INTO public.community_routes (title, from_area, to_area, country)
VALUES ('Security valid route', 'Cairo test', 'Giza test', 'eg');
DO $$
BEGIN
  IF has_column_privilege(current_user, 'public.community_routes', 'price_egp', 'SELECT')
     OR has_column_privilege(current_user, 'public.community_routes', 'price_egp', 'INSERT')
     OR has_column_privilege(current_user, 'public.community_routes', 'price_egp', 'UPDATE')
     OR has_column_privilege(current_user, 'public.community_routes_public', 'price_egp', 'SELECT') THEN
    RAISE EXCEPTION 'FAIL: retired pricing remains available to clients';
  END IF;
  BEGIN
    INSERT INTO public.community_routes (title, country, status)
    VALUES ('Security forged status', 'eg', 'confirmed');
    RAISE EXCEPTION 'FAIL: forged status accepted';
  EXCEPTION WHEN insufficient_privilege THEN NULL; END;
  BEGIN
    INSERT INTO public.community_routes (title, country, confirmations)
    VALUES ('Security forged votes', 'eg', 999);
    RAISE EXCEPTION 'FAIL: forged confirmations accepted';
  EXCEPTION WHEN insufficient_privilege THEN NULL; END;
  BEGIN
    INSERT INTO public.community_routes (title, country, user_id)
    VALUES ('Security forged owner', 'eg', '22222222-2222-4222-8222-222222222222');
    RAISE EXCEPTION 'FAIL: forged owner accepted';
  EXCEPTION WHEN insufficient_privilege THEN NULL; END;
END $$;
ROLLBACK;
