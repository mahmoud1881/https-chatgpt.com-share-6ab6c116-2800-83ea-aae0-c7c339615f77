-- v20.8 deterministic semantic fingerprint for application-owned database surface.
-- Keep this catalog-only and read-only: safe against staging/production.
WITH objects AS (
  SELECT 'table' kind, c.relname name,
    jsonb_build_object('rls', c.relrowsecurity, 'force_rls', c.relforcerowsecurity,
      'acl', coalesce((SELECT jsonb_agg(x ORDER BY x) FROM unnest(coalesce(c.relacl, acldefault('r', c.relowner))) x), '[]'::jsonb)) detail
  FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
  WHERE n.nspname='public' AND c.relkind IN ('r','p')
  UNION ALL
  SELECT 'column', c.relname||'.'||a.attname,
    jsonb_build_object('type',format_type(a.atttypid,a.atttypmod),'not_null',a.attnotnull,
      'identity',a.attidentity,'generated',a.attgenerated,'default',pg_get_expr(d.adbin,d.adrelid))
  FROM pg_attribute a JOIN pg_class c ON c.oid=a.attrelid JOIN pg_namespace n ON n.oid=c.relnamespace
  LEFT JOIN pg_attrdef d ON d.adrelid=a.attrelid AND d.adnum=a.attnum
  WHERE n.nspname='public' AND c.relkind IN ('r','p') AND a.attnum>0 AND NOT a.attisdropped
  UNION ALL
  SELECT 'constraint', c.relname||'.'||con.conname, jsonb_build_object('definition',pg_get_constraintdef(con.oid,true))
  FROM pg_constraint con JOIN pg_class c ON c.oid=con.conrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public'
  UNION ALL
  SELECT 'index', i.relname, jsonb_build_object('definition',pg_get_indexdef(i.oid))
  FROM pg_class i JOIN pg_namespace n ON n.oid=i.relnamespace WHERE n.nspname='public' AND i.relkind='i'
  UNION ALL
  SELECT 'policy', c.relname||'.'||p.polname,
    jsonb_build_object('permissive',p.polpermissive,'cmd',p.polcmd,
      'roles',coalesce((SELECT jsonb_agg(r.rolname ORDER BY r.rolname) FROM unnest(p.polroles) x(oid) JOIN pg_roles r ON r.oid=x.oid),'[]'::jsonb),
      'using',pg_get_expr(p.polqual,p.polrelid),'check',pg_get_expr(p.polwithcheck,p.polrelid))
  FROM pg_policy p JOIN pg_class c ON c.oid=p.polrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public'
  UNION ALL
  SELECT 'function', p.proname||'('||pg_get_function_identity_arguments(p.oid)||')',
    jsonb_build_object('kind',p.prokind,'security_definer',p.prosecdef,'config',coalesce(to_jsonb(p.proconfig),'[]'::jsonb),
      'acl',coalesce((SELECT jsonb_agg(x ORDER BY x) FROM unnest(coalesce(p.proacl, acldefault('f',p.proowner))) x),'[]'::jsonb),
      'definition',pg_get_functiondef(p.oid))
  FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public'
  UNION ALL
  SELECT CASE c.relkind WHEN 'v' THEN 'view' ELSE 'materialized_view' END, c.relname,
    jsonb_build_object('definition',pg_get_viewdef(c.oid,true),'acl',coalesce((SELECT jsonb_agg(x ORDER BY x) FROM unnest(coalesce(c.relacl, acldefault('r',c.relowner))) x),'[]'::jsonb))
  FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relkind IN ('v','m')
  UNION ALL
  SELECT 'trigger', c.relname||'.'||t.tgname, jsonb_build_object('definition',pg_get_triggerdef(t.oid,true))
  FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND NOT t.tgisinternal
  UNION ALL
  SELECT 'type', t.typname, jsonb_build_object('kind',t.typtype,'category',t.typcategory,
    'enum',coalesce((SELECT jsonb_agg(e.enumlabel ORDER BY e.enumsortorder) FROM pg_enum e WHERE e.enumtypid=t.oid),'[]'::jsonb))
  FROM pg_type t JOIN pg_namespace n ON n.oid=t.typnamespace WHERE n.nspname='public' AND t.typtype IN ('e','d')
  UNION ALL
  SELECT 'extension', e.extname, '{}'::jsonb FROM pg_extension e WHERE e.extname <> 'plpgsql'
)
SELECT jsonb_build_object(
  'format','tareeq-schema-fingerprint-v1',
  'objects',coalesce(jsonb_agg(jsonb_build_object('kind',kind,'name',name,'detail',detail) ORDER BY kind,name),'[]'::jsonb)
)::text FROM objects;
