import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";

const env = {
  ...process.env,
  VITE_SUPABASE_URL: process.env.VITE_SUPABASE_URL || "https://api.example.com",
  VITE_SUPABASE_PUBLISHABLE_KEY: process.env.VITE_SUPABASE_PUBLISHABLE_KEY || "ci-placeholder",
  VITE_SUPABASE_PROJECT_ID: process.env.VITE_SUPABASE_PROJECT_ID || "self-hosted",
  VITE_SITE_URL: process.env.VITE_SITE_URL || "https://example.com",
};

const checks = [
  ["admin/security architecture audit", ["node", "scripts/audit-admin-security.mjs"]],
  ["no transit pricing", ["node", "scripts/check-no-transit-pricing.mjs"]],
  ["typecheck", ["bun", "run", "typecheck"]],
  ["lint", ["bun", "run", "lint"]],
  ["unit tests", ["bun", "run", "test"]],
  ["build", ["bun", "run", "build"]],
  ["E2E smoke", ["bun", "run", "test:e2e"]],
  ["data validation", ["bun", "run", "validate:data"]],
];

for (const [name, command] of checks) {
  console.log(`\\n=== ${name} ===`);
  const r = spawnSync(command[0], command.slice(1), { stdio: "inherit", env });
  if (r.status !== 0) process.exit(r.status ?? 1);
}

if (!existsSync("deploy/app/Dockerfile")) {
  console.error("\\n❌ Dockerfile missing");
  process.exit(1);
}

const docker = spawnSync("docker", ["--version"], { stdio: "ignore" });
if (docker.status === 0) {
  if (!/^[a-f0-9]{40}$/i.test(env.RELEASE_COMMIT ?? "")) {
    console.error("Set RELEASE_COMMIT to the full source SHA before building a release image.");
    process.exit(2);
  }
  console.log("\\n=== docker build ===");
  const r = spawnSync(
    "docker",
    [
      "build",
      "-f",
      "deploy/app/Dockerfile",
      "-t",
      "tareeq-platform-release-gate:latest",
      ".",
      "--build-arg",
      `RELEASE_COMMIT=${env.RELEASE_COMMIT}`,
      "--build-arg",
      `VITE_SUPABASE_URL=${env.VITE_SUPABASE_URL}`,
      "--build-arg",
      `VITE_SUPABASE_PUBLISHABLE_KEY=${env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
      "--build-arg",
      `VITE_SUPABASE_PROJECT_ID=${env.VITE_SUPABASE_PROJECT_ID}`,
      "--build-arg",
      `VITE_SITE_URL=${env.VITE_SITE_URL}`,
      "--build-arg",
      "VITE_AUTH_PROVIDER=supabase",
    ],
    { stdio: "inherit", env },
  );
  if (r.status !== 0) process.exit(r.status ?? 1);
  console.log("\\n=== production image runtime smoke ===");
  const smoke = spawnSync(
    "bash",
    ["deploy/scripts/image-smoke.sh", "tareeq-platform-release-gate:latest"],
    {
      stdio: "inherit",
      env,
    },
  );
  if (smoke.status !== 0) process.exit(smoke.status ?? 1);
  console.log(
    "\\n✅ Application release gate passed (including Docker runtime). Staging deployment is still required.",
  );
} else {
  console.error(
    "\\n❌ Docker CLI/daemon unavailable: the release gate cannot verify the production image.",
  );
  process.exit(2);
}
