import fs from 'node:fs'; import path from 'node:path';
import {classifyFailure,createImpactGraph,calculateImpact,newIncident} from './platform-control-plane-remediation.mjs';
const root=process.cwd(), cp=path.join(root,'artifacts','control-plane','workflow-control-plane.json');
const graph=createImpactGraph(JSON.parse(fs.readFileSync(new URL('./platform-impact-graph.json',import.meta.url))));
if(!fs.existsSync(cp)){console.error('P3-1/2/3 report missing');process.exit(75)}
const report=JSON.parse(fs.readFileSync(cp,'utf8')); const incidents=[];
const stageToNodes={'P2-1':['journey-engine'],'P2-2':['trust-boundary','lifecycle','cache'],'P2-3':['journey-engine','trust-boundary'],'P2-4':['journey-success-slo'],'P2-5':['lifecycle','cache'],'P2-6':['journey-engine']};
for(const s of report.result?.stages||[]){if(s.status==='VERIFIED_PASS'||s.status==='BLOCKED') continue; const failure={stage:s.stage,status:s.status,reasons:s.reasons||[],reason:s.reason||null}; const classification=classifyFailure(failure); const impact=calculateImpact(graph,stageToNodes[s.stage]||[]); incidents.push(newIncident({identity:report.identity,source_failure:failure,impact,classification}));}
const out={schema_version:1,control_plane:'P3-4/P3-5/P3-6',generated_at:new Date().toISOString(),source_control_plane:cp,incident_count:incidents.length,incidents};
const dir=path.join(root,'artifacts','control-plane'); fs.mkdirSync(path.join(dir,'incidents'),{recursive:true}); fs.writeFileSync(path.join(dir,'p3-4-5-6-remediation.json'),JSON.stringify(out,null,2)+'\n'); for(const i of incidents) fs.writeFileSync(path.join(dir,'incidents',`${i.incident_id}.json`),JSON.stringify(i,null,2)+'\n');
console.log(JSON.stringify({incident_count:incidents.length,incidents:incidents.map(i=>({incident_id:i.incident_id,classification:i.classification.classification,state:i.state,required_tests:i.impact.required_tests}))},null,2)); process.exit(incidents.length?75:0);
