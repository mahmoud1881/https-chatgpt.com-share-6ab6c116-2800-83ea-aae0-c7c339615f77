// Capture evidence only. This tool never awards a human pass/verification.
import { chromium } from "@playwright/test";
import { readFileSync, mkdirSync, writeFileSync } from "node:fs";
import { resolve, join } from "node:path";
import { benchmarkDigest } from "./trip-benchmark-validation.mjs";
const benchmark = JSON.parse(
  readFileSync(process.argv[2] ?? "benchmarks/trips/core-eg.v1.json", "utf8"),
);
const site = new URL(process.env.SITE_URL);
if (site.protocol !== "https:" || !/staging|stage|test/i.test(site.hostname))
  throw Error("HTTPS staging URL required");
if (!/^[a-f0-9]{40}$/i.test(process.env.BENCHMARK_COMMIT ?? "") || !process.env.DATA_REVISION)
  throw Error("BENCHMARK_COMMIT and DATA_REVISION required");
const output = resolve(
  "deploy/backups/trip-benchmarks",
  new Date().toISOString().replaceAll(":", "-"),
);
mkdirSync(output, { recursive: true, mode: 0o700 });
const report = {
  benchmark_version: benchmark.version,
  benchmark_sha256: benchmarkDigest(benchmark),
  environment: site.origin,
  deployed_commit: process.env.BENCHMARK_COMMIT,
  data_revision: process.env.DATA_REVISION,
  captured_at: new Date().toISOString(),
  cases: [],
};
const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage();
  for (const [index, c] of benchmark.cases.entries()) {
    const row = { id: c.id, reviewer: "", reviewed_at: "", search: null, planner: null };
    for (const surface of ["search", "planner"]) {
      const record = {
        verdict: "pending",
        unsafe_or_fabricated: null,
        outcome: null,
        actual_evidence: "",
        observed_instructions: "",
      };
      try {
        await page.goto(new URL(surface === "search" ? "/" : "/planner", site).href, {
          waitUntil: "domcontentloaded",
          timeout: 15000,
        });
        if (surface === "search") {
          await page.getByRole("searchbox", { name: "نقطة البداية" }).fill(c.from_query);
          await page.getByRole("searchbox", { name: "نقطة الوصول" }).fill(c.to_query);
          await page.getByRole("button", { name: "ابحث الآن" }).click();
        } else {
          await page.getByPlaceholder("مثال: رمسيس، التحرير…").fill(c.from_query);
          await page.getByPlaceholder("مثال: العتبة، مصر الجديدة…").fill(c.to_query);
          await page.getByRole("button", { name: "ابحث", exact: true }).click();
        }
        const result = page.locator(
          `[data-load-result="${surface === "search" ? "structured" : "planner"}"]`,
        );
        await result.waitFor({ state: "visible", timeout: 15000 });
        record.observed_instructions = await result.innerText();
        record.outcome =
          (await result.getAttribute("data-load-status")) === "success"
            ? "route"
            : "no_verified_route";
        record.actual_evidence = `${index + 1}-${surface}.png`;
        await page.screenshot({ path: join(output, record.actual_evidence), fullPage: true });
      } catch (error) {
        record.capture_error = String(error.message).slice(0, 200);
      }
      row[surface] = record;
    }
    report.cases.push(row);
    writeFileSync(join(output, "observations.json"), JSON.stringify(report, null, 2), {
      mode: 0o600,
    });
  }
} finally {
  await browser.close();
}
console.log(`Evidence captured at ${output}; independent review is still mandatory.`);
