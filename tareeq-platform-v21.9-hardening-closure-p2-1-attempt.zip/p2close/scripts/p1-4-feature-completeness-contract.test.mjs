import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const manifest=JSON.parse(fs.readFileSync('config/feature-completeness.json','utf8'));
test('every classified feature uses an allowed explicit status',()=>{
  const allowed=new Set(['working','coming_soon','hidden']);
  assert.ok(manifest.features.length>0);
  for(const f of manifest.features) assert.ok(allowed.has(f.status), `${f.id}: ${f.status}`);
});
test('incomplete wallet and challenge actions are not classified working',()=>{
  for(const id of ['feature:card-wallet','feature:challenge-start']) {
    const f=manifest.features.find(x=>x.id===id); assert.ok(f); assert.notEqual(f.status,'working');
  }
});
test('no duplicate feature ids',()=>{
  const ids=manifest.features.map(x=>x.id); assert.equal(new Set(ids).size,ids.length);
});
