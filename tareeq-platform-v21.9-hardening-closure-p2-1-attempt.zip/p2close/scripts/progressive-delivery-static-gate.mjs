import {readFileSync,existsSync} from 'node:fs';
for(const f of ['deploy/scripts/progressive-delivery.mjs','deploy/scripts/live-canary-slo.mjs','deploy/scripts/provider-selfhost.mjs','deploy/zero-downtime.json'])if(!existsSync(f))throw Error(`missing ${f}`);
const c=readFileSync('deploy/scripts/progressive-delivery.mjs','utf8'),s=readFileSync('deploy/scripts/live-canary-slo.mjs','utf8'),p=readFileSync('deploy/scripts/provider-selfhost.mjs','utf8'),cfg=JSON.parse(readFileSync('deploy/zero-downtime.json','utf8'));
if(JSON.stringify(cfg.progressiveStages)!=='[1,5,25,50,100]')throw Error('progressive stages must be 1,5,25,50,100');
for(const x of ["'promote'","'hold'","'abort'",'progressive-delivery-evidence.json'])if(!c.includes(x))throw Error(`controller missing ${x}`);
for(const x of ['relativeErrorDelta','relativeP95Ratio','burnRate','minCandidate','minStable','candidate','stable'])if(!s.includes(x))throw Error(`stage SLO missing ${x}`);
if(!p.includes('[0,1,5,25,50,100]'))throw Error('provider does not support progressive weights');
console.log('✓ v21.2 gate: staged 1→5→25→50→100 delivery, candidate-vs-stable SLO, burn-rate, confidence, promote/hold/abort and evidence are present.');

const {spawnSync}=await import('node:child_process');
const result=spawnSync(process.execPath,['--test','deploy/scripts/promotion-policy.test.mjs'],{stdio:'inherit'});if(result.error||result.status!==0)process.exit(1);
