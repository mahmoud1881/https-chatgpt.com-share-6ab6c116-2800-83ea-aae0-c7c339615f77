import fs from "node:fs";
const p = "e2e/p0-3-critical-workflows.e2e.ts";
const s = fs.readFileSync(p, "utf8");
const checks = [
  ["auth redirect", /protected deep-link redirects to auth/],
  ["session refresh/logout", /refresh survives; logout revokes/],
  ["invalid session", /invalidated local session/],
  ["planner route details", /opens route details/],
  ["planner explore parity", /same canonical trust semantics/],
  ["anonymous admin deny", /anonymous admin access is denied/],
  ["non-admin deny", /authenticated non-admin is denied/],
  ["admin allow/review", /admin is allowed and review queue/],
  ["real user credentials", /E2E_USER_EMAIL/],
  ["real admin credentials", /E2E_ADMIN_EMAIL/],
];
const failed = checks.filter(([, re]) => !re.test(s));
if (failed.length) {
  console.error("P0-3 E2E static gate: FAIL", failed.map(([n]) => n));
  process.exit(1);
}
console.log(`P0-3 E2E static gate: PASS (${checks.length}/${checks.length})`);
