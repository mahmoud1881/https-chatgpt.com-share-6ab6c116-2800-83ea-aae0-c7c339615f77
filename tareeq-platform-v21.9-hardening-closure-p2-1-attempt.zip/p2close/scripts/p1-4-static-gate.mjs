import fs from 'node:fs'; import path from 'node:path';
const root=process.cwd();
const manifest=JSON.parse(fs.readFileSync('config/feature-completeness.json','utf8'));
const routeDir=path.join(root,'src/routes');
const routeFiles=fs.readdirSync(routeDir).filter(x=>x.endsWith('.tsx')&&!x.startsWith('api.')&&x!=='__root.tsx');
const ids=new Set(manifest.features.map(x=>x.id));
const missing=routeFiles.filter(x=>!ids.has('route:'+x.slice(0,-4)));
const sourceFiles=[];
function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name); if(e.isDirectory()) walk(p); else if(/\.(tsx|ts)$/.test(e.name)) sourceFiles.push(p)}}
walk(path.join(root,'src'));
const issues=[];
for(const f of sourceFiles){const s=fs.readFileSync(f,'utf8'); if(/href\s*=\s*["']#["']/.test(s)) issues.push(`${path.relative(root,f)}: dead href=#`)}
if(missing.length) issues.push('unclassified routes: '+missing.join(', '));
for(const f of manifest.features){if(!['working','coming_soon','hidden'].includes(f.status)) issues.push(`${f.id}: invalid status`)}
const challenges=fs.readFileSync('src/routes/challenges.tsx','utf8');
if(!challenges.includes('ابدأ التحدي — قريباً')||!challenges.includes('disabled aria-disabled="true"')) issues.push('challenge CTA must be explicit coming-soon and disabled');
const card=fs.readFileSync('src/routes/card.tsx','utf8');
if(!card.includes('قريباً')||!card.includes('aria-disabled="true"')) issues.push('wallet CTA must be explicit coming-soon and disabled');
if(issues.length){console.error('P1-4 feature completeness static gate: FAIL\n'+issues.join('\n'));process.exit(1)}
console.log(`P1-4 feature completeness static gate: PASS (${manifest.features.length} classified, ${routeFiles.length} routes, 0 dead href=#)`);
