import fs from 'node:fs';

const tsconfigText = fs.readFileSync('tsconfig.json', 'utf8');
const includes = tsconfigText;
const excludes = tsconfigText;
const failures = [];
if (!includes.includes('src/**/*.ts') || !includes.includes('src/**/*.tsx')) {
  failures.push('tsconfig must include all src TypeScript/TSX files');
}
if (/\"exclude\"[\s\S]{0,500}src\/integrations\/supabase/.test(excludes)) {
  failures.push('Supabase integration code must not be excluded from TypeScript checking');
}
const eslint = fs.readFileSync('eslint.config.js', 'utf8');
if (!eslint.includes('**/*.{ts,tsx}') || !eslint.includes('**/*.{js,mjs,cjs}')) {
  failures.push('ESLint must cover TypeScript and executable JavaScript/MJS sources');
}
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
for (const name of ['typecheck','lint','test','build']) {
  if (!pkg.scripts?.[name]) failures.push(`missing package script: ${name}`);
}
if (failures.length) {
  console.error('Compiler quality configuration: FAIL');
  for (const f of failures) console.error(` - ${f}`);
  process.exit(1);
}
console.log('Compiler quality configuration: PASS');
console.log(' - TypeScript covers src/** including Supabase integrations');
console.log(' - ESLint covers TS/TSX and JS/MJS/CJS');
console.log(' - typecheck/lint/test/build scripts are present');
