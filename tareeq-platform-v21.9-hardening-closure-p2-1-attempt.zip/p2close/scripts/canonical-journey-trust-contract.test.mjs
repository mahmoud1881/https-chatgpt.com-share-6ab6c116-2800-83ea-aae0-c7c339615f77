import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
const canonical=fs.readFileSync("src/lib/journey/canonical.ts","utf8");
const search=fs.readFileSync("src/lib/route-planner/search.functions.ts","utf8");

test("route search only reads active routes and carries lifecycle provenance",()=>{
  assert.match(search,/is_verified,status,country,city/);
  assert.match(search,/\.eq\("status", "active"\)/);
  assert.match(canonical,/provenance:\{source,routeId:r\.id,lifecycle,verifiedAtSource:sourceVerified\}/);
});

test("pending quarantined rejected and unknown are fail-closed",()=>{
  assert.match(canonical,/BLOCKED_LIFECYCLES[^\n]*pending[^\n]*quarantined[^\n]*rejected[^\n]*unknown/);
  assert.match(canonical,/segments\.some\(s => BLOCKED_LIFECYCLES\.has\(s\.lifecycle\)\)\) return null/);
});

test("source verified flag cannot override non-active lifecycle",()=>{
  assert.match(canonical,/verified:lifecycle === "active" && sourceVerified/);
});

test("mixed trust remains non-actionable",()=>{
  assert.match(canonical,/if\(eligible\.some\(Boolean\)\) return "mixed"/);
  assert.match(canonical,/actionable:trust==="verified"/);
});
