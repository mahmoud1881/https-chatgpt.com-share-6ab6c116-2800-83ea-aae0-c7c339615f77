import crypto from 'node:crypto';

const sha = v => crypto.createHash('sha256').update(typeof v==='string'?v:JSON.stringify(v)).digest('hex');
const now = () => new Date().toISOString();

// P3-7: Data & Security Governance
export function evaluateGovernance({data={},security={}}={}) {
  const checks = [
    {id:'data.provenance', required:true, observed:data.provenance_verified ?? null},
    {id:'data.quarantine_leakage', required:0, observed:data.quarantine_leakage ?? null},
    {id:'data.review_backlog_measured', required:true, observed:data.review_backlog == null ? null : Number.isInteger(data.review_backlog)},
    {id:'data.trust_violations', required:0, observed:data.trust_violations ?? null},
    {id:'security.secret_leakage', required:0, observed:security.secret_leakage ?? null},
    {id:'security.authz_violations', required:0, observed:security.authz_violations ?? null},
    {id:'security.privileged_actions_audited', required:true, observed:security.privileged_actions_audited ?? null},
    {id:'security.supply_chain_verified', required:true, observed:security.supply_chain_verified ?? null},
  ].map(c=>({...c, executed:c.observed!==null, passed:c.observed===null?null:c.observed===c.required}));
  return Object.freeze({status:checks.every(c=>c.passed===true)?'VERIFIED_PASS':checks.some(c=>c.passed===false)?'CONFIRMED_FAIL':'PENDING',checks});
}

// P3-9: append-only hash-chained audit trail. Existing events are never rewritten.
export function appendAuditEvent(trail=[], event={}) {
  if(!event.type) throw new Error('audit event type required');
  const previous_hash = trail.length ? trail.at(-1).event_hash : null;
  const record={seq:trail.length+1,at:event.at||now(),type:event.type,actor:event.actor||'system',subject:event.subject||null,data:event.data??null,previous_hash};
  record.event_hash=sha(record);
  return Object.freeze([...trail,Object.freeze(record)]);
}
export function verifyAuditTrail(trail=[]) {
  const reasons=[];
  trail.forEach((e,i)=>{
    const copy={...e}; const h=copy.event_hash; delete copy.event_hash;
    if(sha(copy)!==h) reasons.push(`HASH_MISMATCH:${i+1}`);
    const expected=i?trail[i-1].event_hash:null;
    if(e.previous_hash!==expected) reasons.push(`CHAIN_MISMATCH:${i+1}`);
    if(e.seq!==i+1) reasons.push(`SEQ_MISMATCH:${i+1}`);
  });
  return Object.freeze({verified:reasons.length===0,status:reasons.length?'INVALID':'VERIFIED_PASS',reasons});
}

// P3-8: a single derived control-center projection; it cannot mutate source truth.
export function buildControlCenter({workflow={},governance={},incidents=[],audit=[],continuous={}}={}) {
  const open=incidents.filter(i=>!['CLOSED'].includes(i.state));
  const blocked=(workflow.stages||[]).filter(s=>s.status==='BLOCKED').map(s=>s.stage);
  return Object.freeze({
    generated_at:now(),
    platform_status: workflow.accepted===true && governance.status==='VERIFIED_PASS' && open.length===0 ? 'HEALTHY' : 'ATTENTION_REQUIRED',
    workflow:{accepted:workflow.accepted===true,blocked},
    governance:{status:governance.status||'PENDING'},
    incidents:{total:incidents.length,open:open.length,by_state:Object.fromEntries([...new Set(incidents.map(i=>i.state))].map(s=>[s,incidents.filter(i=>i.state===s).length]))},
    audit:{events:audit.length,integrity:verifyAuditTrail(audit).status},
    continuous:{status:continuous.status||'NOT_RUNNING',last_cycle:continuous.last_cycle||null}
  });
}

// P3-10: continuous verification creates new recurrence incidents; historical CLOSED incidents are immutable inputs.
export function continuousVerificationCycle({signals=[],closedIncidents=[],createRecurrence,executed=true}) {
  if(!executed) return Object.freeze({status:'NOT_EXECUTED',last_cycle:null,signals_evaluated:0,findings:[],recurrences:[]});
  const findings=signals.filter(s=>s.severity==='critical'||s.violated===true);
  const recurrences=[]; const newFindings=[];
  for(const f of findings){
    const parent=closedIncidents.find(i=>f.recurrence_of===i.incident_id);
    if(parent && createRecurrence) recurrences.push(createRecurrence(parent,f)); else newFindings.push(f);
  }
  return Object.freeze({status:findings.length?'ATTENTION_REQUIRED':'VERIFIED_PASS',last_cycle:now(),signals_evaluated:signals.length,findings:newFindings,recurrences});
}
