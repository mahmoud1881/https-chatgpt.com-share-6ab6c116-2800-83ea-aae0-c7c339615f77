import { spawnSync } from 'node:child_process';
import fs from 'node:fs';

const url = process.env.DATABASE_URL || process.env.SUPABASE_DB_URL;
if (!url) {
  console.error('DATABASE_URL (or SUPABASE_DB_URL) is required. Run this against an ephemeral/local Supabase database after migrations.');
  process.exit(2);
}
for (const file of ['scripts/db-authorization-catalog-audit.sql','scripts/db-authorization-negative-proof.sql']) {
  const r = spawnSync('psql', [url, '-X', '-v', 'ON_ERROR_STOP=1', '-f', file], { stdio: 'inherit' });
  if (r.error) { console.error(`Unable to execute psql: ${r.error.message}`); process.exit(2); }
  if (r.status !== 0) process.exit(r.status ?? 1);
}
console.log('v20.6 database authorization proof: PASS');
