import { spawnSync } from 'node:child_process';
import { readFileSync,readdirSync,existsSync,writeFileSync,mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
const ROOT=resolve(new URL('..',import.meta.url).pathname), DIR=resolve(ROOT,'supabase/migrations');
const PROD=process.env.PRODUCTION_DATABASE_URL||''; const approvalFile=resolve(ROOT,'supabase/destructive-migration-approvals.json');
const sha=s=>createHash('sha256').update(s).digest('hex');
function psql(sql){const r=spawnSync('psql',[PROD,'-X','-qAt','-v','ON_ERROR_STOP=1','-c',sql],{encoding:'utf8',env:{...process.env,PGAPPNAME:'tareeq-v20.9-migration-safety'}});if(r.error||r.status)throw new Error((r.stderr||r.error?.message||'psql failed').trim());return r.stdout.trim();}
if(!PROD) throw new Error('PRODUCTION_DATABASE_URL is required (fail-closed).');
const applied=new Set((psql('select version::text from supabase_migrations.schema_migrations order by version')||'').split(/\r?\n/).filter(Boolean));
const files=readdirSync(DIR).filter(x=>x.endsWith('.sql')).sort(); const pending=files.filter(f=>!applied.has(f.split('_')[0]));
const destructive=[/\bdrop\s+(table|column|type|function|view|index|policy|schema)\b/i,/\btruncate\b/i,/\balter\s+table[\s\S]*?\bdrop\b/i,/\balter\s+table[\s\S]*?\balter\s+column[\s\S]*?\btype\b/i,/\balter\s+table[\s\S]*?\bset\s+not\s+null\b/i,/\bdelete\s+from\b/i,/\bupdate\s+\S+\s+set\b/i];
const lockRisk=[/\bcreate\s+(unique\s+)?index\b(?![\s\S]*?concurrently)/i,/\balter\s+table\b/i,/\bvacuum\s+full\b/i,/\breindex\b/i];
const approvals=existsSync(approvalFile)?JSON.parse(readFileSync(approvalFile,'utf8')):{approvals:{}}; const report=[];
for(const f of pending){const sql=readFileSync(resolve(DIR,f),'utf8');const reasons=destructive.filter(r=>r.test(sql)).map(r=>r.source);const risks=lockRisk.filter(r=>r.test(sql)).map(r=>r.source);const hash=sha(sql);let classification=reasons.length?'destructive':risks.length?'lock-sensitive':'backward-compatible';
 if(classification!=='backward-compatible'){const a=approvals.approvals?.[f];if(!a||a.sha256!==hash||!a.approvedBy||!a.ticket||!a.rollbackOrRollforwardPlan) throw new Error(`${f} is ${classification} but has no commit-content-bound approval in supabase/destructive-migration-approvals.json`);}
 report.push({file:f,sha256:hash,classification,destructiveSignals:reasons.length,lockRiskSignals:risks.length});}
mkdirSync(resolve(ROOT,'artifacts'),{recursive:true});writeFileSync(resolve(ROOT,'artifacts/migration-safety-report.json'),JSON.stringify({format:'tareeq-v20.9-migration-safety-v1',completedAt:new Date().toISOString(),pendingCount:pending.length,pending:report},null,2)+'\n');
console.log(`✓ v20.9 migration safety: ${pending.length} pending; `+report.map(x=>`${x.file}:${x.classification}`).join(', '));
