import { spawnSync } from 'node:child_process';
const DB=process.env.EPHEMERAL_DATABASE_URL||'postgresql://postgres:postgres@127.0.0.1:54322/postgres';
function run(cmd,args,env=process.env){ console.log(`\n> ${cmd} ${args.join(' ')}`); const r=spawnSync(cmd,args,{stdio:'inherit',env}); if(r.error) throw new Error(`${cmd} unavailable: ${r.error.message}`); if(r.status!==0) throw new Error(`${cmd} exited with ${r.status}`); }
function ok(cmd){ const r=spawnSync(cmd,['--version'],{stdio:'ignore'}); return !r.error&&r.status===0; }
for(const c of ['docker','supabase','psql']) if(!ok(c)){ console.error(`❌ v20.8 FAIL — ${c} is required.`); process.exit(2); }
if(!process.env.STAGING_DATABASE_URL||!process.env.PRODUCTION_DATABASE_URL){ console.error('❌ v20.8 FAIL — STAGING_DATABASE_URL and PRODUCTION_DATABASE_URL are mandatory release inputs.'); process.exit(2); }
let started=false;
try{
  spawnSync('supabase',['db','stop','--no-backup'],{stdio:'inherit'});
  run('supabase',['db','start']); started=true;
  run('node',['scripts/verify-ephemeral-migration-ledger.mjs',DB]);
  run('node',['scripts/run-db-authorization-proof.mjs'],{...process.env,DATABASE_URL:DB});
  run('node',['scripts/schema-drift-gate.mjs'],{...process.env,EPHEMERAL_DATABASE_URL:DB});
  console.log('\n✅ v20.8 release database gate: PASS');
}catch(e){ console.error(`\n❌ v20.8 release database gate: FAIL — ${e.message}`); process.exitCode=1; }
finally{ if(started) spawnSync('supabase',['db','stop','--no-backup'],{stdio:'inherit'}); }
