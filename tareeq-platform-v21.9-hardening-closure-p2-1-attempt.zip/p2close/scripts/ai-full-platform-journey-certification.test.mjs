import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const src=fs.readFileSync(new URL('./ai-full-platform-journey-certification.mjs',import.meta.url),'utf8');
test('real journey requires every runtime provider and runtime auth',()=>{for(const k of ['TYPESAFE_API_KEY','GROQ_API_KEY','GEMINI_API_KEY','TAREEQ_GEO_GATEWAY_URL','TAREEQ_PLACES_GATEWAY_URL','TAREEQ_ROUTING_GATEWAY_URL','TAREEQ_JOURNEY_GATEWAY_URL','TAREEQ_RUNTIME_TOKEN'])assert.match(src,new RegExp(k))});
test('fixture evidence cannot satisfy real journey',()=>{assert.match(src,/Only REAL_PLATFORM evidence/);assert.match(src,/fixture_as_runtime/);assert.doesNotMatch(src,/certification-tool-fixture/)});
test('geo route eta and stale-live invariants are explicit',()=>{for(const x of ['fabricated_location','fabricated_route','fabricated_eta','stale_as_live','provider_bypass'])assert.match(src,new RegExp(x))});
test('real gateways require provenance and live state',()=>{assert.match(src,/g\.status!==\'LIVE\'/);assert.match(src,/places\.data\?\.status!==\'LIVE\'/);assert.match(src,/route\?\.status!==\'LIVE\'/);assert.match(src,/provenance/)});
test('journey requires persisted database evidence',()=>{assert.match(src,/persisted!==true/);assert.match(src,/journey_id/)});
test('P3 verification remains final evidence verifier and P2-1 stays independent',()=>{assert.match(src,/verifyEvidence/);assert.match(src,/p2_1:\'NOT_CERTIFIED\'/);assert.match(src,/accepted=false/)});
