import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const src = path.join(root, 'src');
const failures = [];
const warnings = [];
function walk(dir) {
  return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e => e.isDirectory() ? walk(path.join(dir,e.name)) : [path.join(dir,e.name)]);
}
const files = fs.existsSync(src) ? walk(src).filter(f => /\.(ts|tsx|js|jsx|mjs|cjs)$/.test(f)) : [];
const secretNames = ['SUPABASE_SERVICE_ROLE_KEY','RELEASE_SIGNING_PRIVATE_KEY','COSIGN_PRIVATE_KEY','DATABASE_URL','PRODUCTION_DATABASE_URL','STAGING_DATABASE_URL'];
for (const f of files) {
  const rel = path.relative(root,f).replaceAll('\\','/');
  const text = fs.readFileSync(f,'utf8');
  if (/\b(TODO|FIXME|HACK|XXX)\b/.test(text)) warnings.push(`${rel}: unresolved marker`);
  if (/\bVITE_(SUPABASE_SERVICE_ROLE_KEY|DATABASE_URL|PRODUCTION_DATABASE_URL|STAGING_DATABASE_URL)\b/.test(text)) failures.push(`${rel}: privileged secret exposed through VITE_*`);
  if (/src\//.test(rel) && !/(^|\/)__tests__\//.test(rel) && !/\.(test|spec)\.[cm]?[jt]sx?$/.test(rel) && /SUPABASE_SERVICE_ROLE_KEY/.test(text) && !/src\/integrations\/supabase\//.test(rel)) failures.push(`${rel}: service-role secret outside centralized Supabase boundary`);
}
for (const n of secretNames) {
  const env = path.join(root,'.env');
  if (fs.existsSync(env) && new RegExp(`^${n}=.+$`,'m').test(fs.readFileSync(env,'utf8'))) failures.push(`.env contains ${n}; production secrets must not be committed`);
}
console.log(`Application quality static gate: scanned ${files.length} source files`);
for (const w of warnings) console.warn(`WARN ${w}`);
if (failures.length) { for (const f of failures) console.error(`FAIL ${f}`); process.exit(2); }
console.log('Application quality static gate: PASS');
