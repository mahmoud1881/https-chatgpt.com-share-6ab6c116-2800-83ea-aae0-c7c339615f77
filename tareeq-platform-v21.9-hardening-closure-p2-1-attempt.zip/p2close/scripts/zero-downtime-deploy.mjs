import {immutableRelease,checkpoint} from '../deploy/scripts/runtime-image-binding.mjs';
import { spawnSync } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';

const ROOT=resolve(new URL('..',import.meta.url).pathname); const ART=resolve(ROOT,'artifacts'); mkdirSync(ART,{recursive:true});
const cfgPath=process.env.ZERO_DOWNTIME_CONFIG || resolve(ROOT,'deploy/zero-downtime.json');
if(!existsSync(cfgPath)) throw new Error('deploy/zero-downtime.json is required.');
if(process.env.ZD_PROVIDER&&process.env.ZD_PROVIDER!=='selfhost')throw Error('Custom promotion providers are not permitted');
if(resolve(cfgPath)!==resolve(ROOT,'deploy/zero-downtime.json'))throw Error('Custom promotion configuration is not permitted');
const cfg=JSON.parse(readFileSync(cfgPath,'utf8'));
const required=['OLD_RELEASE','NEW_RELEASE','STAGING_DATABASE_URL','PRODUCTION_DATABASE_URL']; for(const k of required) if(!process.env[k]) throw new Error(`${k} required (fail-closed).`);
function run(name,cmd,extra={}){ console.log(`\n=== ${name} ===\n> ${cmd}`); const r=spawnSync('bash',['-lc',cmd],{stdio:'inherit',env:{...process.env,...extra}}); if(r.error||r.status!==0) throw new Error(`${name} failed (${r.status??r.error?.message})`); }
function capture(cmd){const r=spawnSync('bash',['-lc',cmd],{encoding:'utf8',env:process.env});if(r.error||r.status!==0)throw new Error((r.stderr||r.error?.message||cmd).trim());return r.stdout.trim();}
function hook(key,vars={}){const cmd=cfg.hooks?.[key];if(!cmd)throw new Error(`Missing zero-downtime hook: ${key}`);run(key,cmd,vars);}
function progressiveHook(){const cmd=cfg.hooks?.progressiveDelivery;if(!cmd)throw new Error('Missing zero-downtime hook: progressiveDelivery');console.log(`\n=== progressiveDelivery ===\n> ${cmd}`);const r=spawnSync('bash',['-lc',cmd],{stdio:'inherit',env:process.env});if(r.status===75)return 'pending';if(r.error||r.status!==0)throw new Error(`progressiveDelivery failed (${r.status??r.error?.message})`);return 'passed';}
if(!process.env.CERTIFICATION_RUN_ID)throw Error('CERTIFICATION_RUN_ID required before deployment');
const immutable=immutableRelease();process.env.NEW_RELEASE=immutable;process.env.CANDIDATE_APP_IMAGE=immutable;
const started=new Date().toISOString(); const evidence={format:'tareeq-v21.0-zero-downtime-v1',startedAt:started,oldRelease:process.env.OLD_RELEASE,newRelease:process.env.NEW_RELEASE,phases:[],trafficCutoverAllowed:false,databaseRollbackAttempted:false,recoveryMode:'roll-forward-only'};
function mark(phase,status='passed',detail={}){evidence.phases.push({phase,status,at:new Date().toISOString(),...detail});writeFileSync(resolve(ART,'zero-downtime-deployment.json'),JSON.stringify(evidence,null,2)+'\n');}
try {
  // EXPAND: migration safety + backup evidence + apply compatible DB changes before app traffic.
  run('expand: migration safety','node scripts/migration-safety-gate.mjs');
  run('expand: backup/restore evidence','node scripts/verify-backup-restore-evidence.mjs');
  run('expand: production migrations','node scripts/production-migration-transaction.mjs'); mark('expand');

  // Compatibility proof: both releases must boot/readiness/synthetic against the expanded schema.
  hook('compatibilityOld',{RELEASE:process.env.OLD_RELEASE}); hook('compatibilityNew',{RELEASE:process.env.NEW_RELEASE}); mark('dual-release-schema-compatibility');

  // Deploy green/canary with zero public traffic, then readiness + synthetic write/read transaction.
  hook('deployGreen',{RELEASE:immutable}); checkpoint('before-deployment-tests',{reset:true}); hook('readinessGreen'); hook('syntheticGreen'); mark('deploy-green-and-probe');

  // Adaptive progressive delivery. Every stage compares candidate vs stable and may promote/hold/abort.
  const progressive=progressiveHook();
  if(progressive==='pending'){mark('progressive-delivery','pending',{stages:cfg.progressiveStages??[1,5,25,50,100]});evidence.status='pending';evidence.completedAt=new Date().toISOString();writeFileSync(resolve(ART,'zero-downtime-deployment.json'),JSON.stringify(evidence,null,2)+'\n');console.log('⏳ rollout observation window is still open; resume later without rollback');process.exit(75);}
  mark('progressive-delivery','passed',{stages:cfg.progressiveStages??[1,5,25,50,100]});
  hook('readinessGreen'); hook('syntheticGreen'); mark('full-cutover'); evidence.trafficCutoverAllowed=true;

  // CONTRACT is deliberately separated and must prove old release is drained before destructive cleanup.
  hook('drainOld'); hook('verifyOldDrained');
  if(cfg.hooks?.contract){hook('contract'); mark('contract');} else mark('contract','deferred',{reason:'No contract hook configured; safe default is defer destructive contraction.'});
  run('post-deploy schema drift proof','node scripts/schema-drift-gate.mjs'); mark('post-deploy-schema-fingerprint');
  checkpoint('after-deployment-tests');
  evidence.completedAt=new Date().toISOString(); evidence.status='passed'; writeFileSync(resolve(ART,'zero-downtime-deployment.json'),JSON.stringify(evidence,null,2)+'\n');
  console.log('✅ v21.0 zero-downtime deployment proof passed.');
} catch(err) {
  evidence.status='failed'; evidence.failure=String(err?.message||err); evidence.failedAt=new Date().toISOString();
  // Never roll DB migrations backward. Restore application traffic to old release and invoke roll-forward hook.
  try { hook('restoreOldTraffic',{FAILED_RELEASE:process.env.NEW_RELEASE}); mark('automatic-app-traffic-recovery'); } catch(recoveryErr){ evidence.recoveryFailure=String(recoveryErr?.message||recoveryErr); }
  if(cfg.hooks?.rollForwardDatabase){ try {hook('rollForwardDatabase',{FAILED_RELEASE:process.env.NEW_RELEASE}); mark('database-roll-forward');} catch(e){evidence.rollForwardFailure=String(e?.message||e);} }
  writeFileSync(resolve(ART,'zero-downtime-deployment.json'),JSON.stringify(evidence,null,2)+'\n'); throw err;
}
