import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
const sha=v=>crypto.createHash('sha256').update(typeof v==='string'?v:JSON.stringify(v)).digest('hex');
const freeze=v=>Object.freeze(v);

// Capability Broker: extensions never receive raw network/fs/env/process handles.
export function createCapabilityBroker({policies={},adapters={}}={}){
  const audit=[];
  const invoke=async({extension,capability,request})=>{
    const allow=new Set(policies[extension?.id]||[]);
    const denied=!extension?.id||!allow.has(capability)||!adapters[capability];
    audit.push(freeze({at:new Date().toISOString(),extension_id:extension?.id||null,capability,decision:denied?'DENY':'ALLOW',request_hash:sha(request??null)}));
    if(denied) return freeze({status:'DENIED'});
    const result=await adapters[capability](structuredClone(request));
    return freeze({status:'OK',result:structuredClone(result)});
  };
  return freeze({invoke,audit:()=>freeze(audit.map(x=>freeze({...x})))});
}

// Production sandbox contract. Worker threads are explicitly rejected as a security boundary.
export function certifySandboxBoundary(observation={}){
  const checks=[
    ['external_isolation',observation.boundary==='container'||observation.boundary==='microvm'||observation.boundary==='sandbox-runtime'],
    ['no_host_fs',observation.host_fs_access===false],
    ['no_raw_network',observation.raw_network_access===false],
    ['no_host_env',observation.host_env_access===false],
    ['no_process_control',observation.process_control===false],
    ['broker_only_resources',observation.broker_only===true],
    ['seccomp_or_equivalent',observation.syscall_policy===true],
  ].map(([id,passed])=>freeze({id,executed:passed===true||passed===false,passed}));
  return freeze({status:checks.every(x=>x.passed)?'VERIFIED_PASS':'RUNTIME_UNVERIFIED',checks});
}

// Signed external checkpoint. Persistence target must be outside the application audit store.
export function createAuditCheckpoint({trail,privateKey,keyId,anchorReceipt=null}){
  if(!trail?.length||!privateKey||!keyId) throw new Error('CHECKPOINT_INPUT_REQUIRED');
  const head=trail.at(-1); const body=freeze({seq:head.seq,event_hash:head.event_hash,key_id:keyId,created_at:new Date().toISOString()});
  const signature=crypto.sign(null,Buffer.from(JSON.stringify(body)),privateKey).toString('base64');
  return freeze({...body,signature,anchor_receipt:anchorReceipt});
}
export function verifyAuditCheckpoint({checkpoint,publicKey,trail}){
  if(!checkpoint||!publicKey||!trail?.length) return freeze({verified:false,reason:'MISSING_INPUT'});
  const {signature,anchor_receipt,...body}=checkpoint;
  const head=trail.at(-1);
  const sig=crypto.verify(null,Buffer.from(JSON.stringify(body)),publicKey,Buffer.from(signature,'base64'));
  const headMatch=body.seq===head.seq&&body.event_hash===head.event_hash;
  return freeze({verified:sig&&headMatch&&anchor_receipt!=null,signature_valid:sig,head_match:headMatch,externally_anchored:anchor_receipt!=null});
}

// Evidence registry uses immutable content addressing + compare-and-set index.
export function createEvidenceRegistry({root}){
  if(!root) throw new Error('EVIDENCE_ROOT_REQUIRED'); fs.mkdirSync(path.join(root,'objects'),{recursive:true});
  const indexPath=path.join(root,'index.json'); if(!fs.existsSync(indexPath)) fs.writeFileSync(indexPath,'{}',{flag:'wx'});
  const readIndex=()=>JSON.parse(fs.readFileSync(indexPath,'utf8'));
  const submit=(e)=>{
    if(!e?.evidence_id||!e?.run_id||!e?.kind||e.observed===undefined) throw new Error('INVALID_EVIDENCE');
    const canonical={...e}; const digest=sha(canonical); const objectPath=path.join(root,'objects',`${digest}.json`);
    if(!fs.existsSync(objectPath)) fs.writeFileSync(objectPath,JSON.stringify(freeze({...canonical,digest}),null,2),{flag:'wx'});
    const idx=readIndex(); if(idx[e.evidence_id]&&idx[e.evidence_id]!==digest) throw new Error('EVIDENCE_HISTORY_IMMUTABLE');
    if(!idx[e.evidence_id]){const next={...idx,[e.evidence_id]:digest}; const tmp=`${indexPath}.${process.pid}.tmp`; fs.writeFileSync(tmp,JSON.stringify(next,null,2),{flag:'wx'}); fs.renameSync(tmp,indexPath);}
    return freeze({status:'STORED',digest});
  };
  const get=id=>{const d=readIndex()[id]; return d?freeze(JSON.parse(fs.readFileSync(path.join(root,'objects',`${d}.json`),'utf8'))):null};
  return freeze({submit,get});
}
