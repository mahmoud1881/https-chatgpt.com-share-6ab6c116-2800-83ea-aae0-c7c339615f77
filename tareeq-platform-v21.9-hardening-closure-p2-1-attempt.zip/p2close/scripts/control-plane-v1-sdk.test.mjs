import test from 'node:test'; import assert from 'node:assert/strict';
import {CONTROL_PLANE_API,validateManifest,createExtensionRegistry,createExtensionContext} from './control-plane-v1-sdk.mjs';
const base={id:'example.signal',version:'1.0.0',type:'SignalProvider',api_version:CONTROL_PLANE_API,entrypoint:'./index.mjs',capabilities:['emitSignal'],permissions:['signals:emit'],timeout_ms:5000,resources:{memory_mb:128},evidence_requirements:[],failure_semantics:'fail-closed',isolation:'process'};
test('valid v1 extension registers only after non-regression',()=>{const r=createExtensionRegistry(); assert.equal(r.register(base).status,'REJECTED'); assert.equal(r.register(base,{nonRegressionPassed:true}).status,'REGISTERED')});
test('truth mutation capabilities are forbidden',()=>{assert.equal(validateManifest({...base,capabilities:['writeClosed']}).valid,false)});
test('wildcard/core truth permissions are forbidden',()=>{assert.equal(validateManifest({...base,permissions:['*']}).valid,false)});
test('incompatible API is rejected',()=>{assert.equal(validateManifest({...base,api_version:'control-plane/v2'}).valid,false)});
test('SDK exposes narrow capability-scoped interfaces',()=>{const out=[]; const ctx=createExtensionContext(base,{emitSignal:v=>out.push(v)}); ctx.emitSignal({id:'s1'}); assert.equal(out[0].extension_id,base.id); assert.throws(()=>ctx.submitEvidence({}),/CAPABILITY_DENIED/)});
test('invalid isolation/resource/timeout is rejected',()=>{assert.equal(validateManifest({...base,isolation:'none',timeout_ms:0,resources:{memory_mb:9999}}).valid,false)});

test('legacy broad deployment execution capability is forbidden',()=>{assert.equal(validateManifest({...base,type:'DeploymentAdapter',capabilities:['requestDeploymentAction'],permissions:['deployment:propose']}).valid,false)});
test('deployment extension can only propose with explicit proposal permission',()=>{const m={...base,type:'DeploymentAdapter',capabilities:['proposeDeployment'],permissions:['deployment:propose']}; const out=[]; const ctx=createExtensionContext(m,{proposeDeployment:v=>out.push(v)}); ctx.proposeDeployment({target_environment:'production'}); assert.equal(out[0].status,'PROPOSED'); assert.equal(out[0].target_environment,'production')});
