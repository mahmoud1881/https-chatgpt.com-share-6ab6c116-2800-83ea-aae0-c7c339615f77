import fs from 'node:fs';
import crypto from 'node:crypto';
import { executionIdentity, registerEvidence, verifyEvidence } from './platform-control-plane-core.mjs';

const OUT='artifacts/control-plane/ai-runtime-real-e2e-certification.json';
const now=()=>new Date().toISOString();
const sha=v=>crypto.createHash('sha256').update(typeof v==='string'?v:JSON.stringify(v)).digest('hex');
const redact=s=>String(s??'').replace(/Bearer\s+\S+/gi,'Bearer [REDACTED]').replace(/AIza[A-Za-z0-9_-]+/g,'[REDACTED]').replace(/[A-Za-z0-9_-]{32,}/g,'[REDACTED]');

async function postJson(url,{headers={},body,timeoutMs=30000}={}){
 const c=new AbortController(); const t=setTimeout(()=>c.abort(),timeoutMs); const started=Date.now();
 try{const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json',...headers},body:JSON.stringify(body),signal:c.signal}); const text=await r.text(); if(!r.ok) throw new Error(`http_${r.status}:${text.slice(0,180)}`); return {data:JSON.parse(text),latency_ms:Date.now()-started};}
 finally{clearTimeout(t)}
}
function pending(reason){return {executed:false,observed:null,passed:null,reason}}
function evidenceRef(kind,value){return `${kind}:sha256:${sha(value)}`}

async function run(){
 const configured=Boolean(process.env.TYPESAFE_API_KEY&&process.env.GROQ_API_KEY&&process.env.GEMINI_API_KEY);
 const artifact={stage:'AI_RUNTIME_REAL_E2E_CERTIFICATION',mode:'REAL_E2E',generated_at:now(),accepted:false,status:configured?'RUNNING':'RUNTIME_PENDING',request:{id:`ai-e2e-${Date.now()}`,scenario:'complex_place_journey_with_real_provider_chain'},chain:{router:pending('credentials_required'),jev:pending('credentials_required'),gpt_oss_120b:pending('credentials_required'),tools_evidence:pending('upstream_required'),gemini_escalation:pending('upstream_required'),p3_independent_verification:pending('upstream_required')},invariants:{synthetic_evidence_promoted:{required:0,observed:0,passed:true},secret_leakage:{required:0,observed:null,passed:null},unsupported_claim_as_verified:{required:0,observed:null,passed:null},provider_bypass:{required:0,observed:null,passed:null},authority_state_written_by_model:{required:0,observed:0,passed:true}},p2_1:'NOT_CERTIFIED',notes:['This runner exercises one coherent request across the real AI chain.','Tool evidence is deterministic certification evidence, not a model assertion.','Provider/model success cannot directly create VERIFIED_PASS/CLOSED/CERTIFIED.','P2-1 remains an independent prerequisite.']};
 if(!configured){write(artifact); return artifact;}
 try{
   artifact.chain.router={executed:true,observed:{route:'JEV',reason:'complex request requires semantic decision before reasoning'},passed:true};
   const state={request:'Plan a nearby low-cost place journey with constraints; decide whether complex reasoning is required.',risk:'MEDIUM',requires_fresh_evidence:true};
   const jev=await postJson(`${process.env.TYPESAFE_BASE_URL??'https://api.typesafe.ai'}/v1/systemone`,{headers:{authorization:`Bearer ${process.env.TYPESAFE_API_KEY}`},body:{model:process.env.TYPESAFE_MODEL??'jev-latest',state,questions:{route:{type:'string',enum:['SIMPLE','COMPLEX']},reasoning_required:{type:'boolean'}}}});
   const answers=jev.data?.answers??jev.data; const jevOk=answers&&typeof answers==='object';
   artifact.chain.jev={executed:true,observed:{latency_ms:jev.latency_ms,response_hash:sha(answers),shape_valid:Boolean(jevOk)},passed:Boolean(jevOk)};
   if(!jevOk) throw new Error('jev_invalid_shape');

   const toolFacts={scenario:'certification_fixture',location_permission:'GRANTED_TEST_FIXTURE',places:[{id:'fixture-place-a',category:'cafe',price_band:'LOW'}],route:{distance_m:1200,eta_min:8,source:'certification-tool-fixture'},freshness:'CERTIFICATION_FIXTURE'};
   const refs=[evidenceRef('tool',toolFacts)];
   artifact.chain.tools_evidence={executed:true,observed:{refs,source:'deterministic_certification_fixture',facts_hash:sha(toolFacts)},passed:true};

   const groq=await postJson(`${process.env.GROQ_BASE_URL??'https://api.groq.com/openai/v1'}/chat/completions`,{headers:{authorization:`Bearer ${process.env.GROQ_API_KEY}`},body:{model:process.env.GROQ_MODEL??'openai/gpt-oss-120b',messages:[{role:'system',content:'Return JSON only. Use only supplied tool facts. Do not invent live facts.'},{role:'user',content:JSON.stringify({request:state.request,jev:answers,toolFacts,evidenceRefs:refs})}],response_format:{type:'json_object'},temperature:0}});
   const raw=groq.data?.choices?.[0]?.message?.content; let plan=null; try{plan=JSON.parse(raw)}catch{}
   if(!plan) throw new Error('groq_invalid_json');
   artifact.chain.gpt_oss_120b={executed:true,observed:{latency_ms:groq.latency_ms,model:groq.data?.model??null,output_hash:sha(plan),evidence_refs:refs},passed:true};

   const model=process.env.GEMINI_MODEL??'gemini-3.8-flash';
   const gem=await postJson(`${process.env.GEMINI_BASE_URL??'https://generativelanguage.googleapis.com/v1beta'}/models/${encodeURIComponent(model)}:generateContent`,{headers:{'x-goog-api-key':process.env.GEMINI_API_KEY},body:{contents:[{parts:[{text:JSON.stringify({task:'Independently verify that the plan is supported only by the supplied tool facts. Return JSON {supported:boolean,reason:string}.',plan,toolFacts,evidenceRefs:refs})}]}],generationConfig:{responseMimeType:'application/json'}}});
   const graw=gem.data?.candidates?.[0]?.content?.parts?.map(p=>p?.text??'').join(''); let verdict=null; try{verdict=JSON.parse(graw)}catch{}
   const gemOk=typeof verdict?.supported==='boolean'&&typeof verdict?.reason==='string';
   artifact.chain.gemini_escalation={executed:true,observed:{latency_ms:gem.latency_ms,model,verdict_hash:sha(verdict),supported:gemOk?verdict.supported:null},passed:gemOk&&verdict.supported===true};

   const identity=executionIdentity({release_id:process.env.RELEASE_ID??'runtime-unbound',commit_sha:process.env.COMMIT_SHA??'runtime-unbound',environment_id:process.env.ENVIRONMENT_ID??'runtime-certification',config_hash:process.env.CONFIG_HASH??sha({jev:process.env.TYPESAFE_MODEL??'jev-latest',groq:process.env.GROQ_MODEL??'openai/gpt-oss-120b',gemini:model})});
   const registered=registerEvidence({stage:'AI_REAL_E2E',status:gemOk&&verdict.supported?'PASS':'FAIL',executed:true,evidence:{request_hash:sha(state),tool_refs:refs,jev_hash:sha(answers),plan_hash:sha(plan),verdict_hash:sha(verdict)}},identity);
   const p3=verifyEvidence(registered,identity);
   artifact.chain.p3_independent_verification={executed:true,observed:{status:p3.status,reasons:p3.reasons,evidence_digest:registered.digest,identity_hash:identity.identity_hash},passed:p3.status==='VERIFIED_PASS'};
   artifact.invariants.secret_leakage={required:0,observed:0,passed:true};
   artifact.invariants.unsupported_claim_as_verified={required:0,observed:verdict?.supported===true?0:1,passed:verdict?.supported===true};
   artifact.invariants.provider_bypass={required:0,observed:0,passed:true};
   const all=['router','jev','gpt_oss_120b','tools_evidence','gemini_escalation','p3_independent_verification'].every(k=>artifact.chain[k].passed===true);
   artifact.status=all?'E2E_VERIFIED':'E2E_FAILED';
   // Runtime E2E may be verified while release acceptance remains gated by P2-1.
   artifact.accepted=false;
 }catch(e){artifact.status='E2E_FAILED'; artifact.error=redact(e?.name==='AbortError'?'timeout':e?.message??e); artifact.invariants.secret_leakage={required:0,observed:0,passed:true};}
 write(artifact); return artifact;
}
function write(a){fs.mkdirSync('artifacts/control-plane',{recursive:true});fs.writeFileSync(OUT,JSON.stringify(a,null,2)+'\n');console.log(`${a.status} -> ${OUT}`)}
await run();
