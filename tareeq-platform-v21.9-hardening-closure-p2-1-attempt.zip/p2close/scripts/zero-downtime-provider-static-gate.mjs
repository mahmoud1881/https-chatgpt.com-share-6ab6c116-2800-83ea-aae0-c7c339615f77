import {readFileSync,existsSync} from 'node:fs';
const required=['deploy/scripts/provider-selfhost.mjs','deploy/scripts/live-canary-slo.mjs','deploy/scripts/zero-downtime-hook.sh'];for(const f of required)if(!existsSync(f))throw Error(`missing ${f}`);
const p=readFileSync(required[0],'utf8'),s=readFileSync(required[1],'utf8'),h=readFileSync(required[2],'utf8');
for(const x of ['shift-canary','shift-full','restore-old-traffic','readiness-green','synthetic-green','observe-canary'])if(!p.includes(x))throw Error(`provider missing ${x}`);
for(const x of ['CANARY_MAX_5XX_RATE','CANARY_MAX_P95_MS','CANARY_MAX_P99_MS','CANARY_MAX_DB_ERRORS','readinessFailures','syntheticFailures'])if(!s.includes(x))throw Error(`SLO gate missing ${x}`);
if(!h.includes('ZD_PROVIDER:-selfhost'))throw Error('selfhost provider is not default');
console.log('✓ v21.1 provider gate: self-host Docker/Caddy adapter + live 5xx/p95/p99/readiness/synthetic/DB SLO + automatic recovery hooks present.');
