import { readFileSync } from "node:fs";
import { spawnSync } from "node:child_process";
const source = readFileSync("deploy/scripts/disaster-recovery-certification.mjs", "utf8");
const backup = readFileSync("deploy/scripts/backup-database.sh", "utf8");
const pkg = JSON.parse(readFileSync("package.json", "utf8"));
for (const value of [
  "DR_BACKUP_DIR", "DR_DISASTER_AT", "recovery-point.json", "source-schema-fingerprint.json",
  "source-content-fingerprint.json", "guard.begin()", "guard.verifyDatabase()", "guard.cleanup()",
  "schemaIntegrity", "contentIntegrity", "rpoMeasuredSeconds", "databaseRecoveryPassed", "blockedReasons",
]) if (!source.includes(value)) throw Error(`recovery invariant missing: ${value}`);
for (const value of ["clock_timestamp()", "source-schema-fingerprint.json", "source-content-fingerprint.json"])
  if (!backup.includes(value)) throw Error(`backup recovery proof missing: ${value}`);
for (const forbidden of ["statSync(resolve(backupDir, \"db.dump\")", "provider-selfhost.mjs", "telemetry-certification.mjs"])
  if (source.includes(forbidden)) throw Error(`unsafe/incorrect recovery operation: ${forbidden}`);
if (!pkg.scripts?.["recovery:certify"]?.includes("disaster-recovery-certification.mjs")) throw Error("recovery:certify missing");
for (const test of ["deploy/scripts/dr-isolation.test.mjs", "deploy/scripts/disaster-recovery-proof.test.mjs"]) {
  const result = spawnSync(process.execPath, ["--test", test], {stdio:"inherit"});
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(1);
}
console.log("Recovery proof gate passed; live RTO/RPO still requires isolated runtime certification.");
