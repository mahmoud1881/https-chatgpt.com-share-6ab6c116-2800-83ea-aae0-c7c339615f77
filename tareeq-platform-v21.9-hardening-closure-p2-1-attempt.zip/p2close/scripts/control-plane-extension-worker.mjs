import {parentPort,workerData} from 'node:worker_threads';
import {pathToFileURL} from 'node:url';
const caps=new Set(workerData.capabilities||[]);
const emit=(cap,kind,value)=>{if(!caps.has(cap)){parentPort.postMessage({type:'denied',cap});return;} parentPort.postMessage({type:'action',kind,value});};
const api=Object.freeze({
 emitSignal:v=>emit('emitSignal','signal',v),
 submitEvidence:v=>emit('submitEvidence','evidence',v),
 submitVerificationObservation:v=>emit('submitVerificationObservation','verification',v),
 proposeRemediation:v=>emit('proposeRemediation','remediation',v),
 proposeDeployment:v=>emit('proposeDeployment','deployment',v)
});
try { const mod=await import(pathToFileURL(workerData.entrypoint).href); const result=await mod.run(workerData.input,api); parentPort.postMessage({type:'done',result}); }
catch(e){ throw e; }
