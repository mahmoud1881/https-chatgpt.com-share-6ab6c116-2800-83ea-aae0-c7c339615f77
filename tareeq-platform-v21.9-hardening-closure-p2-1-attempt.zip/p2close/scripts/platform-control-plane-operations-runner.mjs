import fs from 'node:fs'; import path from 'node:path';
import {evaluateGovernance,appendAuditEvent,buildControlCenter,continuousVerificationCycle} from './platform-control-plane-operations.mjs';
const root=process.cwd(), out=path.join(root,'artifacts','control-plane'); fs.mkdirSync(out,{recursive:true});
const read=p=>{try{return JSON.parse(fs.readFileSync(path.join(root,p),'utf8'))}catch{return null}};
const cp=read('artifacts/control-plane/workflow-control-plane.json')||{accepted:false,stages:[]};
// Never infer zero from absence. Runtime/governance observations must be explicit.
const govInput=read('artifacts/control-plane/governance-observations.json')||{};
const governance=evaluateGovernance(govInput);
let audit=[]; audit=appendAuditEvent(audit,{type:'CONTROL_PLANE_OPERATIONS_RUN',data:{governance:governance.status,workflow_accepted:cp.accepted===true}});
const signalInput=read('artifacts/control-plane/continuous-signals.json');
const continuous=continuousVerificationCycle({signals:signalInput||[],closedIncidents:[],executed:Array.isArray(signalInput)});
const center=buildControlCenter({workflow:cp,governance,incidents:[],audit,continuous});
const report={stage:'P3-7..P3-10',accepted:cp.accepted===true&&governance.status==='VERIFIED_PASS'&&continuous.status==='VERIFIED_PASS',governance,continuous,control_center:center,audit};
report.status=report.accepted?'VERIFIED_PASS':(governance.status==='CONFIRMED_FAIL'?'CONFIRMED_FAIL':'PENDING');
fs.writeFileSync(path.join(out,'platform-management-control-system.json'),JSON.stringify(report,null,2)+'\n');
fs.writeFileSync(path.join(out,'audit-trail.json'),JSON.stringify(audit,null,2)+'\n');
fs.writeFileSync(path.join(out,'control-center.json'),JSON.stringify(center,null,2)+'\n');
console.log(JSON.stringify({status:report.status,accepted:report.accepted,governance:governance.status,continuous:continuous.status},null,2));
process.exit(report.accepted?0:75);
