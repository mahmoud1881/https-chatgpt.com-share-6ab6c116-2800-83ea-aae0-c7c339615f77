import {CONTROL_PLANE_API} from './control-plane-v1-sdk.mjs';
export const CONTRACT_VERSION=CONTROL_PLANE_API;
export const CORE_CONTRACTS=Object.freeze({
 RunIdentity:['release_id','commit_sha','environment_id','config_hash'],
 Evidence:['stage','status','identity','digest','recorded_at'],
 VerificationResult:['status','verified','reasons'],
 Incident:['incident_id','state','classification','created_at'],
 ImpactNode:['id','type'], ImpactEdge:['from','to','relation'],
 Remediation:['incident_id','attempt','status','evidence'],
 Policy:['id','version','rule'], Signal:['id','source','observed_at'],
 AuditEvent:['seq','at','type','actor','previous_hash','event_hash'],
 ExtensionManifest:['id','version','type','api_version','entrypoint','capabilities','permissions','timeout_ms','resources','evidence_requirements','failure_semantics','isolation']
});
export function assertContract(name,value={}){const fields=CORE_CONTRACTS[name]; if(!fields) throw new Error(`UNKNOWN_CONTRACT:${name}`); const missing=fields.filter(k=>value[k]===undefined); return {valid:missing.length===0,missing,version:CONTRACT_VERSION};}
