import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";

const checks = [
  [
    "Docker runtime copies public/",
    readFileSync("deploy/app/Dockerfile", "utf8").includes("/app/public ./public"),
  ],
  [
    "Route request uses DB rate limiting",
    readFileSync("src/lib/route-requests.functions.ts", "utf8").includes(
      'rpc("enforce_rate_limit"',
    ),
  ],
  [
    "Route verification uses atomic RPC",
    readFileSync("src/lib/route-verifications.functions.ts", "utf8").includes(
      'rpc(\n      "submit_route_verification_atomic"',
    ),
  ],
  [
    "Atomic P0 migration exists",
    existsSync(
      join("supabase/migrations", "20260917170000_p0_atomic_public_submission_guards.sql"),
    ),
  ],
];

let failed = false;
for (const [name, ok] of checks) {
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}`);
  if (!ok) failed = true;
}
if (failed) process.exit(1);
