\set ON_ERROR_STOP on
-- Destructive-free negative authorization proof. Run against an ephemeral/local
-- database after all migrations. Each forbidden operation must be rejected.
BEGIN;

CREATE OR REPLACE FUNCTION pg_temp.expect_denied(label text, stmt text) RETURNS void
LANGUAGE plpgsql AS $$
BEGIN
  BEGIN
    EXECUTE stmt;
    RAISE EXCEPTION 'AUTHZ_PROOF_FAILED: % unexpectedly succeeded', label;
  EXCEPTION
    WHEN insufficient_privilege OR check_violation OR raise_exception THEN
      IF SQLERRM LIKE 'AUTHZ_PROOF_FAILED:%' THEN RAISE; END IF;
  END;
END $$;

-- Seed disposable auth identities as owner. user_roles has an FK to auth.users,
-- so the proof must exercise the real relationship rather than bypassing it.
INSERT INTO auth.users (id, aud, role, email, created_at, updated_at)
VALUES
  ('00000000-0000-0000-0000-000000000001', 'authenticated', 'authenticated', 'v207-user@example.invalid', now(), now()),
  ('00000000-0000-0000-0000-000000000002', 'authenticated', 'authenticated', 'v207-admin@example.invalid', now(), now())
ON CONFLICT (id) DO NOTHING;

-- anon cannot mutate core/admin data or inspect role assignments/RPC role checks.
SET LOCAL ROLE anon;
SELECT pg_temp.expect_denied('anon insert routes', $$INSERT INTO public.routes DEFAULT VALUES$$);
SELECT pg_temp.expect_denied('anon read user_roles', $$SELECT * FROM public.user_roles LIMIT 1$$);
SELECT pg_temp.expect_denied('anon execute has_role', $$SELECT public.has_role('00000000-0000-0000-0000-000000000001', 'admin')$$);
RESET ROLE;

-- authenticated without an admin JWT cannot mutate core/admin data or roles.
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001', true);
SELECT set_config('request.jwt.claim.role','authenticated', true);
SELECT pg_temp.expect_denied('authenticated insert routes', $$INSERT INTO public.routes DEFAULT VALUES$$);
SELECT pg_temp.expect_denied('authenticated read user_roles', $$SELECT * FROM public.user_roles LIMIT 1$$);
SELECT pg_temp.expect_denied('authenticated write admin_config', $$DELETE FROM public.admin_config$$);
-- authenticated is allowed to call has_role, but a normal user must resolve false.
DO $$ BEGIN
  IF public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'AUTHZ_PROOF_FAILED: ordinary authenticated user resolved as admin';
  END IF;
END $$;
RESET ROLE;

-- Create a disposable admin membership as the database owner, then prove that
-- the authenticated JWT is recognized by the canonical has_role() decision.
INSERT INTO public.user_roles(user_id, role)
VALUES ('00000000-0000-0000-0000-000000000002', 'admin')
ON CONFLICT (user_id, role) DO NOTHING;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000002', true);
SELECT set_config('request.jwt.claim.role','authenticated', true);
DO $$ BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'AUTHZ_PROOF_FAILED: admin membership not recognized';
  END IF;
END $$;
-- The admin identity is still deliberately unable to read user_roles directly;
-- privilege comes through canonical policies/RPC decisions, not table leakage.
SELECT pg_temp.expect_denied('admin direct read user_roles', $$SELECT * FROM public.user_roles LIMIT 1$$);
RESET ROLE;

-- service_role is intentionally privileged; prove server-only access to the
-- protected role table succeeds, without mutating application data.
SET LOCAL ROLE service_role;
SELECT count(*) AS service_role_user_roles_visible FROM public.user_roles;
RESET ROLE;

ROLLBACK;
SELECT 'negative authorization proof: PASS' AS result;
