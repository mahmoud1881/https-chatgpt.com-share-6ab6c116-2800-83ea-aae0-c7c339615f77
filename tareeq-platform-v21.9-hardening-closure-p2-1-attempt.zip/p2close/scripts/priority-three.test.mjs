import { test } from "node:test";
import assert from "node:assert/strict";
import { benchmarkDigest, validateBenchmark } from "./trip-benchmark-validation.mjs";
import { requireJourneySuccess } from "../deploy/scripts/load-result.mjs";
import { readFileSync, mkdtempSync, writeFileSync, rmSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { tmpdir } from "node:os";
import { join } from "node:path";
function fixture() {
  const date = new Date().toISOString();
  const cases = {
    version: 1,
    acceptance: { min_pass_rate: 0.95, max_unsafe_or_fabricated: 0, minimum_reviewed: 20 },
    cases: Array.from({ length: 20 }, (_, i) => ({
      id: `T${i}`,
      category: "test",
      reference_status: "independently_verified",
      review: {
        reviewer: "test reviewer",
        reviewed_at: date,
        source_kind: "field_visit",
        evidence: "test fixture only",
        expected_outcome: "route",
        aliases: ["test"],
        boarding: "A",
        direction: "B",
        alighting: "C",
        transfers: [],
      },
    })),
  };
  const outcome = () => ({
    verdict: "pass",
    actual_evidence: "fixture.png",
    observed_instructions: "fixture only",
    unsafe_or_fabricated: false,
    outcome: "route",
  });
  const observations = {
    benchmark_version: 1,
    benchmark_sha256: benchmarkDigest(cases),
    environment: "https://staging.example.invalid",
    deployed_commit: "a".repeat(40),
    data_revision: "fixture-only",
    captured_at: date,
    cases: cases.cases.map((c) => ({
      id: c.id,
      reviewed_at: date,
      reviewer: "test reviewer",
      search: outcome(),
      planner: outcome(),
    })),
  };
  return { cases, observations };
}
test("load success requires actual routes, not a visible empty/error box", () => {
  requireJourneySuccess("success", "1");
  for (const [status, count] of [
    ["empty", "0"],
    ["error", "1"],
    ["success", "0"],
    [null, null],
    ["success", "NaN"],
  ])
    assert.throws(() => requireJourneySuccess(status, count));
});
test("complete independent reference and dual-surface evidence passes validation", () => {
  const { cases, observations } = fixture();
  assert.deepEqual(validateBenchmark(cases, observations), []);
});
test("missing/stale independent evidence cannot be bypassed by pass verdicts", () => {
  const { cases, observations } = fixture();
  cases.cases[0].review = null;
  observations.benchmark_sha256 = benchmarkDigest(cases);
  assert.ok(
    validateBenchmark(cases, observations).some((x) => x.includes("independent reference")),
  );
});
test("changing the benchmark invalidates captured evidence", () => {
  const { cases, observations } = fixture();
  cases.cases[0].review.boarding = "changed";
  assert.ok(validateBenchmark(cases, observations).some((x) => x.includes("digest")));
});
test("core positive journeys cannot be relabeled as successful empty searches", () => {
  const { cases, observations } = fixture();
  cases.cases[0].category = "common";
  cases.cases[0].review.expected_outcome = "no_verified_route";
  observations.benchmark_sha256 = benchmarkDigest(cases);
  observations.cases[0].search.outcome = "no_verified_route";
  observations.cases[0].planner.outcome = "no_verified_route";
  assert.ok(
    validateBenchmark(cases, observations).some((x) => x.includes("core positive journey")),
  );
});
test("missing planner results and empty routes marked pass are rejected", () => {
  const { cases, observations } = fixture();
  delete observations.cases[0].planner;
  observations.cases[1].search.outcome = "no_verified_route";
  const errors = validateBenchmark(cases, observations);
  assert.ok(errors.some((x) => x.includes("planner evidence")));
  assert.ok(errors.some((x) => x.includes("contradicts")));
});
test("invalid, future and stale dates fail closed", () => {
  for (const date of ["not-a-date", "2000-01-01", "2999-01-01"]) {
    const { cases, observations } = fixture();
    observations.captured_at = date;
    assert.ok(validateBenchmark(cases, observations).some((x) => x.includes("Capture")));
  }
});
test("evaluator enforces 19/20 and zero unsafe instructions", () => {
  const dir = mkdtempSync(join(tmpdir(), "trip-eval-"));
  try {
    const { cases, observations } = fixture();
    writeFileSync(join(dir, "cases.json"), JSON.stringify(cases));
    const run = () => {
      writeFileSync(join(dir, "observations.json"), JSON.stringify(observations));
      return spawnSync(
        process.execPath,
        [
          "scripts/evaluate-trip-benchmark.mjs",
          join(dir, "cases.json"),
          join(dir, "observations.json"),
        ],
        { encoding: "utf8" },
      ).status;
    };
    assert.equal(run(), 0);
    observations.cases[0].search.verdict = "fail";
    assert.equal(run(), 0);
    observations.cases[1].planner.verdict = "fail";
    assert.equal(run(), 1);
    observations.cases[1].planner.verdict = "pass";
    observations.cases[0].search.unsafe_or_fabricated = true;
    assert.equal(run(), 1);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
test("compact minibus data exactly matches its noncompact source", () => {
  const source = JSON.parse(readFileSync("public/data/cairo-minibus-lines.json"));
  const compact = JSON.parse(readFileSync("public/data/cairo-minibus-lines.compact.json"));
  assert.deepEqual(
    compact.rows,
    source.map((row) => compact.schema.map((key) => row[key] ?? null)),
  );
});
