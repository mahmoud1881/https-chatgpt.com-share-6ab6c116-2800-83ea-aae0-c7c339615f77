import crypto from 'node:crypto';

export const FAILURE_CLASSES = Object.freeze(['CODE','TEST','DATA','CONFIG','DEPENDENCY','INFRA','SECURITY','PERFORMANCE','ENVIRONMENT','FLAKY']);
export const INCIDENT_STATES = Object.freeze(['DETECTED','CLASSIFIED','DIAGNOSED','REMEDIATION_PENDING','REMEDIATED','TARGETED_RETEST','IMPACTED_REGRESSION','REVERIFY','CLOSURE_ELIGIBLE','CLOSED','REOPENED','OVERRIDDEN']);

const rules = [
  ['SECURITY', /unauthori[sz]ed|rls|secret|token leak|permission|forbidden|security/i],
  ['ENVIRONMENT', /enoent|command not found|dns|eai_again|runner|missing runtime|environment|not_executed/i],
  ['DEPENDENCY', /dependency|registry|package|module not found|service unavailable|connection refused/i],
  ['DATA', /quarantine|provenance|schema drift|invalid data|duplicate record|stale data/i],
  ['CONFIG', /config|missing env|endpoint|credential|configuration/i],
  ['PERFORMANCE', /latency|timeout|slo|slow|throughput|performance/i],
  ['TEST', /assertion|fixture|test setup|playwright|vitest|flaky test/i],
  ['INFRA', /docker|disk|memory|network|postgres.*down|redis.*down|smtp.*down/i],
  ['CODE', /typescript|eslint|build failed|exception|stack trace|runtime error/i],
  ['FLAKY', /intermittent|non.?determin|flaky/i],
];

export function classifyFailure(input={}) {
  const text = JSON.stringify(input);
  const matches = rules.filter(([,rx])=>rx.test(text)).map(([classification])=>classification);
  const classification = matches[0] || 'CODE';
  return Object.freeze({classification, confidence: matches.length ? (matches.length===1?0.9:0.7) : 0.5, reasons:matches.length?matches:['DEFAULT_CODE_CLASSIFICATION']});
}

export function createImpactGraph(def={}) {
  const nodes = new Map((def.nodes||[]).map(n=>[n.id,Object.freeze({...n})]));
  const edges = (def.edges||[]).map(e=>Object.freeze({...e}));
  for (const e of edges) if (!nodes.has(e.from)||!nodes.has(e.to)) throw new Error(`invalid impact edge ${e.from}->${e.to}`);
  return Object.freeze({nodes:Object.freeze([...nodes.values()]),edges:Object.freeze(edges)});
}
export function calculateImpact(graph, changedIds=[]) {
  const byId=new Map(graph.nodes.map(n=>[n.id,n])); const adjacency=new Map();
  for(const e of graph.edges){if(!adjacency.has(e.from)) adjacency.set(e.from,[]); adjacency.get(e.from).push(e.to)}
  const seen=new Set(), queue=[...changedIds];
  while(queue.length){const id=queue.shift(); if(seen.has(id)||!byId.has(id)) continue; seen.add(id); for(const n of adjacency.get(id)||[]) queue.push(n)}
  const impacted=[...seen].map(id=>byId.get(id));
  return Object.freeze({changed:[...changedIds], impacted, required_tests:impacted.filter(n=>n.type==='test').map(n=>n.id), affected_slos:impacted.filter(n=>n.type==='slo').map(n=>n.id)});
}

export function newIncident({identity,source_failure,impact,classification}) {
  const created_at=new Date().toISOString();
  const incident_id=`INC-${crypto.createHash('sha256').update(JSON.stringify({identity,source_failure,created_at})).digest('hex').slice(0,12).toUpperCase()}`;
  return {incident_id,identity,state:'CLASSIFIED',source_failure,classification,impact,remediation_attempts:[],targeted_results:{},regression_results:{},reverification:null,override:null,audit:[{at:created_at,event:'INCIDENT_CREATED',state:'CLASSIFIED'}]};
}
function verified(result){return result?.status==='VERIFIED_PASS' && result?.verified===true}
export function deriveIncidentState(incident) {
  if (incident.override?.active===true && (!incident.override.expires_at || Date.parse(incident.override.expires_at)>Date.now())) return 'OVERRIDDEN';
  const attempts=incident.remediation_attempts||[]; if(!attempts.some(x=>x.applied===true)) return attempts.length?'REMEDIATION_PENDING':'CLASSIFIED';
  const req=incident.impact?.required_tests||[];
  if(!req.length) return 'REMEDIATED';
  if(!req.every(t=>verified(incident.targeted_results?.[t]))) return 'TARGETED_RETEST';
  if(!req.every(t=>verified(incident.regression_results?.[t]))) return 'IMPACTED_REGRESSION';
  if(!verified(incident.reverification)) return 'REVERIFY';
  return 'CLOSED';
}
function immutableIncidentUpdate(incident, mutate, auditEvent) {
  const next=structuredClone(incident);
  mutate(next);
  next.state=deriveIncidentState(next);
  next.audit=[...(next.audit||[]),{at:new Date().toISOString(),...auditEvent,state:next.state}];
  return Object.freeze(next);
}
export function recordRemediation(incident, attempt) {
  return immutableIncidentUpdate(incident,n=>{n.remediation_attempts=[...(n.remediation_attempts||[]),{...attempt,at:new Date().toISOString()}]}, {event:'REMEDIATION_RECORDED'});
}
export function recordTestResult(incident, kind, testId, verification) {
  if(!['targeted','regression'].includes(kind)) throw new Error('invalid result kind');
  return immutableIncidentUpdate(incident,n=>{n[`${kind}_results`]={...(n[`${kind}_results`]||{}),[testId]:structuredClone(verification)}}, {event:`${kind.toUpperCase()}_RESULT`,test_id:testId});
}
export function recordReverification(incident, verification){
  return immutableIncidentUpdate(incident,n=>{n.reverification=structuredClone(verification)}, {event:'REVERIFICATION'});
}
export function applyOverride(incident,{principal,actor,reason,evidence,expires_at,approvals=[]}){
  const actorId=principal?.id||actor;
  if(!actorId||!reason||!evidence||!expires_at) throw new Error('override requires authenticated principal/actor, reason, evidence and expiry');
  return immutableIncidentUpdate(incident,n=>{n.override={active:true,actor:actorId,principal:principal?structuredClone(principal):null,reason,evidence,expires_at,approvals:structuredClone(approvals)}}, {event:'OVERRIDE_APPLIED',actor:actorId,reason,expires_at});
}
export function reopenAsRecurrence(closedIncident, source_failure){if(deriveIncidentState(closedIncident)!=='CLOSED') throw new Error('recurrence requires closed incident'); const child=newIncident({identity:closedIncident.identity,source_failure,impact:closedIncident.impact,classification:classifyFailure(source_failure)}); child.relation={type:'RECURRENCE_OF',incident_id:closedIncident.incident_id}; return child;}
