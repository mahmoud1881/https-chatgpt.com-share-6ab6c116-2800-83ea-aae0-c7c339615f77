import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
const read=p=>fs.readFileSync(p,'utf8');
test('Jev adapter is server-side bearer authenticated and typed endpoint',()=>{const s=read('src/lib/ai-runtime/adapters.ts');assert.match(s,/api\.typesafe\.ai.*\/v1\/systemone/s);assert.match(s,/Bearer/);assert.match(s,/jev-latest/)});
test('Groq adapter pins GPT OSS 120B and JSON mode',()=>{const s=read('src/lib/ai-runtime/adapters.ts');assert.match(s,/openai\/gpt-oss-120b/);assert.match(s,/json_object/)});
test('Gemini verifier pins 3.8 and cannot become authority',()=>{const s=read('src/lib/ai-runtime/adapters.ts');assert.match(s,/gemini-3\.8-flash/);assert.ok(!s.includes('VERIFIED_PASS'));assert.ok(!s.includes('CLOSED'))});
test('local AI is a capability bridge, not mandatory',()=>{const s=read('src/lib/ai-runtime/adapters.ts');assert.match(s,/local_ai_unavailable/);assert.match(s,/available\(\)/)});
test('runtime fails closed when independent verification has no evidence',()=>{const s=read('src/lib/ai-runtime/runtime.ts');assert.match(s,/refs\.length===0.*UNVERIFIED/s)});
