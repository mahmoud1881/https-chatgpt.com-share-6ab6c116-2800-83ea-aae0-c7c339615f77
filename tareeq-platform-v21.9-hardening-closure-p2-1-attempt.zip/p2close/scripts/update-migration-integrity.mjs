import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, readdirSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
const root=resolve(new URL('..',import.meta.url).pathname); const dir=resolve(root,'supabase/migrations'); const path=resolve(root,'supabase/migration-integrity.json');
const sha=s=>createHash('sha256').update(s).digest('hex');
const files=readdirSync(dir).filter(x=>x.endsWith('.sql')).sort();
const old=existsSync(path)?JSON.parse(readFileSync(path,'utf8')):{migrations:{}};
for(const [f,h] of Object.entries(old.migrations||{})) if(files.includes(f) && sha(readFileSync(resolve(dir,f)))!==h){ console.error(`Refusing to bless modified historical migration: ${f}. Add a new migration instead.`); process.exit(1); }
const migrations={}; for(const f of files) migrations[f]=sha(readFileSync(resolve(dir,f)));
writeFileSync(path,JSON.stringify({format:'tareeq-migration-integrity-v1',policy:'Existing hashes are immutable. New migrations may be appended with this script.',migrations},null,2)+'\n');
console.log(`Wrote ${files.length} migration hashes to supabase/migration-integrity.json`);
