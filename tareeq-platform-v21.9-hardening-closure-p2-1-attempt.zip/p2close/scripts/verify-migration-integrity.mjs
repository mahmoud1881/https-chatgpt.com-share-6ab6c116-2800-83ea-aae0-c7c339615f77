import { createHash } from 'node:crypto';
import { readFileSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';
const root=resolve(new URL('..',import.meta.url).pathname), dir=resolve(root,'supabase/migrations');
const manifest=JSON.parse(readFileSync(resolve(root,'supabase/migration-integrity.json'),'utf8'));
const files=readdirSync(dir).filter(x=>x.endsWith('.sql')).sort(), recorded=Object.keys(manifest.migrations||{}).sort();
const sha=s=>createHash('sha256').update(s).digest('hex');
if(JSON.stringify(files)!==JSON.stringify(recorded)){ console.error(`❌ migration manifest filename drift: files=${files.length}, recorded=${recorded.length}`); process.exit(1); }
for(const f of files){ const got=sha(readFileSync(resolve(dir,f))); if(got!==manifest.migrations[f]){ console.error(`❌ historical migration hash mismatch: ${f}`); process.exit(1); } }
console.log(`✅ migration integrity: ${files.length} files match immutable SHA-256 manifest`);
