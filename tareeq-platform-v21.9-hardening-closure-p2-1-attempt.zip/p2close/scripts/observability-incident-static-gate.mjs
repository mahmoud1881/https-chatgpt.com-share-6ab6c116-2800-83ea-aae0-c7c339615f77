import {readFileSync,existsSync} from 'node:fs';
const required=['deploy/scripts/incident-evidence.mjs','deploy/scripts/live-canary-slo.mjs','deploy/scripts/progressive-delivery.mjs','deploy/scripts/provider-selfhost.mjs'];for(const f of required)if(!existsSync(f))throw Error(`missing ${f}`);
const slo=readFileSync(required[1],'utf8'),ctl=readFileSync(required[2],'utf8'),inc=readFileSync(required[0],'utf8'),provider=readFileSync(required[3],'utf8');
for(const x of ['deploymentId','correlationId','x-trace-id','anomaly','telemetry'])if(!slo.includes(x))throw Error(`correlated SLO missing ${x}`);
for(const x of ['deploymentId','correlationId',"incident(percent,'hold')","incident(percent,'abort')"])if(!ctl.includes(x))throw Error(`controller missing ${x}`);
for(const x of ['candidateLogs','stableLogs','degraded','database','external','application','timeline'])if(!inc.includes(x))throw Error(`incident bundle missing ${x}`);
if(!provider.includes("case 'incident-evidence'"))throw Error('provider missing incident-evidence phase');
console.log('✓ v21.3 gate: deployment/correlation/trace IDs, logs+metrics+traces, stable anomaly comparison, and hold/abort incident bundles are wired.');
