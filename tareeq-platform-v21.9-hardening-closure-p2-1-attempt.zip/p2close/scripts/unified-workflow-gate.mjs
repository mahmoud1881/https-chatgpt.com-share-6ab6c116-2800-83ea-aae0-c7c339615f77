import { spawnSync } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';

const root = new URL('../', import.meta.url).pathname.replace(/scripts\/$/, '');
process.chdir(root);
const runtimeRequested = process.argv.includes('--runtime');
const buildRequested = runtimeRequested || process.argv.includes('--build');

const localChecks = [
 ['p0-1-contracts',['node','--test','scripts/canonical-journey-contract.test.mjs']],
 ['p0-2-trust-contracts',['node','--test','scripts/canonical-journey-trust-contract.test.mjs']],
 ['p0-3-static',['node','scripts/p0-3-e2e-static-gate.mjs']],
 ['p1-1-contracts',['node','--test','scripts/p1-1-data-lifecycle-contract.test.mjs']],
 ['p1-1-static',['node','scripts/p1-1-static-gate.mjs']],
 ['p1-2-contracts',['node','--test','scripts/p1-2-failure-recovery-contract.test.mjs']],
 ['p1-2-static',['node','scripts/p1-2-static-gate.mjs']],
 ['p1-3-contracts',['node','--test','scripts/p1-3-state-integrity-contract.test.mjs']],
 ['p1-3-static',['node','scripts/p1-3-static-gate.mjs']],
 ['p1-4-contracts',['node','--test','scripts/p1-4-feature-completeness-contract.test.mjs']],
 ['p1-4-static',['node','scripts/p1-4-static-gate.mjs']],
 ['quality-static',['node','scripts/application-quality-static-gate.mjs']],
 ['data-structural',['node','--experimental-strip-types','scripts/validate-data.ts']],
 ['source-integrity',['node','scripts/source-integrity-gate.mjs']],
 ['data-review-tests',['node','--test','scripts/quarantine-eg-routes.test.mjs','scripts/data-review-release-safety.test.mjs']],
 ['data-review-gate',['node','scripts/data-review-gate.mjs']],
];

const buildChecks = [
 ['compiler-config',['node','scripts/compiler-quality-config-gate.mjs']],
 ['typecheck',['npm','run','typecheck']],
 ['eslint',['npm','run','lint']],
 ['vitest',['npm','run','test']],
 ['production-build',['npm','run','build']],
];

const runtimeChecks = [
 ['p0-3-runtime',['npx','playwright','test','e2e/p0-3-critical-workflows.e2e.ts']],
 ['p1-1-runtime',['npx','playwright','test','e2e/p1-1-data-lifecycle.e2e.ts']],
 ['p1-2-runtime',['npx','playwright','test','e2e/p1-2-failure-recovery.e2e.ts']],
 ['p1-3-runtime',['npx','playwright','test','e2e/p1-3-state-integrity.e2e.ts']],
 ['p1-4-runtime',['npx','playwright','test','e2e/p1-4-feature-completeness.e2e.ts']],
];

function run([name,cmd]) {
 const r=spawnSync(cmd[0],cmd.slice(1),{stdio:'inherit',env:process.env});
 return {name,executed:true,passed:r.status===0,exit_code:r.status};
}
function runSeries(checks){
 const results=[];
 for(const c of checks){ const r=run(c); results.push(r); if(!r.passed) break; }
 return results;
}
function seriesPassed(results,checks){ return results.length===checks.length && results.every(x=>x.passed); }

const localResults=runSeries(localChecks);
const localPassed=seriesPassed(localResults,localChecks);
let buildResults=[];
let runtimeResults=[];
let status='LOCAL_FAIL';
let accepted=false;
let reason='One or more local workflow gates failed.';

if(localPassed){
 status='BUILD_PENDING';
 reason='All local workflow gates passed; compiler/test/build evidence has not been executed by this run.';
 if(buildRequested){
   buildResults=runSeries(buildChecks);
   const buildPassed=seriesPassed(buildResults,buildChecks);
   if(!buildPassed){
     status='BUILD_FAIL';
     reason='Compiler/test/build execution failed or did not complete.';
   } else if(runtimeRequested){
     runtimeResults=runSeries(runtimeChecks);
     const runtimePassed=seriesPassed(runtimeResults,runtimeChecks);
     status=runtimePassed?'PASS':'RUNTIME_FAIL';
     accepted=runtimePassed;
     reason=runtimePassed?'All local, compiler/build, and runtime workflow gates executed and passed.':'Runtime workflow execution failed or did not complete.';
   } else {
     status='RUNTIME_PENDING';
     reason='Local and compiler/build gates passed; runtime Playwright evidence has not been executed.';
   }
 }
}

const runtimeComplete=seriesPassed(runtimeResults,runtimeChecks);
const report={
 format:'tareeq-v21.9-unified-workflow-readiness-v2',
 generated_at:new Date().toISOString(),
 status,accepted,
 local:{executed:true,passed:localPassed,checks:localResults,required_checks:localChecks.map(x=>x[0])},
 build:{requested:buildRequested,executed:buildResults.length>0,passed:buildResults.length===buildChecks.length?buildResults.every(x=>x.passed):null,checks:buildResults,required_checks:buildChecks.map(x=>x[0])},
 runtime:{requested:runtimeRequested,executed:runtimeResults.length>0,passed:runtimeResults.length===runtimeChecks.length?runtimeResults.every(x=>x.passed):null,checks:runtimeResults,required_suites:runtimeChecks.map(x=>x[0])},
 invariants:{
   pending_quarantined_rejected_leakage:{required:0,observed:localPassed?0:null,evidence:'local data-review/quarantine gates'},
   duplicate_mutations:{required:0,observed:runtimeComplete?0:null,evidence:runtimeComplete?'p1-3 runtime':'NOT_EXECUTED'},
   stale_response_overwrite:{required:0,observed:runtimeComplete?0:null,evidence:runtimeComplete?'p1-3 runtime':'NOT_EXECUTED'},
   unauthorized_mutations:{required:0,observed:runtimeComplete?0:null,evidence:runtimeComplete?'p0-3/p1 runtime':'NOT_EXECUTED'},
   broken_working_cta:{required:0,observed:runtimeComplete?0:null,evidence:runtimeComplete?'p1-4 runtime':'NOT_EXECUTED'}
 },
 reason
};
mkdirSync('artifacts',{recursive:true});
writeFileSync('artifacts/unified-workflow-readiness.json',JSON.stringify(report,null,2)+'\n');
console.log(`\nUnified Workflow Gate: ${status}`);
console.log(reason);
process.exit(accepted?0:((status==='BUILD_PENDING'||status==='RUNTIME_PENDING')?75:1));
