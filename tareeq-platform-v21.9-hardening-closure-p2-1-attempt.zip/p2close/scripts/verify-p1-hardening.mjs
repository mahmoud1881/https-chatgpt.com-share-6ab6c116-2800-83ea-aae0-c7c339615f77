import { readFileSync, existsSync } from "node:fs";

const mustContain = [
  [
    "src/lib/rate-limit.ts",
    'supabaseAdmin.rpc("enforce_rate_limit"',
    "distributed DB rate limiter",
  ],
  ["src/lib/rate-limit.ts", "TRUST_PROXY_HEADERS", "trusted proxy policy"],
  ["src/lib/incidents.functions.ts", "16_384", "incident metadata size cap"],
  [
    "src/lib/admin/add-bus-line.functions.ts",
    "upsert_route_with_stops_atomic",
    "atomic admin route publication",
  ],
  [
    "supabase/migrations/20260917190000_p1_atomic_admin_route_write.sql",
    "pg_advisory_xact_lock",
    "atomic route transaction lock",
  ],
  [
    "supabase/migrations/20260917191000_p1_country_normalization.sql",
    "normalize_country_code",
    "country normalization",
  ],
  ["src/integrations/lovable/index.ts", "VITE_AUTH_PROVIDER", "self-host auth adapter"],
  ["src/lib/seo/site.ts", "VITE_SITE_URL", "runtime/build site URL configuration"],
  ["scripts/production-release-gate.mjs", "docker", "production release gate"],
  [".github/workflows/ci.yml", "bun run typecheck", "CI typecheck"],
  [".github/workflows/ci.yml", "bun run lint", "CI lint"],
  [".github/workflows/ci.yml", "bun run test:e2e", "CI E2E"],
];

let failed = false;
for (const [file, needle, label] of mustContain) {
  if (!existsSync(file) || !readFileSync(file, "utf8").includes(needle)) {
    console.error(`❌ ${label}: missing ${file} / ${needle}`);
    failed = true;
  } else {
    console.log(`✅ ${label}`);
  }
}

const stale = [
  "src/routes/brt.tsx",
  "src/routes/lrt.tsx",
  "src/routes/navigate.tsx",
  "src/routes/route.$routeId.tsx",
  "src/routes/live.tsx",
  "src/lib/route-planner.tsx",
];
for (const file of stale) {
  const text = readFileSync(file, "utf8");
  if (text.includes('"https://tareeq.world/') || text.includes("`https://tareeq.world/")) {
    console.error(`❌ hard-coded production URL remains in ${file}`);
    failed = true;
  }
}
if (!failed) console.log("\\nP1 structural verification: PASS");
process.exit(failed ? 1 : 0);
