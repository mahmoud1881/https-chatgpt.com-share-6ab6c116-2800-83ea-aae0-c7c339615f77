import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read=p=>fs.readFileSync(p,'utf8');
const canonical=read('src/lib/journey/canonical.ts');
const structured=read('src/lib/route-planner/search.functions.ts');
const gate=read('scripts/data-review-gate.mjs');
const e2e=read('e2e/p1-1-data-lifecycle.e2e.ts');

test('journey layer remains fail-closed for non-active lifecycle states',()=>{
  assert.match(canonical,/BLOCKED_LIFECYCLES[^\n]*pending[^\n]*quarantined[^\n]*rejected[^\n]*unknown/);
  assert.match(canonical,/segments\.some\(s => BLOCKED_LIFECYCLES\.has\(s\.lifecycle\)\)/);
  assert.match(structured,/\.eq\(["']status["'],\s*["']active["']\)/);
});

test('review gate requires evidence for reviewed records and zero quarantine leakage',()=>{
  assert.match(gate,/reviewedBy\s*&&\s*r\.reviewedAt\s*&&\s*r\.reviewEvidence/);
  assert.match(gate,/quarantinedLeakedIntoPublishedData/);
  assert.match(gate,/leakedQuarantined\.length === 0/);
});

test('P1-1 runtime suite covers pending rejected approved publication and provenance',()=>{
  for(const marker of ['pending is absent','rejected is absent','approved but unpublished is absent','published active route is visible','provenance and trust survive publication','revoked route disappears']) {
    assert.match(e2e,new RegExp(marker.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
  }
});
