import { readdirSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

const url = process.argv[2] || process.env.DATABASE_URL;
if (!url) process.exit(2);
const expected = readdirSync('supabase/migrations').filter((f) => f.endsWith('.sql')).length;
const q = "select count(*) from supabase_migrations.schema_migrations";
const r = spawnSync('psql', [url, '-X', '-Atqc', q], { encoding: 'utf8' });
if (r.error || r.status !== 0) {
  console.error(r.stderr || r.error?.message || 'Unable to query migration ledger');
  process.exit(1);
}
const applied = Number(String(r.stdout).trim());
if (!Number.isFinite(applied) || applied !== expected) {
  console.error(`Migration ledger mismatch: expected ${expected}, applied ${applied}`);
  process.exit(1);
}
console.log(`Migration ledger proof: PASS (${applied}/${expected} migrations applied from scratch)`);
