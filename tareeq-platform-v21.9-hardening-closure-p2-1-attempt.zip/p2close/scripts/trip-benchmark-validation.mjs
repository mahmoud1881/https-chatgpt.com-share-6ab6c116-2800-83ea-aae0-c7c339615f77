import { createHash } from "node:crypto";
export const benchmarkDigest = (value) =>
  createHash("sha256").update(JSON.stringify(value)).digest("hex");
const text = (value) => typeof value === "string" && value.trim().length > 0;
function recent(value, maxDays, now) {
  const date = typeof value === "string" ? Date.parse(value) : NaN;
  return Number.isFinite(date) && date <= now + 300000 && now - date <= maxDays * 86400000;
}
export function validateBenchmark(cases, observations, now = Date.now()) {
  const errors = [];
  if (
    cases.acceptance?.min_pass_rate !== 0.95 ||
    cases.acceptance?.max_unsafe_or_fabricated !== 0 ||
    cases.acceptance?.minimum_reviewed !== 20 ||
    cases.cases?.length !== 20
  )
    errors.push("Frozen acceptance must remain 19/20 and zero unsafe instructions");
  if (
    observations.benchmark_version !== cases.version ||
    observations.benchmark_sha256 !== benchmarkDigest(cases)
  )
    errors.push("Benchmark version/digest mismatch");
  if (
    !/^[a-f0-9]{40}$/i.test(observations.deployed_commit ?? "") ||
    !text(observations.data_revision)
  )
    errors.push("Exact deployed commit and data revision required");
  try {
    const url = new URL(observations.environment);
    if (url.protocol !== "https:" || /example\.(com|org|net)$/.test(url.hostname)) throw Error();
  } catch {
    errors.push("Real HTTPS staging URL required");
  }
  if (!recent(observations.captured_at, 7, now))
    errors.push("Capture must be valid, non-future and within 7 days");
  const ids = (cases.cases ?? []).map((c) => c.id);
  const rows = observations.cases ?? [];
  if (
    new Set(ids).size !== ids.length ||
    new Set(rows.map((r) => r.id)).size !== rows.length ||
    rows.some((r) => !ids.includes(r.id))
  )
    errors.push("Invalid/duplicate case IDs");
  const byId = new Map(rows.map((r) => [r.id, r]));
  for (const c of cases.cases ?? []) {
    const ref = c.review;
    const maxDays = ref?.source_kind === "operator" ? 30 : 14;
    if (
      c.reference_status !== "independently_verified" ||
      !ref ||
      !["operator", "field_visit", "independent_local_review"].includes(ref.source_kind) ||
      !text(ref.reviewer) ||
      !text(ref.evidence) ||
      !recent(ref.reviewed_at, maxDays, now) ||
      !["route", "no_verified_route"].includes(ref.expected_outcome)
    ) {
      errors.push(`${c.id}: independent reference missing/stale`);
      continue;
    }
    if (ref.source_kind === "operator" && !/^https:\/\//.test(ref.evidence))
      errors.push(`${c.id}: operator URL required`);
    if (
      ref.expected_outcome === "no_verified_route" &&
      !["reverse_direction", "transfer"].includes(c.category)
    )
      errors.push(`${c.id}: core positive journey cannot pass by returning no route`);
    if (!Array.isArray(ref.aliases) || !ref.aliases.every(text))
      errors.push(`${c.id}: reviewed alias list required`);
    if (
      ref.expected_outcome === "route" &&
      (!text(ref.boarding) ||
        !text(ref.direction) ||
        !text(ref.alighting) ||
        !Array.isArray(ref.transfers) ||
        !ref.transfers.every(text))
    )
      errors.push(`${c.id}: incomplete boarding/direction/transfer reference`);
    const o = byId.get(c.id);
    if (
      !o ||
      !recent(o.reviewed_at, 7, now) ||
      Date.parse(o.reviewed_at) < Date.parse(observations.captured_at) ||
      !text(o.reviewer)
    ) {
      errors.push(`${c.id}: observation review missing/stale`);
      continue;
    }
    for (const surface of ["search", "planner"]) {
      const result = o[surface];
      if (
        !result ||
        !["pass", "fail"].includes(result.verdict) ||
        !text(result.actual_evidence) ||
        !text(result.observed_instructions) ||
        typeof result.unsafe_or_fabricated !== "boolean" ||
        !["route", "no_verified_route"].includes(result.outcome)
      ) {
        errors.push(`${c.id}: ${surface} evidence incomplete`);
        continue;
      }
      if (result.verdict === "pass" && result.outcome !== ref.expected_outcome)
        errors.push(`${c.id}: ${surface} outcome contradicts reference`);
    }
  }
  return errors;
}
