import { existsSync, readFileSync } from "node:fs";
const req = [
  "deploy/scripts/full-production-certification.mjs",
  "deploy/scripts/verify-production-certification.mjs",
];
for (const f of req) if (!existsSync(f)) throw Error(`${f} missing`);
const s = readFileSync(req[0], "utf8");
for (const token of [
  "run-release-database-gate.mjs",
  "zero-downtime-deploy.mjs",
  "telemetry-certification.mjs",
  "runtime-chaos-certification.mjs",
  "disaster-recovery-certification.mjs",
  "RELEASE_IMAGE_DIGEST",
  "RELEASE_COMMIT",
  "schemaFingerprint",
  "Ed25519",
  "PRODUCTION CERTIFIED",
  "production-certification.sig",
])
  if (!s.includes(token)) throw Error(`v21.8 invariant missing: ${token}`);
const catchPart = s.split("}catch(e){")[1] || "";
if (catchPart.includes("cert.status='PRODUCTION CERTIFIED'"))
  throw Error("certification success marker must not be emitted from failure path");
console.log("✅ v21.8 signed production certification static gate: PASS");
const { spawnSync } = await import("node:child_process");
const policyTests = spawnSync(
  process.execPath,
  ["--test", "deploy/scripts/certification-policy.test.mjs", "deploy/scripts/runtime-image-binding.test.mjs"],
  { stdio: "inherit" },
);
if (policyTests.error) throw policyTests.error;
if (policyTests.status !== 0) process.exit(1);
