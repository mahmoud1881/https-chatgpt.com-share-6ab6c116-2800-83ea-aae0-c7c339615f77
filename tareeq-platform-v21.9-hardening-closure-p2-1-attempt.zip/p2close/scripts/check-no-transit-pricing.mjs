import { readFileSync, readdirSync } from "node:fs";

// Active journey surfaces, source datasets, and the reference sample must not
// acquire fares again. Historical database columns remain for migration safety.
const files = [
  "src/components/TransportSearch.tsx",
  "src/routes/ask.tsx",
  "src/routes/semantic-search.tsx",
  "src/lib/seo/eg-meta.ts",
  "src/lib/seo/cross-country.ts",
  "src/lib/auto-translate.ts",
  "src/lib/dict-es.ts",
  "src/lib/dict-fr.ts",
  "src/lib/dict-pt.ts",
  "src/components/growth/ShareTripCard.tsx",
  "src/routes/budget.tsx",
  "src/lib/route-planner.tsx",
  "src/lib/search/e3-structured-route.server.ts",
  "src/lib/route-planner/import-eg/routes.ts",
  "src/data/trains.ts",
  "src/routes/trains.$slug.tsx",
  "src/components/search/RouteMetaBadges.tsx",
  "src/components/growth/engines/ShareRouteButton.tsx",
  "src/components/growth/engines/VerifyRoutePrompt.tsx",
  "src/routes/planner.tsx",
  "src/routes/route.$routeId.tsx",
  "src/routes/trip.$from.$to.tsx",
  "src/routes/lrt.tsx",
  "src/routes/trains.tsx",
  "src/routes/capital-train.tsx",
  "src/routes/community-routes.tsx",
  "src/routes/admin.routes.$routeId.edit.tsx",
  "src/routes/admin.data-review.tsx",
  "src/routes/shared-route.tsx",
  "src/data/popularPairs.ts",
  "src/data/lrtRealStations.ts",
  "src/components/TrainsResearchSections.tsx",
  "src/lib/route-planner/search.functions.ts",
  "src/lib/route-planner/admin-editor.functions.ts",
  "src/lib/route-verifications.functions.ts",
  "src/lib/growth/share-route.ts",
  "benchmarks/trips/metro-operator.v2.json",
  "public/data/rail-lines.json",
  "public/data/trains.json",
];
function jsonFiles(dir) {
  return readdirSync(dir, { withFileTypes: true }).flatMap((entry) =>
    entry.isDirectory()
      ? jsonFiles(`${dir}/${entry.name}`)
      : entry.name.endsWith(".json")
        ? [`${dir}/${entry.name}`]
        : [],
  );
}
files.push(...jsonFiles("public/data"), ...jsonFiles("benchmarks/trips"));
const prohibited =
  /(?:cheapest|[اأ]رخص|price(?:_|[A-Z]|\b)|fare(?:_|[A-Z]|\b)|estimatedCostEgp|التعريفة|تسعير|الأجرة|الأسعار|السعر(?![اأإىةاني])|التكلفة|جنيه|ج\.م)/i;
const failures = [];
for (const file of new Set(files)) {
  const lines = readFileSync(file, "utf8").split("\n");
  for (let i = 0; i < lines.length; i++) {
    if (prohibited.test(lines[i].replaceAll("سائقو الأجرة", "سائقو النقل")))
      failures.push(`${file}:${i + 1}: ${lines[i].trim().slice(0, 120)}`);
  }
}
if (failures.length) {
  console.error("Trip pricing is disabled; remove these references:\n" + failures.join("\n"));
  process.exit(1);
}
console.log(`No trip pricing in ${new Set(files).size} active surfaces and datasets.`);
