import {readFileSync,existsSync} from 'node:fs';
const files=['src/lib/telemetry.server.ts','src/server.ts','deploy/scripts/incident-evidence.mjs'];for(const f of files)if(!existsSync(f))throw Error(`missing ${f}`);
const t=readFileSync(files[0],'utf8'),s=readFileSync(files[1],'utf8'),i=readFileSync(files[2],'utf8');
for(const x of ['AsyncLocalStorage','traceparent','OTEL_EXPORTER_OTLP_ENDPOINT','/v1/traces','[REDACTED]','OTEL_TRACES_SAMPLER_ARG','x-correlation-id','x-deployment-id'])if(!t.includes(x))throw Error(`telemetry missing ${x}`);
for(const x of ['installFetchTracing','withRequestTrace'])if(!s.includes(x))throw Error(`server tracing missing ${x}`);
if(!i.includes('traceIds'))throw Error('incident evidence is not linked to trace IDs');
console.log('✓ v21.4 gate: W3C propagation, OTLP export, sampling, redaction, outgoing fetch/Supabase tracing, and incident trace linkage are wired.');
