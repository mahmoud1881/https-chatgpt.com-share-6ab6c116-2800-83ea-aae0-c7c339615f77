import fs from 'node:fs';
const files=['e2e/p1-3-state-integrity.e2e.ts','scripts/p1-3-state-integrity-contract.test.mjs','src/components/TransportSearch.tsx','src/hooks/use-async-timeout.ts','src/routes/admin.route-requests.tsx'];
const missing=files.filter(x=>!fs.existsSync(x));
if(missing.length){console.error('P1-3 static gate: FAIL missing '+missing.join(', '));process.exit(2)}
const s=fs.readFileSync(files[0],'utf8');
const scenarios=['double-submit','stale response','refresh and back-forward','session interruption','concurrent mutation'];
for(const x of scenarios) if(!s.includes(x)){console.error('P1-3 static gate: FAIL missing '+x);process.exit(2)}
if(/test\.skip\(/.test(s)){console.error('P1-3 static gate: FAIL silent skip forbidden');process.exit(2)}
console.log(`P1-3 static gate: PASS (${scenarios.length}/${scenarios.length} state-integrity scenarios implemented; runtime execution still required)`);
