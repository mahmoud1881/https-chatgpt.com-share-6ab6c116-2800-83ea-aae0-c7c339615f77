import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { partitionRoutes } from "./quarantine-eg-routes.mjs";

const read = (path) => JSON.parse(readFileSync(new URL("../" + path, import.meta.url), "utf8"));
test("quarantine preserves every original record and original order without choosing a conflict winner", () => {
  const originalBytes = readFileSync(
    new URL("../data-review/routes_master.before-quarantine.json", import.meta.url),
  );
  const original = JSON.parse(originalBytes);
  const archive = read("data-review/eg-route-quarantine.v1.json");
  const active = read("public/data/eg/routes_master.json");
  const stops = new Set(read("public/data/eg/stops_master.json").stops.map((s) => s.stop_id));
  assert.equal(createHash("sha256").update(originalBytes).digest("hex"), archive.sourceSha256);
  const result = partitionRoutes(original.routes, stops);
  assert.deepEqual(result.active, active.routes);
  assert.deepEqual(result.quarantined, archive.quarantined);
  assert.equal(active.count + archive.quarantined.length, original.count);
  const rejected = new Set(archive.quarantined.map((entry) => entry.route.route_id));
  assert.ok(active.routes.every((route) => !rejected.has(route.route_id)));
  assert.deepEqual(partitionRoutes(active.routes, stops), {
    active: active.routes,
    quarantined: [],
  });
});

test("published stop index contains exactly active route memberships", () => {
  const routes = read("public/data/eg/routes_master.json").routes;
  const expected = {};
  for (const { route_id, code, mode, origin, destination, stops } of routes) {
    for (const id of new Set(stops.map((stop) => stop.stop_id))) {
      (expected[id] ??= []).push({ route_id, code, mode, origin, destination });
    }
  }
  assert.deepEqual(read("public/data/eg/stop_routes_index.json"), expected);
});
