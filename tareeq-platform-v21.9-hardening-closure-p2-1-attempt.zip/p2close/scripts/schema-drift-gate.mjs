import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';

const ROOT = resolve(new URL('..', import.meta.url).pathname);
const SNAPSHOT_SQL = resolve(ROOT, 'scripts/schema-fingerprint.sql');
const MANIFEST = resolve(ROOT, 'supabase/migration-integrity.json');
const localDb = process.env.EPHEMERAL_DATABASE_URL || 'postgresql://postgres:postgres@127.0.0.1:54322/postgres';
const targets = [
  ['staging', process.env.STAGING_DATABASE_URL],
  ['production', process.env.PRODUCTION_DATABASE_URL],
];
const sha = (s) => createHash('sha256').update(s).digest('hex');
const migrations = () => readdirSync(resolve(ROOT,'supabase/migrations')).filter(x=>x.endsWith('.sql')).sort();

function psql(db, args, input) {
  const r=spawnSync('psql',[db,'-X','-v','ON_ERROR_STOP=1',...args],{encoding:'utf8',input,env:{...process.env,PGAPPNAME:'tareeq-v20.8-schema-drift-gate'}});
  if(r.error) throw new Error(`psql unavailable: ${r.error.message}`);
  if(r.status!==0) throw new Error((r.stderr||r.stdout||`psql exited ${r.status}`).trim());
  return r.stdout.trim();
}
function fingerprint(db) {
  const json=psql(db,['-qAt','-f',SNAPSHOT_SQL]);
  JSON.parse(json); // fail if warnings/noise corrupt the canonical snapshot
  return { hash:sha(json), json };
}
function ledger(db) {
  const out=psql(db,['-qAt','-c',`select version::text from supabase_migrations.schema_migrations order by version;`]);
  return out ? out.split(/\r?\n/).map(x=>x.trim()).filter(Boolean) : [];
}
function localVersions(){ return migrations().map(x=>x.split('_')[0]); }
function verifyManifest(){
  const m=JSON.parse(readFileSync(MANIFEST,'utf8'));
  const files=migrations(); const expected=Object.keys(m.migrations).sort();
  if(JSON.stringify(files)!==JSON.stringify(expected)) throw new Error('Migration integrity manifest does not match migration filenames. Run: node scripts/update-migration-integrity.mjs after intentionally adding a migration.');
  for(const f of files){ const actual=sha(readFileSync(resolve(ROOT,'supabase/migrations',f))); if(actual!==m.migrations[f]) throw new Error(`Historical migration changed: ${f}. Never rewrite applied migrations; add a new migration instead.`); }
  return files.length;
}
function sameArray(a,b){ return a.length===b.length && a.every((x,i)=>x===b[i]); }

try {
  const count=verifyManifest();
  if(!targets.every(([,url])=>url)) throw new Error('STAGING_DATABASE_URL and PRODUCTION_DATABASE_URL are both required; v20.8 fails closed.');
  const expectedLedger=localVersions();
  const baseline=fingerprint(localDb);
  console.log(`v20.8 baseline: ${count} immutable migrations; schema sha256=${baseline.hash}`);
  const report={format:'tareeq-schema-drift-report-v1',expectedMigrationCount:count,expectedSchemaSha256:baseline.hash,targets:{}};
  for(const [name,url] of targets){
    const remoteLedger=ledger(url);
    if(!sameArray(expectedLedger,remoteLedger)) {
      const missing=expectedLedger.filter(x=>!remoteLedger.includes(x)); const extra=remoteLedger.filter(x=>!expectedLedger.includes(x));
      throw new Error(`${name} migration ledger drift: expected ${expectedLedger.length}, got ${remoteLedger.length}; missing=[${missing.join(',')}], extra=[${extra.join(',')}]`);
    }
    const remote=fingerprint(url); report.targets[name]={migrationCount:remoteLedger.length,schemaSha256:remote.hash,matches:remote.hash===baseline.hash};
    if(remote.hash!==baseline.hash){
      writeFileSync(resolve(ROOT,`artifacts/schema-${name}-actual.json`),remote.json+'\n');
      writeFileSync(resolve(ROOT,'artifacts/schema-expected.json'),baseline.json+'\n');
      throw new Error(`${name} schema drift: expected ${baseline.hash}, got ${remote.hash}. Canonical snapshots written under artifacts/.`);
    }
    console.log(`✓ ${name}: ledger=${remoteLedger.length}, schema=${remote.hash}`);
  }
  report.completedAt=new Date().toISOString();
  writeFileSync(resolve(ROOT,'artifacts/schema-drift-report.json'),JSON.stringify(report,null,2)+'\n');
  console.log('✅ v20.8 production/staging schema drift & migration integrity gate: PASS');
} catch(e){ console.error(`❌ v20.8 FAIL — ${e.message}`); process.exit(1); }
