import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = process.cwd();
const input = path.join(root, 'data-review/eg-route-quarantine.v1.json');
const activePath = path.join(root, 'public/data/eg/routes_master.json');
const outDir = path.join(root, 'artifacts');
const out = path.join(outDir, 'data-review-gate.json');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const fail = msg => { console.error(`FAIL ${msg}`); process.exitCode = 2; };

if (!fs.existsSync(input) || !fs.existsSync(activePath)) {
  console.error('FAIL required route review inputs are missing'); process.exit(2);
}
const archiveBytes = fs.readFileSync(input);
const activeBytes = fs.readFileSync(activePath);
const doc = JSON.parse(archiveBytes);
const activeDoc = JSON.parse(activeBytes);
const rows = Array.isArray(doc.quarantined) ? doc.quarantined : [];
const active = Array.isArray(activeDoc.routes) ? activeDoc.routes : [];
const activeIds = new Set(active.map(r => r.route_id));
const byStatus = {}, byReason = {};
for (const row of rows) {
  const status = row.reviewStatus || 'missing'; byStatus[status] = (byStatus[status] || 0) + 1;
  for (const reason of row.reasons || ['missing_reason']) byReason[reason] = (byReason[reason] || 0) + 1;
}
const pending = rows.filter(r => !['approved','rejected'].includes(r.reviewStatus));
const invalidReviewed = rows.filter(r => ['approved','rejected'].includes(r.reviewStatus) && !(r.reviewedBy && r.reviewedAt && r.reviewEvidence));
// Pending factual review is not a release blocker when the disputed record is provably excluded
// from the published dataset. We never guess which conflicting transport record is correct.
const leakedQuarantined = rows.filter(r => activeIds.has(r.route?.route_id));
const activeHasDuplicateIds = active.length !== activeIds.size;
const countInvariant = Number(doc.activeCount) === active.length && Number(doc.sourceCount) === active.length + rows.length;
const releaseReady = leakedQuarantined.length === 0 && !activeHasDuplicateIds && countInvariant && invalidReviewed.length === 0;
const report = {
  generatedAt: new Date().toISOString(), sourceSha256: sha(archiveBytes), activeSha256: sha(activeBytes),
  total: rows.length, pendingIndependentReview: pending.length, invalidReviewed: invalidReviewed.length,
  quarantinedLeakedIntoPublishedData: leakedQuarantined.length, activeHasDuplicateIds, countInvariant,
  byStatus, byReason, releaseReady,
  policy: 'Unresolved conflicting records remain preserved for independent review but are excluded from published production data; release never selects a factual winner without evidence.'
};
fs.mkdirSync(outDir,{recursive:true}); fs.writeFileSync(out, JSON.stringify(report,null,2)+'\n');
console.log(`Data review gate: ${rows.length} quarantined; ${pending.length} awaiting independent review; ${leakedQuarantined.length} leaked into active data`);
console.log(`Evidence: ${path.relative(root,out)}`);
if (leakedQuarantined.length) fail('quarantined route IDs are present in published data');
if (activeHasDuplicateIds) fail('published routes contain duplicate route IDs');
if (!countInvariant) fail('source/active/quarantine count invariant is broken');
if (invalidReviewed.length) fail('reviewed records lack reviewer/evidence metadata');
if (process.exitCode) process.exit(process.exitCode);
console.log('Data review gate: PASS (pending records are safely excluded, not guessed)');
