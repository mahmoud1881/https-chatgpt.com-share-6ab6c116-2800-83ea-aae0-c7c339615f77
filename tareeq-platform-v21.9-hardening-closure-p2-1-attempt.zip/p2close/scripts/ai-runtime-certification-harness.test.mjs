import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {runAICertificationHarness,HARNESS_MODE,FORBIDDEN_HARNESS_CAPABILITIES} from './ai-runtime-certification-harness.mjs';

test('AI harness is certification-only and cannot grant runtime certification',()=>{
 const r=runAICertificationHarness();
 assert.equal(HARNESS_MODE,'CERTIFICATION_ONLY'); assert.equal(r.productionTraffic,false); assert.equal(r.runtimeCertificationGranted,false); assert.equal(r.passed,true);
});
test('failure injection covers provider, evidence, budget and malicious truth writes',()=>{
 const r=runAICertificationHarness(); const ids=new Set(r.results.map(x=>x.id));
 for(const id of ['jev-timeout','jev-malformed','gpt-timeout','gpt-unsupported-claim','gemini-disagreement','provider-outage','rate-limit','budget-exceeded','stale-evidence','malicious-truth-write']) assert.ok(ids.has(id));
});
test('harness forbidden capabilities include truth, production evidence and authorization bypass',()=>{
 for(const c of ['truth:verified-pass','incident:close','evidence:mutate-production','authorization:bypass','deployment:approve']) assert.ok(FORBIDDEN_HARNESS_CAPABILITIES.includes(c));
});
test('production AI runtime does not import certification harness',()=>{
 for(const p of ['src/lib/ai-runtime/runtime.ts','src/lib/ai-runtime/router.ts','src/lib/ai-runtime/providers.ts']) assert.ok(!fs.readFileSync(p,'utf8').includes('certification-harness'));
});
test('synthetic PASS remains distinct from runtime observations',()=>{
 const r=runAICertificationHarness(); assert.equal(r.synthetic,true); assert.equal(r.invariants.authoritative_truth_write,0);
 const runtime=JSON.parse(fs.readFileSync('artifacts/control-plane/ai-runtime-runtime-certification.json','utf8'));
 for(const v of Object.values(runtime.runtime)){assert.equal(v.executed,false);assert.equal(v.observed,null);assert.equal(v.passed,null);}
});
