import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const s=fs.readFileSync('deploy/scripts/ai-journey-runtime-gateway.mjs','utf8');
const r=fs.readFileSync('scripts/ai-full-platform-journey-certification.mjs','utf8');
const m=fs.readFileSync('supabase/migrations/20260925000200_ai_certification_journey_hardening.sql','utf8');
test('device trust uses nonce + asymmetric attestation + replay/run binding',()=>{assert.match(s,/location-challenge/);assert.match(s,/crypto\.verify/);assert.match(s,/replayed_device_attestation/);assert.match(s,/attestation_run_binding_mismatch/);assert.doesNotMatch(s,/createHmac/)});
test('production-like certification forbids public OSRM and Overpass',()=>{assert.match(s,/public_osrm_forbidden_in_production/);assert.match(s,/public_overpass_forbidden_in_production/);assert.match(s,/PRODUCTION_LIKE/)});
test('journey persistence uses least-privilege RPC and no service role',()=>{assert.match(s,/record_ai_certification_journey/);assert.match(s,/TAREEQ_JOURNEY_EVIDENCE_RPC_TOKEN/);assert.doesNotMatch(s,/SUPABASE_SERVICE_ROLE_KEY/);assert.match(m,/SECURITY DEFINER/);assert.match(m,/REVOKE ALL ON FUNCTION/)});
test('journey evidence is bound to full execution identity and digest',()=>{for(const x of ['release_id','commit_sha','environment_id','config_hash','evidence_digest']){assert.match(s,new RegExp(x));assert.match(m,new RegExp(x))}assert.match(m,/UNIQUE INDEX/)});
test('full journey runner remains fail closed and P2-1 independent',()=>{assert.match(r,/RUNTIME_PENDING/);assert.match(r,/accepted:false/);assert.match(r,/p2_1:'NOT_CERTIFIED'/);assert.match(r,/status!==['"]LIVE/)});
