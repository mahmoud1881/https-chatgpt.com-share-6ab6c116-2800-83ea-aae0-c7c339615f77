import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { createHash } from "node:crypto";

export function partitionRoutes(routes, stopIds) {
  const counts = new Map();
  for (const route of routes) counts.set(route.route_id, (counts.get(route.route_id) ?? 0) + 1);
  const active = [],
    quarantined = [];
  routes.forEach((route, sourceIndex) => {
    const reasons = [];
    if (counts.get(route.route_id) > 1) reasons.push("duplicate_route_id");
    if (route.stops.some((stop) => !stopIds.has(stop.stop_id)))
      reasons.push("unknown_stop_reference");
    if (route.stop_count !== route.stops.length) reasons.push("stop_count_mismatch");
    if (reasons.length) quarantined.push({ sourceIndex, reasons, reviewStatus: "pending", route });
    else active.push(route);
  });
  return { active, quarantined };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const root = fileURLToPath(new URL("../", import.meta.url));
  const data = resolve(root, "public/data/eg");
  const raw = readFileSync(resolve(data, "routes_master.json"), "utf8");
  const original = JSON.parse(raw);
  const stops = JSON.parse(readFileSync(resolve(data, "stops_master.json"), "utf8")).stops;
  const { active, quarantined } = partitionRoutes(
    original.routes,
    new Set(stops.map((s) => s.stop_id)),
  );
  console.log(
    JSON.stringify({
      active: active.length,
      quarantined: quarantined.length,
      write: process.argv.includes("--write"),
    }),
  );
  if (process.argv.includes("--write") && quarantined.length) {
    const reviewDir = resolve(root, "data-review");
    const archive = resolve(reviewDir, "eg-route-quarantine.v1.json");
    if (existsSync(archive))
      throw new Error("Review archive already exists; refusing to overwrite evidence");
    mkdirSync(reviewDir, { recursive: true });
    const sourceSha256 = createHash("sha256").update(raw).digest("hex");
    // Preserve exact source bytes before changing the published dataset.
    writeFileSync(resolve(reviewDir, "routes_master.before-quarantine.json"), raw, { flag: "wx" });
    writeFileSync(
      archive,
      JSON.stringify(
        {
          schemaVersion: 1,
          sourceSha256,
          sourceCount: original.routes.length,
          activeCount: active.length,
          quarantined,
        },
        null,
        2,
      ) + "\n",
      { flag: "wx" },
    );
    writeFileSync(
      resolve(data, "routes_master.json"),
      JSON.stringify({ ...original, count: active.length, routes: active }, null, 2) + "\n",
    );
    const index = {};
    for (const route of active) {
      const { route_id, code, mode, origin, destination } = route;
      for (const id of new Set(route.stops.map((stop) => stop.stop_id))) {
        (index[id] ??= []).push({ route_id, code, mode, origin, destination });
      }
    }
    writeFileSync(resolve(data, "stop_routes_index.json"), JSON.stringify(index, null, 2) + "\n");
  }
}
