import {readFileSync,existsSync} from 'node:fs';
const files=['scripts/zero-downtime-deploy.mjs','deploy/zero-downtime.json','deploy/scripts/zero-downtime-hook.sh'];for(const f of files)if(!existsSync(f))throw new Error(`missing ${f}`);
const s=readFileSync('scripts/zero-downtime-deploy.mjs','utf8');
for(const x of ['compatibilityOld','compatibilityNew','syntheticGreen','progressiveDelivery','restoreOldTraffic','databaseRollbackAttempted:false','rollForwardDatabase'])if(!s.includes(x))throw new Error(`v21.0 invariant missing: ${x}`);
if(/rollback[^\n]{0,30}(migration|database)/i.test(s.replace('databaseRollbackAttempted:false',''))) throw new Error('database rollback path detected');
console.log('✓ v21.0 static gate: expand/deploy/contract + dual compatibility + canary + synthetic + app traffic recovery + DB roll-forward invariant present.');
