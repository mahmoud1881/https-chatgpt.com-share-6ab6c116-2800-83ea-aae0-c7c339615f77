export const CORE_ONLY=new Set(['truth:verified-pass','incident:close','evidence:mutate-history','audit:rewrite','certification:force-pass']);
export function authenticatePrincipal(p={}){
 const valid=!!p.id&&['USER','SERVICE','EXTENSION'].includes(p.type)&&Array.isArray(p.roles)&&Array.isArray(p.scopes)&&!!p.environment&&p.revoked!==true&&(!p.authentication_context?.expires_at||Date.parse(p.authentication_context.expires_at)>Date.now());
 return Object.freeze({valid,principal:valid?Object.freeze(structuredClone(p)):null});
}
export function authorize({principal,scope,environment,resource_owner_id=null}){
 const a=authenticatePrincipal(principal); let reason='ALLOW';
 if(!a.valid) reason='INVALID_PRINCIPAL';
 else if(CORE_ONLY.has(scope)) reason='CORE_ONLY_DERIVED_STATE';
 else if(environment&&principal.environment!==environment) reason='ENVIRONMENT_MISMATCH';
 else if(!principal.scopes.includes(scope)) reason='MISSING_SCOPE';
 else if(principal.type==='SERVICE'&&resource_owner_id&&principal.id!==resource_owner_id&&scope==='identity:impersonate') reason='IMPERSONATION_DENIED';
 return Object.freeze({decision:reason==='ALLOW'?'ALLOW':'DENY',reason,principal_id:principal?.id||null,scope,environment:environment||null,at:new Date().toISOString()});
}
export function approveOverride({requester,approver,environment='production',critical=false}){
 if(!requester?.id||!approver?.id) return Object.freeze({decision:'DENY',reason:'AUTHENTICATED_PRINCIPALS_REQUIRED'});
 if(requester.id===approver.id) return Object.freeze({decision:'DENY',reason:'SEPARATION_OF_DUTIES'});
 const a=authorize({principal:approver,scope:'override:approve',environment}); if(a.decision!=='ALLOW') return a;
 if(critical&&!approver.roles.includes('SECURITY_APPROVER')) return Object.freeze({...a,decision:'DENY',reason:'SECURITY_APPROVER_REQUIRED'});
 return Object.freeze({...a,reason:'APPROVED'});
}
export function authorizeDeploymentProposal({principal,target_environment}){
 const scope=target_environment==='production'?'deployment:production':'deployment:staging';
 return authorize({principal,scope,environment:target_environment});
}
