import crypto from 'node:crypto';
export const CONTROL_PLANE_API='control-plane/v1';
export const EXTENSION_TYPES=Object.freeze(['Policy','SignalProvider','EvidenceProvider','Verifier','RemediationAdapter','DeploymentAdapter']);
const FORBIDDEN=new Set(['writeVerifiedPass','writeClosed','deleteIncident','mutateEvidence','rewriteAudit','requestDeploymentAction','executeDeployment']);
const sha=v=>crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');
export function validateManifest(m={}){
 const errors=[];
 for(const k of ['id','version','type','api_version','entrypoint']) if(!m[k]) errors.push(`MISSING:${k}`);
 if(m.api_version!==CONTROL_PLANE_API) errors.push('INCOMPATIBLE_API');
 if(!EXTENSION_TYPES.includes(m.type)) errors.push('INVALID_TYPE');
 const caps=Array.isArray(m.capabilities)?m.capabilities:[];
 if(caps.some(c=>FORBIDDEN.has(c))) errors.push('FORBIDDEN_CAPABILITY');
 const perms=Array.isArray(m.permissions)?m.permissions:[];
 if(perms.includes('*')||perms.includes('core:truth:write')||perms.includes('evidence:history:write')) errors.push('FORBIDDEN_PERMISSION');
 if(!Number.isInteger(m.timeout_ms)||m.timeout_ms<1||m.timeout_ms>300000) errors.push('INVALID_TIMEOUT');
 if(!m.resources||!Number.isFinite(m.resources.memory_mb)||m.resources.memory_mb<=0||m.resources.memory_mb>2048) errors.push('INVALID_RESOURCE_LIMIT');
 if(!m.failure_semantics||!['fail-closed','advisory'].includes(m.failure_semantics)) errors.push('INVALID_FAILURE_SEMANTICS');
 if(!m.isolation||!['process','container','sandbox'].includes(m.isolation)) errors.push('INVALID_ISOLATION');
 if(!Array.isArray(m.evidence_requirements)) errors.push('MISSING_EVIDENCE_REQUIREMENTS');
 return Object.freeze({valid:errors.length===0,errors});
}
export function createExtensionRegistry(){
 const records=new Map();
 return Object.freeze({
  register(manifest,{nonRegressionPassed=false}={}){
   const v=validateManifest(manifest); if(!v.valid) return {status:'REJECTED',reasons:v.errors};
   if(!nonRegressionPassed) return {status:'REJECTED',reasons:['CONTROL_PLANE_NON_REGRESSION_REQUIRED']};
   const key=`${manifest.id}@${manifest.version}`; if(records.has(key)) return {status:'REJECTED',reasons:['DUPLICATE_EXTENSION']};
   const frozen=Object.freeze({...manifest,manifest_hash:sha(manifest),registered_at:new Date().toISOString()}); records.set(key,frozen);
   return {status:'REGISTERED',extension:frozen};
  },
  get(id,version){return records.get(`${id}@${version}`)||null;},
  list(){return [...records.values()];}
 });
}
export function createExtensionContext(manifest,sinks={}){
 const allowed=new Set(manifest.capabilities||[]);
 const need=cap=>{if(!allowed.has(cap)) throw new Error(`CAPABILITY_DENIED:${cap}`)};
 return Object.freeze({
  emitSignal(v){need('emitSignal'); return sinks.emitSignal?.(Object.freeze({...v,extension_id:manifest.id}))},
  submitEvidence(v){need('submitEvidence'); return sinks.submitEvidence?.(Object.freeze({...v,extension_id:manifest.id}))},
  submitVerificationObservation(v){need('submitVerificationObservation'); return sinks.submitVerificationObservation?.(Object.freeze({...v,extension_id:manifest.id}))},
  proposeRemediation(v){need('proposeRemediation'); return sinks.proposeRemediation?.(Object.freeze({...v,extension_id:manifest.id}))},
  proposeDeployment(v){need('proposeDeployment'); if(!manifest.permissions?.includes('deployment:propose')) throw new Error('PERMISSION_DENIED:deployment:propose'); return sinks.proposeDeployment?.(Object.freeze({...v,extension_id:manifest.id,status:'PROPOSED'}))}
 });
}
