import { existsSync, readFileSync } from 'node:fs';
const files=['deploy/scripts/supply-chain-attestation.mjs','deploy/scripts/full-production-certification.mjs'];for(const f of files)if(!existsSync(f))throw Error(`${f} missing`);
const s=readFileSync(files[0],'utf8'), c=readFileSync(files[1],'utf8');
for(const token of ['syft','spdx-json','cyclonedx-json','grype','gitleaks','crane','cosign','RELEASE_IMAGE_REF','RELEASE_IMAGE_DIGEST','oci-image-sign','oci-provenance-attest','slsa.dev/provenance','published-image-digest'])if(!s.includes(token))throw Error(`v21.9 supply-chain invariant missing: ${token}`);
for(const token of ['supply-chain-attestation.mjs','supplyChain','release-sbom.spdx.json','release-provenance.json'])if(!c.includes(token))throw Error(`v21.9 certification binding missing: ${token}`);
console.log('✅ v21.9 certification reproducibility & supply-chain static gate: PASS');
