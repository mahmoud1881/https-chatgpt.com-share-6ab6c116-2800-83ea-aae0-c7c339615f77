import { readFileSync } from "node:fs";

const reference = JSON.parse(readFileSync("benchmarks/trips/metro-operator.v2.json", "utf8"));
const now = new Date();
const NETWORK_DAYS = 30;
let stale = 0;
for (const c of reference.cases) {
  const checked = new Date(`${c.network_source_reviewed_at}T00:00:00Z`);
  const ageDays = (now - checked) / 86_400_000;
  if (Number.isNaN(ageDays) || ageDays < -1 || ageDays > NETWORK_DAYS) {
    console.error(`STALE network ${c.id}: ${c.network_source_reviewed_at}`);
    stale++;
  }
}
if (stale) process.exit(1);
console.log(
  `Current operator-source dates: ${reference.cases.length} station-level references; network ≤${NETWORK_DAYS} days.`,
);
