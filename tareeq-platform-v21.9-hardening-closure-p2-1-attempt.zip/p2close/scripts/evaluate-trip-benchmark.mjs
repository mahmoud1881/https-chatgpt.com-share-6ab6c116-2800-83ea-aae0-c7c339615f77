import { readFileSync } from "node:fs";
import { validateBenchmark } from "./trip-benchmark-validation.mjs";

const casesPath = process.argv[2] ?? "benchmarks/trips/core-eg.v1.json";
const observationsPath = process.argv[3] ?? "benchmarks/trips/observations.example.json";
const cases = JSON.parse(readFileSync(casesPath, "utf8"));
const observations = JSON.parse(readFileSync(observationsPath, "utf8"));
const validationErrors = validateBenchmark(cases, observations);
if (validationErrors.length) {
  console.error("FAIL: benchmark not certified:\n" + validationErrors.join("\n"));
  process.exit(1);
}
observations.cases = observations.cases.map((o) => ({
  ...o,
  verdict: ["search", "planner"].every((s) => o[s].verdict === "pass") ? "pass" : "fail",
  unsafe_or_fabricated: ["search", "planner"].some((s) => o[s].unsafe_or_fabricated),
  reference_evidence: cases.cases.find((c) => c.id === o.id).review.evidence,
  actual_evidence: o.search.actual_evidence + "\n" + o.planner.actual_evidence,
  observed_instructions: o.search.observed_instructions + "\n" + o.planner.observed_instructions,
}));
if (
  !observations.environment ||
  observations.environment.includes("required") ||
  !observations.captured_at ||
  !observations.deployed_commit
) {
  console.error(
    "FAIL: record the staging environment, deployed commit and capture time before scoring.",
  );
  process.exit(1);
}

if (cases.cases.length !== cases.acceptance.minimum_reviewed) {
  throw new Error("Benchmark case count differs from the frozen acceptance minimum.");
}
const ids = cases.cases.map((c) => c.id);
if (new Set(ids).size !== ids.length) throw new Error("Duplicate benchmark case IDs.");
const byId = new Map(observations.cases.map((c) => [c.id, c]));
if (
  byId.size !== observations.cases.length ||
  observations.cases.some((c) => !ids.includes(c.id))
) {
  throw new Error("Observation IDs are duplicated or absent from the benchmark.");
}

let passed = 0;
let unsafe = 0;
let incomplete = 0;
const categoryStats = new Map();
for (const c of cases.cases) {
  const o = byId.get(c.id);
  const complete =
    o &&
    ["pass", "fail"].includes(o.verdict) &&
    typeof o.unsafe_or_fabricated === "boolean" &&
    [
      "reviewer",
      "reviewed_at",
      "reference_evidence",
      "actual_evidence",
      "observed_instructions",
    ].every((field) => typeof o[field] === "string" && o[field].trim().length > 0);
  if (!complete) {
    incomplete++;
    console.log(`PENDING ${c.id}: ${c.from_query} → ${c.to_query}`);
    continue;
  }
  const stat = categoryStats.get(c.category) ?? { passed: 0, total: 0 };
  stat.total++;
  if (o.verdict === "pass") {
    passed++;
    stat.passed++;
  }
  if (o.unsafe_or_fabricated) unsafe++;
  categoryStats.set(c.category, stat);
  console.log(
    `${o.verdict.toUpperCase()} ${c.id}: ${c.from_query} → ${c.to_query}${o.unsafe_or_fabricated ? " [UNSAFE/FABRICATED]" : ""}`,
  );
}

const total = cases.cases.length;
const rate = passed / total;
console.log(
  `\nReviewed ${total - incomplete}/${total}; pass ${passed}/${total} (${(rate * 100).toFixed(1)}%); unsafe/fabricated ${unsafe}`,
);
for (const [category, stat] of categoryStats) {
  console.log(`  ${category}: ${stat.passed}/${stat.total}`);
}
if (
  incomplete ||
  rate < cases.acceptance.min_pass_rate ||
  unsafe > cases.acceptance.max_unsafe_or_fabricated
) {
  console.error("FAIL: acceptance threshold not met or independent review incomplete.");
  process.exit(1);
}
console.log("PASS: benchmark acceptance threshold met for this reviewed observation set.");
