import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = p => fs.readFileSync(p,'utf8');

test('AI runtime layers exist in required order', () => {
  const router=read('src/lib/ai-runtime/router.ts');
  for (const x of ['DETERMINISTIC','LOCAL','JEV','GPT_OSS_120B','GEMINI_3_8']) assert.ok(router.includes(x));
});

test('providers are observation-only and core truth is not provider permission', () => {
  const providers=read('src/lib/ai-runtime/providers.ts');
  const contracts=read('src/lib/ai-runtime/contracts.ts');
  assert.ok(providers.includes('observations only'));
  assert.ok(contracts.includes('VERIFIED_PASS'));
  assert.ok(!providers.includes('incident:close'));
});

test('high risk and conflicts escalate to Gemini verification lane', () => {
  const router=read('src/lib/ai-runtime/router.ts');
  assert.match(router,/CRITICAL.*semanticConflict.*GEMINI_3_8/s);
});

test('cost governor has hard cap', () => {
  const cost=read('src/lib/ai-runtime/cost-governor.ts');
  assert.ok(cost.includes('monthlyHardCapUsd'));
  assert.ok(cost.includes('canSpend'));
});

test('verified evidence cannot be empty', () => {
  const evidence=read('src/lib/ai-runtime/evidence.ts');
  assert.ok(evidence.includes('evidenceRefs.length === 0'));
});
