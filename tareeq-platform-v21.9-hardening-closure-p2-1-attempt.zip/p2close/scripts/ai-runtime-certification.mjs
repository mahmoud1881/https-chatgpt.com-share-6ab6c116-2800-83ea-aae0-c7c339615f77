import fs from 'node:fs';
import { execFileSync } from 'node:child_process';
const out='artifacts/control-plane/ai-runtime-certification.json';
let localPass=false, error=null;
try { execFileSync(process.execPath,['--test','scripts/ai-runtime-architecture.test.mjs'],{stdio:'inherit'}); localPass=true; } catch(e) { error=String(e?.message||e); }
const artifact={
  stage:'AI_RUNTIME_V1',
  architecture:'DETERMINISTIC -> LOCAL -> JEV -> GPT_OSS_120B -> GEMINI_3_8 -> CONTROL_PLANE',
  local_contracts:{executed:true,observed:localPass?'PASS':'FAIL',passed:localPass},
  runtime:{
    local_device_ai:{executed:false,observed:null,passed:null},
    jev:{executed:false,observed:null,passed:null},
    gpt_oss_120b:{executed:false,observed:null,passed:null},
    gemini_3_8:{executed:false,observed:null,passed:null},
    end_to_end_evidence:{executed:false,observed:null,passed:null}
  },
  invariants:{unsupported_claim_as_verified:{required:0,observed:null,passed:null},provider_bypass:{required:0,observed:null,passed:null},unauthorized_execution:{required:0,observed:null,passed:null},budget_bypass:{required:0,observed:null,passed:null}},
  accepted:false,
  status:localPass?'RUNTIME_PENDING':'LOCAL_CONTRACT_FAIL',
  error
};
fs.writeFileSync(out,JSON.stringify(artifact,null,2)+'\n');
console.log(`AI runtime certification: ${artifact.status} -> ${out}`);
if(!localPass) process.exit(1);
