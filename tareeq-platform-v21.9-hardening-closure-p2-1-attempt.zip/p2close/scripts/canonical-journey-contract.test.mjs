import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
const canonical=fs.readFileSync('src/lib/journey/canonical.ts','utf8');
const planner=fs.readFileSync('src/routes/planner.tsx','utf8');
const explore=fs.readFileSync('src/routes/explore.tsx','utf8');
test('planner and explore both consume canonical orchestrator',()=>{ assert.match(planner,/useServerFn\(searchCanonicalJourney\)/); assert.match(explore,/useServerFn\(searchCanonicalJourney\)/); });
test('explore no longer uses graph shortest path for journey decision',()=>{ const ai=explore.slice(explore.indexOf('const onAiSearch')); assert.doesNotMatch(ai,/engines\.findShortestPath/); });
test('canonical trust is fail closed and mixed is not verified/actionable',()=>{ assert.match(canonical,/trust==="verified"/); assert.match(canonical,/actionable:trust==="verified"/); assert.match(canonical,/return "mixed"/); });
