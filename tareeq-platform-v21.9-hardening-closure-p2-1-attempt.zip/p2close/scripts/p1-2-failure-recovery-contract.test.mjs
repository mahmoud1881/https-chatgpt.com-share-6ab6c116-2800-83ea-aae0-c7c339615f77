import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const hook=fs.readFileSync('src/hooks/use-async-timeout.ts','utf8');
const asyncState=fs.readFileSync('src/components/shared/AsyncState.tsx','utf8');
const admin=fs.readFileSync('src/integrations/supabase/verify-admin-session.server.ts','utf8');

test('async loader is bounded, abortable, and retryable',()=>{
  assert.match(hook,/timeoutMs\s*=\s*15_000/);
  assert.match(hook,/new AbortController\(\)/);
  assert.match(hook,/controller\.abort\(\)/);
  assert.match(hook,/const retry = useCallback/);
  assert.match(hook,/"timeout"/);
});

test('async failure UI exposes error, empty, timeout and recovery states',()=>{
  for(const token of ['error','empty','timeout','إعادة المحاولة']) assert.ok(asyncState.includes(token),`missing ${token}`);
});

test('authorization backend fails closed on auth or role dependency failure',()=>{
  assert.match(admin,/if \(userError \|\| !user\)/);
  assert.match(admin,/if \(!hasRole\)/);
  assert.match(admin,/catch \(error\)/);
  assert.match(admin,/throw jsonError\(403/);
});

test('P1-2 E2E suite requires explicit failure injection rather than silent skip',()=>{
  const e2e=fs.readFileSync('e2e/p1-2-failure-recovery.e2e.ts','utf8');
  assert.match(e2e,/P1_FAILURE_PROXY_URL/);
  assert.match(e2e,/prerequisite missing/);
  assert.doesNotMatch(e2e,/test\.skip\(/);
});
