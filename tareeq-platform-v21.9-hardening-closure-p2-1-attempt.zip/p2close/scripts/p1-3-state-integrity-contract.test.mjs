import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const transport=fs.readFileSync('src/components/TransportSearch.tsx','utf8');
const asyncHook=fs.readFileSync('src/hooks/use-async-timeout.ts','utf8');
const admin=fs.readFileSync('src/routes/admin.route-requests.tsx','utf8');
const e2e=fs.readFileSync('e2e/p1-3-state-integrity.e2e.ts','utf8');

test('journey search rejects stale async responses',()=>{
  assert.match(transport,/reqIdRef\s*=\s*useRef\(0\)/);
  assert.match(transport,/const myReq = \+\+reqIdRef\.current/);
  assert.match(transport,/reqIdRef\.current === myReq/);
});

test('generic async loader aborts superseded or unmounted attempts',()=>{
  assert.match(asyncHook,/attemptRef\s*=\s*useRef\(0\)/);
  assert.match(asyncHook,/attemptRef\.current !== attempt/);
  assert.match(asyncHook,/controller\.abort\(\)/);
});

test('admin moderation closes synchronous double-submit window',()=>{
  assert.match(admin,/mutationLockRef\s*=\s*useRef\(false\)/);
  assert.match(admin,/if \(mutationLockRef\.current\) return/);
  assert.match(admin,/mutationLockRef\.current = true/);
  assert.match(admin,/onSettled:[\s\S]*mutationLockRef\.current = false/);
  assert.match(admin,/disabled=\{busy\}/);
});

test('P1-3 E2E is fail-closed and covers state-integrity classes',()=>{
  assert.match(e2e,/P1_STATE_PROXY_URL/);
  assert.match(e2e,/prerequisite missing/);
  assert.doesNotMatch(e2e,/test\.skip\(/);
  for(const token of ['double-submit','stale response','refresh and back-forward','session interruption','concurrent mutation']) assert.ok(e2e.includes(token),`missing ${token}`);
});
