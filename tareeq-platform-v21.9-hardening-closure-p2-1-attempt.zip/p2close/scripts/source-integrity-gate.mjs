import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const roots=['src','scripts','deploy'].map(x=>path.join(root,x)).filter(fs.existsSync);
const exts=['.ts','.tsx','.js','.jsx','.mjs','.cjs','.json'];
const files=[];
const walk=d=>{for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);e.isDirectory()?walk(p):files.push(p)}};
roots.forEach(walk);
const code=files.filter(f=>/\.(?:[cm]?[jt]sx?)$/.test(f));
const failures=[];
function resolves(from,spec){
 spec=spec.split('?')[0].split('#')[0];
 if(!spec.startsWith('.')&&!spec.startsWith('@/')) return true;
 let base=spec.startsWith('@/')?path.join(root,'src',spec.slice(2)):path.resolve(path.dirname(from),spec);
 const candidates=[base,...exts.map(e=>base+e),...exts.map(e=>path.join(base,'index'+e))];
 return candidates.some(p=>fs.existsSync(p));
}
for(const f of code){
 const t=fs.readFileSync(f,'utf8');
 const re=/(?:import\s+(?:[^'\"]+?\s+from\s+)?|export\s+[^'\"]*?\s+from\s+|import\s*\()\s*['\"]([^'\"]+)['\"]/g;
 for(const m of t.matchAll(re)) if(!resolves(f,m[1])) failures.push(`${path.relative(root,f)}: unresolved local import ${m[1]}`);
 if(/process\.env\.VITE_(?:SUPABASE_SERVICE_ROLE_KEY|DATABASE_URL|PRODUCTION_DATABASE_URL|STAGING_DATABASE_URL)/.test(t)) failures.push(`${path.relative(root,f)}: privileged VITE_* secret reference`);
}
console.log(`Source integrity gate: scanned ${code.length} code files`);
if(failures.length){for(const f of failures) console.error(`FAIL ${f}`); process.exit(2)}
console.log('Source integrity gate: PASS');
