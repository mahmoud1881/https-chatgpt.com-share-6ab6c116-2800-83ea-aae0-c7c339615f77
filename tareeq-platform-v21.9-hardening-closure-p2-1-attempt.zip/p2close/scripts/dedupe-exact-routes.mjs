// Only identical records are removable without making a transit-data judgment.
import { readFileSync, writeFileSync } from "node:fs";
const path = "public/data/eg/routes_master.json";
const data = JSON.parse(readFileSync(path, "utf8"));
function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.keys(value)
        .sort()
        .map((k) => [k, canonical(value[k])]),
    );
  }
  return value;
}
const seen = new Set();
const routes = data.routes.filter((route) => {
  const key = JSON.stringify(canonical(route));
  if (seen.has(key)) return false;
  seen.add(key);
  return true;
});
const counts = new Map();
for (const route of routes) counts.set(route.route_id, (counts.get(route.route_id) ?? 0) + 1);
const conflicts = [...counts].filter(([, count]) => count > 1);
console.log(
  JSON.stringify({
    before: data.routes.length,
    after: routes.length,
    exactDuplicatesRemoved: data.routes.length - routes.length,
    unresolvedIdGroups: conflicts.length,
  }),
);
if (process.argv.includes("--write")) {
  data.routes = routes;
  data.count = routes.length;
  writeFileSync(path, JSON.stringify(data, null, 2) + "\n");
}
