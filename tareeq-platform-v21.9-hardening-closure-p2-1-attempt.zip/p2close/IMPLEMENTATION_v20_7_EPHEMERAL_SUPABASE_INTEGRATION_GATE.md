# v20.7 — Ephemeral Supabase Integration Gate

## Implemented
- Added `security:db:integration`, a fail-closed release gate that requires Docker, Supabase CLI, and `psql`.
- The gate destroys stale local DB state, starts a fresh local Supabase database, replays the complete migration ledger, verifies the applied migration count, executes catalog authorization audits and the runtime authorization matrix, then destroys the ephemeral DB again.
- `release:gate` now requires this runtime database proof before application release checks. Missing Docker/Supabase CLI/psql is a release failure, not a skipped check.
- CI's existing from-scratch Supabase migration job now executes the same v20.7 ledger proof and database authorization proof.
- Fixed the v20.6 proof fixture so disposable admin/user role rows have real `auth.users` parents and therefore satisfy the production FK.
- Expanded negative proof: `anon` cannot execute `has_role`; an ordinary authenticated identity resolves non-admin; the disposable admin resolves admin through the canonical `has_role(auth.uid(),'admin')`; even that admin cannot directly read `user_roles`; `service_role` can access the protected role table.

## Mandatory release command
```sh
bun run release:gate
```

A release environment must have Docker, Supabase CLI, `psql`, Bun and project dependencies. The database integration stage intentionally fails closed if any required runtime is absent.

## Proof semantics
A green v20.7 gate means the repository's migration history replayed from empty in local Supabase and the deployed PostgreSQL catalog passed the authorization/RLS proof. It does not claim that an unrelated remote production database has the same schema; production drift should be checked separately before rollout.
