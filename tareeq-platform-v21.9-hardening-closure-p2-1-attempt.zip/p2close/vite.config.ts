// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - tanstackStart, viteReact, tailwindcss, tsConfigPaths, nitro (build-only using cloudflare as a default target),
//     componentTagger (dev-only), VITE_* env injection, @ path alias, React/TanStack dedupe,
//     error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

export default defineConfig({
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
  // Explicit output dir — @lovable.dev/vite-tanstack-config only rewrites nitro's
  // output to dist/ when running inside a Lovable sandbox (isSandbox). Any build
  // outside the sandbox (self-host CI, `deploy/app/Dockerfile`, local `bun run build`)
  // falls back to nitro's own default (`.output/`), which deploy/app/Dockerfile and
  // deploy/app/server.mjs do NOT know about (both hardcode `dist/`). Setting this
  // explicitly makes the output location consistent in every environment.
  nitro: {
    output: {
      dir: "dist",
      serverDir: "dist/server",
      publicDir: "dist/client",
    },
  },
  vite: {
    build: {
      rollupOptions: {
        output: {
          // فصل المكتبات الثقيلة في Chunks مستقلة تُحمَّل كسولاً في المتصفح فقط.
          // نستخدم صيغة الدالة لأن هذه المكتبات externals في بناء SSR،
          // فمحاولة إدراجها في manualChunks هناك تُفشل البناء.
          manualChunks(id) {
            if (id.includes("node_modules/@huggingface/transformers")) return "ai-transformers";
            if (id.includes("node_modules/@mlc-ai/web-llm")) return "web-llm-core";
            if (id.includes("node_modules/maplibre-gl")) return "map-renderers";
            // Everything below is a genuinely shared, slow-changing vendor
            // cluster used across most routes — splitting it out of the
            // single ~840KB "index" chunk doesn't reduce total bytes shipped,
            // but (a) gets the app's own route/component code under the
            // per-chunk size gate, and (b) lets browsers cache these chunks
            // across deploys where only app code changed, since vendor deps
            // bump far less often than our own source.
            // Note: @tanstack/* (router/query/start) was tried here too, but
            // Rollup merges it straight back into the entry chunk regardless
            // of this hint — it's synchronously required to boot the router
            // on every route, so there's no split point that doesn't just
            // recreate the same waterfall. Verified by inspecting the output:
            // no vendor-tanstack chunk is ever produced.
            if (id.includes("node_modules/@supabase/")) return "vendor-supabase";
            if (
              id.includes("node_modules/react-i18next") ||
              id.includes("node_modules/i18next") ||
              id.includes("node_modules/html-parse-stringify") ||
              id.includes("node_modules/void-elements")
            )
              return "vendor-i18n";
            // Radix's shared scroll-lock/focus-trap internals — pulled in by
            // every Dialog/Dropdown/Select/Popover, not any one component.
            if (
              id.includes("node_modules/react-remove-scroll") ||
              id.includes("node_modules/use-sidecar") ||
              id.includes("node_modules/use-callback-ref") ||
              id.includes("node_modules/react-style-singleton") ||
              id.includes("node_modules/aria-hidden")
            )
              return "vendor-radix-internals";
            if (id.includes("node_modules/zod")) return "vendor-zod";
            if (id.includes("node_modules/lucide-react")) return "vendor-icons";
          },
        },
      },
    },
  },
});
