import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AdminPageShell } from "@/components/admin/AdminPageShell";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/stats")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "لوحة تحكم الإدارة — إحصائيات لحظية" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AdminStatsPage,
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Stats = any;

function fmtNum(n: number | null | undefined): string {
  if (n == null) return "—";
  return new Intl.NumberFormat("ar-EG").format(n);
}
function fmtSecs(s: number | null | undefined): string {
  if (!s) return "—";
  const m = Math.floor(s / 60);
  const r = s % 60;
  return m > 0 ? `${m}د ${r}ث` : `${r}ث`;
}
function fmtCredits(n: number | null | undefined): string {
  if (n == null) return "—";
  return `${Number(n).toFixed(2)} credits`;
}
function fmtDate(iso: string): string {
  try {
    return new Date(iso).toLocaleString("ar-EG", {
      day: "2-digit",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

function AdminStatsPage() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [presenceCount, setPresenceCount] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  const load = async () => {
    setRefreshing(true);
    const { data, error } = await supabase.rpc("get_admin_stats");
    setRefreshing(false);
    if (error) {
      toast.error("تعذر تحميل الإحصائيات");
      console.error(error);
      return;
    }
    setStats(data as Stats);
  };

  // Load stats + realtime presence for concurrent users. AdminGate mounts
  // this subtree only after admin is confirmed, so the effect runs at the
  // right moment without an explicit phase gate.
  useEffect(() => {
    let cancelled = false;
    void load();

    supabase.auth
      .getUser()
      .then(({ data }) => {
        if (cancelled) return;
        const uid = data.user?.id ?? "anon";
        const ch = supabase.channel("live-presence", {
          config: { presence: { key: uid } },
        });
        ch.on("presence", { event: "sync" }, () => {
          if (cancelled) return;
          const state = ch.presenceState();
          setPresenceCount(Object.keys(state).length);
        }).subscribe(async (status) => {
          if (cancelled) {
            await supabase.removeChannel(ch);
            return;
          }
          if (status === "SUBSCRIBED") {
            await ch.track({ role: "admin", at: Date.now() });
          }
        });
        if (cancelled) {
          void supabase.removeChannel(ch);
        } else {
          channelRef.current = ch;
        }
      })
      .catch((err) => {
        console.warn("[admin.stats] presence init failed:", err);
      });

    const t = setInterval(() => void load(), 30_000);
    return () => {
      cancelled = true;
      clearInterval(t);
      if (channelRef.current) void supabase.removeChannel(channelRef.current);
      channelRef.current = null;
    };
  }, []);

  const budgetRemaining = useMemo(() => {
    if (!stats) return null;
    const used = Number(stats.ai_credits_used_month ?? 0);
    const budget = Number(stats.ai_monthly_budget ?? 0);
    return {
      used,
      budget,
      remaining: Math.max(0, budget - used),
      pct: budget > 0 ? Math.min(100, (used / budget) * 100) : 0,
    };
  }, [stats]);

  return (
    <AdminPageShell wrapperClassName="min-h-screen bg-gradient-to-b from-slate-50 to-white pb-16">
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur border-b">
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center gap-3">
          <h1 className="text-lg font-bold">🛠️ لوحة تحكم الإدارة</h1>
          <span className="text-[10px] rounded-full bg-emerald-100 text-emerald-700 px-2 py-0.5 font-bold">
            LIVE
          </span>
          <button
            onClick={() => void load()}
            disabled={refreshing}
            className="mr-auto rounded-lg border bg-white px-3 py-1.5 text-xs font-bold hover:bg-muted disabled:opacity-50"
          >
            {refreshing ? "…" : "تحديث"}
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6 space-y-6">
        {!stats ? (
          <p className="text-sm text-muted-foreground">جاري تحميل الإحصائيات…</p>
        ) : (
          <>
            {/* KPIs */}
            <section className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Kpi
                label="متزامنون الآن"
                value={fmtNum(presenceCount)}
                accent="emerald"
                hint="Realtime Presence"
              />
              <Kpi label="نشِطون آخر 24 ساعة" value={fmtNum(stats.active_24h)} />
              <Kpi label="إجمالي المسجّلين" value={fmtNum(stats.total_users)} />
              <Kpi label="جدد آخر 7 أيام" value={`+${fmtNum(stats.new_users_7d)}`} accent="sky" />
              <Kpi label="جدد آخر 30 يوم" value={`+${fmtNum(stats.new_users_30d)}`} accent="sky" />
              <Kpi label="جلسات آخر 24 ساعة" value={fmtNum(stats.sessions_24h)} />
              <Kpi
                label="متوسط مدة الجلسة (7 أيام)"
                value={fmtSecs(stats.avg_session_seconds_7d)}
              />
              <Kpi
                label="وسيط مدة الجلسة (7 أيام)"
                value={fmtSecs(stats.median_session_seconds_7d)}
              />
            </section>

            {/* AI Budget */}
            {budgetRemaining && (
              <section className="rounded-2xl border bg-white p-5 shadow-sm">
                <div className="flex items-center gap-2 mb-3">
                  <h2 className="font-bold">💳 استهلاك رصيد legacy AI gateway هذا الشهر</h2>
                  <span className="mr-auto text-xs text-muted-foreground">
                    الميزانية: {fmtCredits(budgetRemaining.budget)}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-3 text-center mb-3">
                  <div className="rounded-xl bg-muted/40 p-3">
                    <div className="text-[11px] text-muted-foreground">مستهلَك</div>
                    <div className="text-lg font-bold text-rose-600">
                      {fmtCredits(budgetRemaining.used)}
                    </div>
                  </div>
                  <div className="rounded-xl bg-muted/40 p-3">
                    <div className="text-[11px] text-muted-foreground">المتبقّي</div>
                    <div className="text-lg font-bold text-emerald-600">
                      {fmtCredits(budgetRemaining.remaining)}
                    </div>
                  </div>
                  <div className="rounded-xl bg-muted/40 p-3">
                    <div className="text-[11px] text-muted-foreground">النسبة</div>
                    <div className="text-lg font-bold">{budgetRemaining.pct.toFixed(1)}%</div>
                  </div>
                </div>
                <div className="h-3 w-full rounded-full bg-slate-200 overflow-hidden">
                  <div
                    className={`h-full ${
                      budgetRemaining.pct > 85
                        ? "bg-rose-500"
                        : budgetRemaining.pct > 60
                          ? "bg-amber-500"
                          : "bg-emerald-500"
                    }`}
                    style={{ width: `${budgetRemaining.pct}%` }}
                  />
                </div>
                <div className="mt-3 grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                  <Info label="مكالمات اليوم" v={fmtNum(stats.ai_calls_today)} />
                  <Info label="مكالمات آخر 7 أيام" v={fmtNum(stats.ai_calls_7d)} />
                  <Info label="مكالمات هذا الشهر" v={fmtNum(stats.ai_calls_month)} />
                  <Info
                    label="نسبة إصابة الكاش (7 أيام)"
                    v={`${stats.ai_cache_hit_rate_7d ?? 0}%`}
                  />
                </div>
              </section>
            )}

            {/* By model */}
            <section className="rounded-2xl border bg-white p-5 shadow-sm">
              <h2 className="font-bold mb-3">🧠 استهلاك النماذج (آخر 30 يوم)</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead className="text-muted-foreground">
                    <tr className="text-right">
                      <th className="p-2">النموذج</th>
                      <th className="p-2">مكالمات</th>
                      <th className="p-2">Input tok.</th>
                      <th className="p-2">Output tok.</th>
                      <th className="p-2">Cached</th>
                      <th className="p-2">Credits</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(stats.ai_by_model_30d ?? []).length === 0 ? (
                      <tr>
                        <td colSpan={6} className="p-4 text-center text-muted-foreground">
                          لا يوجد استخدام بعد
                        </td>
                      </tr>
                    ) : (
                      (stats.ai_by_model_30d ?? []).map((m: Stats) => (
                        <tr key={m.model} className="border-t">
                          <td className="p-2 font-mono text-[11px]">{m.model}</td>
                          <td className="p-2">{fmtNum(m.calls)}</td>
                          <td className="p-2">{fmtNum(m.input_tokens)}</td>
                          <td className="p-2">{fmtNum(m.output_tokens)}</td>
                          <td className="p-2">{fmtNum(m.cached_tokens)}</td>
                          <td className="p-2 font-bold">{fmtCredits(m.credits)}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </section>

            {/* Daily AI usage */}
            <section className="rounded-2xl border bg-white p-5 shadow-sm">
              <h2 className="font-bold mb-3">📈 الاستخدام اليومي للـAI (14 يوم)</h2>
              <MiniBars
                rows={(stats.ai_daily_14d ?? []).slice().reverse()}
                valueKey="credits"
                labelKey="day"
                unit="credits"
              />
            </section>

            {/* Recent sign-ins */}
            <section className="rounded-2xl border bg-white p-5 shadow-sm">
              <h2 className="font-bold mb-3">🔐 آخر تسجيلات الدخول</h2>
              <ul className="divide-y">
                {(stats.recent_signins ?? []).length === 0 && (
                  <li className="p-2 text-sm text-muted-foreground">لا يوجد سجلات</li>
                )}
                {(stats.recent_signins ?? []).map((s: Stats, i: number) => (
                  <li key={i} className="py-2 flex items-center gap-3 text-xs">
                    <span className="size-2 rounded-full bg-emerald-500" />
                    <span className="font-bold">{s.display_name ?? "مستخدم"}</span>
                    <span className="text-muted-foreground">{s.platform ?? ""}</span>
                    <span className="mr-auto text-muted-foreground" title={s.user_agent ?? ""}>
                      {fmtDate(s.started_at)}
                    </span>
                  </li>
                ))}
              </ul>
            </section>

            {/* Top users */}
            <section className="rounded-2xl border bg-white p-5 shadow-sm">
              <h2 className="font-bold mb-3">🏆 أكثر المستخدمين نشاطاً (7 أيام)</h2>
              <ul className="space-y-2">
                {(stats.top_users_7d ?? []).length === 0 && (
                  <li className="text-sm text-muted-foreground">لا يوجد بيانات</li>
                )}
                {(stats.top_users_7d ?? []).map((u: Stats, i: number) => (
                  <li key={i} className="flex items-center gap-3 text-xs">
                    <span className="w-5 text-center font-bold text-muted-foreground">{i + 1}</span>
                    <span className="font-bold">{u.display_name ?? "مستخدم"}</span>
                    <span className="mr-auto text-muted-foreground">
                      {fmtNum(u.sessions)} جلسة · {fmtSecs(u.total_seconds)}
                    </span>
                  </li>
                ))}
              </ul>
            </section>

            {/* Daily active */}
            <section className="rounded-2xl border bg-white p-5 shadow-sm">
              <h2 className="font-bold mb-3">👥 المستخدمون النشِطون (14 يوم)</h2>
              <MiniBars
                rows={(stats.daily ?? []).slice().reverse()}
                valueKey="users"
                labelKey="day"
                unit="مستخدم"
              />
            </section>

            {/* Pricing table */}
            <section className="rounded-2xl border bg-white p-5 shadow-sm">
              <h2 className="font-bold mb-3">💰 تسعير النماذج (Credits لكل مليون Token)</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead className="text-muted-foreground">
                    <tr className="text-right">
                      <th className="p-2">النموذج</th>
                      <th className="p-2">Input / 1M</th>
                      <th className="p-2">Output / 1M</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(stats.ai_pricing ?? []).map((p: Stats) => (
                      <tr key={p.model} className="border-t">
                        <td className="p-2 font-mono text-[11px]">{p.model}</td>
                        <td className="p-2">{Number(p.credits_per_m_input).toFixed(3)}</td>
                        <td className="p-2">{Number(p.credits_per_m_output).toFixed(3)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </>
        )}
      </main>
    </AdminPageShell>
  );
}

function Kpi({
  label,
  value,
  accent,
  hint,
}: {
  label: string;
  value: string;
  accent?: "emerald" | "sky";
  hint?: string;
}) {
  const color =
    accent === "emerald"
      ? "text-emerald-600"
      : accent === "sky"
        ? "text-sky-600"
        : "text-foreground";
  return (
    <div className="rounded-2xl border bg-white p-4 shadow-sm">
      <div className="text-[11px] text-muted-foreground">{label}</div>
      <div className={`mt-1 text-2xl font-bold ${color}`}>{value}</div>
      {hint && <div className="text-[10px] text-muted-foreground mt-1">{hint}</div>}
    </div>
  );
}

function Info({ label, v }: { label: string; v: string }) {
  return (
    <div className="rounded-lg bg-muted/40 p-2">
      <div className="text-[10px] text-muted-foreground">{label}</div>
      <div className="font-bold">{v}</div>
    </div>
  );
}

function MiniBars({
  rows,
  valueKey,
  labelKey,
  unit,
}: {
  rows: Array<Record<string, unknown>>;
  valueKey: string;
  labelKey: string;
  unit: string;
}) {
  const nums = rows.map((r) => Number(r[valueKey] ?? 0));
  const max = Math.max(1, ...nums);
  if (!rows.length) {
    return <p className="text-xs text-muted-foreground">لا يوجد بيانات</p>;
  }
  return (
    <div className="flex items-end gap-1 h-32">
      {rows.map((r, i) => {
        const v = Number(r[valueKey] ?? 0);
        const h = Math.round((v / max) * 100);
        const label = String(r[labelKey] ?? "");
        return (
          <div
            key={i}
            className="flex-1 flex flex-col items-center gap-1"
            title={`${label}: ${v} ${unit}`}
          >
            <div
              className="w-full rounded-t bg-gradient-to-t from-emerald-500 to-emerald-300"
              style={{ height: `${Math.max(2, h)}%` }}
            />
            <span className="text-[9px] text-muted-foreground truncate w-full text-center">
              {label.slice(5)}
            </span>
          </div>
        );
      })}
    </div>
  );
}
