import { SITE_BASE_URL } from "@/lib/seo/site";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { z } from "zod";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  ChevronRight,
  ChevronLeft,
  Volume2,
  VolumeX,
  Navigation as NavIcon,
  ArrowRight,
  ArrowLeftRight,
  Loader2,
  MapPin,
} from "lucide-react";
import type { PathResult } from "@/lib/transit/graph";

import type { NavInstruction } from "@/lib/transit/navigation";

import { AuthGateLoading } from "@/components/AuthGateLoading";
import { useRequireAuth } from "@/hooks/useRequireAuth";

const search = z.object({
  from: z.string().optional().default(""),
  to: z.string().optional().default(""),
});

export const Route = createFileRoute("/navigate")({
  ssr: false,
  validateSearch: search,
  head: () => ({
    meta: [
      { title: "ملاحة خطوة بخطوة — مواصلات" },
      { name: "description", content: "تعليمات تفصيلية لرحلتك خطوة بخطوة مع نطق صوتي." },
      { property: "og:title", content: "🧭 ملاحة خطوة بخطوة" },
    ],
    links: [
      { rel: "canonical", href: `${SITE_BASE_URL}/navigate` },
      { rel: "alternate", hrefLang: "ar-EG", href: `${SITE_BASE_URL}/navigate` },
      { rel: "alternate", hrefLang: "x-default", href: `${SITE_BASE_URL}/navigate` },
    ],
  }),
  component: NavigateRoute,
});

/** بوابة استخدام: يتطلب تسجيل دخول قبل عرض هذه الصفحة (مش مجرد تصفح). */
function NavigateRoute() {
  const authStatus = useRequireAuth();
  if (authStatus !== "authenticated") return <AuthGateLoading />;
  return <NavigatePage />;
}

function NavigatePage() {
  const { from, to } = Route.useSearch();
  const [loading, setLoading] = useState(false);
  const [path, setPath] = useState<PathResult | null>(null);
  const [instructions, setInstructions] = useState<NavInstruction[]>([]);
  const [idx, setIdx] = useState(0);
  const [voiceOn, setVoiceOn] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function run() {
      if (!from || !to) return;
      setLoading(true);
      try {
        const [{ findShortestPath, loadTransitGraph }, { buildInstructions }] = await Promise.all([
          import("@/lib/transit/graph"),
          import("@/lib/transit/navigation"),
        ]);
        await loadTransitGraph();
        const result = await findShortestPath(from, to);
        if (cancelled) return;
        if (!result) {
          toast.error("لم أعثر على مسار بين هاتين المحطتين");
          setPath(null);
          setInstructions([]);
          return;
        }
        const inst = buildInstructions(result);
        setPath(result);
        setInstructions(inst);
        setIdx(0);
      } catch (e: unknown) {
        toast.error(e instanceof Error ? e.message : "تعذّر حساب المسار");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    run();
    return () => {
      cancelled = true;
    };
  }, [from, to]);

  const current = instructions[idx];

  // نطق التعليمة الحالية
  useEffect(() => {
    if (!voiceOn || !current) return;
    let active = true;
    (async () => {
      try {
        const { speak, stopSpeaking } = await import("@/lib/transit/voice");
        if (!active) return;
        stopSpeaking();
        speak(current.spoken);
      } catch {
        /* ignore */
      }
    })();
    return () => {
      active = false;
      import("@/lib/transit/voice").then((m) => m.stopSpeaking()).catch(() => {});
    };
  }, [current, voiceOn]);

  const progress = instructions.length ? ((idx + 1) / instructions.length) * 100 : 0;

  // from/to aren't read inside the callback, but window.location.href IS
  // reactive to them here: this route's URL search params change whenever
  // from/to change, so they're what should trigger recomputing shareUrl.
  const shareUrl = useMemo(() => {
    if (typeof window === "undefined") return "";
    return window.location.href;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [from, to]);

  if (!from || !to) {
    return <NavigateEmptyForm />;
  }

  return (
    <div className="mx-auto max-w-xl px-4 py-6" dir="rtl">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-lg font-bold flex items-center gap-2">
          <NavIcon className="size-5 text-primary" /> ملاحة خطوة بخطوة
        </h1>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => {
            setVoiceOn((v) => !v);
            if (voiceOn)
              import("@/lib/transit/voice").then((m) => m.stopSpeaking()).catch(() => {});
          }}
          aria-label={voiceOn ? "كتم النطق" : "تشغيل النطق"}
        >
          {voiceOn ? <Volume2 className="size-5" /> : <VolumeX className="size-5" />}
        </Button>
      </div>

      <Card className="p-4 mb-3">
        <div className="text-xs text-muted-foreground mb-1">رحلتك</div>
        <div className="flex items-center gap-2 text-sm font-semibold">
          <span className="truncate">{from}</span>
          <ArrowRight className="size-4 shrink-0 text-muted-foreground" />
          <span className="truncate">{to}</span>
        </div>
        {path && (
          <div className="mt-2 flex flex-wrap gap-1.5">
            <Badge variant="secondary">{path.totalHops} محطة</Badge>
            <Badge variant="secondary">{path.transfers} تبديل</Badge>
            {path.modes.map((m) => (
              <Badge key={m} variant="outline">
                {m}
              </Badge>
            ))}
          </div>
        )}
      </Card>

      {loading && (
        <Card className="p-8 text-center text-muted-foreground">
          <Loader2 className="mx-auto mb-2 size-6 animate-spin" />
          أحسب أفضل مسار…
        </Card>
      )}

      {!loading && current && (
        <>
          <div className="mb-3 h-1.5 w-full overflow-hidden rounded-full bg-muted">
            <div className="h-full bg-primary transition-all" style={{ width: `${progress}%` }} />
          </div>
          <Card className="p-5 mb-3">
            <div className="text-[11px] text-muted-foreground mb-1">
              خطوة {idx + 1} من {instructions.length}
            </div>
            <div className="text-lg font-bold mb-1">{current.title}</div>
            {current.detail && (
              <div className="text-sm text-muted-foreground">{current.detail}</div>
            )}
          </Card>

          <div className="flex items-center justify-between gap-2">
            <Button
              variant="outline"
              onClick={() => setIdx((i) => Math.max(0, i - 1))}
              disabled={idx === 0}
            >
              <ChevronRight className="size-4 ml-1" /> السابق
            </Button>
            <div className="text-xs text-muted-foreground">
              {idx + 1} / {instructions.length}
            </div>
            <Button
              onClick={() => setIdx((i) => Math.min(instructions.length - 1, i + 1))}
              disabled={idx >= instructions.length - 1}
            >
              التالي <ChevronLeft className="size-4 mr-1" />
            </Button>
          </div>

          <Card className="mt-4 p-3">
            <div className="text-xs font-semibold mb-2">كل الخطوات</div>
            <ol className="space-y-1.5 text-sm">
              {instructions.map((s, i) => (
                <li
                  key={s.index}
                  className={`flex items-start gap-2 rounded p-1.5 cursor-pointer ${
                    i === idx ? "bg-primary/10 font-semibold" : "hover:bg-muted/50"
                  }`}
                  onClick={() => setIdx(i)}
                >
                  <span className="text-xs text-muted-foreground shrink-0 w-5 text-center">
                    {i + 1}
                  </span>
                  <span className="flex-1">{s.title}</span>
                </li>
              ))}
            </ol>
          </Card>

          <div className="mt-4 flex gap-2">
            <Button
              variant="outline"
              className="flex-1"
              onClick={async () => {
                try {
                  if (navigator.share) {
                    await navigator.share({ title: "رحلتي", url: shareUrl });
                  } else {
                    await navigator.clipboard.writeText(shareUrl);
                    toast.success("تم نسخ الرابط");
                  }
                } catch {
                  /* ignore */
                }
              }}
            >
              شارك الرحلة
            </Button>
            <Button variant="ghost" asChild>
              <Link to="/explore">رحلة جديدة</Link>
            </Button>
          </div>
        </>
      )}
    </div>
  );
}

const RECENT_KEY = "tareeq:navigate:recent";
type RecentTrip = { from: string; to: string; at: number };

function readRecent(): RecentTrip[] {
  if (typeof localStorage === "undefined") return [];
  try {
    const raw = localStorage.getItem(RECENT_KEY);
    return raw ? (JSON.parse(raw) as RecentTrip[]) : [];
  } catch {
    return [];
  }
}

function NavigateEmptyForm() {
  const navigate = useNavigate();
  const [fromVal, setFromVal] = useState("");
  const [toVal, setToVal] = useState("");
  const [stations, setStations] = useState<string[]>([]);
  const [loadingStations, setLoadingStations] = useState(true);
  const [locating, setLocating] = useState(false);
  const [recent, setRecent] = useState<RecentTrip[]>([]);

  useEffect(() => {
    setRecent(readRecent());
    let cancelled = false;
    (async () => {
      try {
        const { loadTransitGraph } = await import("@/lib/transit/graph");
        const graph = await loadTransitGraph();
        if (cancelled) return;
        setStations(Array.from(graph.keys()).sort((a, b) => a.localeCompare(b, "ar")));
      } catch {
        /* ignore */
      } finally {
        if (!cancelled) setLoadingStations(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const canSubmit =
    fromVal.trim().length > 0 && toVal.trim().length > 0 && fromVal.trim() !== toVal.trim();

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    const from = fromVal.trim();
    const to = toVal.trim();
    try {
      const next: RecentTrip[] = [
        { from, to, at: Date.now() },
        ...readRecent().filter((r) => !(r.from === from && r.to === to)),
      ].slice(0, 5);
      localStorage.setItem(RECENT_KEY, JSON.stringify(next));
    } catch {
      /* ignore */
    }
    navigate({ to: "/navigate", search: { from, to } });
  };

  const swap = () => {
    setFromVal(toVal);
    setToVal(fromVal);
  };

  const useMyLocation = () => {
    if (!("geolocation" in navigator)) {
      toast.error("جهازك لا يدعم تحديد الموقع");
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const { loadTransitGraph } = await import("@/lib/transit/graph");
          const graph = await loadTransitGraph();
          const { latitude, longitude } = pos.coords;
          let best: { name: string; d: number } | null = null;
          for (const [name, node] of graph.entries()) {
            const n = node as { lat?: number; lng?: number };
            if (typeof n.lat !== "number" || typeof n.lng !== "number") continue;
            const dx = n.lat - latitude;
            const dy = n.lng - longitude;
            const d = dx * dx + dy * dy;
            if (!best || d < best.d) best = { name, d };
          }
          if (best) {
            setFromVal(best.name);
            toast.success(`أقرب محطة: ${best.name}`);
          } else {
            toast.error("لم أجد محطة قريبة على الخريطة");
          }
        } catch {
          toast.error("تعذّر تحديد أقرب محطة");
        } finally {
          setLocating(false);
        }
      },
      (err) => {
        setLocating(false);
        toast.error(
          err.code === err.PERMISSION_DENIED ? "لم تسمح بمشاركة موقعك" : "تعذّر الحصول على موقعك",
        );
      },
      { timeout: 10_000, maximumAge: 60_000 },
    );
  };

  return (
    <div className="mx-auto max-w-xl px-4 py-8" dir="rtl">
      <Card className="p-6">
        <div className="mb-5 text-center">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            <NavIcon className="size-7" />
          </div>
          <h1 className="text-xl font-bold">الملاحة خطوة بخطوة</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            اختر محطة البداية والوجهة لبناء تعليمات الرحلة.
          </p>
        </div>

        <form onSubmit={submit} className="space-y-3">
          <div>
            <label
              htmlFor="nav-from"
              className="mb-1 flex items-center gap-1 text-xs font-semibold text-muted-foreground"
            >
              <MapPin className="size-3.5 text-emerald-600" /> من
            </label>
            <Input
              id="nav-from"
              list="nav-stations"
              placeholder={loadingStations ? "جارٍ تحميل المحطات…" : "مثال: العتبة"}
              value={fromVal}
              onChange={(e) => setFromVal(e.target.value)}
              disabled={loadingStations}
              autoComplete="off"
            />
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={useMyLocation}
              disabled={locating || loadingStations}
              className="mt-1 h-7 px-2 text-xs"
            >
              {locating ? (
                <Loader2 className="size-3.5 animate-spin ml-1" />
              ) : (
                <NavIcon className="size-3.5 ml-1" />
              )}
              استخدم موقعي الحالي
            </Button>
            <p className="mt-1 text-[10px] text-muted-foreground">
              نستخدم موقعك محلياً فقط لإيجاد أقرب محطة — لا يُرسل لأي خادم.
            </p>
          </div>

          <div className="flex justify-center">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={swap}
              disabled={!fromVal && !toVal}
            >
              <ArrowLeftRight className="size-4 ml-1" /> عكس الاتجاه
            </Button>
          </div>

          <div>
            <label
              htmlFor="nav-to"
              className="mb-1 flex items-center gap-1 text-xs font-semibold text-muted-foreground"
            >
              <MapPin className="size-3.5 text-rose-600" /> إلى
            </label>
            <Input
              id="nav-to"
              list="nav-stations"
              placeholder={loadingStations ? "جارٍ تحميل المحطات…" : "مثال: السادات"}
              value={toVal}
              onChange={(e) => setToVal(e.target.value)}
              disabled={loadingStations}
              autoComplete="off"
            />
          </div>

          <datalist id="nav-stations">
            {stations.slice(0, 500).map((s) => (
              <option key={s} value={s} />
            ))}
          </datalist>

          <Button type="submit" className="w-full" disabled={!canSubmit || loadingStations}>
            {loadingStations ? (
              <>
                <Loader2 className="size-4 animate-spin ml-1" /> تحميل…
              </>
            ) : (
              <>
                ابدأ الملاحة <ArrowRight className="size-4 mr-1" />
              </>
            )}
          </Button>
        </form>

        {recent.length > 0 && (
          <div className="mt-5 border-t pt-3">
            <div className="mb-2 text-xs font-semibold text-muted-foreground">رحلات أخيرة</div>
            <ul className="space-y-1.5">
              {recent.map((r) => (
                <li key={`${r.from}→${r.to}`}>
                  <button
                    type="button"
                    onClick={() =>
                      navigate({ to: "/navigate", search: { from: r.from, to: r.to } })
                    }
                    className="flex w-full items-center justify-between gap-2 rounded-lg border bg-card px-3 py-2 text-right text-sm hover:bg-accent"
                  >
                    <span className="flex items-center gap-2 truncate">
                      <span className="truncate">{r.from}</span>
                      <ArrowRight className="size-3 shrink-0 text-muted-foreground" />
                      <span className="truncate">{r.to}</span>
                    </span>
                    <ChevronLeft className="size-4 shrink-0 text-muted-foreground" />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="mt-4 border-t pt-3 text-center text-xs text-muted-foreground">
          أو تصفّح{" "}
          <Link to="/explore" className="text-primary underline">
            مستكشف الخطوط
          </Link>
          {stations.length > 0 && <span className="mx-1">· {stations.length} محطة متاحة</span>}
        </div>
      </Card>
    </div>
  );
}
