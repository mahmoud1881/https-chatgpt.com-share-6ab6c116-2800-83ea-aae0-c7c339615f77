import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { usePublishSnapshot } from "@/hooks/use-publish-snapshot";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { searchCanonicalJourney } from "@/lib/journey/search.functions";
import { z } from "zod";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ArrowRight,
  Search,
  Route as RouteIcon,
  MapPin,
  Loader2,
  Sparkles,
  ArrowLeftRight,
  Share2,
  Link2,
  Navigation as NavIcon,
} from "lucide-react";
import { VoiceSearchButton } from "@/components/VoiceSearchButton";
import { RouteCard } from "@/components/shared/RouteCard";
import { CountBadge } from "@/components/shared/CountBadge";
import { interpretQuery, type SearchMode } from "@/lib/transit/intent";
import { useDeepLinkTrip, type TripPath } from "@/hooks/useDeepLinkTrip";
import { useIdlePreload } from "@/hooks/useIdlePreload";
import { useExploreResults } from "@/hooks/useExploreResults";
import { getLocalRouteStops } from "@/lib/local-data";

const searchSchema = z.object({
  q: z.string().optional().default(""),
  mode: z.string().optional().default("all"),
  tab: z.enum(["routes", "stops"]).optional().default("routes"),
  from: z.string().optional(),
  to: z.string().optional(),
});

export const Route = createFileRoute("/explore")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "مستكشف المواصلات — قاعدة بيانات تفاعلية" },
      { name: "description", content: "ابحث بين 1,877 خط سير و1,600 محطة في القاهرة الكبرى." },
      { property: "og:title", content: "🔎 مستكشف المواصلات" },
      { property: "og:url", content: "/explore" },
    ],
    links: [{ rel: "canonical", href: "/explore" }],
  }),
  component: ExplorePage,
});

const MODES: { value: string; label: string }[] = [
  { value: "all", label: "الكل" },
  { value: "bus", label: "أتوبيس" },
  { value: "minibus", label: "ميني باص" },
  { value: "microbus", label: "ميكروباص" },
  { value: "bus_minibus", label: "أتوبيس/ميني" },
  { value: "private_bus", label: "خاص" },
  { value: "tram", label: "ترام" },
  { value: "brt", label: "BRT" },
];

const STOP_TYPE_LABELS: Record<string, string> = {
  bus_stop: "موقف أتوبيس",
  brt: "محطة BRT",
  urban_microbus_hub: "موقف ميكروباص",
  intercity_terminal: "موقف أقاليم",
  transport_hub: "محور نقل",
  garage: "جراج",
  cta_garage: "جراج هيئة النقل",
  station: "محطة",
};

function ExplorePage() {
  usePublishSnapshot({
    id: "eg:explore",
    source: "استكشف",
    title: "استكشاف المحطات",
    summary: "استكشف المحطات والوجهات القريبة",
    category: "transit",
    href: "/explore",
  });
  const { q, mode, tab, from: deepFrom, to: deepTo } = Route.useSearch();
  const navigate = useNavigate({ from: "/explore" });
  const [input, setInput] = useState(q);
  const [aiHint, setAiHint] = useState<string | null>(null);
  const [tripPath, setTripPath] = useState<TripPath | null>(null);

  const { routes, stops, counts, loading, limit: RESULTS_LIMIT } = useExploreResults(q, mode, tab);
  const suggestions = useIdlePreload();
  const canonicalJourneySearch = useServerFn(searchCanonicalJourney);

  useEffect(() => setInput(q), [q]);

  useDeepLinkTrip(deepFrom, deepTo, (trip, hint) => {
    if (trip) setTripPath(trip);
    if (hint) setAiHint(hint);
  });

  const setSearch = (next: Partial<{ q: string; mode: string; tab: "routes" | "stops" }>) =>
    navigate({ search: (prev: z.infer<typeof searchSchema>) => ({ ...prev, ...next }) });

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAiHint(null);
    setTripPath(null);
    setSearch({ q: input });
  };

  const onAiSearch = async () => {
    const query = input.trim();
    if (!query) {
      toast.error("اكتب سؤالك أولاً");
      return;
    }
    // 1) المسار السريع (sync): تفسير + تطبيق الفلاتر فورًا
    const intent = interpretQuery(query);
    const nextTab: "routes" | "stops" = intent.tab === "stops" ? "stops" : "routes";
    const nextMode: SearchMode = intent.mode === "metro" ? "all" : intent.mode;
    const nextQuery = intent.query || query;
    setInput(nextQuery);
    setAiHint(intent.explanation || `فهمت: ${nextQuery}`);
    toast.success("تم فهم استعلامك ✨");
    setSearch({ q: nextQuery, mode: nextMode, tab: nextTab });

    // 2) المسار الذكي (lazy، غير محجوب): إثراء التلميح بكيانات + مسار Graph + زحمة + NLG
    try {
      const { getSmartEngines } = await import("@/lib/transit/registry");
      const engines = await getSmartEngines();
      let enriched = intent.explanation || `فهمت: ${nextQuery}`;
      if (intent.from && intent.to) {
        const [eFrom, eTo, canonical] = await Promise.all([
          engines.resolveEntity(intent.from),
          engines.resolveEntity(intent.to),
          canonicalJourneySearch({ data: { fromQuery: intent.from, toQuery: intent.to, country: "EG" } }),
        ]);
        const path = null; // Graph is enrichment-only; canonical journey decisions come from the shared orchestrator.
        const fromLabel = eFrom?.canonical ?? intent.from;
        const toLabel = eTo?.canonical ?? intent.to;
        const [trafficFrom, trafficTo] = await Promise.all([
          engines.trafficSummaryFor(fromLabel).catch(() => null),
          engines.trafficSummaryFor(toLabel).catch(() => null),
        ]);
        enriched = canonical.ok
          ? `${fromLabel} → ${toLabel} • ${canonical.journeys.length} بدائل • ${canonical.trust === "verified" ? "موثّق" : canonical.trust === "mixed" ? "مختلط — يحتاج مراجعة" : "قيد المراجعة"}`
          : `لم أجد مسارًا منظّمًا بين ${fromLabel} و${toLabel}`;
        if (path && path.steps.length) {
          setTripPath({ from: fromLabel, to: toLabel, path });
          // اجعل الرابط قابلًا للمشاركة (deep link)
          navigate({
            search: (prev: z.infer<typeof searchSchema>) => ({
              ...prev,
              from: fromLabel,
              to: toLabel,
            }),
          });
        } else {
          setTripPath(null);
        }
        engines.recordUse(`trip:${fromLabel}>${toLabel}`, "query", `${fromLabel} → ${toLabel}`);
        try {
          const { recordTrip } = await import("@/lib/transit/favorites");
          recordTrip(fromLabel, toLabel);
        } catch {
          /* best-effort — safe to ignore */
        }
      } else {
        setTripPath(null);
        const found = await engines.extractEntities(query);
        if (found.length) {
          enriched += ` • تم التعرف: ${found.map((f) => f.canonical).join("، ")}`;
        }
        engines.recordUse(`q:${nextQuery}`, "query", nextQuery);
      }
      setAiHint(enriched);
    } catch {
      // الفشل الصامت — المسار السريع نجح بالفعل
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-background px-4 py-8">
      <div className="mx-auto max-w-4xl space-y-6">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowRight className="size-4" />
          العودة للرئيسية
        </Link>

        <header className="space-y-2 text-center">
          <h1 className="text-3xl font-extrabold tracking-tight md:text-4xl">
            🔎 مستكشف المواصلات
          </h1>
          <p className="text-sm text-muted-foreground">
            قاعدة بيانات تفاعلية: <strong>1,877</strong> خط سير و<strong>1,600</strong> محطة و
            <strong>17,583</strong> ربط
          </p>
        </header>

        <div className="flex gap-2">
          <Button
            variant={tab === "routes" ? "default" : "outline"}
            onClick={() => setSearch({ tab: "routes" })}
            className="flex-1 gap-2"
          >
            <RouteIcon className="size-4" /> خطوط السير
          </Button>
          <Button
            variant={tab === "stops" ? "default" : "outline"}
            onClick={() => setSearch({ tab: "stops" })}
            className="flex-1 gap-2"
          >
            <MapPin className="size-4" /> المحطات
          </Button>
        </div>

        <form onSubmit={onSubmit} className="flex flex-wrap gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={
              tab === "routes" ? "اكتب بلغتك: ازاي اروح من مادي لرمسيس؟" : "ابحث عن محطة..."
            }
            className="min-w-[200px] flex-1"
          />
          <Button type="submit" variant="secondary" className="gap-2">
            <Search className="size-4" /> بحث
          </Button>
          <VoiceSearchButton
            onResult={(text) => {
              setInput(text);
              setSearch({ q: text });
            }}
          />
          <Button
            type="button"
            onClick={onAiSearch}
            className="gap-2 bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white hover:opacity-90"
          >
            <Sparkles className="size-4" />
            بحث ذكي
          </Button>
        </form>

        {aiHint && (
          <div className="rounded-lg border border-violet-200 bg-violet-50 px-3 py-2 text-sm text-violet-900 dark:border-violet-900 dark:bg-violet-950/40 dark:text-violet-200">
            ✨ {aiHint}
          </div>
        )}

        {tripPath && (
          <Card className="space-y-3 p-4">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-sm font-bold">
                <MapPin className="size-4 text-primary" />
                {tripPath.from}
                <ArrowLeftRight className="size-4 text-muted-foreground" />
                {tripPath.to}
              </div>
              <div className="flex gap-1.5">
                <Badge variant="secondary" className="text-xs">
                  {tripPath.path.totalHops} محطة
                </Badge>
                <Badge
                  variant={tripPath.path.transfers === 0 ? "default" : "outline"}
                  className="text-xs"
                >
                  {tripPath.path.transfers === 0
                    ? "بدون تبديل"
                    : `${tripPath.path.transfers} تبديل`}
                </Badge>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                type="button"
                size="sm"
                variant="default"
                className="gap-1.5"
                onClick={async () => {
                  const url = `${window.location.origin}/explore?from=${encodeURIComponent(tripPath.from)}&to=${encodeURIComponent(tripPath.to)}`;
                  const shareData = {
                    title: "رحلتي على مواصلات",
                    text: `${tripPath.from} → ${tripPath.to}`,
                    url,
                  };
                  try {
                    if (typeof navigator !== "undefined" && typeof navigator.share === "function") {
                      await navigator.share(shareData);
                      return;
                    }
                    await navigator.clipboard.writeText(url);
                    toast.success("تم نسخ رابط الرحلة — جاهز للمشاركة");
                  } catch {
                    // المستخدم ألغى — تجاهل
                  }
                }}
              >
                <Share2 className="size-3.5" /> شارك الرحلة
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                className="gap-1.5"
                onClick={async () => {
                  const url = `${window.location.origin}/explore?from=${encodeURIComponent(tripPath.from)}&to=${encodeURIComponent(tripPath.to)}`;
                  try {
                    await navigator.clipboard.writeText(url);
                    toast.success("تم نسخ الرابط");
                  } catch {
                    toast.error("تعذّر النسخ");
                  }
                }}
              >
                <Link2 className="size-3.5" /> نسخ الرابط
              </Button>
              <Button asChild size="sm" variant="secondary" className="gap-1.5">
                <Link to="/navigate" search={{ from: tripPath.from, to: tripPath.to }}>
                  <NavIcon className="size-3.5" /> ابدأ الملاحة
                </Link>
              </Button>
            </div>
            <ol className="space-y-2">
              {(() => {
                const segs: Array<{
                  lineName: string;
                  mode: string;
                  from: string;
                  to: string;
                  hops: number;
                }> = [];
                for (const s of tripPath.path.steps) {
                  const last = segs[segs.length - 1];
                  if (last && last.lineName === s.lineName) {
                    last.to = s.to;
                    last.hops++;
                  } else {
                    segs.push({
                      lineName: s.lineName,
                      mode: s.mode,
                      from: s.from,
                      to: s.to,
                      hops: 1,
                    });
                  }
                }
                return segs.map((seg, i) => (
                  <li
                    key={i}
                    className="flex items-start gap-2 rounded-md border bg-muted/30 p-2 text-xs"
                  >
                    <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                      {i + 1}
                    </span>
                    <div className="flex-1">
                      <div className="font-bold text-sm">{seg.lineName}</div>
                      <div className="text-muted-foreground">
                        {seg.from} ← {seg.to} <span className="opacity-60">• {seg.hops} محطة</span>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-[10px]">
                      {seg.mode}
                    </Badge>
                  </li>
                ));
              })()}
            </ol>
          </Card>
        )}

        {suggestions.length > 0 && !q && (
          <div className="rounded-lg border bg-muted/30 px-3 py-2">
            <div className="mb-1.5 text-xs text-muted-foreground">⭐ آخر ما بحثت عنه</div>
            <div className="flex flex-wrap gap-1.5">
              {suggestions.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => {
                    const label = s.label;
                    setInput(label);
                    if (s.kind === "stop") setSearch({ q: label, tab: "stops" });
                    else setSearch({ q: label, tab: "routes" });
                  }}
                  className="rounded-full border bg-background px-2.5 py-1 text-xs hover:bg-accent"
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="flex flex-wrap gap-2">
          {MODES.map((m) => (
            <Button
              key={m.value}
              size="sm"
              variant={mode === m.value ? "default" : "secondary"}
              onClick={() => setSearch({ mode: m.value })}
            >
              {m.label}
            </Button>
          ))}
        </div>

        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="size-6 animate-spin text-muted-foreground" />
          </div>
        ) : tab === "routes" ? (
          <>
            <p className="flex items-center gap-1 text-sm text-muted-foreground">
              عدد النتائج:{" "}
              <CountBadge
                value={counts?.routes ?? null}
                status={loading ? "loading" : counts === null ? "loading" : "success"}
              />
              {(counts?.routes ?? 0) > RESULTS_LIMIT ? ` — عرض أول ${RESULTS_LIMIT}` : ""}
            </p>
            <div className="grid gap-2">
              {routes.map((r) => {
                const label = r.name_ar || r.name || r.route_code || r.id;
                return (
                  <div
                    key={r.id}
                    onClick={() => {
                      void import("@/lib/transit/personalization").then((m) =>
                        m.recordUse(r.id, "route", label),
                      );
                    }}
                  >
                    <RouteCard
                      id={r.id}
                      routeCode={r.route_code}
                      transportMode={r.transport_mode}
                      originName={r.origin_name}
                      destinationName={r.destination_name}
                      stops={getLocalRouteStops(r.id)
                        .filter((s) => s.stop_name)
                        .map((s) => ({
                          name: s.stop_name as string,
                          lat: (s as { lat?: number }).lat ?? s.latitude ?? null,
                          lng: (s as { lng?: number }).lng ?? s.longitude ?? null,
                        }))}
                    />
                  </div>
                );
              })}
              {routes.length === 0 && (
                <Card className="p-8 text-center text-sm text-muted-foreground">
                  لا توجد نتائج.
                </Card>
              )}
            </div>
          </>
        ) : (
          <>
            <p className="flex items-center gap-1 text-sm text-muted-foreground">
              عدد النتائج:{" "}
              <CountBadge
                value={counts?.stops ?? null}
                status={loading ? "loading" : counts === null ? "loading" : "success"}
              />
              {(counts?.stops ?? 0) > RESULTS_LIMIT ? ` — عرض أول ${RESULTS_LIMIT}` : ""}
            </p>
            <div className="grid gap-2 md:grid-cols-2">
              {stops.map((s) => {
                const label = s.name || s.id;
                return (
                  <Link
                    key={s.id}
                    to="/stop/$stopId"
                    params={{ stopId: s.id }}
                    onClick={() => {
                      void import("@/lib/transit/personalization").then((m) =>
                        m.recordUse(s.id, "stop", label),
                      );
                    }}
                  >
                    <Card className="flex items-start gap-3 p-4 transition hover:bg-accent">
                      <MapPin className="mt-1 size-5 text-primary" />
                      <div className="flex-1">
                        <div className="font-bold">{label}</div>
                        <div className="text-xs text-muted-foreground">
                          {[s.area, s.governorate].filter(Boolean).join(" • ")}
                        </div>
                        {s.stop_type && (
                          <Badge variant="outline" className="mt-2 text-xs">
                            {STOP_TYPE_LABELS[s.stop_type] ?? s.stop_type}
                          </Badge>
                        )}
                      </div>
                    </Card>
                  </Link>
                );
              })}
              {stops.length === 0 && (
                <Card className="col-span-full p-8 text-center text-sm text-muted-foreground">
                  لا توجد نتائج.
                </Card>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
