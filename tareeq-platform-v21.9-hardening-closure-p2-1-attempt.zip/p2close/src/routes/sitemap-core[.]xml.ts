// Core static routes (non-country-specific + root) — kept small for fast crawl.
import { createFileRoute } from "@tanstack/react-router";

import { SITE_BASE_URL as BASE } from "@/lib/seo/site";
const CORE: Array<{ path: string; pri: string; freq: string }> = [
  { path: "/", pri: "1.0", freq: "weekly" },
  { path: "/metro", pri: "0.9", freq: "weekly" },
  { path: "/lrt", pri: "0.8", freq: "weekly" },
  { path: "/brt", pri: "0.8", freq: "weekly" },
  { path: "/trains", pri: "0.8", freq: "weekly" },
  { path: "/capital-train", pri: "0.7", freq: "monthly" },
  { path: "/intercity", pri: "0.7", freq: "weekly" },
  { path: "/bus-stations", pri: "0.7", freq: "weekly" },
  { path: "/community-routes", pri: "0.7", freq: "weekly" },
  { path: "/stops", pri: "0.7", freq: "weekly" },
  { path: "/data", pri: "0.8", freq: "monthly" },
  { path: "/explore", pri: "0.7", freq: "weekly" },
  { path: "/ask", pri: "0.6", freq: "weekly" },
  { path: "/planner", pri: "0.6", freq: "weekly" },
  { path: "/live", pri: "0.6", freq: "daily" },
  { path: "/alerts", pri: "0.6", freq: "daily" },
  { path: "/nearby", pri: "0.6", freq: "weekly" },
  { path: "/navigate", pri: "0.6", freq: "weekly" },
  { path: "/ambassador", pri: "0.5", freq: "monthly" },
  { path: "/meet", pri: "0.5", freq: "monthly" },
  { path: "/privacy", pri: "0.3", freq: "yearly" },
  { path: "/terms", pri: "0.3", freq: "yearly" },
];

export const Route = createFileRoute("/sitemap-core.xml")({
  server: {
    handlers: {
      GET: async () => {
        const urls = CORE.map(
          (e) =>
            `  <url><loc>${BASE}${e.path}</loc><changefreq>${e.freq}</changefreq><priority>${e.pri}</priority></url>`,
        );
        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...urls,
          `</urlset>`,
        ].join("\n");
        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml; charset=utf-8",
            "Cache-Control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
