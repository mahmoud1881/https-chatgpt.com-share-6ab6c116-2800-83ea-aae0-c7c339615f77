import { createFileRoute, Link } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import {
  type StructuredSearchResponse,
} from "@/lib/route-planner/search.functions";
import { searchCanonicalJourney } from "@/lib/journey/search.functions";
import { FloatingHomeButton } from "@/components/FloatingHomeButton";
import {
  ArrowLeftRight,
  Loader2,
  Search,
  MapPin,
  AlertCircle,
  CheckCircle2,
  HelpCircle,
  ArrowRight,
  TrainFront,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { findTrainsBetweenFn, type TrainMatch } from "@/lib/trains/queries.functions";

export const Route = createFileRoute("/planner")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "مخطط الرحلات — Tareeq.world" },
      {
        name: "description",
        content: "ابحث عن أفضل طريق بين محطتين اعتمادًا على قاعدة بيانات المحطات والخطوط.",
      },
    ],
  }),
  component: PlannerPage,
});

const COUNTRIES = [
  { code: "EG", label: "🇪🇬 مصر" },
  { code: "LY", label: "🇱🇾 ليبيا" },
  { code: "IQ", label: "🇮🇶 العراق" },
  { code: "SY", label: "🇸🇾 سوريا" },
  { code: "SD", label: "🇸🇩 السودان" },
  { code: "YE", label: "🇾🇪 اليمن" },
];

const SOURCE_TEXT: Record<string, string> = {
  database_direct: "مطابقة مباشرة",
  database_transfer: "مطابقة بتحويلة",
  semantic_route_match: "مطابقة دلالية داخل الخطوط",
  alias_match: "مطابقة باسم بديل",
};

function PlannerPage() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [country, setCountry] = useState<string>("EG");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<StructuredSearchResponse | null>(null);
  const [enrMatch, setEnrMatch] = useState<TrainMatch | null>(null);
  const reqIdRef = useRef(0);

  const searchFn = useServerFn(searchCanonicalJourney);
  const trainsFn = useServerFn(findTrainsBetweenFn);

  async function submit(e?: React.FormEvent) {
    e?.preventDefault();
    if (!from.trim() || !to.trim()) {
      toast.error("املأ الحقلين من وإلى");
      return;
    }
    const myReqId = ++reqIdRef.current;
    setLoading(true);
    setResult(null);
    setEnrMatch(null);
    trainsFn({ data: { from: from.trim(), to: to.trim() } })
      .then((m) => {
        if (reqIdRef.current === myReqId) setEnrMatch(m);
      })
      .catch(() => {
        if (reqIdRef.current === myReqId) setEnrMatch(null);
      });
    try {
      const res = await searchFn({ data: { fromQuery: from.trim(), toQuery: to.trim(), country } });
      if (reqIdRef.current === myReqId) setResult(res.legacy);
    } catch (err) {
      if (reqIdRef.current === myReqId) {
        toast.error(`فشل البحث: ${(err as Error).message}`);
      }
    } finally {
      if (reqIdRef.current === myReqId) setLoading(false);
    }
  }

  function swap() {
    setFrom(to);
    setTo(from);
  }

  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-b from-background to-muted/40 pb-24">
      <FloatingHomeButton />

      <header className="px-4 pt-6 pb-3">
        <Link to="/" className="text-xs text-muted-foreground underline">
          ← الرئيسية
        </Link>
        <h1 className="text-2xl font-black mt-2 flex items-center gap-2">
          <MapPin className="w-6 h-6 text-primary" />
          مخطط الرحلات
        </h1>
        <p className="text-xs text-muted-foreground mt-1">
          نتائج مبنية على قاعدة بيانات منظمة — تظهر شارة{" "}
          <span className="inline-flex items-center gap-0.5">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            موثّق
          </span>{" "}
          فقط للخطوط التي راجعها مشرف.
        </p>
      </header>

      {/* Form */}
      <form onSubmit={submit} className="px-4">
        <div className="rounded-2xl border bg-card/70 backdrop-blur p-3 space-y-2 shadow-sm">
          <div className="flex items-center gap-2">
            <label className="text-[11px] text-muted-foreground w-10 shrink-0">من</label>
            <input
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              placeholder="مثال: رمسيس، التحرير…"
              className="flex-1 bg-background rounded-xl border px-3 py-2 text-sm"
            />
          </div>
          <div className="flex justify-center">
            <button
              type="button"
              onClick={swap}
              aria-label="تبديل نقطتَي الانطلاق والوصول"
              className="rounded-full border p-1.5 bg-background hover:bg-muted"
            >
              <ArrowLeftRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="flex items-center gap-2">
            <label className="text-[11px] text-muted-foreground w-10 shrink-0">إلى</label>
            <input
              value={to}
              onChange={(e) => setTo(e.target.value)}
              placeholder="مثال: العتبة، مصر الجديدة…"
              className="flex-1 bg-background rounded-xl border px-3 py-2 text-sm"
            />
          </div>
          <div className="flex items-center gap-2 pt-1">
            <label className="text-[11px] text-muted-foreground w-10 shrink-0">دولة</label>
            <select
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              className="flex-1 bg-background rounded-xl border px-3 py-2 text-sm"
            >
              {COUNTRIES.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl bg-primary text-primary-foreground py-2.5 text-sm font-bold flex items-center justify-center gap-2 disabled:opacity-60"
          >
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Search className="w-4 h-4" />
            )}
            ابحث
          </button>
        </div>
      </form>

      {/* ENR train schedule — shown FIRST when the pair matches a known intercity train line */}
      {enrMatch && enrMatch.trains.length > 0 && <ENRTrainCard schedule={enrMatch} />}

      {/* Result */}
      {result && (
        <section
          data-load-result="planner"
          data-load-status={
            result.ok && result.results.some((group) => group.routes.length > 0)
              ? "success"
              : "empty"
          }
          data-load-route-count={
            result.ok ? result.results.reduce((n, group) => n + group.routes.length, 0) : 0
          }
          className="px-4 mt-4 space-y-3"
        >
          {result.ok ? (
            <>
              <div className="text-[11px] text-muted-foreground">
                من <span className="font-bold text-foreground">{result.from.name_ar}</span> إلى{" "}
                <span className="font-bold text-foreground">{result.to.name_ar}</span> —{" "}
                {result.verified_count} موثّق و{result.unverified_count} قيد المراجعة
                {SOURCE_TEXT[result.source] && <span> — {SOURCE_TEXT[result.source]}</span>}
              </div>
              {result.results.map((group, idx) => (
                <ResultGroup key={idx} group={group} />
              ))}
            </>
          ) : (
            <NoResultCard result={result} country={country} from={from} to={to} />
          )}
        </section>
      )}
    </div>
  );
}

function ENRTrainCard({ schedule }: { schedule: TrainMatch }) {
  return (
    <section className="px-4 mt-4">
      <div className="rounded-2xl border-2 border-primary/30 bg-gradient-to-b from-primary/5 to-transparent p-3 shadow-sm">
        <div className="flex items-center gap-2 mb-2">
          <TrainFront className="w-5 h-5 text-primary" />
          <div className="text-sm font-black">
            قطارات سكة حديد مصر — {schedule.fromAr} → {schedule.toAr}
          </div>
          <span className="mr-auto text-[10px] rounded-full bg-primary text-primary-foreground px-2 py-0.5 font-bold">
            الاختيار الأول
          </span>
        </div>
        <div className="text-[10px] text-muted-foreground mb-2">
          {schedule.trains.length} قطار متاح — الأسرع والأوفر بين المحافظتين
        </div>
        <div className="overflow-x-auto -mx-1">
          <table className="w-full text-[11px]">
            <thead className="text-muted-foreground">
              <tr className="text-right">
                <th className="px-1.5 py-1 font-medium">رقم</th>
                <th className="px-1.5 py-1 font-medium">النوع</th>
                <th className="px-1.5 py-1 font-medium">مغادرة</th>
                <th className="px-1.5 py-1 font-medium">وصول</th>
                <th className="px-1.5 py-1 font-medium">المدة</th>
                <th className="px-1.5 py-1 font-medium">محطات</th>
              </tr>
            </thead>
            <tbody>
              {schedule.trains.map((t) => (
                <tr key={t.number} className="border-t border-border/50">
                  <td className="px-1.5 py-1.5 font-bold text-primary">{t.number}</td>
                  <td className="px-1.5 py-1.5">{t.type}</td>
                  <td className="px-1.5 py-1.5 whitespace-nowrap">{t.departure}</td>
                  <td className="px-1.5 py-1.5 whitespace-nowrap">{t.arrival}</td>
                  <td className="px-1.5 py-1.5 whitespace-nowrap">{t.duration}</td>
                  <td className="px-1.5 py-1.5">{t.stops}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-2 flex justify-end">
          <Link to="/trains" className="text-[10px] text-primary underline">
            كل القطارات ←
          </Link>
        </div>
      </div>
    </section>
  );
}

function ResultGroup({
  group,
}: {
  group: import("@/lib/route-planner/search.functions").StructuredRouteResult;
}) {
  return (
    <div className="rounded-2xl border bg-card p-3">
      <div className="text-[10px] font-bold text-primary mb-2">
        {group.kind === "direct" ? "طريق مباشر" : `تحويلة عند ${group.transfer_stop?.name_ar}`}
      </div>
      <div className="space-y-2">
        {group.routes.map((r, i) => (
          <Link
            key={r.id}
            to="/route/$routeId"
            params={{ routeId: r.id }}
            className="block rounded-xl bg-muted/40 p-2.5 hover:bg-muted transition"
          >
            <div className="flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="text-sm font-bold truncate">
                  {r.route_code && <span className="text-primary">{r.route_code} · </span>}
                  {r.route_name}
                </div>
                <div className="text-[10px] text-muted-foreground mt-0.5 flex items-center gap-2 flex-wrap">
                  {r.transport_type_id && <span>{r.transport_type_id}</span>}
                  {r.stops_between > 0 && <span>· {r.stops_between} محطة بين النقطتين</span>}
                  {r.estimated_duration && <span>· ~{r.estimated_duration} د</span>}
                </div>
              </div>
              {r.is_verified ? (
                <span className="shrink-0 inline-flex items-center gap-0.5 text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-full px-1.5 py-0.5">
                  <CheckCircle2 className="w-3 h-3" /> موثّق
                </span>
              ) : (
                <span className="shrink-0 inline-flex items-center gap-0.5 text-[10px] text-amber-700 bg-amber-50 border border-amber-200 rounded-full px-1.5 py-0.5">
                  <HelpCircle className="w-3 h-3" /> قيد المراجعة
                </span>
              )}
            </div>
            {group.kind === "transfer" && i === 0 && (
              <div className="flex justify-center mt-2">
                <ArrowRight className="w-3.5 h-3.5 text-muted-foreground rotate-90" />
              </div>
            )}
          </Link>
        ))}
      </div>

      <div className="flex gap-2 mt-3 justify-end">
        <ReportButton routeId={group.routes[0]?.id} />
      </div>
    </div>
  );
}

function ReportButton({ routeId }: { routeId?: string }) {
  const [busy, setBusy] = useState(false);
  async function report() {
    if (!routeId) return;
    const reason = window.prompt("ما المعلومة غير الدقيقة في هذا الطريق؟");
    if (!reason || !reason.trim()) return;
    setBusy(true);
    try {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) {
        toast.error("سجّل الدخول أولاً لإرسال بلاغ");
        return;
      }
      const { error } = await supabase.from("route_corrections").insert({
        route_id: routeId,
        user_id: u.user.id,
        user_comment: reason.trim().slice(0, 500),
        status: "pending",
      });
      if (error) throw error;
      toast.success("تم إرسال البلاغ للمراجعة");
    } catch (err) {
      toast.error(`تعذّر الإرسال: ${(err as Error).message}`);
    } finally {
      setBusy(false);
    }
  }
  return (
    <button
      onClick={report}
      disabled={busy}
      className="text-[10px] rounded-full border px-2 py-1 hover:bg-muted disabled:opacity-50"
    >
      {busy ? "..." : "معلومة غير دقيقة"}
    </button>
  );
}

function NoResultCard({
  result,
  country,
  from,
  to,
}: {
  result: Extract<StructuredSearchResponse, { ok: false }>;
  country: string;
  from: string;
  to: string;
}) {
  const [suggesting, setSuggesting] = useState(false);

  const reasonText =
    result.reason === "no_from"
      ? "لم نتعرّف على نقطة الانطلاق"
      : result.reason === "no_to"
        ? "لم نتعرّف على الوجهة"
        : "لا يوجد خط مسجّل بين المحطتين حتى الآن";

  async function suggestNewRoute() {
    const notes = window.prompt("أضف تفاصيل الطريق الذي تعرفه (وسيلة النقل، ملاحظات):");
    if (!notes) return;
    setSuggesting(true);
    try {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) {
        toast.error("سجّل الدخول أولاً لإضافة اقتراح");
        return;
      }
      const { error } = await supabase.from("user_route_suggestions").insert({
        user_id: u.user.id,
        from_text: from,
        to_text: to,
        country,
        notes: notes.slice(0, 1000),
        status: "pending",
      });
      if (error) throw error;
      toast.success("شكرًا! سيراجع المشرفون اقتراحك.");
    } catch (err) {
      toast.error(`تعذّر الإرسال: ${(err as Error).message}`);
    } finally {
      setSuggesting(false);
    }
  }

  return (
    <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4">
      <div className="flex items-center gap-2 mb-2">
        <AlertCircle className="w-4 h-4 text-amber-700" />
        <p className="text-sm font-bold text-amber-800">{reasonText}</p>
      </div>

      {result.reason !== "no_route" && (
        <div className="text-[11px] text-amber-800 mb-3">
          جرّب كتابة الاسم بشكل مختلف أو اختر من الاقتراحات:
          <div className="mt-1 flex flex-wrap gap-1">
            {[...result.fromCandidates, ...result.toCandidates].slice(0, 8).map((c) => (
              <span
                key={c.id}
                className="rounded-full bg-white/70 border border-amber-200 px-2 py-0.5"
              >
                {c.name_ar}
                {c.city ? ` — ${c.city}` : ""}
              </span>
            ))}
            {result.fromCandidates.length === 0 && result.toCandidates.length === 0 && (
              <span className="text-amber-700/70">لا توجد اقتراحات</span>
            )}
          </div>
        </div>
      )}

      <button
        onClick={suggestNewRoute}
        disabled={suggesting}
        className="w-full rounded-xl bg-amber-600 text-white py-2 text-xs font-bold disabled:opacity-60"
      >
        {suggesting ? "جارِ الإرسال…" : "أضف طريق ناقص"}
      </button>
    </div>
  );
}
