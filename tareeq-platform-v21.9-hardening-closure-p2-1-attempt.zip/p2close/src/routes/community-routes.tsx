import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { AsyncState } from "@/components/shared/AsyncState";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Map, Plus, ShieldCheck, ArrowRight, Check, ArrowLeft, ThumbsUp } from "lucide-react";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { pubsub } from "@/lib/free-realtime";
import { trustScore, trustLabel } from "@/lib/transit/trust";
import { SemanticSearchBox } from "@/components/semantic-search-box";
import { RequestRouteForm } from "@/components/growth/engines/RequestRouteForm";
import { AuthGateLoading } from "@/components/AuthGateLoading";
import { useRequireAuth } from "@/hooks/useRequireAuth";

type Row = {
  id: string;
  title: string;
  from_area: string;
  to_area: string;
  duration_min: number | null;
  status: "pending" | "confirmed";
  confirmations: number;
  created_at: string;
};

const CONFIRM_THRESHOLD = 5;
const CONFIRMED_KEY = "community_routes_confirmed";

const FormSchema = z.object({
  from: z.string().trim().min(1, "أدخل نقطة البداية").max(60),
  to: z.string().trim().min(1, "أدخل نقطة النهاية").max(60),
  duration: z
    .string()
    .trim()
    .optional()
    .refine((v) => !v || (/^\d+$/.test(v) && Number(v) <= 300), "مدة غير صالحة"),
});

export const Route = createFileRoute("/community-routes")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "خطوط المجتمع — ساهم بمعرفتك" },
      {
        name: "description",
        content: "شارك معرفتك بالشارع — كل خط جديد بإسم اللي ضافه. خطوط مواصلات بالمجتمع.",
      },
      { property: "og:title", content: "🗺️ خطوط المجتمع" },
      {
        property: "og:description",
        content: "شارك معرفتك بالشارع — خطوط مواصلات بالمجتمع.",
      },
    ],
  }),
  component: CommunityRoutesRoute,
});

/** المساهمة بخطوط المجتمع ميزة استخدام فعلية، فبتتطلب تسجيل دخول. */
function CommunityRoutesRoute() {
  const authStatus = useRequireAuth();
  if (authStatus !== "authenticated") return <AuthGateLoading />;
  return <CommunityRoutesPage />;
}

function getConfirmedSet(): Set<string> {
  if (typeof window === "undefined") return new Set();
  try {
    const raw = window.localStorage.getItem(CONFIRMED_KEY);
    return new Set(raw ? (JSON.parse(raw) as string[]) : []);
  } catch {
    return new Set();
  }
}

function saveConfirmedSet(set: Set<string>) {
  try {
    window.localStorage.setItem(CONFIRMED_KEY, JSON.stringify([...set]));
  } catch {
    /* ignore */
  }
}

function CommunityRoutesPage() {
  const [routes, setRoutes] = useState<Row[]>([]);
  const [filtered, setFiltered] = useState<Row[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [duration, setDuration] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [confirmed, setConfirmed] = useState<Set<string>>(new Set());

  useEffect(() => {
    setConfirmed(getConfirmedSet());

    let active = true;
    (async () => {
      const { getActiveCountry } = await import("@/lib/active-country");
      const { data, error } = await supabase
        .from("community_routes")
        .select(
          // NOTE: `user_id` is deliberately NOT selectable here — migration
          // 20260820193552 revoked it at the column-privilege level for
          // both anon and authenticated ("hide the account-identifying
          // user_id column from community reads"). Requesting it would
          // make PostgREST reject the whole query (42501), not just omit
          // the field. This means the client can never know whether a row
          // is "my own route" — the self-vote check has to live entirely
          // server-side, in confirm_community_route() (SECURITY DEFINER,
          // so it can read user_id internally despite the client-facing
          // column grant not including it).
          "id, title, from_area, to_area, duration_min, status, confirmations, country, created_at",
        )
        .eq("country", getActiveCountry())
        .order("created_at", { ascending: false })
        .limit(100);
      if (!active) return;
      if (error) {
        toast.error("تعذر تحميل الخطوط");
      } else {
        setRoutes((data ?? []) as Row[]);
      }
      setLoading(false);
    })();

    const country = "eg";
    const topic = `community_routes/${country}`;
    const unsubIns = pubsub.subscribe(topic, "insert", (payload) => {
      const row = payload as Row;
      setRoutes((prev) =>
        prev.some((r) => r.id === row.id) ? prev : [row, ...prev].slice(0, 100),
      );
    });
    const unsubUpd = pubsub.subscribe(topic, "update", (payload) => {
      const row = payload as Row;
      setRoutes((prev) => prev.map((r) => (r.id === row.id ? row : r)));
    });

    return () => {
      active = false;
      unsubIns();
      unsubUpd();
    };
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = FormSchema.safeParse({ from, to, duration });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "بيانات غير صالحة");
      return;
    }
    setSubmitting(true);
    try {
      const {
        data: { user },
        error: authError,
      } = await supabase.auth.getUser();
      if (authError || !user) {
        toast.error("يرجى تسجيل الدخول مجددًا لإضافة الخط");
        return;
      }
      const f = parsed.data.from.trim();
      const t = parsed.data.to.trim();
      const { getActiveCountry } = await import("@/lib/active-country");
      const country = getActiveCountry();
      const row = {
        user_id: user.id,
        title: `${f} - ${t}`,
        from_area: f,
        to_area: t,
        duration_min: parsed.data.duration ? Number(parsed.data.duration) : null,
        status: "pending" as const,
        confirmations: 0,
        country,
      };
      const { data: inserted, error } = await supabase
        .from("community_routes")
        .insert(row)
        .select("id,title,from_area,to_area,duration_min,status,confirmations,country,created_at")
        .single();
      setSubmitting(false);
      if (error) {
        toast.error("تعذر حفظ الخط");
        return;
      }
      if (inserted) pubsub.publish(`community_routes/${country}`, "insert", inserted);
      if (inserted)
        setRoutes((prev) =>
          prev.some((r) => r.id === inserted.id) ? prev : [inserted as Row, ...prev].slice(0, 100),
        );
      toast.success("تم إضافة الخط — شكراً لمساهمتك");
      setFrom("");
      setTo("");
      setDuration("");
      setOpen(false);
    } catch {
      toast.error("تعذر حفظ الخط، حاول مجددًا");
    } finally {
      setSubmitting(false);
    }
  };

  const confirmRoute = async (id: string) => {
    if (confirmed.has(id)) return;
    const next = new Set(confirmed);
    next.add(id);
    setConfirmed(next);
    saveConfirmedSet(next);
    const { error } = await supabase.rpc("confirm_community_route", {
      route_id: id,
    });
    if (error) {
      // The client can't know in advance whether a route is "mine" (see
      // the select() comment above), so this rejection is the only signal
      // — cannot_vote_own_route comes from confirm_community_route().
      const message = error.message?.includes("cannot_vote_own_route")
        ? "متقدرش تأكّد خط أنت اللي ضفته"
        : error.message?.includes("duplicate_vote")
          ? "أنت أكّدت الخط ده قبل كده"
          : "تعذر تأكيد الخط";
      toast.error(message);
      next.delete(id);
      setConfirmed(new Set(next));
      saveConfirmedSet(next);
      return;
    }
    toast.success("تم التأكيد");
  };

  return (
    <div dir="rtl" className="min-h-screen bg-background text-foreground">
      <header className="border-b">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
          <Link to="/" className="text-sm text-muted-foreground hover:underline">
            ← الرئيسية
          </Link>
          <h1 className="text-lg font-bold">خطوط مجتمعية</h1>
          <div className="w-16" />
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-10">
        <section className="mb-8 text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-medium text-emerald-600">
            <Map className="size-4" />
            ساهم
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight md:text-4xl">🗺️ خطوط المجتمع</h2>
          <p className="mt-2 text-muted-foreground">
            شارك معرفتك بالشارع — كل خط جديد بإسم اللي ضافه
          </p>
        </section>

        <div className="mb-6 flex justify-center">
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="lg" className="gap-2">
                <Plus className="size-4" />
                أضف خط جديد
              </Button>
            </DialogTrigger>
            <DialogContent dir="rtl">
              <DialogHeader>
                <DialogTitle>أضف خط جديد</DialogTitle>
              </DialogHeader>
              <form onSubmit={submit} className="space-y-3">
                <div>
                  <label className="mb-1 block text-sm">من</label>
                  <Input
                    value={from}
                    onChange={(e) => setFrom(e.target.value)}
                    placeholder="مثلاً: المعادي"
                    maxLength={60}
                    required
                  />
                </div>
                <div>
                  <label className="mb-1 block text-sm">إلى</label>
                  <Input
                    value={to}
                    onChange={(e) => setTo(e.target.value)}
                    placeholder="مثلاً: التحرير"
                    maxLength={60}
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="mb-1 block text-sm">المدة (دقيقة)</label>
                    <Input
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      type="number"
                      min={0}
                      max={300}
                      placeholder="25"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit" className="w-full" disabled={submitting}>
                    {submitting ? "جاري الحفظ..." : "احفظ الخط"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="mx-auto mb-6 max-w-xl">
          <RequestRouteForm variant="compact" source="community" />
        </div>

        {routes.length > 0 && (
          <SemanticSearchBox
            items={routes}
            getText={(r) => `${r.title} ${r.from_area} ${r.to_area}`}
            onFilter={setFiltered}
            placeholder="ابحث عن خط أو منطقة (مثال: مدينة نصر، وسط البلد)..."
          />
        )}

        {loading ? (
          <AsyncState status="loading" skeletonCount={4} />
        ) : routes.length === 0 ? (
          <AsyncState status="empty" emptyMessage="مفيش خطوط لسه — كن أول من يضيف خط!" />
        ) : (filtered ?? routes).length === 0 ? (
          <AsyncState
            status="empty"
            emptyMessage="مفيش نتائج — جرب تفعّل البحث الذكي أعلى الصفحة."
          />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            {(filtered ?? routes).map((r) => {
              const didConfirm = confirmed.has(r.id);
              const ts = trustScore({
                confirmations: r.confirmations,
                created_at: r.created_at,
                status: r.status === "confirmed" ? "verified" : r.status,
              });
              const tlabel = trustLabel(ts);
              const tColor =
                tlabel === "موثوق"
                  ? "bg-emerald-600 hover:bg-emerald-600"
                  : tlabel === "قيد التحقق"
                    ? "bg-amber-500 hover:bg-amber-500"
                    : "bg-muted text-muted-foreground hover:bg-muted";
              return (
                <Card key={r.id} className="p-5">
                  <div className="mb-2 flex items-start justify-between gap-2">
                    <h3 className="text-base font-bold">{r.title}</h3>
                    <div className="flex flex-col items-end gap-1">
                      {r.status === "confirmed" ? (
                        <Badge className="gap-1 bg-emerald-600 hover:bg-emerald-600">
                          <Check className="size-3" />
                          مؤكد
                        </Badge>
                      ) : (
                        <Badge variant="secondary">
                          {Math.min(r.confirmations, CONFIRM_THRESHOLD)}/{CONFIRM_THRESHOLD}
                        </Badge>
                      )}
                      <Badge
                        className={`gap-1 text-[10px] ${tColor}`}
                        title={`موثوقية: ${(ts * 100).toFixed(0)}%`}
                      >
                        <ShieldCheck className="size-2.5" />
                        {tlabel}
                      </Badge>
                    </div>
                  </div>
                  <p className="mb-4 flex items-center gap-2 text-sm text-muted-foreground">
                    <span>{r.from_area}</span>
                    <ArrowLeft className="size-3.5" />
                    <span>{r.to_area}</span>
                  </p>
                  <div className="mb-3 flex gap-4 text-sm">
                    <span>⏱️ {r.duration_min != null ? `${r.duration_min} د` : "—"}</span>
                  </div>
                  {r.status === "pending" && (
                    <Button
                      size="sm"
                      variant={didConfirm ? "secondary" : "outline"}
                      className="w-full gap-2"
                      disabled={didConfirm}
                      onClick={() => confirmRoute(r.id)}
                    >
                      <ThumbsUp className="size-3.5" />
                      {didConfirm ? "أكدت ركوبه" : "أكد أنك ركبته"}
                    </Button>
                  )}
                </Card>
              );
            })}
          </div>
        )}

        <p className="mt-10 flex items-center justify-center gap-1 text-xs text-muted-foreground">
          <ShieldCheck className="size-3.5" />
          نحترم خصوصيتك
        </p>

        <div className="mt-8 text-center">
          <Link to="/">
            <Button variant="ghost" className="gap-1">
              العودة للرئيسية
              <ArrowRight className="size-4 rotate-180" />
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
