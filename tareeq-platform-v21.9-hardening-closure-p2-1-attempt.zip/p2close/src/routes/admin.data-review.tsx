import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AdminPageShell } from "@/components/admin/AdminPageShell";
import { StatCard } from "@/components/admin/StatCard";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Loader2, RefreshCw } from "lucide-react";
import {
  isLayer4AdminReviewEnabled,
  isLayer4bDataQualityEnabled,
  isLayer4cReviewQueueEnabled,
} from "@/lib/flags";
import { ServicePlacesPanel } from "@/components/service-places/ServicePlacesPanel";
import { DataQualityInsights } from "@/components/admin/DataQualityInsights";
import { ReviewQueuePanel } from "@/components/admin/ReviewQueuePanel";

export const Route = createFileRoute("/admin/data-review")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Admin Data Review — Tareeq" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AdminDataReviewPage,
});

// -------- Static file counts via Vite glob (build-time, real numbers) --------
const SRC_DATA_TS_FILES = Object.keys(import.meta.glob("/src/data/**/*.ts", { eager: false }));
const SRC_DATA_JSON_FILES = Object.keys(import.meta.glob("/src/data/**/*.json", { eager: false }));
// public/ is served statically; Vite cannot glob it. Marked as "غير متاح".

// -------- Types --------
type Counts = {
  routes_total: number | null;
  routes_active: number | null;
  routes_verified: number | null;
  stops_total: number | null;
  route_stops_total: number | null;
  aliases_total: number | null;
  train_lines_total: number | null;
  train_stations_total: number | null;
  trains_total: number | null;
  community_routes_total: number | null;
  user_route_suggestions_total: number | null;
  qi_routes_no_stops: number | null;
  qi_stops_no_coords: number | null;
  qi_routes_not_active: number | null;
  qi_routes_missing_source: number | null;
};

const PAGE_SIZE = 25;

function AdminDataReviewPage() {
  const flagOn = isLayer4AdminReviewEnabled();

  if (!flagOn) {
    return (
      <AdminPageShell>
        <div className="max-w-2xl mx-auto p-6 text-center">
          <h1 className="text-xl font-bold mb-2">مراجعة البيانات — Layer 4A</h1>
          <p className="text-muted-foreground text-sm">
            هذه الطبقة غير مفعّلة حاليًا. لتشغيلها في المتصفح مؤقتًا نفّذ في الـ Console:
          </p>
          <code className="mt-3 inline-block bg-muted px-3 py-1 rounded text-xs">
            localStorage.setItem('USE_LAYER_4_ADMIN_REVIEW','true')
          </code>
        </div>
      </AdminPageShell>
    );
  }

  return (
    <AdminPageShell>
      <ReviewContent />
    </AdminPageShell>
  );
}

// -------- Main content --------
function ReviewContent() {
  const [counts, setCounts] = useState<Counts | null>(null);
  const [loadingCounts, setLoadingCounts] = useState(true);
  const [countsError, setCountsError] = useState<string | null>(null);

  const loadCounts = useCallback(async () => {
    setLoadingCounts(true);
    setCountsError(null);
    try {
      // Each `count: exact` query returns { count } without rows.
      const q = (
        tbl:
          | "routes"
          | "stops"
          | "route_stops"
          | "stop_aliases"
          | "train_lines"
          | "train_line_stations"
          | "trains"
          | "community_routes"
          | "user_route_suggestions",
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        build?: (b: any) => any,
      ) => {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let b: any = supabase.from(tbl).select("*", { count: "exact", head: true });
        if (build) b = build(b);
        return b.then((r: { count: number | null; error: unknown }) => ({
          count: r.count ?? null,
          error: r.error ?? null,
        }));
      };

      const [
        routesTotal,
        routesActive,
        routesVerified,
        stopsTotal,
        routeStopsTotal,
        aliasesTotal,
        trainLinesTotal,
        trainStationsTotal,
        trainsTotal,
        communityRoutesTotal,
        userSuggestionsTotal,
        qiRoutesNotActive,
        qiRoutesMissingSource,
        qiStopsNoCoords,
      ] = await Promise.all([
        q("routes"),
        q("routes", (b) => b.eq("status", "active")),
        q("routes", (b) => b.eq("is_verified", true)),
        q("stops"),
        q("route_stops"),
        q("stop_aliases"),
        q("train_lines"),
        q("train_line_stations"),
        q("trains"),
        q("community_routes"),
        q("user_route_suggestions"),
        q("routes", (b) => b.neq("status", "active")),
        q("routes", (b) => b.is("source", null)),
        q("stops", (b) => b.or("latitude.is.null,longitude.is.null")),
      ]);

      setCounts({
        routes_total: routesTotal.count,
        routes_active: routesActive.count,
        routes_verified: routesVerified.count,
        stops_total: stopsTotal.count,
        route_stops_total: routeStopsTotal.count,
        aliases_total: aliasesTotal.count,
        train_lines_total: trainLinesTotal.count,
        train_stations_total: trainStationsTotal.count,
        trains_total: trainsTotal.count,
        community_routes_total: communityRoutesTotal.count,
        user_route_suggestions_total: userSuggestionsTotal.count,
        qi_routes_not_active: qiRoutesNotActive.count,
        qi_routes_missing_source: qiRoutesMissingSource.count,
        qi_stops_no_coords: qiStopsNoCoords.count,
        // Routes with zero stops requires join — deferred as "غير متاح"
        // to avoid a heavy full-table anti-join.
        qi_routes_no_stops: null,
      });
    } catch (err) {
      setCountsError((err as Error).message);
    } finally {
      setLoadingCounts(false);
    }
  }, []);

  useEffect(() => {
    loadCounts();
  }, [loadCounts]);

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-6">
      <header className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div>
          <h1 className="text-2xl font-bold">مراجعة البيانات — للقراءة فقط</h1>
          <p className="text-sm text-muted-foreground">
            Layer 4A — لا يوجد تعديل، لا كتابة، لا استيراد.
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={loadCounts} disabled={loadingCounts}>
          {loadingCounts ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <RefreshCw className="w-4 h-4" />
          )}
          <span className="mr-2">تحديث الأعداد</span>
        </Button>
      </header>

      {countsError && (
        <div className="mb-4 p-3 rounded border border-red-200 bg-red-50 text-red-700 text-sm">
          فشل تحميل الأعداد: {countsError}
        </div>
      )}

      {/* Dashboard cards */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <StatCard label="إجمالي الخطوط" value={counts?.routes_total ?? null} />
        <StatCard label="الخطوط النشطة" value={counts?.routes_active ?? null} />
        <StatCard label="الخطوط الموثقة" value={counts?.routes_verified ?? null} />
        <StatCard label="إجمالي المحطات" value={counts?.stops_total ?? null} />
        <StatCard label="Route stops" value={counts?.route_stops_total ?? null} />
        <StatCard label="الأسماء البديلة" value={counts?.aliases_total ?? null} />
        <StatCard label="خطوط القطارات" value={counts?.train_lines_total ?? null} />
        <StatCard label="محطات القطار" value={counts?.train_stations_total ?? null} />
        <StatCard label="Trains" value={counts?.trains_total ?? null} />
        <StatCard label="Community routes" value={counts?.community_routes_total ?? null} />
        <StatCard
          label="اقتراحات المستخدمين"
          value={counts?.user_route_suggestions_total ?? null}
        />
        <StatCard
          label="ملفات src/data"
          value={SRC_DATA_TS_FILES.length + SRC_DATA_JSON_FILES.length}
          sub={
            <span className="text-[10px]">
              {SRC_DATA_TS_FILES.length} ts / {SRC_DATA_JSON_FILES.length} json
            </span>
          }
        />
        <StatCard label="ملفات public/data" value="غير متاح" />
      </section>

      {/* Data quality cards */}
      <section className="mb-8">
        <h2 className="text-lg font-semibold mb-2">جودة البيانات</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatCard
            label="خطوط بحالة غير active"
            value={counts?.qi_routes_not_active ?? null}
            tone="amber"
          />
          <StatCard
            label="خطوط بدون source"
            value={counts?.qi_routes_missing_source ?? null}
            tone="amber"
          />
          <StatCard
            label="محطات بدون إحداثيات"
            value={counts?.qi_stops_no_coords ?? null}
            tone="amber"
          />
          <StatCard
            label="خطوط بدون محطات"
            value="غير متاح"
            sub={<span className="text-[10px]">يتطلب join كامل — مؤجل للأمان</span>}
            tone="warn"
          />
        </div>
      </section>

      {/* Tables */}
      <RoutesTable />
      <StopsTable />
      <AliasesTable />

      {/* Layer 4B — Data Quality Insights (flag-gated, read-only) */}
      <DataQualityInsightsSection />

      {/* Layer 4C — Review Queue (flag-gated, staging-only writes) */}
      <ReviewQueueSection />
    </div>
  );
}

function DataQualityInsightsSection() {
  const on = isLayer4bDataQualityEnabled();
  if (!on) return null;
  return <DataQualityInsights />;
}

function ReviewQueueSection() {
  const on = isLayer4cReviewQueueEnabled();
  if (!on) return null;
  return <ReviewQueuePanel />;
}

// -------- Routes table --------
type RouteRow = {
  id: string;
  route_code: string | null;
  route_name: string | null;
  transport_type_id: string | null;
  status: string | null;
  is_verified: boolean | null;
  source: string | null;
  updated_at: string | null;
};

function RoutesTable() {
  const [rows, setRows] = useState<RouteRow[]>([]);
  const [total, setTotal] = useState<number | null>(null);
  const [page, setPage] = useState(0);
  const [q, setQ] = useState("");
  const [ttype, setTtype] = useState("");
  const [status, setStatus] = useState("");
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setErr(null);
    try {
      let b = supabase
        .from("routes")
        .select("id,route_code,route_name,transport_type_id,status,is_verified,source,updated_at", {
          count: "exact",
        })
        .order("updated_at", { ascending: false, nullsFirst: false });
      if (q.trim()) b = b.ilike("route_name", `%${q.trim()}%`);
      if (ttype) b = b.eq("transport_type_id", ttype);
      if (status) b = b.eq("status", status);
      if (verifiedOnly) b = b.eq("is_verified", true);
      b = b.range(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE - 1);
      const { data, error, count } = await b;
      if (error) throw error;
      setRows((data ?? []) as RouteRow[]);
      setTotal(count ?? null);
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [q, ttype, status, verifiedOnly, page]);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <section className="mb-8">
      <h2 className="text-lg font-semibold mb-2">Routes</h2>
      <div className="flex flex-wrap gap-2 mb-2">
        <Input
          placeholder="بحث في اسم الخط…"
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setPage(0);
          }}
          className="max-w-xs"
        />
        <select
          className="border rounded px-2 py-1 text-sm bg-background"
          value={ttype}
          onChange={(e) => {
            setTtype(e.target.value);
            setPage(0);
          }}
        >
          <option value="">كل الوسائل</option>
          <option value="bus">bus</option>
          <option value="microbus">microbus</option>
          <option value="minibus">minibus</option>
          <option value="metro">metro</option>
          <option value="train">train</option>
          <option value="brt">brt</option>
        </select>
        <select
          className="border rounded px-2 py-1 text-sm bg-background"
          value={status}
          onChange={(e) => {
            setStatus(e.target.value);
            setPage(0);
          }}
        >
          <option value="">كل الحالات</option>
          <option value="active">active</option>
          <option value="inactive">inactive</option>
          <option value="draft">draft</option>
        </select>
        <label className="flex items-center gap-1 text-sm">
          <input
            type="checkbox"
            checked={verifiedOnly}
            onChange={(e) => {
              setVerifiedOnly(e.target.checked);
              setPage(0);
            }}
          />
          verified فقط
        </label>
      </div>
      {err && <div className="p-2 text-sm text-red-700 bg-red-50 border rounded mb-2">{err}</div>}
      <div className="overflow-x-auto border rounded">
        <table className="min-w-full text-sm">
          <thead className="bg-muted/50">
            <tr>
              <th className="p-2 text-right">Route ID</th>
              <th className="p-2 text-right">اسم</th>
              <th className="p-2 text-right">كود</th>
              <th className="p-2 text-right">وسيلة</th>
              <th className="p-2 text-right">حالة</th>
              <th className="p-2 text-right">verified</th>
              <th className="p-2 text-right">source</th>
              <th className="p-2 text-right">تحديث</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr>
                <td colSpan={8} className="p-6 text-center text-muted-foreground">
                  <Loader2 className="inline w-4 h-4 animate-spin" /> تحميل…
                </td>
              </tr>
            )}
            {!loading && rows.length === 0 && (
              <tr>
                <td colSpan={8} className="p-6 text-center text-muted-foreground">
                  لا نتائج
                </td>
              </tr>
            )}
            {!loading &&
              rows.map((r) => (
                <tr
                  key={r.id}
                  className="border-t cursor-pointer hover:bg-muted/40"
                  onClick={() => setOpenId(r.id)}
                >
                  <td className="p-2 font-mono text-[11px]">{r.id.slice(0, 8)}</td>
                  <td className="p-2">{r.route_name ?? "—"}</td>
                  <td className="p-2">{r.route_code ?? "—"}</td>
                  <td className="p-2">{r.transport_type_id ?? "—"}</td>
                  <td className="p-2">
                    <Badge variant="outline">{r.status ?? "—"}</Badge>
                  </td>
                  <td className="p-2">{r.is_verified ? "✓" : "—"}</td>
                  <td className="p-2">{r.source ?? "—"}</td>
                  <td className="p-2 text-[11px]">
                    {r.updated_at ? new Date(r.updated_at).toLocaleDateString("ar-EG") : "—"}
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
      <Pagination
        page={page}
        setPage={setPage}
        total={total}
        pageSize={PAGE_SIZE}
        currentCount={rows.length}
      />
      <RouteDrawer routeId={openId} onClose={() => setOpenId(null)} />
    </section>
  );
}

// -------- Route drawer --------
type RouteFull = RouteRow & {
  city: string | null;
  country: string | null;
  notes: string | null;
};

function RouteDrawer({ routeId, onClose }: { routeId: string | null; onClose: () => void }) {
  const [row, setRow] = useState<RouteFull | null>(null);
  const [stops, setStops] = useState<
    Array<{ order: number; name: string | null; stop_id: string }>
  >([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (!routeId) return;
    setLoading(true);
    setErr(null);
    setRow(null);
    setStops([]);
    (async () => {
      try {
        const { data: r, error: e1 } = await supabase
          .from("routes")
          .select(
            "id,route_code,route_name,transport_type_id,status,is_verified,source,updated_at,city,country,notes",
          )
          .eq("id", routeId)
          .maybeSingle();
        if (e1) throw e1;
        setRow(r as RouteFull | null);
        const { data: rs, error: e2 } = await supabase
          .from("route_stops")
          .select("stop_order,stop_id,stops(name_ar)")
          .eq("route_id", routeId)
          .order("stop_order", { ascending: true })
          .limit(200);
        if (e2) throw e2;
        setStops(
          (rs ?? []).map(
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            (x: any) => ({
              order: x.stop_order,
              stop_id: x.stop_id,
              name: x.stops?.name_ar ?? null,
            }),
          ),
        );
      } catch (e) {
        setErr((e as Error).message);
      } finally {
        setLoading(false);
      }
    })();
  }, [routeId]);

  return (
    <Sheet open={!!routeId} onOpenChange={(o) => !o && onClose()}>
      <SheetContent side="left" className="w-full sm:max-w-lg overflow-y-auto">
        <SheetHeader>
          <SheetTitle>تفاصيل الخط</SheetTitle>
        </SheetHeader>
        {loading && (
          <div className="p-6 text-center">
            <Loader2 className="inline w-4 h-4 animate-spin" />
          </div>
        )}
        {err && <div className="p-3 text-sm bg-red-50 text-red-700 rounded">{err}</div>}
        {row && (
          <div className="mt-4 space-y-3 text-sm">
            <KV k="ID" v={row.id} mono />
            <KV k="الاسم" v={row.route_name} />
            <KV k="الكود" v={row.route_code} />
            <KV k="وسيلة" v={row.transport_type_id} />
            <KV k="حالة" v={row.status} />
            <KV k="verified" v={row.is_verified ? "true" : "false"} />
            <KV k="مدينة" v={row.city} />
            <KV k="دولة" v={row.country} />
            <KV k="source" v={row.source} />
            <KV k="آخر تحديث" v={row.updated_at} />
            {row.notes && (
              <div>
                <div className="text-muted-foreground">ملاحظات</div>
                <div className="whitespace-pre-wrap">{row.notes}</div>
              </div>
            )}
            <div>
              <div className="font-semibold mb-1">المحطات ({stops.length})</div>
              {stops.length === 0 && (
                <div className="text-muted-foreground text-xs">لا محطات مسجلة لهذا الخط.</div>
              )}
              <ol className="space-y-1 list-decimal pr-4">
                {stops.map((s) => (
                  <li key={s.stop_id + "-" + s.order}>
                    <span>{s.name ?? s.stop_id.slice(0, 8)}</span>
                    <span className="text-muted-foreground text-[11px] mr-2">
                      {s.stop_id.slice(0, 8)}
                    </span>
                  </li>
                ))}
              </ol>
            </div>
            <div className="pt-2 border-t">
              <a
                href={`/route/${row.id}`}
                target="_blank"
                rel="noreferrer"
                className="text-primary underline text-xs"
              >
                فتح صفحة الخط العامة ↗
              </a>
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}

// -------- Stops table --------
type StopRow = {
  id: string;
  name_ar: string | null;
  name_en: string | null;
  latitude: number | null;
  longitude: number | null;
  source: string | null;
};

function StopsTable() {
  const [rows, setRows] = useState<StopRow[]>([]);
  const [total, setTotal] = useState<number | null>(null);
  const [page, setPage] = useState(0);
  const [q, setQ] = useState("");
  const [hasCoords, setHasCoords] = useState<"all" | "yes" | "no">("all");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setErr(null);
    try {
      let b = supabase
        .from("stops")
        .select("id,name_ar,name_en,latitude,longitude,source", { count: "exact" })
        .order("name_ar", { ascending: true });
      if (q.trim()) b = b.ilike("name_ar", `%${q.trim()}%`);
      if (hasCoords === "yes") b = b.not("latitude", "is", null).not("longitude", "is", null);
      if (hasCoords === "no") b = b.or("latitude.is.null,longitude.is.null");
      b = b.range(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE - 1);
      const { data, error, count } = await b;
      if (error) throw error;
      setRows((data ?? []) as StopRow[]);
      setTotal(count ?? null);
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [q, hasCoords, page]);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <section className="mb-8">
      <h2 className="text-lg font-semibold mb-2">Stops</h2>
      <div className="flex flex-wrap gap-2 mb-2">
        <Input
          placeholder="بحث في اسم المحطة…"
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setPage(0);
          }}
          className="max-w-xs"
        />
        <select
          className="border rounded px-2 py-1 text-sm bg-background"
          value={hasCoords}
          onChange={(e) => {
            setHasCoords(e.target.value as typeof hasCoords);
            setPage(0);
          }}
        >
          <option value="all">كل المحطات</option>
          <option value="yes">لديها إحداثيات</option>
          <option value="no">بدون إحداثيات</option>
        </select>
      </div>
      {err && <div className="p-2 text-sm text-red-700 bg-red-50 border rounded mb-2">{err}</div>}
      <div className="overflow-x-auto border rounded">
        <table className="min-w-full text-sm">
          <thead className="bg-muted/50">
            <tr>
              <th className="p-2 text-right">Stop ID</th>
              <th className="p-2 text-right">اسم عربي</th>
              <th className="p-2 text-right">اسم إنجليزي</th>
              <th className="p-2 text-right">Lat</th>
              <th className="p-2 text-right">Lng</th>
              <th className="p-2 text-right">source</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr>
                <td colSpan={6} className="p-6 text-center text-muted-foreground">
                  <Loader2 className="inline w-4 h-4 animate-spin" /> تحميل…
                </td>
              </tr>
            )}
            {!loading && rows.length === 0 && (
              <tr>
                <td colSpan={6} className="p-6 text-center text-muted-foreground">
                  لا نتائج
                </td>
              </tr>
            )}
            {!loading &&
              rows.map((r) => (
                <tr
                  key={r.id}
                  className="border-t cursor-pointer hover:bg-muted/40"
                  onClick={() => setOpenId(r.id)}
                >
                  <td className="p-2 font-mono text-[11px]">{r.id.slice(0, 8)}</td>
                  <td className="p-2">{r.name_ar ?? "—"}</td>
                  <td className="p-2">{r.name_en ?? "—"}</td>
                  <td className="p-2 text-[11px]">{r.latitude ?? "—"}</td>
                  <td className="p-2 text-[11px]">{r.longitude ?? "—"}</td>
                  <td className="p-2">{r.source ?? "—"}</td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
      <Pagination
        page={page}
        setPage={setPage}
        total={total}
        pageSize={PAGE_SIZE}
        currentCount={rows.length}
      />
      <StopDrawer stopId={openId} onClose={() => setOpenId(null)} />
    </section>
  );
}

function StopDrawer({ stopId, onClose }: { stopId: string | null; onClose: () => void }) {
  const [row, setRow] = useState<StopRow | null>(null);
  const [routes, setRoutes] = useState<Array<{ id: string; name: string | null }>>([]);
  const [aliases, setAliases] = useState<
    Array<{ id: string; alias: string; source: string | null }>
  >([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (!stopId) return;
    setLoading(true);
    setErr(null);
    setRow(null);
    setRoutes([]);
    setAliases([]);
    (async () => {
      try {
        const { data: s, error: e1 } = await supabase
          .from("stops")
          .select("id,name_ar,name_en,latitude,longitude,source")
          .eq("id", stopId)
          .maybeSingle();
        if (e1) throw e1;
        setRow(s as StopRow | null);
        const { data: rs } = await supabase
          .from("route_stops")
          .select("route_id,routes(route_name)")
          .eq("stop_id", stopId)
          .limit(100);
        setRoutes(
          (rs ?? []).map(
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            (x: any) => ({ id: x.route_id, name: x.routes?.route_name ?? null }),
          ),
        );
        const { data: al } = await supabase
          .from("stop_aliases")
          .select("id,alias,source")
          .eq("stop_id", stopId)
          .limit(50);
        setAliases((al ?? []) as typeof aliases);
      } catch (e) {
        setErr((e as Error).message);
      } finally {
        setLoading(false);
      }
    })();
  }, [stopId]);

  return (
    <Sheet open={!!stopId} onOpenChange={(o) => !o && onClose()}>
      <SheetContent side="left" className="w-full sm:max-w-lg overflow-y-auto">
        <SheetHeader>
          <SheetTitle>تفاصيل المحطة</SheetTitle>
        </SheetHeader>
        {loading && (
          <div className="p-6 text-center">
            <Loader2 className="inline w-4 h-4 animate-spin" />
          </div>
        )}
        {err && <div className="p-3 text-sm bg-red-50 text-red-700 rounded">{err}</div>}
        {row && (
          <div className="mt-4 space-y-3 text-sm">
            <KV k="ID" v={row.id} mono />
            <KV k="اسم عربي" v={row.name_ar} />
            <KV k="اسم إنجليزي" v={row.name_en} />
            <KV
              k="إحداثيات"
              v={row.latitude != null ? `${row.latitude}, ${row.longitude}` : null}
            />
            <KV k="source" v={row.source} />
            <div>
              <div className="font-semibold mb-1">خطوط تخدم هذه المحطة ({routes.length})</div>
              {routes.length === 0 && <div className="text-muted-foreground text-xs">—</div>}
              <ul className="space-y-1">
                {routes.map((r) => (
                  <li key={r.id} className="text-xs">
                    <span className="font-mono text-muted-foreground">{r.id.slice(0, 8)}</span> —{" "}
                    {r.name ?? "—"}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <div className="font-semibold mb-1">الأسماء البديلة ({aliases.length})</div>
              {aliases.length === 0 && <div className="text-muted-foreground text-xs">—</div>}
              <ul className="space-y-1">
                {aliases.map((a) => (
                  <li key={a.id} className="text-xs">
                    {a.alias}
                    {a.source && <span className="text-muted-foreground"> — {a.source}</span>}
                  </li>
                ))}
              </ul>
            </div>
            {row.name_ar && (
              <div>
                <div className="font-semibold mb-1">أماكن الخدمة (Layer 3)</div>
                <ServicePlacesPanel stopName={row.name_ar} variant="stop-page" />
              </div>
            )}
            <div className="pt-2 border-t">
              <a
                href={`/stop/${row.id}`}
                target="_blank"
                rel="noreferrer"
                className="text-primary underline text-xs"
              >
                فتح صفحة المحطة العامة ↗
              </a>
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}

// -------- Aliases table --------
type AliasRow = {
  id: string;
  alias: string;
  normalized_alias: string | null;
  stop_id: string | null;
  source: string | null;
};

function AliasesTable() {
  const [rows, setRows] = useState<AliasRow[]>([]);
  const [total, setTotal] = useState<number | null>(null);
  const [page, setPage] = useState(0);
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setErr(null);
    try {
      let b = supabase
        .from("stop_aliases")
        .select("id,alias,normalized_alias,stop_id,source", { count: "exact" })
        .order("alias", { ascending: true });
      if (q.trim()) b = b.ilike("alias", `%${q.trim()}%`);
      b = b.range(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE - 1);
      const { data, error, count } = await b;
      if (error) throw error;
      setRows((data ?? []) as AliasRow[]);
      setTotal(count ?? null);
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [q, page]);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <section className="mb-8">
      <h2 className="text-lg font-semibold mb-2">Stop Aliases</h2>
      <div className="flex flex-wrap gap-2 mb-2">
        <Input
          placeholder="بحث بالاسم البديل…"
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setPage(0);
          }}
          className="max-w-xs"
        />
      </div>
      {err && <div className="p-2 text-sm text-red-700 bg-red-50 border rounded mb-2">{err}</div>}
      <div className="overflow-x-auto border rounded">
        <table className="min-w-full text-sm">
          <thead className="bg-muted/50">
            <tr>
              <th className="p-2 text-right">Alias</th>
              <th className="p-2 text-right">Normalized</th>
              <th className="p-2 text-right">Stop ID</th>
              <th className="p-2 text-right">Source</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr>
                <td colSpan={4} className="p-6 text-center text-muted-foreground">
                  <Loader2 className="inline w-4 h-4 animate-spin" /> تحميل…
                </td>
              </tr>
            )}
            {!loading && rows.length === 0 && (
              <tr>
                <td colSpan={4} className="p-6 text-center text-muted-foreground">
                  لا نتائج
                </td>
              </tr>
            )}
            {!loading &&
              rows.map((r) => (
                <tr key={r.id} className="border-t">
                  <td className="p-2">{r.alias}</td>
                  <td className="p-2 text-[11px] text-muted-foreground">
                    {r.normalized_alias ?? "—"}
                  </td>
                  <td className="p-2 font-mono text-[11px]">
                    {r.stop_id ? (
                      r.stop_id.slice(0, 8)
                    ) : (
                      <span className="text-red-600">— بلا محطة</span>
                    )}
                  </td>
                  <td className="p-2">{r.source ?? "—"}</td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
      <Pagination
        page={page}
        setPage={setPage}
        total={total}
        pageSize={PAGE_SIZE}
        currentCount={rows.length}
      />
    </section>
  );
}

// -------- Helpers --------
function Pagination({
  page,
  setPage,
  total,
  pageSize,
  currentCount,
}: {
  page: number;
  setPage: (n: number) => void;
  total: number | null;
  pageSize: number;
  currentCount: number;
}) {
  const maxPage = total == null ? null : Math.max(0, Math.ceil(total / pageSize) - 1);
  return (
    <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
      <div>
        {total != null
          ? `صفحة ${page + 1} من ${(maxPage ?? 0) + 1} — الإجمالي ${new Intl.NumberFormat("ar-EG").format(total)}`
          : `${currentCount} صف`}
      </div>
      <div className="flex gap-1">
        <Button
          size="sm"
          variant="outline"
          disabled={page === 0}
          onClick={() => setPage(Math.max(0, page - 1))}
        >
          السابق
        </Button>
        <Button
          size="sm"
          variant="outline"
          disabled={maxPage != null && page >= maxPage}
          onClick={() => setPage(page + 1)}
        >
          التالي
        </Button>
      </div>
    </div>
  );
}

function KV({ k, v, mono }: { k: string; v: string | number | null | undefined; mono?: boolean }) {
  return (
    <div className="flex justify-between gap-2">
      <span className="text-muted-foreground">{k}</span>
      <span className={mono ? "font-mono text-[11px]" : ""}>
        {v == null || v === "" ? "—" : String(v)}
      </span>
    </div>
  );
}
