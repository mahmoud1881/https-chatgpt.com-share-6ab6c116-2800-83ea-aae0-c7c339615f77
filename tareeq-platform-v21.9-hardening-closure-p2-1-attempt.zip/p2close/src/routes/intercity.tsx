import { createFileRoute, Link } from "@tanstack/react-router";
import { usePublishSnapshot } from "@/hooks/use-publish-snapshot";
import { lazy, Suspense } from "react";
import { ArrowRight, Bus, ShieldCheck } from "lucide-react";
import { Card } from "@/components/ui/card";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { egHead, getEgPage } from "@/lib/seo/eg-meta";

const IntercityBusCompanies = lazy(() =>
  import("@/components/IntercityBusCompanies").then((m) => ({ default: m.IntercityBusCompanies })),
);

export const Route = createFileRoute("/intercity")({
  head: () => {
    const p = getEgPage("/intercity")!;
    return egHead({
      path: p.path,
      titleAr: p.titleAr,
      descAr: p.descAr,
      ogImage: p.ogImage,
      breadcrumbLabel: "التنقل بين المحافظات",
    });
  },
  component: IntercityPage,
});

function IntercityPage() {
  usePublishSnapshot({
    id: "eg:intercity",
    source: "التنقل بين المحافظات",
    title: "شركات الأتوبيس",
    summary: "شركات النقل بين المحافظات ومحطاتها",
    category: "transit",
    href: "/intercity",
  });
  return (
    <div dir="rtl" className="min-h-screen bg-background px-4 py-10">
      <div className="mx-auto max-w-3xl space-y-6">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowRight className="size-4" />
          العودة للرئيسية
        </Link>

        <header className="space-y-3 text-center">
          <div className="inline-flex items-center justify-center rounded-full bg-primary/10 p-3">
            <Bus className="size-7 text-primary" />
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight md:text-4xl">
            التنقل بين المحافظات
          </h1>
          <p className="mx-auto max-w-xl text-muted-foreground">
            شركات النقل الإقليمي والسياحي بين محافظات مصر — مواقف، خطوط ساخنة، ومحطات الانطلاق على
            الخريطة.
          </p>
        </header>

        <Card className="space-y-3 p-4">
          <ErrorBoundary boundary="IntercityBusCompanies">
            <Suspense fallback={<div className="text-xs text-muted-foreground">جارٍ التحميل…</div>}>
              <IntercityBusCompanies />
            </Suspense>
          </ErrorBoundary>
        </Card>

        <div className="flex items-center justify-center gap-2 pt-4 text-xs text-muted-foreground">
          <ShieldCheck className="size-4" />
          نحترم خصوصيتك
        </div>
      </div>
    </div>
  );
}
