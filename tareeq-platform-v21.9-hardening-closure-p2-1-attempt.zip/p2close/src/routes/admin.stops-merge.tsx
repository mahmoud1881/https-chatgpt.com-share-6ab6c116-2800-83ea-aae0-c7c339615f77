import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { AdminPageShell } from "@/components/admin/AdminPageShell";
import { useWindowedList } from "@/hooks/use-windowed-list";
import { toast } from "sonner";
import { listDuplicateStops, mergeStops } from "@/lib/route-planner/admin-merge.functions";
import { Loader2, CheckCircle2, Link2 } from "lucide-react";

export const Route = createFileRoute("/admin/stops-merge")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "دمج المحطات — Tareeq Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: StopsMergePage,
});

const COUNTRIES = [
  { code: "eg", label: "🇪🇬 مصر" },
  { code: "ly", label: "🇱🇾 ليبيا" },
  { code: "iq", label: "🇮🇶 العراق" },
  { code: "sy", label: "🇸🇾 سوريا" },
  { code: "sd", label: "🇸🇩 السودان" },
  { code: "ye", label: "🇾🇪 اليمن" },
];

type Stop = { id: string; name_ar: string; is_verified: boolean; city: string | null };
type Group = { normalized_name: string; city: string | null; stops: Stop[] };

function StopsMergePage() {
  const navigate = useNavigate();
  const [country, setCountry] = useState("eg");
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(false);
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [primaryChoice, setPrimaryChoice] = useState<Record<string, string>>({});

  const listFn = useServerFn(listDuplicateStops);
  const mergeFn = useServerFn(mergeStops);
  const { visibleItems: visibleGroups, SentinelComponent } = useWindowedList(groups, {
    initial: 40,
    batch: 40,
  });

  async function scan() {
    setLoading(true);
    setGroups([]);
    try {
      const res = await listFn({ data: { country } });
      setGroups(res.groups as Group[]);
      if (res.groups.length === 0) toast.success("لا توجد محطات مكررة 🎉");
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  async function doMerge(group: Group) {
    const key = `${group.city ?? ""}::${group.normalized_name}`;
    const primaryId =
      primaryChoice[key] ?? group.stops.find((s) => s.is_verified)?.id ?? group.stops[0].id;
    const loserIds = group.stops.filter((s) => s.id !== primaryId).map((s) => s.id);
    if (loserIds.length === 0) return;
    if (!confirm(`دمج ${loserIds.length} محطة داخل المحطة المختارة؟`)) return;
    setBusyKey(key);
    try {
      const res = await mergeFn({ data: { primaryId, loserIds } });
      toast.success(`تم دمج ${res.merged} محطة`);
      setGroups((gs) => gs.filter((g) => `${g.city ?? ""}::${g.normalized_name}` !== key));
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setBusyKey(null);
    }
  }

  return (
    <AdminPageShell>
      <header className="px-4 pt-6 pb-4 flex items-center justify-between">
        <Link to="/admin/data-health" className="text-xs underline text-muted-foreground">
          ← صحّة البيانات
        </Link>
        <h1 className="text-lg font-bold flex items-center gap-2">
          <Link2 className="w-5 h-5" /> دمج المحطات
        </h1>
      </header>

      <div className="px-4 flex items-center gap-2">
        <select
          value={country}
          onChange={(e) => setCountry(e.target.value)}
          className="rounded-xl border bg-background px-3 py-2 text-sm"
        >
          {COUNTRIES.map((c) => (
            <option key={c.code} value={c.code}>
              {c.label}
            </option>
          ))}
        </select>
        <button
          onClick={scan}
          disabled={loading}
          className="rounded-xl bg-primary text-primary-foreground px-4 py-2 text-sm font-bold disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-4 h-4 inline animate-spin" /> : "🔍"} ابحث عن مكررات
        </button>
        <span className="text-xs text-muted-foreground">{groups.length} مجموعة</span>
      </div>

      <ul className="px-4 mt-4 space-y-3">
        {visibleGroups.map((g) => {
          const key = `${g.city ?? ""}::${g.normalized_name}`;
          const currentPrimary =
            primaryChoice[key] ?? g.stops.find((s) => s.is_verified)?.id ?? g.stops[0].id;
          return (
            <li key={key} className="rounded-2xl border bg-card p-3">
              <div className="text-[11px] text-muted-foreground mb-2">
                {g.city ?? "بلا مدينة"} · <span className="font-mono">{g.normalized_name}</span> ·{" "}
                {g.stops.length} نسخة
              </div>
              <div className="space-y-1">
                {g.stops.map((s) => (
                  <label
                    key={s.id}
                    className="flex items-center gap-2 rounded-lg border p-2 hover:bg-muted cursor-pointer"
                  >
                    <input
                      type="radio"
                      name={`primary-${key}`}
                      checked={currentPrimary === s.id}
                      onChange={() => setPrimaryChoice((p) => ({ ...p, [key]: s.id }))}
                    />
                    <span className="text-sm flex-1">{s.name_ar}</span>
                    {s.is_verified && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
                    <span className="text-[10px] text-muted-foreground font-mono">
                      {s.id.slice(0, 8)}
                    </span>
                  </label>
                ))}
              </div>
              <div className="flex justify-end mt-2">
                <button
                  onClick={() => doMerge(g)}
                  disabled={busyKey === key}
                  className="text-xs rounded-full bg-primary text-primary-foreground px-3 py-1.5 disabled:opacity-50"
                >
                  {busyKey === key ? (
                    <Loader2 className="w-3 h-3 inline animate-spin" />
                  ) : (
                    "ادمج داخل المختار"
                  )}
                </button>
              </div>
            </li>
          );
        })}
        <SentinelComponent />
      </ul>
    </AdminPageShell>
  );
}
