// Programmatic trips sub-sitemap — thousands of /trip/$from/$to URLs.
import { createFileRoute } from "@tanstack/react-router";
import { getAllTripPaths } from "@/data/popularPairs";

import { SITE_BASE_URL as BASE } from "@/lib/seo/site";

export const Route = createFileRoute("/sitemap-trips.xml")({
  server: {
    handlers: {
      GET: async () => {
        const urls = getAllTripPaths().map(
          (path) =>
            `  <url><loc>${BASE}${path}</loc><changefreq>monthly</changefreq><priority>0.6</priority></url>`,
        );
        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...urls,
          `</urlset>`,
        ].join("\n");
        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml; charset=utf-8",
            "Cache-Control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
