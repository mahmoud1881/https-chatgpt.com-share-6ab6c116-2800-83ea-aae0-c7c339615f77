import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Route as RouteIcon, MapPin } from "lucide-react";
import LazyTransitMap from "@/components/LazyTransitMap";
import { ServicePlacesPanel } from "@/components/service-places/ServicePlacesPanel";
import { getLocalStop, getLocalStopRoutes } from "@/lib/local-data";
import { gmapsQuery } from "@/lib/geo/gmaps";
import { SITE_BASE_URL as SITE_URL } from "@/lib/seo/site";
import { NotFoundState } from "@/components/NotFoundState";

type StopData = {
  id: string;
  name: string | null;
  stop_type: string | null;
  area: string | null;
  governorate: string | null;
  lat: number | null;
  lng: number | null;
};

type RouteLink = {
  id: string;
  route_id: string | null;
  route_name_ar: string | null;
  route_name: string | null;
  transport_mode: string | null;
  sequence_order: number | null;
};

export const Route = createFileRoute("/stop/$stopId")({
  head: ({ params }) => {
    const stop = getLocalStop(params.stopId) as StopData | null;
    const title = stop?.name || `محطة ${params.stopId}`;
    const fullTitle = `${title} — مواصلات مصر`;
    const description = stop
      ? `معلومات ${title}${stop.area ? ` بمنطقة ${stop.area}` : ""}${stop.governorate ? ` (${stop.governorate})` : ""} والخطوط المارة بها.`
      : "تفاصيل موقف ومحطة نقل عام في مصر.";
    const url = `${SITE_URL}/stop/${params.stopId}`;
    const placeLd: Record<string, unknown> = {
      "@context": "https://schema.org",
      "@type": "BusStation",
      name: title,
      url,
    };
    if (stop?.area || stop?.governorate) {
      placeLd.address = {
        "@type": "PostalAddress",
        addressLocality: stop?.area ?? undefined,
        addressRegion: stop?.governorate ?? undefined,
        addressCountry: "EG",
      };
    }
    if (stop?.lat != null && stop?.lng != null) {
      placeLd.geo = { "@type": "GeoCoordinates", latitude: stop.lat, longitude: stop.lng };
    }
    return {
      meta: [
        { title: fullTitle },
        { name: "description", content: description },
        { property: "og:title", content: fullTitle },
        { property: "og:description", content: description },
        { property: "og:type", content: "article" },
        { property: "og:url", content: url },
        { name: "twitter:title", content: fullTitle },
        { name: "twitter:description", content: description },
      ],
      links: [{ rel: "canonical", href: url }],
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "الرئيسية", item: SITE_URL },
              { "@type": "ListItem", position: 2, name: "المواقف", item: `${SITE_URL}/stops` },
              { "@type": "ListItem", position: 3, name: title, item: url },
            ],
          }),
        },
        { type: "application/ld+json", children: JSON.stringify(placeLd) },
      ],
    };
  },
  component: StopDetailPage,
  notFoundComponent: () => (
    <NotFoundState
      title="المحطة غير موجودة"
      description="لم نجد هذا الموقف في قاعدة البيانات. ابحث عن المحطة بالاسم أو استعرض المواقف القريبة."
      suggestions={[
        { to: "/stops", label: "كل المحطات" },
        { to: "/nearby", label: "قريب مني" },
        { to: "/bus-stations", label: "مواقف الأتوبيسات" },
      ]}
    />
  ),
});

function StopDetailPage() {
  const { stopId } = Route.useParams();
  const stop = getLocalStop(stopId) as StopData | null;
  const routes = getLocalStopRoutes(stopId) as RouteLink[];
  const [nearby, setNearby] = useState<
    Array<{ id: string; name: string; lat: number; lng: number; distanceKm: number; type?: string }>
  >([]);
  const [traffic, setTraffic] = useState<{
    count: number;
    worst: "low" | "medium" | "high" | null;
  } | null>(null);

  // أقرب المحطات — lazy، يعمل فقط لو فيه إحداثيات
  useEffect(() => {
    if (!stop?.lat || !stop?.lng) return;
    let cancelled = false;
    const t = setTimeout(async () => {
      try {
        const { nearestPoints } = await import("@/lib/transit/geo");
        const pts = await nearestPoints({ lat: stop.lat!, lng: stop.lng! }, 6, 3);
        // استبعاد المحطة نفسها
        const filtered = pts
          .filter((p) => !p.id.endsWith(`:${stopId}`) && p.name !== stop.name)
          .slice(0, 5);
        if (!cancelled) setNearby(filtered);
      } catch {
        /* best-effort — safe to ignore */
      }
    }, 600);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [stop?.lat, stop?.lng, stop?.name, stopId]);

  // ملخّص زحمة المنطقة — lazy، Realtime engine
  useEffect(() => {
    const area = stop?.area || stop?.name;
    if (!area) return;
    let cancelled = false;
    const t = setTimeout(async () => {
      try {
        const { trafficSummaryFor } = await import("@/lib/transit/realtime");
        const s = await trafficSummaryFor(area);
        if (!cancelled && s.count > 0) setTraffic(s);
      } catch {
        /* best-effort — safe to ignore */
      }
    }, 800);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [stop?.area, stop?.name]);

  if (!stop) {
    return (
      <div dir="rtl" className="min-h-screen px-4 py-10">
        <div className="mx-auto max-w-2xl space-y-4 text-center">
          <h1 className="text-2xl font-bold">المحطة غير موجودة</h1>
          <Link to="/explore" className="inline-flex items-center gap-2 text-sm text-primary">
            <ArrowRight className="size-4" /> رجوع للمستكشف
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div dir="rtl" className="min-h-screen bg-background px-4 py-8">
      <div className="mx-auto max-w-3xl space-y-6">
        <Link
          to="/explore"
          search={{ tab: "stops", q: "", mode: "all" }}
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowRight className="size-4" /> رجوع للمستكشف
        </Link>

        <header className="space-y-2">
          {stop.stop_type && <Badge>{stop.stop_type}</Badge>}
          <h1 className="text-2xl font-extrabold leading-tight md:text-3xl">{stop.name}</h1>
          {(stop.area || stop.governorate) && (
            <p className="text-sm text-muted-foreground">
              {[stop.area, stop.governorate].filter(Boolean).join(" • ")}
            </p>
          )}
          {stop.lat && stop.lng && (
            <a
              href={gmapsQuery(stop.lat, stop.lng)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block text-sm text-primary hover:underline"
            >
              📍 فتح على الخريطة
            </a>
          )}
          {traffic && traffic.worst && (
            <Badge
              className={
                traffic.worst === "high"
                  ? "bg-red-600 text-white hover:bg-red-600"
                  : traffic.worst === "medium"
                    ? "bg-orange-500 text-white hover:bg-orange-500"
                    : "bg-yellow-500 text-white hover:bg-yellow-500"
              }
            >
              🚦 زحمة{" "}
              {traffic.worst === "high" ? "شديدة" : traffic.worst === "medium" ? "متوسطة" : "خفيفة"}{" "}
              • {traffic.count} بلاغ
            </Badge>
          )}
        </header>

        <ServicePlacesPanel stopName={stop.name} variant="stop-page" initialCap={5} />

        <section className="space-y-3">
          <h2 className="flex items-center gap-2 text-lg font-bold">
            <RouteIcon className="size-5" /> ماذا يمر بهذه المحطة ({routes.length})
          </h2>
          {routes.length === 0 ? (
            <Card className="p-6 text-center text-sm text-muted-foreground">
              لا توجد خطوط مسجلة تمر بهذه المحطة في قاعدة بياناتنا حالياً.
              <br />
              <span className="text-xs">جرّب فتح صفحة المستكشف للبحث بالاسم.</span>
            </Card>
          ) : (
            (() => {
              const byMode = new Map<string, RouteLink[]>();
              for (const r of routes) {
                const m = (r.transport_mode || "غير محدد") as string;
                const arr = byMode.get(m) ?? [];
                arr.push(r);
                byMode.set(m, arr);
              }
              const modeLabel: Record<string, string> = {
                bus: "🚌 أتوبيس",
                minibus: "🚐 ميني باص",
                microbus: "🚖 ميكروباص",
                metro: "🚇 مترو",
                brt: "🛣️ BRT",
                tram: "🚋 ترام",
              };
              return Array.from(byMode.entries()).map(([mode, list]) => (
                <div key={mode} className="space-y-2">
                  <div className="flex items-center gap-2 text-sm font-semibold text-muted-foreground">
                    <span>{modeLabel[mode] ?? mode}</span>
                    <Badge variant="outline" className="text-xs">
                      {list.length}
                    </Badge>
                  </div>
                  <div className="grid gap-2">
                    {list.map((r) =>
                      r.route_id ? (
                        <Link key={r.id} to="/route/$routeId" params={{ routeId: r.route_id }}>
                          <Card className="flex items-center justify-between p-3 transition hover:bg-accent">
                            <span className="font-medium">
                              {r.route_name_ar || r.route_name || r.route_id}
                            </span>
                            {r.transport_mode && (
                              <Badge variant="secondary" className="text-xs">
                                {r.transport_mode}
                              </Badge>
                            )}
                          </Card>
                        </Link>
                      ) : null,
                    )}
                  </div>
                </div>
              ));
            })()
          )}
        </section>

        {stop.lat && stop.lng && (
          <section className="space-y-3">
            <h2 className="flex items-center gap-2 text-lg font-bold">
              <MapPin className="size-5" /> الخريطة
            </h2>
            <Card className="overflow-hidden p-0">
              <LazyTransitMap
                points={[
                  {
                    id: stopId,
                    name: stop.name || "المحطة",
                    lat: stop.lat,
                    lng: stop.lng,
                    color: "#dc2626",
                  },
                  ...nearby
                    .map((p) => ({
                      id: p.id,
                      name: p.name,
                      lat: p.lat,
                      lng: p.lng,
                      color: "#2563eb",
                    }))
                    .filter((p) => Number.isFinite(p.lat) && Number.isFinite(p.lng)),
                ]}
                defaultCenter={{ lat: stop.lat, lng: stop.lng }}
                height={320}
              />
            </Card>
          </section>
        )}

        {nearby.length > 0 && (
          <section className="space-y-3">
            <h2 className="flex items-center gap-2 text-lg font-bold">
              <MapPin className="size-5" /> أقرب المحطات
            </h2>
            <div className="grid gap-2 sm:grid-cols-2">
              {nearby.map((p) => (
                <Card key={p.id} className="flex items-center justify-between p-3">
                  <span className="font-medium">{p.name}</span>
                  <Badge variant="outline" className="text-xs">
                    {p.distanceKm < 1
                      ? `${Math.round(p.distanceKm * 1000)} م`
                      : `${p.distanceKm.toFixed(1)} كم`}
                  </Badge>
                </Card>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
