import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowRight, Bell, BellOff, BellRing, Trash2, Plus, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import {
  addSub,
  canNotify,
  readSubs,
  removeSub,
  requestNotificationPermission,
  startAlertsWatcher,
  type AlertSub,
} from "@/lib/transit/alerts";
import { usePublishSnapshot } from "@/hooks/use-publish-snapshot";

import { AuthGateLoading } from "@/components/AuthGateLoading";
import { useRequireAuth } from "@/hooks/useRequireAuth";

export const Route = createFileRoute("/alerts")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "تنبيهات المواصلات — اشتراكات الزحمة" },
      {
        name: "description",
        content: "اشترك في تنبيهات زحمة لخطوط ومناطق معينة، يصلك إشعار فوري عند البلاغات.",
      },
    ],
  }),
  component: AlertsRoute,
});

/** بوابة استخدام: يتطلب تسجيل دخول قبل عرض هذه الصفحة (مش مجرد تصفح). */
function AlertsRoute() {
  const authStatus = useRequireAuth();
  if (authStatus !== "authenticated") return <AuthGateLoading />;
  return <AlertsPage />;
}

function AlertsPage() {
  const [subs, setSubs] = useState<AlertSub[]>([]);
  const [keyword, setKeyword] = useState("");
  const [minSev, setMinSev] = useState<1 | 2 | 3>(1);
  const [permission, setPermission] = useState<NotificationPermission | "unsupported">("default");

  useEffect(() => {
    setSubs(readSubs());
    if (typeof Notification === "undefined") setPermission("unsupported");
    else setPermission(Notification.permission);
  }, []);

  // نشر snapshot للمساعد الذكي المحلي
  usePublishSnapshot(
    subs.length > 0
      ? {
          id: "eg:alerts",
          source: "تنبيهات المواصلات",
          title: `${subs.length} اشتراك تنبيهات نشط`,
          summary: `المستخدم مشترك في ${subs.length} تنبيه، أعلى مستوى حدة: ${Math.max(...subs.map((s) => s.minSeverity ?? 1))}. الكلمات المتابعة: ${subs
            .map((s) => s.keyword)
            .slice(0, 3)
            .join("، ")}.`,
          metrics: { subscriptions: subs.length },
          href: "/alerts",
          category: "alerts",
        }
      : null,
    [subs.length],
  );

  useEffect(() => {
    if (subs.length === 0) return;
    const stop = startAlertsWatcher((report, sub) => {
      toast.warning(`🚨 تنبيه: ${sub.keyword}`, {
        description: `${report.area}${report.notes ? ` — ${report.notes}` : ""}`,
      });
    });
    return stop;
  }, [subs.length]);

  const enablePermission = async () => {
    const r = await requestNotificationPermission();
    setPermission(r);
    if (r === "granted") toast.success("تم تفعيل التنبيهات");
    else if (r === "denied") toast.error("تم رفض الإذن. فعّله من إعدادات المتصفح.");
  };

  const add = () => {
    const s = addSub(keyword, minSev);
    if (!s) {
      toast.error("اكتب كلمة جديدة أو اختلفة عن المسجلة");
      return;
    }
    setSubs(readSubs());
    setKeyword("");
    toast.success(`تم الاشتراك: ${s.keyword}`);
  };

  const remove = (id: string) => {
    removeSub(id);
    setSubs(readSubs());
  };

  return (
    <div dir="rtl" className="min-h-screen bg-background px-4 py-8">
      <div className="mx-auto max-w-2xl space-y-6">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowRight className="size-4" /> الرئيسية
        </Link>

        <header className="space-y-1">
          <h1 className="flex items-center gap-2 text-2xl font-extrabold">
            <BellRing className="size-6 text-amber-500" /> تنبيهاتي
          </h1>
          <p className="text-sm text-muted-foreground">
            اشترك في كلمات تخص خطك/منطقتك — يجيلك إشعار فوري لما حد يبلغ عن زحمة.
          </p>
        </header>

        {/* حالة الإذن */}
        <Card className={`p-4 ${canNotify() ? "bg-emerald-50" : "bg-amber-50"}`}>
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-sm">
              {canNotify() ? (
                <Bell className="size-5 text-emerald-600" />
              ) : (
                <BellOff className="size-5 text-amber-600" />
              )}
              <div>
                <div className="font-semibold">
                  {permission === "granted" && "إشعارات المتصفح مفعّلة"}
                  {permission === "default" && "إشعارات المتصفح غير مفعّلة"}
                  {permission === "denied" && "تم رفض إذن الإشعارات"}
                  {permission === "unsupported" && "متصفحك لا يدعم الإشعارات"}
                </div>
                <div className="text-[11px] text-muted-foreground">
                  بدون إذن المتصفح، التنبيهات تظهر داخل التطبيق فقط لما يكون مفتوح.
                </div>
              </div>
            </div>
            {permission !== "granted" &&
              permission !== "unsupported" &&
              permission !== "denied" && (
                <Button size="sm" onClick={enablePermission}>
                  فعّل
                </Button>
              )}
          </div>
        </Card>

        {/* إضافة اشتراك */}
        <Card className="p-4 space-y-3">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <Plus className="size-4" /> اشترك في كلمة جديدة
          </div>
          <div>
            <Label className="text-xs">الكلمة (اسم خط، منطقة، محطة)</Label>
            <Input
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              placeholder="مثال: المعادي، مترو، رمسيس"
              dir="rtl"
              onKeyDown={(e) => e.key === "Enter" && add()}
            />
          </div>
          <div>
            <Label className="text-xs">أدنى شدة تنبهك</Label>
            <div className="mt-1 grid grid-cols-3 gap-1.5">
              {([1, 2, 3] as const).map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setMinSev(s)}
                  className={`rounded-md border px-2 py-1.5 text-xs font-semibold ${
                    minSev === s ? "border-amber-500 bg-amber-100" : "bg-muted/30"
                  }`}
                >
                  {s === 1 ? "🟡 أي زحمة" : s === 2 ? "🟠 متوسطة+" : "🔴 شديدة فقط"}
                </button>
              ))}
            </div>
          </div>
          <Button onClick={add} className="w-full gap-2">
            <Plus className="size-4" /> اشترك
          </Button>
        </Card>

        {/* القائمة */}
        <Card className="p-4 space-y-3">
          <div className="text-sm font-semibold">اشتراكاتي ({subs.length})</div>
          {subs.length === 0 ? (
            <div className="rounded-lg bg-muted/30 p-6 text-center text-sm text-muted-foreground">
              ما فيش اشتراكات. ابدأ بكلمة أعلى ↑
            </div>
          ) : (
            <div className="space-y-1.5">
              {subs.map((s) => (
                <div
                  key={s.id}
                  className="flex items-center justify-between rounded-lg border bg-muted/20 px-3 py-2 text-sm"
                >
                  <div>
                    <div className="font-semibold">{s.keyword}</div>
                    <div className="text-[11px] text-muted-foreground">
                      {s.minSeverity === 1
                        ? "كل البلاغات"
                        : s.minSeverity === 2
                          ? "متوسطة وأعلى"
                          : "شديدة فقط"}
                    </div>
                  </div>
                  <button
                    onClick={() => remove(s.id)}
                    className="text-muted-foreground hover:text-red-600"
                    aria-label="حذف"
                  >
                    <Trash2 className="size-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card className="p-4 bg-muted/30 text-xs text-muted-foreground space-y-1">
          <div className="flex items-center gap-1.5">
            <AlertTriangle className="size-3.5" /> ملاحظات
          </div>
          <div>• الاشتراكات محفوظة على جهازك فقط، لا تتبع.</div>
          <div>• الإشعارات تشتغل لما يكون التطبيق مفتوح في تبويب.</div>
          <div>
            • شوف{" "}
            <Link to="/live" className="underline">
              آخر البلاغات اللحظية
            </Link>
            .
          </div>
        </Card>
      </div>
    </div>
  );
}
