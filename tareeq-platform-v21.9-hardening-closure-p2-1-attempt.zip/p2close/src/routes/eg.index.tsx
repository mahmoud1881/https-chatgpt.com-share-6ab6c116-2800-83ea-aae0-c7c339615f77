import { createFileRoute, redirect } from "@tanstack/react-router";

// Egypt lives at "/" — redirect /eg to home.
export const Route = createFileRoute("/eg/")({
  beforeLoad: () => {
    throw redirect({ to: "/" });
  },
  component: () => null,
});
