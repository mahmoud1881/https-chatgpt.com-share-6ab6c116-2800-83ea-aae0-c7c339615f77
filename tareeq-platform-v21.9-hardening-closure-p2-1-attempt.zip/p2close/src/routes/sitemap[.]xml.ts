// Sitemap index — Egypt-only build.
import { createFileRoute } from "@tanstack/react-router";

import { SITE_BASE_URL as BASE } from "@/lib/seo/site";

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const now = new Date().toISOString();
        const subs = ["sitemap-core.xml", "sitemap-eg.xml", "sitemap-trips.xml"];
        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...subs.map(
            (s) => `  <sitemap><loc>${BASE}/${s}</loc><lastmod>${now}</lastmod></sitemap>`,
          ),
          `</sitemapindex>`,
        ].join("\n");
        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml; charset=utf-8",
            "Cache-Control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
