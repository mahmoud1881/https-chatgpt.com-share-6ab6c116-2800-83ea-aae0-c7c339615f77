import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Trophy, Users, Bell, ShieldCheck, ArrowRight } from "lucide-react";

import { AuthGateLoading } from "@/components/AuthGateLoading";
import { useRequireAuth } from "@/hooks/useRequireAuth";

const NEIGHBORHOODS = [
  "المعادي",
  "المهندسين",
  "وسط البلد",
  "مدينة نصر",
  "الزمالك",
  "فيصل",
  "حلوان",
  "شبرا",
  "العباسية",
  "الهرم",
];

export const Route = createFileRoute("/challenge")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "تحدّي الحيّ — لوحة الصدارة الأسبوعية" },
      {
        name: "description",
        content: "نافس على المركز الأول في حيّك هذا الأسبوع. لوحة صدارة لأحياء القاهرة الكبرى.",
      },
      { property: "og:title", content: "تحدّي الحيّ — لوحة الصدارة" },
      {
        property: "og:description",
        content: "بطل حيّك الأسبوع ده — نافس على المركز الأول.",
      },
    ],
  }),
  component: ChallengeRoute,
});

/** بوابة استخدام: يتطلب تسجيل دخول قبل عرض هذه الصفحة (مش مجرد تصفح). */
function ChallengeRoute() {
  const authStatus = useRequireAuth();
  if (authStatus !== "authenticated") return <AuthGateLoading />;
  return <ChallengePage />;
}

function ChallengePage() {
  const [selected, setSelected] = useState<string>("المعادي");

  return (
    <div dir="rtl" className="min-h-screen bg-background text-foreground">
      <header className="border-b">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
          <Link to="/" className="text-sm text-muted-foreground hover:underline">
            ← الرئيسية
          </Link>
          <h1 className="text-lg font-bold">تحدّي الأسبوع</h1>
          <div className="w-16" />
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-8">
        <section className="mb-8 text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
            <Trophy className="size-4" />
            لوحة الصدارة
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight md:text-4xl">
            بطل حيّك الأسبوع ده
          </h2>
          <p className="mt-2 text-muted-foreground">نافس على المركز الأول — وكن أول صوت في حيّك.</p>
        </section>

        <section className="mb-8">
          <h3 className="mb-3 text-sm font-semibold text-muted-foreground">اختر حيّك</h3>
          <div className="flex flex-wrap gap-2">
            {NEIGHBORHOODS.map((n) => (
              <button
                key={n}
                onClick={() => setSelected(n)}
                className={`rounded-full border px-4 py-2 text-sm transition-colors ${
                  selected === n
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-input bg-background hover:bg-accent"
                }`}
              >
                {n}
              </button>
            ))}
          </div>
        </section>

        <Card className="border-dashed p-8 text-center">
          <div className="mx-auto mb-4 flex size-14 items-center justify-center rounded-full bg-primary/10 text-primary">
            <Trophy className="size-7" />
          </div>
          <h3 className="mb-2 text-xl font-bold">لسه مفيش متنافسين في {selected} — كن أول واحد!</h3>
          <p className="mx-auto mb-6 max-w-md text-sm text-muted-foreground">
            ابدأ التحدي دلوقتي وادعِ جيرانك للمنافسة. كل تنبيه بيرفع ترتيبك.
          </p>
          <div className="flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button size="lg" className="gap-2">
              <Bell className="size-4" />
              ابدأ بأول تنبيه
            </Button>
            <Button size="lg" variant="outline" className="gap-2">
              <Users className="size-4" />
              ادعُ ناس من حيّك للتنافس
            </Button>
          </div>
          <p className="mt-6 inline-flex items-center justify-center gap-1 text-xs text-muted-foreground">
            <ShieldCheck className="size-3.5" />
            نحترم خصوصيتك
          </p>
        </Card>

        <section className="mt-10">
          <h3 className="mb-4 text-sm font-semibold text-muted-foreground">
            ترتيب الأحياء — الأسبوع الحالي
          </h3>
          <div className="overflow-hidden rounded-lg border">
            {NEIGHBORHOODS.map((n, i) => (
              <div
                key={n}
                className={`flex items-center justify-between px-4 py-3 ${
                  i !== NEIGHBORHOODS.length - 1 ? "border-b" : ""
                } ${selected === n ? "bg-accent/40" : ""}`}
              >
                <div className="flex items-center gap-3">
                  <span className="flex size-7 items-center justify-center rounded-full bg-muted text-xs font-bold">
                    {i + 1}
                  </span>
                  <span className="font-medium">{n}</span>
                </div>
                <span className="text-sm text-muted-foreground">0 نقطة</span>
              </div>
            ))}
          </div>
        </section>

        <div className="mt-10 text-center">
          <Link to="/">
            <Button variant="ghost" className="gap-1">
              العودة للرئيسية
              <ArrowRight className="size-4 rotate-180" />
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
