import { SITE_BASE_URL } from "@/lib/seo/site";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, type ReactNode } from "react";

import { ArrowRight, ShieldCheck, MapPin, ExternalLink, Bus, Loader2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";

type BrtStation = {
  id: string;
  name: string;
  area: string | null;
  priority: string | null;
  governorate: string;
  lat: number | null;
  lng: number | null;
  approx: boolean;
  seq: number;
  phase: 1 | 2;
  description: string | null;
};

export const Route = createFileRoute("/brt")({
  head: () => ({
    meta: [
      { title: "محطات الأتوبيس الترددي BRT — 27 محطة على الدائري" },
      {
        name: "description",
        content:
          "دليل تفاعلي لمحطات الأتوبيس الترددي (BRT) على الطريق الدائري بترتيب المسار، مع وصف كل محطة وروابط مباشرة لخرائط جوجل لكل منطقة تخدمها المحطة.",
      },
      { property: "og:title", content: "🚍 محطات الأتوبيس الترددي (BRT)" },
      {
        property: "og:description",
        content: "27 محطة على الطريق الدائري بترتيب المسار مع روابط جوجل لكل منطقة.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: `${SITE_BASE_URL}/brt` },
      { property: "og:image", content: `${SITE_BASE_URL}/og-eg-bus.jpg` },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: `${SITE_BASE_URL}/og-eg-bus.jpg` },
    ],
    links: [
      { rel: "canonical", href: `${SITE_BASE_URL}/brt` },
      { rel: "alternate", hrefLang: "ar-EG", href: `${SITE_BASE_URL}/brt` },
      { rel: "alternate", hrefLang: "x-default", href: `${SITE_BASE_URL}/brt` },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            {
              "@type": "ListItem",
              position: 1,
              name: "الرئيسية",
              item: `${SITE_BASE_URL}/`,
            },
            {
              "@type": "ListItem",
              position: 2,
              name: "محطات BRT",
              item: `${SITE_BASE_URL}/brt`,
            },
          ],
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          name: "الأتوبيس الترددي BRT — الطريق الدائري",
          serviceType: "BusOrCoach",
          areaServed: { "@type": "City", name: "القاهرة الكبرى" },
          provider: { "@type": "Organization", name: "Tareeq" },
          url: `${SITE_BASE_URL}/brt`,
        }),
      },
    ],
  }),
  component: BrtPage,
  errorComponent: ({ error }) => (
    <div dir="rtl" className="p-8 text-center text-destructive">
      حدث خطأ في التحميل، يرجى المحاولة مجدداً
    </div>
  ),
  notFoundComponent: () => (
    <div dir="rtl" className="p-8">
      غير موجود
    </div>
  ),
});

const PRIORITY_BADGE: Record<string, { label: string; cls: string }> = {
  P0: { label: "محورية", cls: "bg-red-500/15 text-red-600 dark:text-red-400 border-red-500/30" },
  P1: { label: "عادية", cls: "bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/30" },
  P2: { label: "ثانوية", cls: "bg-muted text-muted-foreground border-border" },
};

import { gmapsCoords, gmapsSearch } from "@/lib/geo/gmaps";

// Parse a free-form Arabic "تخدم" description into discrete area names.

function splitAreas(text: string): string[] {
  if (!text) return [];
  // Extract parenthetical asides as their own areas (e.g. "EIEC", "الحي السادس والسابع")
  const parenContents: string[] = [];
  const stripped = text.replace(/\(([^)]+)\)/g, (_m, inner) => {
    parenContents.push(String(inner));
    return " ";
  });

  // Split everything (stripped text + paren contents) by Arabic/Latin separators
  const allChunks: string[] = [];
  for (const src of [stripped, ...parenContents]) {
    const cleaned = src.replace(/\s+/g, " ");
    const parts = cleaned.split(/[،,؛;·•|/\n.]+|\s-\s|\sو\s|\sأو\s|\sثم\s|\sمع\s|\sإلى\s/u);
    for (const p of parts) allChunks.push(p);
  }

  const seen = new Set<string>();
  const out: string[] = [];
  for (const raw of allChunks) {
    let p = raw.trim();
    // Iteratively strip common leading prose words so a noun phrase remains
    const LEAD =
      /^(تقع|تخدم|تربط|يربط|القاصدين|القادمين|المسافرين|المتجهين|زوار|سكان|أهالي|طلاب|ضباط|متداولي|عند|تقاطع|الدائري|في|على|من|إلى|نحو|عبر|أمام|خلف|بجانب|تحت|فوق|بمحيط|بـ|والوصلات|المؤدية|الربط|السريع|امتداد|مباشرة|مع|و|أو|ثم|هذه|هذا|تلك|ذلك|كل|بين|ذات|كثافة|الكثافة|منطقة|مناطق|محطة|محطات|مدينة|أمامية|للأقاليم|ميدان|حي)\s+/u;
    while (LEAD.test(p)) p = p.replace(LEAD, "").trim();
    p = p.replace(/[.،,؛;:!?]+$/u, "").trim();
    if (p.length < 2) continue;
    if (p.length > 45) continue;
    const key = p.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(p);
  }
  return out.slice(0, 20);
}

// Render description text with each detected area replaced by a Google-Maps link.
function renderLinkifiedDescription(text: string, areas: string[], gov: string): ReactNode[] {
  if (!text) return [];
  if (areas.length === 0) return [text];
  // Longest-first so multi-word areas match before their substrings
  const sorted = [...areas].sort((a, b) => b.length - a.length);
  const escape = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const pattern = new RegExp(`(${sorted.map(escape).join("|")})`, "g");
  const parts = text.split(pattern);
  return parts.map((part, i) => {
    if (i % 2 === 1) {
      return (
        <a
          key={i}
          href={gmapsSearch(`${part} ${gov}`)}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-0.5 font-medium text-primary underline decoration-primary/40 underline-offset-2 hover:decoration-primary"
        >
          {part}
        </a>
      );
    }
    return <span key={i}>{part}</span>;
  });
}

function StationCard({ s, idx }: { s: BrtStation; idx: number }) {
  const pBadge = PRIORITY_BADGE[s.priority ?? "P1"] ?? PRIORITY_BADGE.P1;
  const mapsUrl =
    s.lat != null && s.lng != null
      ? gmapsCoords(s.lat, s.lng)
      : gmapsSearch(`محطة ${s.name} ${s.area ?? ""} ${s.governorate}`);
  const areas = splitAreas(s.description ?? "");

  return (
    <Card className="p-5">
      <div className="flex items-start gap-4">
        <div className="flex size-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-base font-bold text-primary">
          {idx}
        </div>
        <div className="flex-1 space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-lg font-bold">محطة {s.name}</h3>
            <span className={`rounded-full border px-2 py-0.5 text-xs font-medium ${pBadge.cls}`}>
              {pBadge.label}
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
            <Badge variant="outline" className="text-xs">
              {s.governorate}
            </Badge>
            {s.area && <span>· {s.area}</span>}
          </div>
          {s.description && (
            <p className="text-sm leading-relaxed text-foreground/90">
              <span className="font-semibold">تخدم: </span>
              {renderLinkifiedDescription(s.description, areas, s.governorate)}
            </p>
          )}

          {areas.length > 0 && (
            <div className="space-y-1.5 pt-1">
              <p className="text-xs font-semibold text-muted-foreground">
                المناطق التي تخدمها (اضغط لفتح الموقع على خرائط جوجل):
              </p>
              <div className="flex flex-wrap gap-1.5">
                {areas.map((area, i) => (
                  <a
                    key={i}
                    href={gmapsSearch(`${area} ${s.governorate}`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 rounded-full border bg-muted/40 px-2.5 py-1 text-xs text-foreground/90 transition hover:bg-primary/10 hover:text-primary hover:underline"
                  >
                    <MapPin className="size-3" />
                    {area}
                  </a>
                ))}
              </div>
            </div>
          )}
          <a
            href={mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
          >
            <MapPin className="size-4" />
            {s.approx ? "موقع المحطة التقريبي على خرائط جوجل" : "موقع المحطة على خرائط جوجل"}
            <ExternalLink className="size-3" />
          </a>
        </div>
      </div>
    </Card>
  );
}

function BrtPage() {
  const { data: stations, isLoading } = useQuery({
    queryKey: ["brt-stations-live"],
    queryFn: async () => {
      const { data: route } = await supabase
        .from("routes")
        .select("id")
        .eq("route_code", "BRT-01")
        .single();

      if (!route) return [];

      const { data, error } = await supabase
        .from("route_stops")
        .select(
          `
          stop_order,
          stops (
            id,
            name_ar,
            area,
            latitude,
            longitude,
            city,
            country
          )
        `,
        )
        .eq("route_id", route.id)
        .order("stop_order", { ascending: true });

      if (error) {
        console.error("[brt] route_stops query failed:", error.message);
      }

      return (data ?? []).map((rs) => ({
        id: rs.stops.id,
        name: rs.stops.name_ar,
        area: rs.stops.area,
        priority: rs.stop_order <= 5 ? "P0" : "P1", // Basic mapping
        governorate: rs.stops.city === "cairo" ? "القاهرة" : "الجيزة",
        lat: rs.stops.latitude,
        lng: rs.stops.longitude,
        approx: true,
        seq: rs.stop_order,
        phase: rs.stop_order > 8 ? 1 : 2,
        description: null, // We could add notes to routes or stops if needed
      })) as BrtStation[];
    },
  });

  const { phase2, phase1 } = useMemo(() => {
    if (!stations) return { phase2: [], phase1: [] };
    const bySeq = (a: BrtStation, b: BrtStation) => a.seq - b.seq;
    return {
      phase2: stations.filter((s) => s.phase === 2).sort(bySeq),
      phase1: stations.filter((s) => s.phase === 1).sort(bySeq),
    };
  }, [stations]);

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background p-8">
        <Loader2 className="size-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div dir="rtl" className="min-h-screen bg-background px-4 py-10">
      <div className="mx-auto max-w-3xl space-y-8">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowRight className="size-4" />
          العودة للرئيسية
        </Link>

        <header className="space-y-3 text-center">
          <div className="inline-flex items-center justify-center rounded-full bg-primary/10 p-3">
            <Bus className="size-7 text-primary" />
          </div>
          <h1 className="text-4xl font-extrabold tracking-tight md:text-5xl">
            محطات الأتوبيس الترددي (BRT)
          </h1>
          <p className="mx-auto max-w-xl text-muted-foreground">
            {stations?.length ?? 0} محطة على الطريق الدائري بترتيب المسار
          </p>
        </header>

        <section className="space-y-4">
          <div className="rounded-lg border bg-card p-4">
            <h2 className="text-lg font-bold">
              ١. قطاع شرق وجنوب القاهرة (المرحلة الثانية — تشغيل تجريبي)
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              يبدأ من غرب التجمع الخامس ومدينة نصر جنوباً نحو المعادي ومصر القديمة ثم المنيب.
            </p>
          </div>
          <div className="space-y-3">
            {phase2.map((s, i) => (
              <StationCard key={s.id} s={s} idx={i + 1} />
            ))}
          </div>
        </section>

        <section className="space-y-4">
          <div className="rounded-lg border bg-card p-4">
            <h2 className="text-lg font-bold">
              ٢. قطاع القوس الشمالي والشرقي (المرحلة الأولى — تشغيل فعلي)
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              من التجمع الأول صعوداً إلى عدلي منصور ثم غرباً نحو المرج ومسطرد وصولاً إلى طريق
              إسكندرية الزراعي.
            </p>
          </div>
          <div className="space-y-3">
            {phase1.map((s, i) => (
              <StationCard key={s.id} s={s} idx={i + 1} />
            ))}
          </div>
        </section>

        <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
          <ShieldCheck className="size-4" />
          نحترم خصوصيتك
        </div>
      </div>
    </div>
  );
}
