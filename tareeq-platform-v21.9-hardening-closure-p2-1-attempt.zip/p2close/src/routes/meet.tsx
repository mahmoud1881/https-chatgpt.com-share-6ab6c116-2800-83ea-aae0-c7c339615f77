/**
 * /meet — نقطة لقاء جماعية مجانية 100%.
 *
 * كل المنطق client-side: قراءة المشاركين من ?p=lat,lng,label (متعدد) +
 * حساب مركز الثقل رياضياً + إيجاد أقرب محطات نقل عام للمركز.
 * لا سيرفر، لا تتبع لحظي، لا تخزين — فقط رابط مشارَك بين الأصدقاء.
 */
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  ArrowRight,
  Users,
  Loader2,
  LocateFixed,
  Share2,
  Link2,
  UserPlus,
  Trash2,
  Navigation,
  Sparkles,
} from "lucide-react";
import LazyTransitMap from "@/components/LazyTransitMap";
import type { MapPointInput } from "@/components/TransitMap";
import { SITE_BASE_URL as SITE_URL } from "@/lib/seo/site";

import { AuthGateLoading } from "@/components/AuthGateLoading";
import { useRequireAuth } from "@/hooks/useRequireAuth";

const searchSchema = z.object({
  /** صيغة كل مشارك: "lat,lng,label" — يُكرَّر */
  p: z.union([z.string(), z.array(z.string())]).optional(),
});

export const Route = createFileRoute("/meet")({
  ssr: false,
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "نقطة لقاء جماعية — مواصلات مصر" },
      {
        name: "description",
        content:
          "اقترح نقطة لقاء عادلة لمجموعتك: أضف موقع كل شخص وسنحسب أقرب محطة مشتركة للجميع — مجاناً وبدون تتبع.",
      },
      { property: "og:title", content: "نقطة لقاء جماعية — مواصلات مصر" },
      {
        property: "og:description",
        content: "احسب أقرب نقطة لقاء عادلة لمجموعة أصدقاء عبر رابط مشترك.",
      },
      { property: "og:url", content: `${SITE_URL}/meet` },
    ],
    links: [{ rel: "canonical", href: `${SITE_URL}/meet` }],
  }),
  component: MeetRoute,
});

type Participant = { lat: number; lng: number; label: string };
type NearbyPoint = {
  id: string;
  name: string;
  lat: number;
  lng: number;
  distanceKm: number;
  type?: string;
};

function parseParticipants(raw: string | string[] | undefined): Participant[] {
  if (!raw) return [];
  const arr = Array.isArray(raw) ? raw : [raw];
  const out: Participant[] = [];
  for (const s of arr) {
    const [latS, lngS, ...labelParts] = String(s).split(",");
    const lat = Number(latS);
    const lng = Number(lngS);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) continue;
    const label =
      decodeURIComponent((labelParts.join(",") || "").trim()) || `شخص ${out.length + 1}`;
    out.push({ lat, lng, label });
  }
  return out;
}

function centroidOf(pts: Participant[]): { lat: number; lng: number } | null {
  if (pts.length === 0) return null;
  let sumLat = 0;
  let sumLng = 0;
  for (const p of pts) {
    sumLat += p.lat;
    sumLng += p.lng;
  }
  return { lat: sumLat / pts.length, lng: sumLng / pts.length };
}

/** بوابة استخدام: يتطلب تسجيل دخول قبل عرض هذه الصفحة (مش مجرد تصفح). */
function MeetRoute() {
  const authStatus = useRequireAuth();
  if (authStatus !== "authenticated") return <AuthGateLoading />;
  return <MeetPage />;
}

function MeetPage() {
  const { p } = Route.useSearch();
  const navigate = useNavigate();
  const initial = useMemo(() => parseParticipants(p), [p]);

  const [participants, setParticipants] = useState<Participant[]>(initial);
  const [myLabel, setMyLabel] = useState("");
  const [busy, setBusy] = useState(false);
  const [nearStops, setNearStops] = useState<NearbyPoint[]>([]);
  const [perPerson, setPerPerson] = useState<number[]>([]);

  // إذا تغيّر الرابط، حدّث القائمة
  useEffect(() => {
    setParticipants(initial);
  }, [initial]);

  const meetingPoint = useMemo(() => centroidOf(participants), [participants]);

  // احسب أقرب المحطات لنقطة اللقاء والمسافات لكل شخص
  useEffect(() => {
    if (!meetingPoint || participants.length === 0) {
      setNearStops([]);
      setPerPerson([]);
      return;
    }
    let cancelled = false;
    (async () => {
      const { nearestPoints, haversineKm } = await import("@/lib/transit/geo");
      const stops = await nearestPoints(meetingPoint, 6, 10);
      if (cancelled) return;
      setNearStops(stops);
      setPerPerson(participants.map((q) => haversineKm(q, meetingPoint)));
    })();
    return () => {
      cancelled = true;
    };
  }, [meetingPoint, participants]);

  const syncUrl = (next: Participant[]) => {
    const params = next.map(
      (q) => `${q.lat.toFixed(5)},${q.lng.toFixed(5)},${encodeURIComponent(q.label)}`,
    );
    void navigate({
      to: "/meet",
      search: { p: params.length ? params : undefined } as never,
      replace: true,
    });
  };

  const addMe = async () => {
    setBusy(true);
    try {
      const { getUserLocation } = await import("@/lib/transit/geo");
      const here = await getUserLocation();
      const label = myLabel.trim() || `شخص ${participants.length + 1}`;
      const next = [...participants, { lat: here.lat, lng: here.lng, label }];
      setParticipants(next);
      syncUrl(next);
      setMyLabel("");
      toast.success("تمت إضافة موقعك");
    } catch {
      toast.error("تعذّر تحديد موقعك — فعّل الإذن");
    } finally {
      setBusy(false);
    }
  };

  const removeAt = (i: number) => {
    const next = participants.filter((_, idx) => idx !== i);
    setParticipants(next);
    syncUrl(next);
  };

  const shareLink = async (kind: "share" | "copy") => {
    const url = window.location.href;
    const data = {
      title: "نقطة لقاء — مواصلات",
      text: `اقترح نقطة لقاء عادلة لمجموعتنا (${participants.length} أشخاص) 📍`,
      url,
    };
    if (
      kind === "share" &&
      typeof navigator !== "undefined" &&
      typeof navigator.share === "function"
    ) {
      try {
        await navigator.share(data);
        return;
      } catch {
        return;
      }
    }
    try {
      await navigator.clipboard.writeText(url);
      toast.success("تم نسخ الرابط — أرسله لأصدقائك ليضيفوا مواقعهم");
    } catch {
      toast.error("تعذّر النسخ");
    }
  };

  const routeToMeeting = () => {
    if (!meetingPoint) return;
    const nearest = nearStops[0];
    const to = nearest?.name || `${meetingPoint.lat.toFixed(4)},${meetingPoint.lng.toFixed(4)}`;
    navigate({ to: "/explore", search: { to } as never });
  };

  const colors = [
    "#2563eb",
    "#10b981",
    "#f97316",
    "#8b5cf6",
    "#ec4899",
    "#0ea5e9",
    "#eab308",
    "#ef4444",
  ];

  const mapPoints: MapPointInput[] = [
    ...participants.map((q, i) => ({
      id: `p_${i}`,
      name: q.label,
      lat: q.lat,
      lng: q.lng,
      color: colors[i % colors.length],
      type: "person",
    })),
    ...(meetingPoint
      ? [
          {
            id: "__meet__",
            name: "📍 نقطة اللقاء",
            lat: meetingPoint.lat,
            lng: meetingPoint.lng,
            color: "#dc2626",
            type: "meeting",
          } as MapPointInput,
        ]
      : []),
    ...nearStops.slice(0, 3).map((s) => ({
      id: s.id,
      name: `🚏 ${s.name}`,
      lat: s.lat,
      lng: s.lng,
      color: "#059669",
      type: s.type,
    })),
  ];

  return (
    <div dir="rtl" className="min-h-screen bg-background px-4 py-8">
      <div className="mx-auto max-w-4xl space-y-6">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowRight className="size-4" /> رجوع للرئيسية
        </Link>

        <header className="space-y-2">
          <h1 className="flex items-center gap-2 text-2xl font-extrabold md:text-3xl">
            <Users className="size-7 text-primary" /> نقطة لقاء جماعية
          </h1>
          <p className="text-sm text-muted-foreground">
            أضف موقع كل شخص → نحسب مركز عادل للجميع ونقترح أقرب محطة نقل عام. كل شيء في متصفحك، بدون
            تتبع ولا تخزين.
          </p>
        </header>

        <Card className="p-4 space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <Input
              value={myLabel}
              onChange={(e) => setMyLabel(e.target.value)}
              placeholder="اسمك (اختياري)"
              className="h-9 max-w-[200px] text-sm"
            />
            <Button onClick={addMe} disabled={busy} className="gap-2">
              {busy ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <LocateFixed className="size-4" />
              )}
              أضف موقعي
            </Button>
            <Button
              onClick={() => shareLink("share")}
              className="gap-2 bg-emerald-600 hover:bg-emerald-700"
            >
              <Share2 className="size-4" /> شارك مع المجموعة
            </Button>
            <Button onClick={() => shareLink("copy")} variant="outline" className="gap-2">
              <Link2 className="size-4" /> نسخ الرابط
            </Button>
            <Badge variant="secondary" className="text-xs">
              <UserPlus className="ms-1 size-3" /> {participants.length} مشارك
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground">
            💡 شارك الرابط، وكل شخص يفتحه ويضغط "أضف موقعي" — الرابط يتحدّث تلقائياً. أعد مشاركته
            بعد كل إضافة.
          </p>
        </Card>

        {participants.length > 0 && (
          <Card className="p-4 space-y-2">
            <h2 className="text-sm font-bold text-muted-foreground">المشاركون</h2>
            <ul className="grid gap-2 sm:grid-cols-2">
              {participants.map((q, i) => (
                <li
                  key={`${i}-${q.lat}-${q.lng}`}
                  className="flex items-center justify-between rounded-md border p-2 text-sm"
                >
                  <div className="flex min-w-0 items-center gap-2">
                    <span
                      className="inline-block size-3 shrink-0 rounded-full"
                      style={{ background: colors[i % colors.length] }}
                    />
                    <span className="truncate font-medium">{q.label}</span>
                    {perPerson[i] !== undefined && (
                      <Badge variant="outline" className="text-[10px]">
                        {perPerson[i] < 1
                          ? `${Math.round(perPerson[i] * 1000)} م`
                          : `${perPerson[i].toFixed(1)} كم`}
                      </Badge>
                    )}
                  </div>
                  <Button size="icon" variant="ghost" onClick={() => removeAt(i)} aria-label="حذف">
                    <Trash2 className="size-4 text-destructive" />
                  </Button>
                </li>
              ))}
            </ul>
          </Card>
        )}

        {meetingPoint && (
          <Card className="border-red-300 bg-red-50/60 p-4 dark:border-red-900 dark:bg-red-950/30">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2 text-sm">
                <Sparkles className="size-5 text-red-600" />
                <span className="font-bold">نقطة اللقاء المقترحة</span>
                <Badge variant="outline" className="text-xs">
                  {meetingPoint.lat.toFixed(4)}, {meetingPoint.lng.toFixed(4)}
                </Badge>
                {nearStops[0] && (
                  <Badge variant="secondary" className="text-xs">
                    🚏 أقرب محطة: {nearStops[0].name}
                  </Badge>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Button
                  size="sm"
                  onClick={routeToMeeting}
                  className="gap-1 bg-emerald-600 hover:bg-emerald-700"
                >
                  <Navigation className="size-4" /> كيف أصل لهنا
                </Button>
                <a
                  href={`https://www.openstreetmap.org/?mlat=${meetingPoint.lat}&mlon=${meetingPoint.lng}#map=16/${meetingPoint.lat}/${meetingPoint.lng}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-primary underline"
                >
                  فتح في OpenStreetMap
                </a>
              </div>
            </div>
          </Card>
        )}

        <Card className="overflow-hidden p-0">
          <LazyTransitMap
            points={mapPoints}
            defaultCenter={meetingPoint ?? { lat: 30.0444, lng: 31.2357 }}
            height={420}
          />
        </Card>

        {nearStops.length > 0 && (
          <section className="space-y-2">
            <h2 className="text-lg font-bold">أقرب المحطات من نقطة اللقاء</h2>
            <div className="grid gap-2 sm:grid-cols-2">
              {nearStops.map((s) => (
                <Card key={s.id} className="flex items-center justify-between p-3">
                  <p className="truncate font-medium">{s.name}</p>
                  <Badge variant="outline" className="text-xs">
                    {s.distanceKm < 1
                      ? `${Math.round(s.distanceKm * 1000)} م`
                      : `${s.distanceKm.toFixed(1)} كم`}
                  </Badge>
                </Card>
              ))}
            </div>
          </section>
        )}

        {participants.length === 0 && (
          <Card className="p-6 text-center text-sm text-muted-foreground">
            ابدأ بإضافة موقعك ثم شارك الرابط مع أصدقائك ليضيفوا مواقعهم.
          </Card>
        )}
      </div>
    </div>
  );
}
