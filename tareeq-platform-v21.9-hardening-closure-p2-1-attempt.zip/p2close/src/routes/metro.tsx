import { createFileRoute, Link } from "@tanstack/react-router";
import { usePublishSnapshot } from "@/hooks/use-publish-snapshot";
import { useEffect, useMemo, useState } from "react";
import { ArrowRight, ShieldCheck, MapPin, ChevronDown, Train, X } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { METRO_STATION_AREAS } from "@/data/metroAreas";
import { egHead, getEgPage } from "@/lib/seo/eg-meta";
import { useMetro } from "@/hooks/useMetro";
import { deriveGov, type MetroRow } from "@/lib/metro/search-helpers";
import { NotFoundState } from "@/components/NotFoundState";

export const Route = createFileRoute("/metro")({
  head: () => {
    const p = getEgPage("/metro")!;
    return egHead({
      path: p.path,
      titleAr: p.titleAr,
      descAr: p.descAr,
      ogImage: p.ogImage,
      breadcrumbLabel: "مترو القاهرة",
    });
  },
  component: MetroPage,
  errorComponent: () => (
    <div dir="rtl" className="p-8 text-center text-destructive">
      حدث خطأ في التحميل، يرجى المحاولة مجدداً
    </div>
  ),
  notFoundComponent: () => (
    <NotFoundState
      title="المحطة غير موجودة"
      description="لم نجد محطة المترو المطلوبة. استعرض خطوط المترو الثلاثة أو ابحث بالمنطقة."
      suggestions={[
        { to: "/metro", label: "خطوط المترو" },
        { to: "/lrt", label: "القطار الكهربائي" },
        { to: "/stops", label: "كل المحطات" },
      ]}
    />
  ),
});

const LINE_META: Record<
  string,
  { title: string; subtitle: string; dot: string; bar: string; chip: string }
> = {
  "1": {
    title: "الخط الأول — حلوان ↔ المرج الجديدة",
    subtitle: "لون الخط أحمر",
    dot: "bg-red-500",
    bar: "from-red-500/80 to-red-500/40",
    chip: "bg-red-500/15 text-red-600 dark:text-red-400 border-red-500/30",
  },
  "2": {
    title: "الخط الثاني — شبرا الخيمة ↔ المنيب",
    subtitle: "لون الخط أزرق",
    dot: "bg-blue-500",
    bar: "from-blue-500/80 to-blue-500/40",
    chip: "bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/30",
  },
  "3": {
    title: "الخط الثالث (الرئيسي) — عدلي منصور ← كيت كات",
    subtitle: "لون الخط أخضر/زيتوني",
    dot: "bg-emerald-600",
    bar: "from-emerald-600/80 to-emerald-600/40",
    chip: "bg-emerald-600/15 text-emerald-700 dark:text-emerald-400 border-emerald-600/30",
  },
  "3a": {
    title: "الفرع (أ): كيت كات ← محور روض الفرج",
    subtitle: "امتداد شمالي للخط الثالث",
    dot: "bg-emerald-500",
    bar: "from-emerald-500/70 to-emerald-500/30",
    chip: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30",
  },
  "3b": {
    title: "الفرع (ب): كيت كات ← جامعة القاهرة",
    subtitle: "امتداد غربي للخط الثالث",
    dot: "bg-emerald-500",
    bar: "from-emerald-500/70 to-emerald-500/30",
    chip: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30",
  },
};

const LINE_ORDER = ["1", "2", "3", "3a", "3b"];

import { gmapsCoords, gmapsSearch } from "@/lib/geo/gmaps";

function splitAreas(text: string): string[] {
  return text
    .split(/[،,؛;·•|/\n]+|\s-\s/)
    .map((s) => s.trim())
    .filter((s) => s.length > 1);
}

function normalizeNearbyName(name: string): string {
  return name
    .replace(/[أإآ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function StationCard({
  row,
  index,
  lineKey,
  metroStationNames,
}: {
  row: MetroRow;
  index: number;
  lineKey: string;
  metroStationNames: Set<string>;
}) {
  const [open, setOpen] = useState(false);
  const description: string = row.description ?? "";
  const gov = deriveGov(row);
  const meta = LINE_META[lineKey];
  const nearest = (row.nearby ?? [])
    .slice()
    .filter((s) => {
      const name = normalizeNearbyName(s.name ?? "");
      return name && !name.includes("مترو") && !metroStationNames.has(name);
    })
    .filter((s, i, arr) => {
      const name = normalizeNearbyName(s.name ?? "");
      return arr.findIndex((x) => normalizeNearbyName(x.name ?? "") === name) === i;
    })
    .sort((a, b) => (a.km ?? 999) - (b.km ?? 999))
    .slice(0, 8);
  const mapsUrl =
    row.lat && row.lng ? gmapsCoords(row.lat, row.lng) : gmapsSearch(`محطة مترو ${row.name}`);
  const curatedAreas = METRO_STATION_AREAS[row.name];
  const areas = (
    curatedAreas && curatedAreas.length ? curatedAreas : splitAreas(description)
  ).slice(0, 8);

  return (
    <Card className="p-5">
      <div className="flex items-start gap-4">
        <div
          className={`flex size-10 shrink-0 items-center justify-center rounded-full text-base font-bold text-white ${meta.dot}`}
        >
          {index}
        </div>
        <div className="flex-1 space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-lg font-bold">محطة {row.name}</h3>
            <Badge variant="outline" className="text-xs">
              {gov}
            </Badge>
            <a
              href={mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline"
            >
              <MapPin className="size-3" />
              الموقع
            </a>
          </div>
          {areas.length > 0 && (
            <div className="space-y-1.5">
              <p className="text-sm font-semibold">ما تخدمه:</p>
              <div className="flex flex-wrap gap-1.5">
                {areas.map((area, i) => (
                  <a
                    key={i}
                    href={gmapsSearch(`${area} القاهرة`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 rounded-full border bg-muted/40 px-2.5 py-1 text-xs text-foreground/90 transition hover:bg-primary/10 hover:text-primary hover:underline"
                  >
                    <MapPin className="size-3" />
                    {area}
                  </a>
                ))}
              </div>
            </div>
          )}
          {nearest.length > 0 && (
            <button
              onClick={() => setOpen((v) => !v)}
              className="inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline"
            >
              <ChevronDown className={`size-4 transition-transform ${open ? "rotate-180" : ""}`} />
              أقرب المحطات والمواقف ({nearest.length})
            </button>
          )}
          {open && nearest.length > 0 && (
            <div className="mt-2 grid gap-1.5 rounded-lg border bg-muted/30 p-3 sm:grid-cols-2">
              {nearest.map((s, i) => (
                <a
                  key={i}
                  href={gmapsSearch(`${s.name} القاهرة`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between gap-3 rounded-md bg-background px-3 py-1.5 text-sm transition hover:bg-primary/10 hover:text-primary"
                >
                  <span className="flex items-center gap-1.5 truncate">
                    <MapPin className="size-3 shrink-0" />
                    {s.name}
                  </span>
                  <span className="shrink-0 text-xs text-muted-foreground">
                    {Number(s.km ?? 0).toFixed(2)} كم
                  </span>
                </a>
              ))}
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}

function MetroPage() {
  usePublishSnapshot({
    id: "eg:metro",
    source: "مترو الأنفاق",
    title: "خطوط المترو",
    summary: "خطوط ومحطات مترو القاهرة الثلاث",
    category: "transit",
    href: "/metro",
  });
  const {
    data,
    isLoading,
    error,
    refetch,
    search,
    setSearch,
    lineFilter,
    setLineFilter,
    govFilter,
    setGovFilter,
    trip,
    tripResult,
    filtered,
    grouped,
    hasFilter,
    reset,
  } = useMetro();

  const [fromInput, setFromInput] = useState("");
  const [toInput, setToInput] = useState("");

  // Sync From/To fields → underlying trip search string
  useEffect(() => {
    const f = fromInput.trim();
    const t = toInput.trim();
    if (f && t) setSearch(`${f} الى ${t}`);
    else if (f) setSearch(f);
    else if (t) setSearch(t);
    else setSearch("");
  }, [fromInput, toInput, setSearch]);

  const stationNames = useMemo(() => {
    const set = new Set<string>();
    (data ?? []).forEach((r) => {
      if (r.name) set.add(r.name);
      (r.aliases ?? []).forEach((a) => set.add(a));
      const curated = METRO_STATION_AREAS[r.name] ?? [];
      curated.forEach((a) => set.add(a));
    });
    return Array.from(set);
  }, [data]);

  const metroStationNameSet = useMemo(() => {
    const set = new Set<string>();
    (data ?? []).forEach((r) => {
      [r.name, r.name_en, ...(r.aliases ?? [])].forEach((name) => {
        if (name) set.add(normalizeNearbyName(name));
      });
    });
    return set;
  }, [data]);

  const resetAll = () => {
    setFromInput("");
    setToInput("");
    reset();
  };
  const hasTripFilter = hasFilter || !!fromInput || !!toInput;

  const fromAreas = tripResult?.from ? (METRO_STATION_AREAS[tripResult.from.name] ?? []) : [];
  const toAreas = tripResult?.to ? (METRO_STATION_AREAS[tripResult.to.name] ?? []) : [];

  return (
    <div dir="rtl" className="min-h-screen bg-background px-4 py-10">
      <div className="mx-auto max-w-3xl space-y-8">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowRight className="size-4" />
          العودة للرئيسية
        </Link>

        <header className="space-y-3 text-center">
          <div className="inline-flex items-center justify-center rounded-full bg-primary/10 p-3">
            <Train className="size-7 text-primary" />
          </div>
          <h1 className="text-4xl font-extrabold tracking-tight md:text-5xl">محطات مترو القاهرة</h1>
          <p className="mx-auto max-w-xl text-muted-foreground">
            {data ? `${data.length} محطة` : "…"} على الخطوط الثلاثة بترتيب المسار
          </p>
        </header>

        {/* Trip Search: From / To */}
        <Card className="p-4 space-y-3">
          <div className="grid gap-2 sm:grid-cols-[1fr_auto_1fr]">
            <div className="space-y-1">
              <label htmlFor="metro-from" className="text-xs font-semibold text-muted-foreground">
                من
              </label>
              <Input
                id="metro-from"
                value={fromInput}
                onChange={(e) => setFromInput(e.target.value)}
                placeholder="محطة أو منطقة (مثال: السادات / الزمالك)"
                list="metro-stations-list"
                autoComplete="off"
              />
            </div>
            <div className="hidden sm:flex items-end justify-center pb-2 text-muted-foreground">
              <ArrowRight className="size-5 rotate-180" />
            </div>
            <div className="space-y-1">
              <label htmlFor="metro-to" className="text-xs font-semibold text-muted-foreground">
                إلى
              </label>
              <Input
                id="metro-to"
                value={toInput}
                onChange={(e) => setToInput(e.target.value)}
                placeholder="محطة أو منطقة (مثال: المرج / مصر الجديدة)"
                list="metro-stations-list"
                autoComplete="off"
              />
            </div>
          </div>
          <datalist id="metro-stations-list">
            {stationNames.map((n) => (
              <option key={n} value={n} />
            ))}
          </datalist>
          <div className="grid gap-2 sm:grid-cols-3">
            <Select value={lineFilter} onValueChange={setLineFilter}>
              <SelectTrigger>
                <SelectValue placeholder="الخط" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل الخطوط</SelectItem>
                {LINE_ORDER.map((k) => (
                  <SelectItem key={k} value={k}>
                    {LINE_META[k].title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={govFilter} onValueChange={setGovFilter}>
              <SelectTrigger>
                <SelectValue placeholder="المحافظة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل المحافظات</SelectItem>
                <SelectItem value="القاهرة">القاهرة</SelectItem>
                <SelectItem value="الجيزة">الجيزة</SelectItem>
                <SelectItem value="القليوبية">القليوبية</SelectItem>
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              onClick={resetAll}
              disabled={!hasTripFilter}
              className="gap-2"
            >
              <X className="size-4" />
              مسح
            </Button>
          </div>
          {!isLoading && (fromInput || toInput) && (
            <p className="text-xs text-muted-foreground">النتائج: {filtered.length} محطة مطابقة</p>
          )}
        </Card>

        {tripResult && (
          <Card className="p-4 space-y-3 border-primary/40">
            <div className="flex items-center gap-2 text-sm font-semibold">
              <Train className="size-4 text-primary" />
              رحلة: <span className="text-primary">{trip?.from}</span>
              <ArrowRight className="size-3 rotate-180" />
              <span className="text-primary">{trip?.to}</span>
            </div>
            {!tripResult.from && (
              <p className="text-xs text-destructive">لم نتعرف على محطة «{trip?.from}»</p>
            )}
            {!tripResult.to && (
              <p className="text-xs text-destructive">لم نتعرف على محطة «{trip?.to}»</p>
            )}
            {tripResult.from && trip?.from && tripResult.from.name !== trip.from && (
              <p className="text-xs text-muted-foreground">
                «{trip.from}» منطقة تخدمها محطة{" "}
                <span className="font-semibold text-foreground">{tripResult.from.name}</span>
              </p>
            )}
            {tripResult.to && trip?.to && tripResult.to.name !== trip.to && (
              <p className="text-xs text-muted-foreground">
                «{trip.to}» منطقة تخدمها محطة{" "}
                <span className="font-semibold text-foreground">{tripResult.to.name}</span>
              </p>
            )}

            {tripResult.from && tripResult.to && tripResult.segments && (
              <div className="space-y-4">
                {tripResult.segments.map((seg, sIdx) => (
                  <div key={sIdx} className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <div
                        className={`size-2.5 rounded-full ${LINE_META[seg.line]?.dot || "bg-zinc-400"}`}
                      />
                      <p className="text-xs font-bold">
                        الخط {seg.line} — {seg.path.length} محطة
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-1.5 text-[11px]">
                      {seg.path.map((s, i) => {
                        const isFirstInTrip = sIdx === 0 && i === 0;
                        const isLastInTrip =
                          sIdx === tripResult.segments!.length - 1 && i === seg.path.length - 1;
                        const isTransfer =
                          (sIdx > 0 && i === 0) ||
                          (sIdx < tripResult.segments!.length - 1 && i === seg.path.length - 1);

                        return (
                          <span
                            key={s.id}
                            className={`rounded-full border px-2 py-0.5 ${
                              isFirstInTrip || isLastInTrip
                                ? "bg-primary/20 border-primary/50 font-bold"
                                : isTransfer
                                  ? "bg-amber-100 border-amber-300 font-semibold"
                                  : "bg-muted/50 border-transparent text-muted-foreground"
                            }`}
                          >
                            {isTransfer && "🔄 "}
                            {s.name}
                          </span>
                        );
                      })}
                    </div>
                    {sIdx < tripResult.segments!.length - 1 && (
                      <div className="mr-1 h-3 border-r-2 border-dashed border-muted-foreground/30" />
                    )}
                  </div>
                ))}
              </div>
            )}
            {tripResult.from && tripResult.to && !tripResult.segments && (
              <p className="text-xs text-destructive bg-destructive/10 p-2 rounded-md">
                عذراً، لا يوجد مسار مترو موثّق في البيانات الحالية بين هاتين المحطتين.
              </p>
            )}

            {(fromAreas.length > 0 || toAreas.length > 0) && (
              <div className="grid gap-3 border-t pt-3 sm:grid-cols-2">
                {tripResult.from && fromAreas.length > 0 && (
                  <div className="space-y-1.5">
                    <p className="text-xs font-semibold">
                      مناطق تخدمها محطة {tripResult.from.name}:
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {fromAreas.slice(0, 8).map((a, i) => (
                        <span
                          key={i}
                          className="inline-flex items-center gap-1 rounded-full border bg-muted/40 px-2 py-0.5 text-xs"
                        >
                          <MapPin className="size-3" />
                          {a}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                {tripResult.to && toAreas.length > 0 && (
                  <div className="space-y-1.5">
                    <p className="text-xs font-semibold">مناطق تخدمها محطة {tripResult.to.name}:</p>
                    <div className="flex flex-wrap gap-1.5">
                      {toAreas.slice(0, 8).map((a, i) => (
                        <span
                          key={i}
                          className="inline-flex items-center gap-1 rounded-full border bg-muted/40 px-2 py-0.5 text-xs"
                        >
                          <MapPin className="size-3" />
                          {a}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </Card>
        )}

        {error && (
          <Card className="p-6 text-center" role="alert">
            <p className="mb-3 text-destructive">تعذر تحميل خطوط المترو — تحقق من اتصالك.</p>
            <button
              type="button"
              onClick={() => refetch()}
              className="inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-1.5 text-xs font-semibold hover:bg-accent"
            >
              إعادة المحاولة
            </button>
          </Card>
        )}

        {isLoading && <Card className="p-12 text-center text-muted-foreground">جارٍ التحميل…</Card>}

        {!isLoading && filtered.length === 0 && (
          <Card className="p-8 text-center text-muted-foreground">
            لا توجد محطات مطابقة للتصفية.
          </Card>
        )}

        {!isLoading &&
          LINE_ORDER.filter((k) => (grouped[k]?.length ?? 0) > 0).map((lineKey) => {
            const meta = LINE_META[lineKey];
            const rows = grouped[lineKey];
            return (
              <section key={lineKey} className="space-y-4">
                <div
                  className={`rounded-lg border-r-4 bg-card p-4 ${meta.dot.replace("bg-", "border-")}`}
                >
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`size-3 rounded-full ${meta.dot}`} />
                    <h2 className="text-lg font-bold">{meta.title}</h2>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {rows.length} محطة · {meta.subtitle}
                  </p>
                </div>
                <div className="space-y-3">
                  {rows.map((r) => (
                    <StationCard
                      key={r.id}
                      row={r}
                      index={Number(r.seq ?? 0)}
                      lineKey={lineKey}
                      metroStationNames={metroStationNameSet}
                    />
                  ))}
                </div>
              </section>
            );
          })}

        <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
          <ShieldCheck className="size-4" />
          نحترم خصوصيتك
        </div>
      </div>
    </div>
  );
}
