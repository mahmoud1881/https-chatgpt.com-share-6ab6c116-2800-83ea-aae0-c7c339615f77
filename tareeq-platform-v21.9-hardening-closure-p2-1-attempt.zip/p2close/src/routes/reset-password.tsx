import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { translateAuthError } from "@/lib/auth-errors";

export const Route = createFileRoute("/reset-password")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "إعادة تعيين كلمة المرور — طريقك" },
      { name: "description", content: "أدخل كلمة مرور جديدة لحسابك." },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    // Supabase يعالج hash (#access_token=…&type=recovery) تلقائياً عبر detectSessionInUrl
    // ننتظر تأكيد الجلسة قبل السماح بتحديث كلمة المرور.
    supabase.auth
      .getSession()
      .then(({ data }) => {
        if (data.session) {
          setReady(true);
        } else {
          toast.error("رابط الاسترداد منتهي أو غير صالح");
          void router.navigate({ to: "/auth" });
        }
      })
      .catch((err) => {
        console.warn("[reset-password] getSession failed:", err);
        toast.error("تعذّر التحقق من رابط الاسترداد. حاول مجدداً.");
        void router.navigate({ to: "/auth" });
      });
  }, [router]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    if (password.length < 6) {
      toast.error("كلمة المرور قصيرة جداً");
      return;
    }
    if (password !== confirm) {
      toast.error("كلمتا المرور غير متطابقتين");
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) {
      toast.error(translateAuthError(error.message));
      return;
    }
    toast.success("تم تحديث كلمة المرور");
    void router.navigate({ to: "/" });
  }

  return (
    <div
      dir="rtl"
      className="min-h-screen bg-background flex items-center justify-center px-4 py-10"
    >
      <div className="w-full max-w-md rounded-xl border border-border bg-card p-6 shadow-sm">
        <h1 className="text-2xl font-bold text-foreground text-center mb-6">كلمة مرور جديدة</h1>
        {!ready ? (
          <p className="text-center text-sm text-muted-foreground">جارٍ التحقق من الرابط…</p>
        ) : (
          <form onSubmit={onSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">كلمة المرور الجديدة</label>
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                autoComplete="new-password"
                dir="ltr"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">تأكيد كلمة المرور</label>
              <input
                type="password"
                required
                minLength={6}
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                autoComplete="new-password"
                dir="ltr"
              />
            </div>
            <button
              type="submit"
              disabled={busy}
              className="w-full rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-60"
            >
              {busy ? "جارٍ التحديث…" : "تحديث كلمة المرور"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
