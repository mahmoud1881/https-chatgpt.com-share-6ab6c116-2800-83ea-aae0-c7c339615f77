import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { submitBusLine, type SubmitBusLineResult } from "@/lib/admin/add-bus-line.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Loader2, MapPin, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/admin/add-bus-line")({
  head: () => ({
    meta: [{ title: "إضافة خط أتوبيس — Tareeq Admin" }],
  }),
  component: AddBusLinePage,
});

function AddBusLinePage() {
  const submit = useServerFn(submitBusLine);
  const [transportType, setTransportType] = useState("bus");
  const [routeCode, setRouteCode] = useState("");
  const [routeName, setRouteName] = useState("");
  const [city, setCity] = useState("القاهرة");
  const [stopsText, setStopsText] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SubmitBusLineResult | null>(null);

  const stopsList = stopsText
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter(Boolean);

  const canSubmit =
    !loading && routeCode.trim() && routeName.trim() && city.trim() && stopsList.length >= 2;

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!canSubmit) return;
    setLoading(true);
    setResult(null);
    try {
      const res = await submit({
        data: {
          route_code: routeCode.trim(),
          route_name: routeName.trim(),
          transport_type_id: transportType,
          country: "eg",
          city: city.trim(),
          stops: stopsList,
          notes: notes.trim() || undefined,
        },
      });
      setResult(res);
      const geocodedCount = res.stops.filter((s) => s.lat != null).length;
      toast.success(
        res.action === "created"
          ? `تم إنشاء الخط — ${geocodedCount}/${res.stops.length} محطة بموقع جغرافي`
          : `تم تحديث الخط — ${geocodedCount}/${res.stops.length} محطة بموقع جغرافي`,
      );
      // Reset for next line but keep city + type for speed
      setRouteCode("");
      setRouteName("");
      setStopsText("");
      setNotes("");
    } catch (err) {
      toast.error((err as Error).message || "فشل الحفظ");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="container mx-auto max-w-3xl py-8 px-4" dir="rtl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">إضافة خط أتوبيس</h1>
        <p className="text-sm text-muted-foreground">
          أدخل خط واحد كل مرة. النظام هيجيب إحداثيات كل محطة تلقائي من OpenStreetMap. لو الكود موجود
          قبل كده هيتم استبدال الخط بالتفاصيل الجديدة.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>بيانات الخط</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="type">نوع المواصلة</Label>
                <Select value={transportType} onValueChange={setTransportType}>
                  <SelectTrigger id="type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bus">أتوبيس</SelectItem>
                    <SelectItem value="minibus">ميني باص</SelectItem>
                    <SelectItem value="microbus">ميكروباص</SelectItem>
                    <SelectItem value="brt">أتوبيس ترددي (BRT)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="city">المدينة / المحافظة</Label>
                <Input
                  id="city"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="القاهرة"
                />
              </div>
              <div>
                <Label htmlFor="code">كود الخط</Label>
                <Input
                  id="code"
                  value={routeCode}
                  onChange={(e) => setRouteCode(e.target.value)}
                  placeholder="مثال: 24 أ"
                />
              </div>
              <div>
                <Label htmlFor="name">اسم الخط</Label>
                <Input
                  id="name"
                  value={routeName}
                  onChange={(e) => setRouteName(e.target.value)}
                  placeholder="رمسيس — العتبة"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="stops">المحطات (كل محطة في سطر — من البداية للنهاية بالترتيب)</Label>
              <Textarea
                id="stops"
                value={stopsText}
                onChange={(e) => setStopsText(e.target.value)}
                placeholder={"رمسيس\nالجيش\nالعتبة"}
                rows={8}
                className="font-mono text-sm"
              />
              <p className="text-xs text-muted-foreground mt-1">
                {stopsList.length} محطة — الأولى هي البداية والأخيرة هي النهاية
              </p>
            </div>

            <div>
              <Label htmlFor="notes">ملاحظات (اختياري)</Label>
              <Input
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="أي تفاصيل إضافية"
              />
            </div>

            <Button type="submit" disabled={!canSubmit} className="w-full">
              {loading ? (
                <>
                  <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                  جاري الحفظ وجلب الإحداثيات...
                </>
              ) : (
                "حفظ الخط"
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {result && (
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              {result.action === "created" ? "تم الإنشاء" : "تم التحديث"} — إحداثيات المحطات
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-1 text-sm">
              {result.stops.map((s, i) => (
                <li key={i} className="flex items-center gap-2">
                  <MapPin
                    className={`h-4 w-4 ${s.lat != null ? "text-green-600" : "text-muted-foreground"}`}
                  />
                  <span className="flex-1">{s.name}</span>
                  <span className="text-xs text-muted-foreground">
                    {s.lat != null && s.lon != null
                      ? `${s.lat.toFixed(4)}, ${s.lon.toFixed(4)}`
                      : "لم يتم العثور على موقع"}
                    {s.geocoded ? " • جديد" : ""}
                  </span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
