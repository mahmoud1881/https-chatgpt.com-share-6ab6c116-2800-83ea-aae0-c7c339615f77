import { SITE_BASE_URL } from "@/lib/seo/site";
import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "سياسة الخصوصية — مواصلات مصر" },
      {
        name: "description",
        content:
          "كيف نجمع بياناتك ونستخدمها ونحميها في تطبيق مواصلات مصر: بيانات الموقع، السجل، الحساب، وحقوقك.",
      },
      { property: "og:title", content: "سياسة الخصوصية — مواصلات مصر" },
      { property: "og:description", content: "بياناتك، حقوقك، وكيف نستخدم موقعك الجغرافي." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { rel: "canonical", href: `${SITE_BASE_URL}/privacy` } as unknown as {
        name: string;
        content: string;
      },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <main dir="rtl" className="mx-auto max-w-3xl px-4 py-10 text-right leading-loose">
      <h1 className="text-3xl font-bold text-foreground">سياسة الخصوصية</h1>
      <p className="mt-2 text-sm text-muted-foreground">آخر تحديث: 12 يوليو 2026</p>

      <section className="mt-8 space-y-4">
        <h2 className="text-xl font-semibold">ما البيانات التي نجمعها؟</h2>
        <ul className="list-disc space-y-2 pr-6 text-sm">
          <li>
            <strong>الموقع الجغرافي (اختياري):</strong> نستخدمه فقط لعرض أقرب المحطات وخطوط النقل
            حولك. لا يُحفظ على أجهزتنا ولا يُشارك مع طرف ثالث.
          </li>
          <li>
            <strong>سجل البحث:</strong> يُخزَّن محلياً على جهازك فقط (متصفحك) لتحسين اقتراحات البحث.
          </li>
          <li>
            <strong>بيانات الحساب:</strong> عند تسجيل الدخول، نحفظ بريدك الإلكتروني ومعرّف حساب واحد
            فقط. لا نطلب أرقام هوية أو بيانات بنكية.
          </li>
          <li>
            <strong>المساهمات المجتمعية:</strong> عند إضافة خط أو محطة، نحفظ المحتوى مع معرّف
            الحساب.
          </li>
        </ul>
      </section>

      <section className="mt-8 space-y-4">
        <h2 className="text-xl font-semibold">لماذا نجمع هذه البيانات؟</h2>
        <ul className="list-disc space-y-2 pr-6 text-sm">
          <li>لعرض الخطوط والمحطات الأقرب إليك.</li>
          <li>لتحسين دقة نتائج البحث.</li>
          <li>لحماية المنصة من الاستخدام المسيء (حماية من الرسائل المزعجة).</li>
        </ul>
      </section>

      <section className="mt-8 space-y-4">
        <h2 className="text-xl font-semibold">مدة الاحتفاظ بالبيانات</h2>
        <p className="text-sm">
          بيانات الحساب تُحفظ حتى تطلب حذفها. سجل البحث المحلي يبقى على جهازك حتى تمسحه أو تمسح
          بيانات المتصفح. الموقع الجغرافي لا يُحفظ إطلاقاً — يُستخدم لحظياً فقط.
        </p>
      </section>

      <section className="mt-8 space-y-4">
        <h2 className="text-xl font-semibold">هل تُشارك بياناتنا مع طرف ثالث؟</h2>
        <p className="text-sm">
          لا. لا نبيع ولا نُشارك بياناتك مع أي معلن أو شركة خارجية. نستخدم فقط خدمات بنية تحتية
          موثوقة (استضافة، قاعدة بيانات) بشروط سرية صارمة.
        </p>
      </section>

      <section className="mt-8 space-y-4">
        <h2 className="text-xl font-semibold">حقوقك</h2>
        <ul className="list-disc space-y-2 pr-6 text-sm">
          <li>طلب نسخة من بياناتك في أي وقت.</li>
          <li>حذف حسابك وكل ما يتعلق به.</li>
          <li>تصحيح أي معلومة غير دقيقة.</li>
          <li>سحب الموافقة على استخدام الموقع الجغرافي (متاح مباشرة من المتصفح).</li>
        </ul>
      </section>

      <section className="mt-8 space-y-4">
        <h2 className="text-xl font-semibold">التواصل</h2>
        <p className="text-sm">
          لأي طلب متعلق بالخصوصية أو حذف البيانات، راسلنا عبر{" "}
          <a href="mailto:privacy@tareeq.world" className="text-primary underline">
            privacy@tareeq.world
          </a>
          .
        </p>
      </section>

      <div className="mt-10 flex flex-wrap gap-3 border-t pt-6 text-sm">
        <Link to="/terms" className="text-primary hover:underline">
          شروط الاستخدام
        </Link>
        <span aria-hidden="true">·</span>
        <Link to="/" className="text-primary hover:underline">
          العودة للرئيسية
        </Link>
      </div>
    </main>
  );
}
