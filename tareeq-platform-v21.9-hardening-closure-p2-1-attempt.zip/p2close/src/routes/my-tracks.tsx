import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowRight, MapPin, ShieldCheck, Trash2, Route as RouteIcon } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { TrackImport } from "@/components/track-import";
import { listTracks, deleteTrack, type UserTrack } from "@/lib/user-tracks";
import LazyTransitMap from "@/components/LazyTransitMap";
import { usePublishSnapshot } from "@/hooks/use-publish-snapshot";
import { analyzeTrackPoints } from "@/lib/track-analytics";
import { AuthGateLoading } from "@/components/AuthGateLoading";
import { useRequireAuth } from "@/hooks/useRequireAuth";

export const Route = createFileRoute("/my-tracks")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "مساراتي — بياناتك على جهازك فقط" },
      {
        name: "description",
        content:
          "استورد ملفات مواقعك (GPX/KML/JSON) وشوفها على الخريطة. البيانات تبقى على جهازك — صفر بايت للسيرفر. تسجيل الدخول مطلوب كبوابة دخول فقط.",
      },
      { property: "og:title", content: "🗺️ مساراتي الشخصية" },
      {
        property: "og:description",
        content: "بياناتك على جهازك فقط — معالجة محلية 100%.",
      },
    ],
  }),
  component: MyTracksRoute,
});

/** مساراتي ميزة استخدام فعلية، فبتتطلب تسجيل دخول — لكن التخزين نفسه يفضل محلياً 100%. */
function MyTracksRoute() {
  const authStatus = useRequireAuth();
  if (authStatus !== "authenticated") return <AuthGateLoading />;
  return <MyTracksPage />;
}

function MyTracksPage() {
  const [tracks, setTracks] = useState<UserTrack[]>([]);
  const [selected, setSelected] = useState<string | null>(null);

  const totalKm = tracks.reduce((n, t) => n + (t.analytics?.totalDistanceKm ?? 0), 0);
  usePublishSnapshot(
    tracks.length > 0
      ? {
          id: "eg:my-tracks",
          source: "مساراتي",
          title: "مسارات مخزنة محلياً",
          summary: `${tracks.length} مسار محفوظ على جهازك · ${totalKm.toFixed(
            1,
          )} كم إجمالاً (${tracks.reduce((n, t) => n + t.points.length, 0).toLocaleString()} نقطة)`,
          category: "transit",
          href: "/my-tracks",
        }
      : null,
    [tracks.length, totalKm],
  );

  async function refresh() {
    setTracks(await listTracks());
  }

  useEffect(() => {
    void refresh();
  }, []);

  async function handleDelete(id: string) {
    await deleteTrack(id);
    if (selected === id) setSelected(null);
    await refresh();
    toast.success("تم الحذف من جهازك");
  }

  const active = tracks.find((t) => t.id === selected);
  const mapPoints =
    active?.points.map((p, i) => ({
      id: String(i),
      name: p.name || `نقطة ${i + 1}`,
      lat: p.lat,
      lng: p.lng,
      color: "#3b82f6",
    })) ?? [];

  return (
    <div dir="rtl" className="min-h-screen bg-background text-foreground">
      <header className="border-b">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
          <Link to="/" className="text-sm text-muted-foreground hover:underline">
            <span className="inline-flex items-center gap-1">
              <ArrowRight className="size-4" />
              الرئيسية
            </span>
          </Link>
          <Badge variant="outline" className="gap-1">
            <ShieldCheck className="size-3" />
            التخزين على جهازك فقط
          </Badge>
        </div>
      </header>

      <main className="mx-auto max-w-5xl space-y-6 px-4 py-8">
        <div>
          <h1 className="mb-1 text-2xl font-bold">مساراتي الشخصية</h1>
          <p className="text-sm text-muted-foreground">
            استورد ملفات مواقعك (GPX من Strava، KML من Google Earth، JSON من Google Timeline…). كل
            شيء يُعالَج ويُخزَّن على جهازك في IndexedDB — صفر بايت يغادر جهازك.
          </p>
        </div>

        <TrackImport onSaved={refresh} />

        <section>
          <h2 className="mb-3 text-lg font-bold">
            <RouteIcon className="inline size-4 align-middle" /> المسارات المحفوظة ({tracks.length})
          </h2>

          {tracks.length === 0 ? (
            <Card className="p-6 text-center text-sm text-muted-foreground">
              لا توجد مسارات محفوظة بعد. استخدم القسم أعلاه لاستيراد ملفك الأول.
            </Card>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              {tracks.map((t) => (
                <Card
                  key={t.id}
                  className={`cursor-pointer p-4 transition ${
                    selected === t.id
                      ? "border-blue-500 ring-1 ring-blue-500"
                      : "hover:border-blue-300"
                  }`}
                  onClick={() => setSelected(t.id === selected ? null : t.id)}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <h3 className="truncate text-sm font-bold">{t.name}</h3>
                      <div className="mt-1 flex flex-wrap items-center gap-1 text-xs text-muted-foreground">
                        <Badge variant="outline" className="text-[10px]">
                          {t.format.toUpperCase()}
                        </Badge>
                        <span className="inline-flex items-center gap-1">
                          <MapPin className="size-3" />
                          {t.points.length.toLocaleString()} نقطة
                        </span>
                        <span>·</span>
                        <span>{new Date(t.createdAt).toLocaleDateString("ar-EG")}</span>
                      </div>
                      {(() => {
                        const a = t.analytics ?? analyzeTrackPoints(t.points);
                        if (a.totalDistanceKm <= 0) return null;
                        return (
                          <div className="mt-2 flex flex-wrap gap-1 text-[10px]">
                            <Badge variant="secondary">📏 {a.totalDistanceKm} كم</Badge>
                            {a.totalDurationMinutes > 0 && (
                              <Badge variant="secondary">⏱ {a.totalDurationMinutes} د</Badge>
                            )}
                            {a.averageSpeedKmh > 0 && (
                              <Badge variant="secondary">🚀 {a.averageSpeedKmh} كم/س</Badge>
                            )}
                          </div>
                        );
                      })()}
                    </div>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="size-8 shrink-0 text-destructive"
                      onClick={(e) => {
                        e.stopPropagation();
                        void handleDelete(t.id);
                      }}
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </section>

        {active && (
          <section>
            <h2 className="mb-3 text-lg font-bold">معاينة: {active.name}</h2>
            <LazyTransitMap points={mapPoints} connectPoints height={400} />
          </section>
        )}
      </main>
    </div>
  );
}
