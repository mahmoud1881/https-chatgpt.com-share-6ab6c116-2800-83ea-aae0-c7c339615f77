import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import {
  AlertCircle,
  CheckCircle2,
  ClipboardPaste,
  ExternalLink,
  KeyRound,
  Loader2,
  Search,
  Sparkles,
  Trash2,
} from "lucide-react";
import { FloatingHomeButton } from "@/components/FloatingHomeButton";
import { AuthGateLoading } from "@/components/AuthGateLoading";
import { useRequireAuth } from "@/hooks/useRequireAuth";
import {
  askGemini,
  clearGeminiApiKey,
  clearGeminiHistory,
  getGeminiApiKey,
  getGeminiHistory,
  setGeminiApiKey,
  validateGeminiApiKey,
  GeminiKeyValidationError,
  type GeminiMessage,
} from "@/lib/gemini/client";

const AI_STUDIO_KEY_URL = "https://aistudio.google.com/app/apikey";

type KeySetupStep = "idle" | "awaiting" | "checking" | "error";

export const Route = createFileRoute("/ai-planner")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "المساعد الذكي — Tareeq" },
      {
        name: "description",
        content: "مساعد Gemini مباشر من متصفح المستخدم، بدون محرك أو بيانات AI من المنصة.",
      },
    ],
  }),
  component: AiPlannerRoute,
});

/** المساعد الذكي أداة استخدام فعلية للمنصة، فبيتطلب تسجيل دخول. */
function AiPlannerRoute() {
  const authStatus = useRequireAuth();
  if (authStatus !== "authenticated") return <AuthGateLoading />;
  return <AiPlannerPage />;
}

function AiPlannerPage() {
  const [apiKey, setApiKey] = useState("");
  const [query, setQuery] = useState("");
  const [messages, setMessages] = useState<GeminiMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [showKey, setShowKey] = useState(false);

  // حالة تدفّق ربط المفتاح المبسّط بضغطتين: افتح الصفحة -> الصق وفعّل
  const [keyStep, setKeyStep] = useState<KeySetupStep>("idle");
  const [keySetupError, setKeySetupError] = useState<string | null>(null);

  useEffect(() => {
    const savedKey = getGeminiApiKey();
    setApiKey(savedKey);
    setMessages(getGeminiHistory());
    // نبدأ بزر الربط المبسّط بدل ما نفتح خانة اللصق اليدوي على طول؛
    // اللصق اليدوي متاح كخيار احتياطي عبر الزر الفرعي أو تلقائيًا لو فشل اكتشاف الحافظة.
    setShowKey(false);
  }, []);

  /** يتحقق من المفتاح فعليًا عند جوجل قبل حفظه، ثم يفعّله محليًا. */
  async function commitKey(key: string) {
    setKeyStep("checking");
    setKeySetupError(null);
    try {
      await validateGeminiApiKey(key);
      setGeminiApiKey(key);
      setApiKey(key.trim());
      setShowKey(false);
      setKeyStep("idle");
      setErr(null);
    } catch (error) {
      const message =
        error instanceof GeminiKeyValidationError
          ? error.message
          : "حصل خطأ غير متوقع أثناء التحقق من المفتاح.";
      setKeySetupError(message);
      setKeyStep("error");
    }
  }

  /** الضغطة 1: يفتح صفحة إنشاء المفتاح في تبويب جديد. */
  function openAiStudio() {
    window.open(AI_STUDIO_KEY_URL, "_blank", "noopener,noreferrer");
    setKeyStep("awaiting");
    setKeySetupError(null);
  }

  /**
   * الضغطة 2: يحاول يقرا المفتاح من الحافظة تلقائيًا ويتحقق منه.
   * لو المتصفح مش بيسمح بقراءة الحافظة برمجيًا (فايرفوكس مثلًا) أو مفيش
   * حاجة منسوخة، نرجع بهدوء للصق اليدوي بدل ما نعلّق المستخدم.
   */
  async function pasteAndActivate() {
    setKeySetupError(null);
    let text: string;
    try {
      if (!navigator.clipboard?.readText) throw new Error("CLIPBOARD_UNSUPPORTED");
      text = (await navigator.clipboard.readText()).trim();
      if (!text) throw new Error("CLIPBOARD_EMPTY");
    } catch {
      setShowKey(true);
      setKeyStep("idle");
      setKeySetupError(
        "تعذّر اللصق التلقائي من المتصفح — الصق المفتاح يدويًا في الخانة تحت واضغط تفعيل.",
      );
      return;
    }
    setApiKey(text);
    await commitKey(text);
  }

  function saveKey() {
    void commitKey(apiKey);
  }

  function removeKey() {
    clearGeminiApiKey();
    clearGeminiHistory();
    setApiKey("");
    setMessages([]);
    setShowKey(true);
    setKeyStep("idle");
    setKeySetupError(null);
  }

  function clearChat() {
    clearGeminiHistory();
    setMessages([]);
    setErr(null);
  }

  async function ask(e: FormEvent) {
    e.preventDefault();
    const prompt = query.trim();
    if (!apiKey.trim()) {
      setErr("أدخل مفتاح Gemini الخاص بك أولًا.");
      return;
    }
    if (!prompt || loading) return;

    setGeminiApiKey(apiKey);
    setLoading(true);
    setErr(null);
    try {
      const reply = await askGemini(prompt, { useSearch: true });
      setMessages(getGeminiHistory());
      setQuery("");
      void reply;
    } catch (error) {
      const code = error instanceof Error ? error.message : "";
      if (code === "GEMINI_API_KEY_INVALID")
        setErr("مفتاح Gemini غير صالح أو غير مسموح له باستخدام Gemini API.");
      else if (code === "GEMINI_RATE_LIMITED")
        setErr("تم الوصول إلى حد الاستخدام في حساب Gemini. جرّب لاحقًا أو راجع حصة حسابك.");
      else if (code.startsWith("GEMINI_HTTP_"))
        setErr("تعذر إكمال طلب Gemini. تحقق من الإنترنت وإعدادات حساب Google.");
      else setErr("حدث خطأ أثناء الاتصال بـ Gemini.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-background p-6" dir="rtl">
      <FloatingHomeButton />
      <div className="max-w-3xl mx-auto space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            <div>
              <h1 className="text-2xl font-bold">المساعد الذكي</h1>
              <p className="text-xs text-muted-foreground mt-1">Gemini مباشرة من متصفحك</p>
            </div>
          </div>
          {messages.length > 0 && (
            <button
              type="button"
              onClick={clearChat}
              className="px-3 py-2 rounded-xl border border-border text-xs font-bold"
            >
              محادثة جديدة
            </button>
          )}
        </div>

        <div className="bg-card border border-border rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 font-semibold">
              <KeyRound className="h-4 w-4" />
              {apiKey ? "المساعد مفعّل" : "تفعيل المساعد مرة واحدة"}
            </div>
            <div className="flex items-center gap-2">
              {apiKey && (
                <button
                  type="button"
                  onClick={() => setShowKey((value) => !value)}
                  className="px-3 py-2 rounded-xl border border-border text-xs font-bold"
                >
                  {showKey ? "إخفاء" : "تغيير المفتاح"}
                </button>
              )}
              {apiKey && (
                <button
                  type="button"
                  onClick={removeKey}
                  title="حذف المفتاح والمحادثة"
                  aria-label="حذف المفتاح والمحادثة"
                  className="p-2 rounded-xl border border-border"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            استخدم Gemini الخاص بك. المفتاح يبقى على جهازك ولا يُرسل إلى خادم المنصة؛ المتصفح يتصل
            مباشرة بـ Google Gemini.
          </p>
          {!apiKey && keyStep !== "checking" && (
            <div className="space-y-2">
              {keyStep === "idle" && (
                <button
                  type="button"
                  onClick={openAiStudio}
                  className="w-full flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-primary text-primary-foreground text-sm font-bold"
                >
                  <ExternalLink className="h-4 w-4" />
                  1) افتح Google AI Studio واحصل على مفتاحك
                </button>
              )}

              {keyStep === "awaiting" && (
                <div className="space-y-2">
                  <button
                    type="button"
                    onClick={pasteAndActivate}
                    className="w-full flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-primary text-primary-foreground text-sm font-bold"
                  >
                    <ClipboardPaste className="h-4 w-4" />
                    2) الصق المفتاح وفعّل
                  </button>
                  <button
                    type="button"
                    onClick={openAiStudio}
                    className="w-full text-xs text-muted-foreground underline"
                  >
                    لسه معملتش نسخ؟ افتح الصفحة تاني
                  </button>
                </div>
              )}

              {keyStep === "error" && (
                <button
                  type="button"
                  onClick={openAiStudio}
                  className="w-full flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-primary text-primary-foreground text-sm font-bold"
                >
                  <ExternalLink className="h-4 w-4" />
                  حاول تاني
                </button>
              )}

              {keySetupError && (
                <div className="flex items-start gap-2 text-xs bg-destructive/10 text-destructive rounded-xl p-3">
                  <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                  <span>{keySetupError}</span>
                </div>
              )}

              <button
                type="button"
                onClick={() => setShowKey((value) => !value)}
                className="w-full text-xs text-muted-foreground underline"
              >
                {showKey ? "إخفاء اللصق اليدوي" : "أو الصق المفتاح يدويًا"}
              </button>
            </div>
          )}

          {keyStep === "checking" && (
            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground py-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              بنتحقق من المفتاح تلقائيًا...
            </div>
          )}

          {showKey && keyStep !== "checking" && (
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="الصق مفتاح Gemini هنا"
                autoComplete="off"
                className="flex-1 px-4 py-3 rounded-xl bg-background border border-border text-sm font-mono"
              />
              <button
                type="button"
                onClick={saveKey}
                disabled={!apiKey.trim()}
                className="px-5 py-3 rounded-xl bg-primary text-primary-foreground text-sm font-bold disabled:opacity-50"
              >
                تفعيل
              </button>
            </div>
          )}
          {apiKey && !showKey && (
            <p className="flex items-center gap-2 text-xs text-emerald-600">
              <CheckCircle2 className="h-4 w-4" />
              جاهز — يمكنك الكتابة مباشرة. لن نطلب المفتاح مرة أخرى على هذا الجهاز.
            </p>
          )}
        </div>

        <div className="bg-primary/5 border border-primary/10 rounded-2xl p-4 text-sm leading-7">
          <div className="flex items-center gap-2 font-bold mb-1">
            <Search className="h-4 w-4" /> Gemini يعمل من جهازك
          </div>
          <p className="text-muted-foreground">
            اكتب طلبك طبيعيًا. Gemini هو الذي يفهم ويحلل ويبحث عند الحاجة ويستخدم الأدوات المتاحة،
            ثم تعود الإجابة الكاملة إلى منصتك. لا نستخدم محرك AI أو بيانات نقل من المنصة لهذا
            المساعد.
          </p>
        </div>

        <form onSubmit={ask} className="flex gap-2">
          <textarea
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="مثال: عايز أعرف أفضل طريقة للسفر من المنيا للقاهرة غدًا، وما الذي يجب أن أنتبه له؟"
            rows={3}
            className="flex-1 px-4 py-3 rounded-xl bg-card border border-border text-sm resize-y"
          />
          <button
            type="submit"
            disabled={loading || !query.trim() || !apiKey.trim()}
            className="self-end px-5 py-3 rounded-xl bg-primary text-primary-foreground text-sm font-bold disabled:opacity-50 min-w-24"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin mx-auto" /> : "اسأل"}
          </button>
        </form>

        {err && (
          <div className="flex items-start gap-2 text-sm bg-destructive/10 text-destructive rounded-xl p-3">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{err}</span>
          </div>
        )}

        <div className="space-y-3">
          {messages.map((message, index) => (
            <article
              key={`${message.role}-${index}`}
              className={
                message.role === "user"
                  ? "rounded-2xl bg-primary/10 border border-primary/10 p-4"
                  : "rounded-2xl bg-card border border-border p-5"
              }
            >
              <div className="text-xs font-bold text-muted-foreground mb-2">
                {message.role === "user" ? "أنت" : "Gemini"}
              </div>
              <div className="text-sm leading-7 whitespace-pre-wrap">{message.text}</div>
              {message.citations && message.citations.length > 0 && (
                <div className="mt-4 pt-3 border-t border-border space-y-1">
                  <div className="text-xs font-bold text-muted-foreground">
                    المصادر التي استخدمها Gemini
                  </div>
                  {message.citations.map((citation, citationIndex) => (
                    <a
                      key={`${citation.url}-${citationIndex}`}
                      href={citation.url}
                      target="_blank"
                      rel="noreferrer"
                      className="block text-xs text-primary underline truncate"
                    >
                      {citation.title || citation.url}
                    </a>
                  ))}
                </div>
              )}
            </article>
          ))}
        </div>

        <p className="text-[11px] text-muted-foreground text-center leading-5">
          ملاحظة: المنصة لا تدفع تكلفة Gemini ولا تستخدم مفتاحًا خاصًا بها. استخدام Gemini يخضع لحصة
          وشروط حساب Google الذي أدخل مفتاحه المستخدم.
        </p>
      </div>
    </div>
  );
}
