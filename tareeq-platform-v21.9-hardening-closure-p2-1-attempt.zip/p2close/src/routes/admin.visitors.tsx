import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { FloatingHomeButton } from "@/components/FloatingHomeButton";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/visitors")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "متابعة زوار الموقع — لوحة الإدارة" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: VisitorsPage,
});

type Row = Record<string, unknown>;

function fmtNum(n: number | null | undefined) {
  if (n == null) return "—";
  return new Intl.NumberFormat("ar-EG").format(n);
}
function fmtDate(iso: string) {
  try {
    return new Date(iso).toLocaleString("ar-EG", {
      day: "2-digit",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}
function shortUA(ua: string | null | undefined): string {
  if (!ua) return "—";
  if (/Android/i.test(ua)) return "Android";
  if (/iPhone|iPad|iOS/i.test(ua)) return "iOS";
  if (/Windows/i.test(ua)) return "Windows";
  if (/Mac OS/i.test(ua)) return "macOS";
  if (/Linux/i.test(ua)) return "Linux";
  return "غير معروف";
}

interface DailyPoint {
  day: string;
  sessions: number;
  unique_users: number;
}
interface TopQuery {
  q: string;
  hits: number;
}
interface RecentSession {
  id: string;
  started_at: string;
  last_seen_at: string;
  ended_at: string | null;
  user_agent: string | null;
  platform: string | null;
  user_id: string | null;
  display_name?: string | null;
}
interface AnonRow {
  day: string;
  anon_hits: number;
}

interface Payload {
  totalSessions30d: number;
  uniqueUsers30d: number;
  activeNow: number;
  anon24h: number;
  daily14d: DailyPoint[];
  anonDaily14d: AnonRow[];
  platforms: { platform: string; count: number }[];
  browsers: { browser: string; count: number }[];
  topQueries: TopQuery[];
  topMissing: TopQuery[];
  recentSessions: RecentSession[];
  incidents24h: number;
}

function VisitorsPage() {
  const [phase, setPhase] = useState<"loading" | "denied" | "ready">("loading");
  const [data, setData] = useState<Payload | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const load = async () => {
    setRefreshing(true);
    try {
      const since30 = new Date(Date.now() - 30 * 864e5).toISOString();
      const since14 = new Date(Date.now() - 14 * 864e5).toISOString();
      const since24h = new Date(Date.now() - 24 * 3600e3).toISOString();
      const active = new Date(Date.now() - 2 * 60e3).toISOString();

      const [sess30, sessActive, sess14, anon14, plat, topQ, topM, recent, inc, anon24] =
        await Promise.all([
          supabase
            .from("user_sessions")
            .select("user_id, started_at, user_agent, platform", { count: "exact" })
            .gte("started_at", since30)
            .limit(5000),
          supabase
            .from("user_sessions")
            .select("user_id", { count: "exact", head: true })
            .is("ended_at", null)
            .gte("last_seen_at", active),
          supabase
            .from("user_sessions")
            .select("started_at, user_id")
            .gte("started_at", since14)
            .limit(10000),
          supabase
            .from("search_logs")
            .select("created_at")
            .is("user_id", null)
            .gte("created_at", since14)
            .limit(10000),
          supabase
            .from("user_sessions")
            .select("user_agent, platform")
            .gte("started_at", since30)
            .limit(5000),
          supabase
            .from("search_logs")
            .select("from_query, to_query")
            .gte("created_at", since30)
            .limit(5000),
          supabase
            .from("missing_searches")
            .select("from_query, to_query, hits")
            .order("hits", { ascending: false })
            .limit(15),
          supabase
            .from("user_sessions")
            .select("id, user_id, started_at, last_seen_at, ended_at, user_agent, platform")
            .order("started_at", { ascending: false })
            .limit(30),
          supabase
            .from("api_incidents")
            .select("*", { count: "exact", head: true })
            .gte("created_at", since24h),
          supabase
            .from("search_logs")
            .select("*", { count: "exact", head: true })
            .is("user_id", null)
            .gte("created_at", since24h),
        ]);

      // Aggregate daily
      const byDay = new Map<string, { s: Set<string>; u: Set<string> }>();
      for (const r of (sess14.data ?? []) as Row[]) {
        const d = String(r.started_at).slice(0, 10);
        const bucket = byDay.get(d) ?? { s: new Set(), u: new Set() };
        bucket.s.add(String(r.started_at));
        if (r.user_id) bucket.u.add(String(r.user_id));
        byDay.set(d, bucket);
      }
      const daily14d: DailyPoint[] = Array.from(byDay.entries())
        .map(([day, b]) => ({ day, sessions: b.s.size, unique_users: b.u.size }))
        .sort((a, b) => a.day.localeCompare(b.day));

      const byDayAnon = new Map<string, number>();
      for (const r of (anon14.data ?? []) as Row[]) {
        const d = String(r.created_at).slice(0, 10);
        byDayAnon.set(d, (byDayAnon.get(d) ?? 0) + 1);
      }
      const anonDaily14d: AnonRow[] = Array.from(byDayAnon.entries())
        .map(([day, c]) => ({ day, anon_hits: c }))
        .sort((a, b) => a.day.localeCompare(b.day));

      // Platforms / browsers
      const platMap = new Map<string, number>();
      const brMap = new Map<string, number>();
      for (const r of (plat.data ?? []) as Row[]) {
        const p = String(r.platform || "غير معروف");
        platMap.set(p, (platMap.get(p) ?? 0) + 1);
        const br = shortUA(String(r.user_agent || ""));
        brMap.set(br, (brMap.get(br) ?? 0) + 1);
      }
      const platforms = Array.from(platMap.entries())
        .map(([platform, count]) => ({ platform, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 8);
      const browsers = Array.from(brMap.entries())
        .map(([browser, count]) => ({ browser, count }))
        .sort((a, b) => b.count - a.count);

      // Top queries
      const qMap = new Map<string, number>();
      for (const r of (topQ.data ?? []) as Row[]) {
        const q = `${String(r.from_query || "").trim()} → ${String(r.to_query || "").trim()}`;
        if (q.trim() === "→") continue;
        qMap.set(q, (qMap.get(q) ?? 0) + 1);
      }
      const topQueries: TopQuery[] = Array.from(qMap.entries())
        .map(([q, hits]) => ({ q, hits }))
        .sort((a, b) => b.hits - a.hits)
        .slice(0, 15);

      const topMissing: TopQuery[] = ((topM.data ?? []) as Row[]).map((r) => ({
        q: `${String(r.from_query || "")} → ${String(r.to_query || "")}`,
        hits: Number(r.hits ?? 0),
      }));

      // Enrich recent sessions with display_name
      const recentRows = (recent.data ?? []) as RecentSession[];
      const uids = Array.from(
        new Set(recentRows.map((r) => r.user_id).filter(Boolean)),
      ) as string[];
      let names = new Map<string, string>();
      if (uids.length) {
        const { data: profs } = await supabase
          .from("profiles")
          .select("id, display_name")
          .in("id", uids);
        names = new Map(
          ((profs ?? []) as Row[]).map((p) => [String(p.id), String(p.display_name ?? "")]),
        );
      }
      const recentSessions = recentRows.map((r) => ({
        ...r,
        display_name: r.user_id ? names.get(r.user_id) : null,
      }));

      const uniq = new Set<string>();
      for (const r of (sess30.data ?? []) as Row[]) if (r.user_id) uniq.add(String(r.user_id));

      setData({
        totalSessions30d: sess30.count ?? sess30.data?.length ?? 0,
        uniqueUsers30d: uniq.size,
        activeNow: sessActive.count ?? 0,
        anon24h: anon24.count ?? 0,
        daily14d,
        anonDaily14d,
        platforms,
        browsers,
        topQueries,
        topMissing,
        recentSessions,
        incidents24h: inc.count ?? 0,
      });
      setPhase("ready");
    } catch (e) {
      console.error(e);
      toast.error("تعذر تحميل بيانات الزوار");
      setPhase("denied");
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    void load();
    const t = setInterval(() => void load(), 60_000);
    return () => clearInterval(t);
  }, []);

  const maxDaily = useMemo(() => {
    if (!data) return 1;
    return Math.max(
      1,
      ...data.daily14d.map((d) => d.sessions),
      ...data.anonDaily14d.map((d) => d.anon_hits),
    );
  }, [data]);

  if (phase === "loading" && !data) {
    return (
      <div className="min-h-screen grid place-items-center" dir="rtl">
        <p className="text-sm text-muted-foreground">جاري التحميل…</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white pb-16" dir="rtl">
      <FloatingHomeButton />
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur border-b">
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center gap-3">
          <h1 className="text-lg font-bold">👁️ متابعة الزوار</h1>
          <span className="text-[10px] rounded-full bg-emerald-100 text-emerald-700 px-2 py-0.5 font-bold">
            LIVE
          </span>
          <Link
            to="/admin/stats"
            className="mr-auto text-xs font-bold text-primary hover:underline"
          >
            إحصائيات الإدارة →
          </Link>
          <button
            onClick={() => void load()}
            disabled={refreshing}
            className="rounded-lg border bg-white px-3 py-1.5 text-xs font-bold hover:bg-muted disabled:opacity-50"
          >
            {refreshing ? "…" : "تحديث"}
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6 space-y-6">
        {!data ? null : (
          <>
            <section className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Kpi
                label="نشِط الآن"
                value={fmtNum(data.activeNow)}
                accent="emerald"
                hint="آخر دقيقتين"
              />
              <Kpi label="مستخدمون فريدون (30 يوم)" value={fmtNum(data.uniqueUsers30d)} />
              <Kpi label="جلسات (30 يوم)" value={fmtNum(data.totalSessions30d)} />
              <Kpi
                label="زوار مجهولون (24 ساعة)"
                value={fmtNum(data.anon24h)}
                accent="sky"
                hint="عبر عمليات البحث"
              />
            </section>

            <section className="rounded-2xl border bg-white p-5 shadow-sm">
              <h2 className="font-bold mb-3">📈 حركة الزوار — 14 يوم</h2>
              <StackedBars daily={data.daily14d} anon={data.anonDaily14d} max={maxDaily} />
              <div className="flex gap-4 mt-3 text-[11px] text-muted-foreground">
                <span className="flex items-center gap-1">
                  <span className="size-2 rounded bg-emerald-500" /> جلسات مسجلين
                </span>
                <span className="flex items-center gap-1">
                  <span className="size-2 rounded bg-sky-400" /> زوار مجهولون
                </span>
              </div>
            </section>

            <div className="grid md:grid-cols-2 gap-4">
              <section className="rounded-2xl border bg-white p-5 shadow-sm">
                <h2 className="font-bold mb-3">📱 المنصات</h2>
                <BarList
                  items={data.platforms.map((p) => ({ label: p.platform, value: p.count }))}
                />
              </section>
              <section className="rounded-2xl border bg-white p-5 shadow-sm">
                <h2 className="font-bold mb-3">🌐 نظام التشغيل</h2>
                <BarList items={data.browsers.map((b) => ({ label: b.browser, value: b.count }))} />
              </section>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <section className="rounded-2xl border bg-white p-5 shadow-sm">
                <h2 className="font-bold mb-3">🔥 أكثر عمليات البحث (30 يوم)</h2>
                {data.topQueries.length === 0 ? (
                  <p className="text-xs text-muted-foreground">لا يوجد بيانات</p>
                ) : (
                  <ul className="space-y-1.5">
                    {data.topQueries.map((q, i) => (
                      <li key={i} className="flex items-center gap-2 text-xs">
                        <span className="w-5 text-center font-bold text-muted-foreground">
                          {i + 1}
                        </span>
                        <span className="truncate flex-1">{q.q}</span>
                        <span className="rounded bg-emerald-50 text-emerald-700 px-2 py-0.5 font-bold">
                          {fmtNum(q.hits)}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </section>

              <section className="rounded-2xl border bg-white p-5 shadow-sm">
                <h2 className="font-bold mb-3">❓ عمليات بحث بدون نتائج</h2>
                {data.topMissing.length === 0 ? (
                  <p className="text-xs text-muted-foreground">لا يوجد بيانات</p>
                ) : (
                  <ul className="space-y-1.5">
                    {data.topMissing.map((q, i) => (
                      <li key={i} className="flex items-center gap-2 text-xs">
                        <span className="w-5 text-center font-bold text-muted-foreground">
                          {i + 1}
                        </span>
                        <span className="truncate flex-1">{q.q}</span>
                        <span className="rounded bg-rose-50 text-rose-700 px-2 py-0.5 font-bold">
                          {fmtNum(q.hits)}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            </div>

            <section className="rounded-2xl border bg-white p-5 shadow-sm">
              <div className="flex items-center gap-2 mb-3">
                <h2 className="font-bold">🕒 آخر الزيارات</h2>
                {data.incidents24h > 0 && (
                  <span className="mr-auto text-[10px] rounded-full bg-rose-100 text-rose-700 px-2 py-0.5 font-bold">
                    {fmtNum(data.incidents24h)} حادث آخر 24س
                  </span>
                )}
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead className="text-muted-foreground">
                    <tr className="text-right">
                      <th className="p-2">المستخدم</th>
                      <th className="p-2">المنصة</th>
                      <th className="p-2">النظام</th>
                      <th className="p-2">البداية</th>
                      <th className="p-2">آخر نشاط</th>
                      <th className="p-2">الحالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.recentSessions.map((s) => {
                      const active =
                        !s.ended_at && new Date(s.last_seen_at).getTime() > Date.now() - 2 * 60e3;
                      return (
                        <tr key={s.id} className="border-t">
                          <td className="p-2 font-bold">
                            {s.display_name || (s.user_id ? "مستخدم" : "زائر")}
                          </td>
                          <td className="p-2 text-muted-foreground">{s.platform ?? "—"}</td>
                          <td className="p-2 text-muted-foreground">{shortUA(s.user_agent)}</td>
                          <td className="p-2 text-muted-foreground">{fmtDate(s.started_at)}</td>
                          <td className="p-2 text-muted-foreground">{fmtDate(s.last_seen_at)}</td>
                          <td className="p-2">
                            {active ? (
                              <span className="inline-flex items-center gap-1 text-emerald-600 font-bold">
                                <span className="size-1.5 rounded-full bg-emerald-500 animate-pulse" />{" "}
                                نشط
                              </span>
                            ) : (
                              <span className="text-muted-foreground">منتهية</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </section>
          </>
        )}
      </main>
    </div>
  );
}

function Kpi({
  label,
  value,
  accent,
  hint,
}: {
  label: string;
  value: string;
  accent?: "emerald" | "sky";
  hint?: string;
}) {
  const color =
    accent === "emerald"
      ? "text-emerald-600"
      : accent === "sky"
        ? "text-sky-600"
        : "text-foreground";
  return (
    <div className="rounded-2xl border bg-white p-4 shadow-sm">
      <div className="text-[11px] text-muted-foreground">{label}</div>
      <div className={`mt-1 text-2xl font-bold ${color}`}>{value}</div>
      {hint && <div className="text-[10px] text-muted-foreground mt-1">{hint}</div>}
    </div>
  );
}

function BarList({ items }: { items: { label: string; value: number }[] }) {
  const max = Math.max(1, ...items.map((i) => i.value));
  if (!items.length) return <p className="text-xs text-muted-foreground">لا يوجد بيانات</p>;
  return (
    <ul className="space-y-2">
      {items.map((it) => (
        <li key={it.label} className="text-xs">
          <div className="flex justify-between mb-1">
            <span className="font-bold">{it.label}</span>
            <span className="text-muted-foreground">
              {new Intl.NumberFormat("ar-EG").format(it.value)}
            </span>
          </div>
          <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-l from-emerald-500 to-emerald-300"
              style={{ width: `${(it.value / max) * 100}%` }}
            />
          </div>
        </li>
      ))}
    </ul>
  );
}

function StackedBars({
  daily,
  anon,
  max,
}: {
  daily: { day: string; sessions: number }[];
  anon: { day: string; anon_hits: number }[];
  max: number;
}) {
  const days = new Set<string>();
  daily.forEach((d) => days.add(d.day));
  anon.forEach((d) => days.add(d.day));
  const arr = Array.from(days).sort();
  if (!arr.length) return <p className="text-xs text-muted-foreground">لا يوجد بيانات</p>;
  const dMap = new Map(daily.map((d) => [d.day, d.sessions]));
  const aMap = new Map(anon.map((d) => [d.day, d.anon_hits]));
  return (
    <div className="flex items-end gap-1 h-40">
      {arr.map((day) => {
        const s = dMap.get(day) ?? 0;
        const a = aMap.get(day) ?? 0;
        const total = s + a;
        return (
          <div
            key={day}
            className="flex-1 flex flex-col items-center gap-1"
            title={`${day}: ${s} مسجل + ${a} مجهول`}
          >
            <div
              className="w-full flex flex-col-reverse"
              style={{ height: `${Math.max(2, (total / max) * 100)}%` }}
            >
              <div
                className="w-full bg-emerald-500"
                style={{ height: `${(s / Math.max(1, total)) * 100}%` }}
              />
              <div
                className="w-full bg-sky-400"
                style={{ height: `${(a / Math.max(1, total)) * 100}%` }}
              />
            </div>
            <span className="text-[9px] text-muted-foreground">{day.slice(5)}</span>
          </div>
        );
      })}
    </div>
  );
}
