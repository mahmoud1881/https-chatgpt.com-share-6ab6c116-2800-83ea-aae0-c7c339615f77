import { createFileRoute, Link } from "@tanstack/react-router";
import { TrainFront, ArrowRight, MapPin, Clock, Navigation, AlertTriangle } from "lucide-react";

import { CAPITAL_TRAIN_STATIONS } from "@/data/capitalTrainStations";

import { egHead, getEgPage } from "@/lib/seo/eg-meta";

export const Route = createFileRoute("/capital-train")({
  head: () => {
    const p = getEgPage("/capital-train")!;
    return egHead({
      path: p.path,
      titleAr: p.titleAr,
      descAr: p.descAr,
      ogImage: p.ogImage,
      breadcrumbLabel: "قطار العاصمة",
    });
  },
  component: CapitalTrainPage,
});

import { gmapsCoords } from "@/lib/geo/gmaps";
const gmaps = (lat: number, lng: number, label?: string) =>
  label
    ? `${gmapsCoords(lat, lng)}&query_place_id=${encodeURIComponent(label)}`
    : gmapsCoords(lat, lng);

const westStations: { name: string; note?: string }[] = [
  { name: "أكتوبر الجديدة" },
  { name: "جامعة الأهرام الكندية" },
  { name: "السادات" },
  { name: "جهاز 6 أكتوبر" },
  { name: "نقابة المهندسين", note: "محطة ربط مع القطار الكهربائي السريع" },
  { name: "مول مصر" },
  { name: "مدينة الشيخ زايد" },
  { name: "طريق القاهرة - الإسكندرية الصحراوي" },
  { name: "المنصورية" },
  { name: "المريوطية" },
  { name: "الطريق الدائري" },
  { name: "بشتيل", note: "محطة ربط مع محطة سكك حديد بشتيل لقطارات الصعيد" },
  { name: "وادي النيل", note: "محطة ربط مع الخط الثالث لمترو الأنفاق" },
];

function CapitalTrainPage() {
  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-b from-indigo-50 to-white">
      <header className="sticky top-0 z-10 border-b bg-white/80 backdrop-blur">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white shadow">
              <TrainFront className="size-5" />
            </div>
            <div>
              <div className="text-base font-extrabold">قطار العاصمة</div>
              <div className="text-[11px] text-muted-foreground">LRT — القطار الكهربائي الخفيف</div>
            </div>
          </div>
          <Link
            to="/"
            className="inline-flex items-center gap-1 text-sm text-primary hover:underline"
          >
            <ArrowRight className="size-4" />
            الرئيسية
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-4 py-6">
        <div
          className="mb-5 rounded-xl border-2 border-amber-300 bg-amber-50 p-4 shadow-sm"
          role="alert"
        >
          <div className="flex items-start gap-3">
            <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-amber-500 text-white">
              <AlertTriangle className="size-4" />
            </div>
            <div className="flex-1">
              <div className="text-sm font-bold text-amber-900">بيانات تحت المراجعة</div>
              <p className="mt-1 text-xs leading-relaxed text-amber-800">
                محطات ومواعيد قطار العاصمة (LRT) وخط مونوريل غرب النيل معروضة كمرجع مبدئي فقط ولم
                يتم التحقق منها بعد من مصدر رسمي. يُرجى التأكد من الجهات المختصة قبل الاعتماد عليها.
              </p>
              <div className="mt-2 flex flex-wrap gap-2 text-[11px]">
                <span className="rounded-full bg-white/70 px-2 py-0.5 font-semibold text-amber-800 border border-amber-200">
                  الحالة: قيد المراجعة
                </span>
                <span className="rounded-full bg-white/70 px-2 py-0.5 font-mono text-amber-700 border border-amber-200">
                  آخر تحديث: —
                </span>
              </div>
            </div>
          </div>
        </div>

        <section className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="rounded-xl border bg-white p-4 shadow-sm">
            <div className="flex items-center gap-2 text-indigo-600">
              <MapPin className="size-5" />
              <span className="text-sm font-semibold">المسار</span>
            </div>
            <div className="mt-1 text-lg font-bold">عدلي منصور ↔ العاصمة</div>
            <div className="text-xs text-muted-foreground">حوالي 70 كم</div>
          </div>
          <div className="rounded-xl border bg-white p-4 shadow-sm">
            <div className="flex items-center gap-2 text-emerald-600">
              <Clock className="size-5" />
              <span className="text-sm font-semibold">المواعيد</span>
            </div>
            <div className="mt-1 text-lg font-bold">٦ ص — ١٢ م</div>
            <div className="text-xs text-muted-foreground">كل 10–15 دقيقة</div>
          </div>
        </section>

        <section className="mt-6 rounded-2xl border bg-white p-5 shadow-sm">
          <div className="mb-4 flex items-center justify-between gap-2 flex-wrap">
            <h2 className="text-lg font-bold">المحطات والمناطق المخدومة</h2>
            <span className="text-[11px] text-muted-foreground">
              {CAPITAL_TRAIN_STATIONS.length} محطة · 8 مناطق لكل محطة
            </span>
          </div>
          <ol className="relative space-y-5 border-r-2 border-indigo-200 pr-5">
            {CAPITAL_TRAIN_STATIONS.map((s, i) => (
              <li key={s.name} className="relative">
                <span className="absolute -right-[27px] top-1 flex h-4 w-4 items-center justify-center rounded-full bg-indigo-500 text-[10px] font-bold text-white">
                  {i + 1}
                </span>
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="text-sm font-bold text-indigo-900">{s.name}</div>
                  <a
                    href={gmaps(s.lat, s.lng)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 rounded-full border border-indigo-200 bg-indigo-50 px-2 py-0.5 text-[10px] font-semibold text-indigo-700 hover:bg-indigo-100"
                    title={`${s.lat.toFixed(4)}, ${s.lng.toFixed(4)}`}
                  >
                    <Navigation className="size-3" />
                    {s.lat.toFixed(4)}, {s.lng.toFixed(4)}
                  </a>
                </div>
                {s.interchange && (
                  <div className="mt-0.5 text-[11px] text-muted-foreground">{s.interchange}</div>
                )}
                <details className="mt-2 group">
                  <summary className="cursor-pointer text-xs font-semibold text-indigo-700 hover:underline">
                    المناطق المخدومة ({s.areas.length})
                  </summary>
                  <ul className="mt-2 grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                    {s.areas.map((a) => (
                      <li key={a.name}>
                        <a
                          href={gmaps(a.lat, a.lng)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center justify-between gap-2 rounded-md border border-slate-200 bg-slate-50 px-2 py-1 text-[11px] text-slate-700 hover:border-indigo-300 hover:bg-indigo-50"
                        >
                          <span className="flex items-center gap-1 truncate">
                            <MapPin className="size-3 shrink-0 text-indigo-500" />
                            <span className="truncate">{a.name}</span>
                          </span>
                          <span className="shrink-0 font-mono text-[10px] text-muted-foreground">
                            {a.lat.toFixed(3)},{a.lng.toFixed(3)}
                          </span>
                        </a>
                      </li>
                    ))}
                  </ul>
                </details>
              </li>
            ))}
          </ol>
        </section>
        <section className="mt-6 rounded-2xl border bg-white p-5 shadow-sm">
          <h2 className="mb-1 text-lg font-bold">خط مونوريل غرب النيل</h2>
          <p className="mb-3 text-xs text-muted-foreground">يشتمل الخط على 13 محطة ركاب</p>
          <ol className="relative space-y-3 border-r-2 border-violet-200 pr-5">
            {westStations.map((s, i) => (
              <li key={s.name} className="relative">
                <span className="absolute -right-[27px] top-1 flex h-4 w-4 items-center justify-center rounded-full bg-violet-500 text-[10px] font-bold text-white">
                  {i + 1}
                </span>
                <div className="text-sm font-semibold">{s.name}</div>
                {s.note && <div className="text-xs text-muted-foreground">{s.note}</div>}
              </li>
            ))}
          </ol>
        </section>
      </main>
    </div>
  );
}
