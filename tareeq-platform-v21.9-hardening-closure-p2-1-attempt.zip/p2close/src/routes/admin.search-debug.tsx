import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { AdminPageShell } from "@/components/admin/AdminPageShell";
import { toast } from "sonner";
import { AlertTriangle, Loader2, RefreshCw, Search } from "lucide-react";
import { StatCard } from "@/components/admin/StatCard";
import {
  listRecentSearchLogs,
  getSearchHealthStats,
  type SearchLogRow,
  type SearchHealthStats,
} from "@/lib/route-planner/admin-search-debug.functions";

export const Route = createFileRoute("/admin/search-debug")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "تشخيص البحث — Tareeq Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: SearchDebugPage,
});

const SOURCE_COLORS: Record<string, string> = {
  database_direct: "bg-emerald-100 text-emerald-800",
  database_transfer: "bg-sky-100 text-sky-800",
  alias_match: "bg-amber-100 text-amber-800",
  no_verified_data: "bg-red-100 text-red-800",
  old_fallback: "bg-zinc-200 text-zinc-800",
};

const REASON_AR: Record<string, string> = {
  no_from: "لم يُتعرَّف على البداية",
  no_to: "لم يُتعرَّف على الوصول",
  no_from_and_to: "البداية والوصول غير معروفَين",
  no_route_between_matched_stops: "لا يوجد خط مربوط بين المحطتَين",
  no_route: "لا يوجد خط",
};

function SearchDebugPage() {
  const navigate = useNavigate();
  const [logs, setLogs] = useState<SearchLogRow[] | null>(null);
  const [stats, setStats] = useState<SearchHealthStats | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchLogs = useServerFn(listRecentSearchLogs);
  const fetchStats = useServerFn(getSearchHealthStats);
  useEffect(() => {
    (async () => {
      await refresh();
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function refresh() {
    setLoading(true);
    try {
      const [l, s] = await Promise.all([fetchLogs(), fetchStats()]);
      setLogs(l.rows);
      setStats(s);
    } catch (err) {
      toast.error(`فشل التحميل: ${(err as Error).message}`);
    } finally {
      setLoading(false);
    }
  }

  const showWarning = stats && stats.routes_total > 0 && stats.routes_without_stops_pct > 30;

  return (
    <AdminPageShell>
      <header className="px-4 pt-6 pb-4 flex items-center justify-between">
        <Link to="/admin/data-health" className="text-xs underline text-muted-foreground">
          ← صحّة البيانات
        </Link>
        <h1 className="text-lg font-bold flex items-center gap-2">
          <Search className="w-5 h-5" /> تشخيص البحث
        </h1>
        <button
          onClick={refresh}
          disabled={loading}
          className="rounded-lg border px-3 py-1.5 text-sm hover:bg-muted disabled:opacity-50"
        >
          <RefreshCw className={`inline size-4 me-1 ${loading ? "animate-spin" : ""}`} /> تحديث
        </button>
      </header>

      <div className="container mx-auto max-w-6xl px-4">
        {showWarning && (
          <div className="mb-6 rounded-lg border border-amber-300 bg-amber-50 p-4">
            <div className="flex items-start gap-2">
              <AlertTriangle className="mt-0.5 size-5 text-amber-600" />
              <div>
                <p className="font-semibold text-amber-900">تحذير جوهري</p>
                <p className="text-sm text-amber-800">
                  المشكلة الأساسية أن الخطوط غير مربوطة بمحطات مرتّبة، لذلك البحث لن يتحسّن. (
                  {stats!.routes_without_stops_pct}% — {stats!.routes_without_stops} من{" "}
                  {stats!.routes_total} خط بدون route_stops).
                </p>
              </div>
            </div>
          </div>
        )}

        {stats && (
          <>
            <section className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
              <StatCard labelPosition="bottom" label="عدد الخطوط" value={stats.routes_total} />
              <StatCard
                labelPosition="bottom"
                label="خطوط لها محطات"
                value={stats.routes_with_stops}
              />
              <StatCard
                labelPosition="bottom"
                label="خطوط بدون محطات"
                value={stats.routes_without_stops}
                tone="red"
              />
              <StatCard
                labelPosition="bottom"
                label="نسبة الخطوط الفارغة"
                value={`${stats.routes_without_stops_pct}%`}
              />
              <StatCard labelPosition="bottom" label="عدد المحطات" value={stats.stops_total} />
              <StatCard
                labelPosition="bottom"
                label="محطات لها أسماء بديلة"
                value={stats.stops_with_aliases}
              />
              <StatCard
                labelPosition="bottom"
                label="محطات مكرّرة"
                value={stats.duplicate_stops}
                tone="amber"
              />
              <StatCard
                labelPosition="bottom"
                label="عمليات بحث آخر 30 يوم"
                value={stats.logs_total_30d}
              />
            </section>
            <section className="mb-8 grid grid-cols-2 gap-3 md:grid-cols-4">
              <StatCard
                labelPosition="bottom"
                label="فشل: البداية لم تُطابَق"
                value={stats.fail_no_from}
                tone="red"
              />
              <StatCard
                labelPosition="bottom"
                label="فشل: الوصول لم يُطابَق"
                value={stats.fail_no_to}
                tone="red"
              />
              <StatCard
                labelPosition="bottom"
                label="فشل: الاثنان"
                value={stats.fail_no_from_and_to}
                tone="red"
              />
              <StatCard
                labelPosition="bottom"
                label="فشل رغم وجود المحطتَين"
                value={stats.fail_no_route}
                tone="red"
              />
            </section>
          </>
        )}

        <h2 className="mb-3 text-lg font-bold">آخر 100 عملية بحث</h2>
        {logs && logs.length === 0 && (
          <p className="text-sm text-muted-foreground">
            لا توجد عمليات بحث مسجّلة بعد. جرّب البحث من الصفحة الرئيسية أولاً.
          </p>
        )}
        {logs && logs.length > 0 && (
          <div className="overflow-x-auto rounded-lg border bg-card">
            <table className="w-full text-sm">
              <thead className="bg-muted text-right">
                <tr>
                  <th className="p-2">الوقت</th>
                  <th className="p-2">المستخدم كتب</th>
                  <th className="p-2">مطابقة</th>
                  <th className="p-2">النتيجة</th>
                  <th className="p-2">المصدر</th>
                  <th className="p-2">السبب</th>
                </tr>
              </thead>
              <tbody>
                {logs.map((r) => (
                  <tr key={r.id} className="border-t align-top">
                    <td className="p-2 text-xs text-muted-foreground whitespace-nowrap">
                      {new Date(r.created_at).toLocaleString("ar-EG")}
                    </td>
                    <td className="p-2">
                      <div>
                        <strong>من:</strong> {r.from_query}
                      </div>
                      <div>
                        <strong>إلى:</strong> {r.to_query}
                      </div>
                      {(r.normalized_from || r.normalized_to) && (
                        <div className="text-[11px] text-muted-foreground">
                          بعد التطبيع: {r.normalized_from ?? "—"} → {r.normalized_to ?? "—"}
                        </div>
                      )}
                    </td>
                    <td className="p-2 text-xs">
                      <div>من: {r.matched_from_name ?? "—"}</div>
                      <div>إلى: {r.matched_to_name ?? "—"}</div>
                    </td>
                    <td className="p-2 text-xs">
                      <div>
                        الحالة: <strong>{r.result_status}</strong>
                      </div>
                      <div>مباشر: {r.direct_routes_count}</div>
                      <div>تحويلة: {r.transfer_routes_count}</div>
                    </td>
                    <td className="p-2">
                      {r.source && (
                        <span
                          className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${SOURCE_COLORS[r.source] ?? "bg-zinc-100"}`}
                        >
                          {r.source}
                        </span>
                      )}
                    </td>
                    <td className="p-2 text-xs text-muted-foreground">
                      {r.no_result_reason
                        ? (REASON_AR[r.no_result_reason] ?? r.no_result_reason)
                        : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AdminPageShell>
  );
}
