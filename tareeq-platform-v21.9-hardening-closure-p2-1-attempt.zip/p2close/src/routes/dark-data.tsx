import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { getSnapshots } from "@/lib/local-ai/data-registry";
import { embedBatch, cosineSimilarity } from "@/lib/local-ai/embedder";
import { AuthGateLoading } from "@/components/AuthGateLoading";
import { useRequireAuth } from "@/hooks/useRequireAuth";

import {
  analyzeDarkDataWithGemini,
  getGeminiApiKey,
  type DarkDataAnalysis,
} from "@/lib/gemini/client";

export const Route = createFileRoute("/dark-data")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Dark Data Finder — كاشف البيانات الظلمة" },
      { name: "description", content: "تحليل محلي للبيانات مع Gemini مباشرة من متصفح المستخدم." },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: DarkDataRoute,
});

type Snapshot = ReturnType<typeof getSnapshots>[number];
type Result = {
  models: { chat: string; embed: string };
  total: number;
  clusters: Array<{ size: number; items: Array<{ id: string; title: string; source: string }> }>;
  nearDuplicates: Array<{ score: number; a: Snapshot; b: Snapshot }>;
  distribution: {
    categories: Record<string, number>;
    sources: Record<string, number>;
    quietSources: string[];
  };
  analysis: DarkDataAnalysis;
};

function clusterByCosine(vectors: Float32Array[], threshold = 0.82): number[][] {
  const parent = Array.from({ length: vectors.length }, (_, i) => i);
  const find = (x: number): number => (parent[x] === x ? x : (parent[x] = find(parent[x])));
  const union = (a: number, b: number) => {
    const ra = find(a);
    const rb = find(b);
    if (ra !== rb) parent[ra] = rb;
  };
  for (let i = 0; i < vectors.length; i++)
    for (let j = i + 1; j < vectors.length; j++)
      if (cosineSimilarity(vectors[i], vectors[j]) >= threshold) union(i, j);
  const groups = new Map<number, number[]>();
  vectors.forEach((_, i) => {
    const r = find(i);
    groups.set(r, [...(groups.get(r) ?? []), i]);
  });
  return [...groups.values()].sort((a, b) => b.length - a.length);
}

function buildPrompt(snaps: Snapshot[], country: string, lang: "ar" | "en") {
  return [
    `Country: ${country}`,
    `Language: ${lang}`,
    `Snapshots (${snaps.length}):`,
    ...snaps.map(
      (s, i) => `#${i} [${s.source}${s.category ? "/" + s.category : ""}] ${s.title}: ${s.summary}`,
    ),
  ].join("\n");
}

/** بوابة استخدام: يتطلب تسجيل دخول قبل عرض هذه الصفحة (مش مجرد تصفح). */
function DarkDataRoute() {
  const authStatus = useRequireAuth();
  if (authStatus !== "authenticated") return <AuthGateLoading />;
  return <DarkDataPage />;
}

function DarkDataPage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Result | null>(null);
  const [country, setCountry] = useState("all");

  async function analyze() {
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      if (!getGeminiApiKey()) throw new Error("أدخل مفتاح Gemini من صفحة المساعد الذكي أولًا.");
      const snaps = getSnapshots().slice(0, 200);
      if (!snaps.length) throw new Error("لا توجد لقطات مسجّلة. تصفّح بعض الصفحات أولًا.");

      const texts = snaps.map(
        (s) => `[${s.source}${s.category ? "/" + s.category : ""}] ${s.title} — ${s.summary}`,
      );
      const vectors = await embedBatch(texts);
      const clusters = clusterByCosine(vectors);
      const nearDuplicates: Result["nearDuplicates"] = [];
      for (let i = 0; i < vectors.length; i++)
        for (let j = i + 1; j < vectors.length; j++) {
          const score = cosineSimilarity(vectors[i], vectors[j]);
          if (score >= 0.9)
            nearDuplicates.push({ score: Number(score.toFixed(3)), a: snaps[i], b: snaps[j] });
        }
      nearDuplicates.sort((a, b) => b.score - a.score);

      const categories: Record<string, number> = {};
      const sources: Record<string, number> = {};
      for (const s of snaps) {
        const c = s.category ?? "other";
        categories[c] = (categories[c] ?? 0) + 1;
        sources[s.source] = (sources[s.source] ?? 0) + 1;
      }
      const quietSources = Object.entries(sources)
        .filter(([, c]) => c === 1)
        .map(([s]) => s);
      const analysis = await analyzeDarkDataWithGemini(buildPrompt(snaps, country, "ar"), "ar");

      setResult({
        models: { chat: "Gemini (browser BYOK)", embed: "Xenova/all-MiniLM-L6-v2 (browser-local)" },
        total: snaps.length,
        clusters: clusters.map((idxs) => ({
          size: idxs.length,
          items: idxs.map((i) => ({
            id: snaps[i].id,
            title: snaps[i].title,
            source: snaps[i].source,
          })),
        })),
        nearDuplicates: nearDuplicates.slice(0, 20),
        distribution: { categories, sources, quietSources },
        analysis,
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }

  const localCount = getSnapshots().length;
  return (
    <div className="mx-auto max-w-4xl space-y-6 p-6" dir="rtl">
      <header className="space-y-2">
        <h1 className="text-2xl font-bold">كاشف البيانات الظلمة</h1>
        <p className="text-sm text-muted-foreground">
          الـembeddings تعمل محليًا داخل المتصفح، والتحليل النصي يذهب مباشرة من المتصفح إلى Gemini.
          لا يوجد legacy AI gateway ولا AI Server.
        </p>
        <p className="text-xs text-muted-foreground">
          اللقطات المتاحة محليًا: <b>{localCount}</b>
        </p>
      </header>
      <div className="flex flex-wrap items-center gap-3">
        <label className="text-sm">
          الدولة:{" "}
          <select
            value={country}
            onChange={(e) => setCountry(e.target.value)}
            className="rounded border bg-background px-2 py-1 text-sm"
          >
            <option value="all">الكل</option>
            <option value="eg">مصر</option>
            <option value="ma">المغرب</option>
            <option value="dz">الجزائر</option>
            <option value="tn">تونس</option>
            <option value="ly">ليبيا</option>
          </select>
        </label>
        <button
          onClick={analyze}
          disabled={loading}
          className="rounded bg-primary px-4 py-2 text-sm font-medium text-primary-foreground disabled:opacity-50"
        >
          {loading ? "جاري التحليل…" : "شغّل التحليل"}
        </button>
      </div>
      {error && (
        <div className="rounded border border-destructive/50 bg-destructive/10 p-3 text-sm text-destructive">
          {error}
        </div>
      )}
      {result && (
        <div className="space-y-6">
          <section className="rounded border p-4">
            <h2 className="mb-2 font-semibold">الملخّص التنفيذي</h2>
            <pre className="whitespace-pre-wrap text-sm leading-relaxed">
              {result.analysis.analysis}
            </pre>
            <ul className="mt-3 list-disc space-y-1 pr-5 text-sm">
              {result.analysis.gaps.map((x) => (
                <li key={x}>{x}</li>
              ))}
              {result.analysis.contradictions.map((x) => (
                <li key={x}>{x}</li>
              ))}
              {result.analysis.patterns.map((x) => (
                <li key={x}>{x}</li>
              ))}
            </ul>
            <p className="mt-3 text-sm font-semibold">التوصية: {result.analysis.recommendation}</p>
            <p className="mt-2 text-xs text-muted-foreground">
              chat: {result.models.chat} · embed: {result.models.embed} · لقطات: {result.total}
            </p>
          </section>
          <section className="rounded border p-4">
            <h2 className="mb-2 font-semibold">العناقيد الدلالية ({result.clusters.length})</h2>
            <ul className="space-y-2 text-sm">
              {result.clusters
                .filter((c) => c.size > 1)
                .map((c, i) => (
                  <li key={i}>
                    <b>عنقود #{i + 1}</b> ({c.size} عناصر):
                    <ul className="mr-4 list-disc">
                      {c.items.map((it) => (
                        <li key={it.id}>
                          [{it.source}] {it.title}
                        </li>
                      ))}
                    </ul>
                  </li>
                ))}
            </ul>
          </section>
          <section className="rounded border p-4">
            <h2 className="mb-2 font-semibold">التكرارات القريبة</h2>
            {result.nearDuplicates.length === 0 ? (
              <p className="text-sm text-muted-foreground">لا تكرارات قريبة.</p>
            ) : (
              <ul className="space-y-1 text-sm">
                {result.nearDuplicates.map((p, i) => (
                  <li key={i}>
                    <code>{p.score}</code> — [{p.a.source}] {p.a.title} ↔ [{p.b.source}] {p.b.title}
                  </li>
                ))}
              </ul>
            )}
          </section>
          <section className="rounded border p-4">
            <h2 className="mb-2 font-semibold">التوزيع</h2>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3 text-sm">
              <div>
                <b>الفئات</b>
                <ul>
                  {Object.entries(result.distribution.categories).map(([k, v]) => (
                    <li key={k}>
                      {k}: {v}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <b>المصادر</b>
                <ul className="max-h-40 overflow-auto">
                  {Object.entries(result.distribution.sources).map(([k, v]) => (
                    <li key={k}>
                      {k}: {v}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <b>مصادر خافتة</b>
                <ul className="max-h-40 overflow-auto text-muted-foreground">
                  {result.distribution.quietSources.map((s) => (
                    <li key={s}>{s}</li>
                  ))}
                </ul>
              </div>
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
