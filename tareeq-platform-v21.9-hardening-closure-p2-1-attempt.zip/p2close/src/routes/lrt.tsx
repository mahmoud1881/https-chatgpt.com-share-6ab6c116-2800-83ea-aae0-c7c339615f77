import { SITE_BASE_URL } from "@/lib/seo/site";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  TrainFront,
  ArrowRight,
  MapPin,
  Clock,
  Navigation,
  Wifi,
  Snowflake,
  Users,
  CreditCard,
  Search,
  ArrowLeftRight,
} from "lucide-react";
import { LRT_REAL_STATIONS, LRT_META, type LrtRealStation } from "@/data/lrtRealStations";
import { gmapsCoords } from "@/lib/geo/gmaps";

export const Route = createFileRoute("/lrt")({
  head: () => ({
    meta: [
      { title: "القطار الكهربائي الخفيف LRT — المحطات والمواعيد" },
      {
        name: "description",
        content:
          "دليل القطار الكهربائي الخفيف (LRT) من عدلي منصور إلى العاصمة الإدارية: كل المحطات بالترتيب، مواعيد التشغيل، ونقاط التبادل مع المترو.",
      },
      { property: "og:title", content: "🚆 القطار الكهربائي الخفيف (LRT)" },
      {
        property: "og:description",
        content: "كل محطات LRT بالترتيب مع المواعيد ونقاط التبادل مع المترو.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: `${SITE_BASE_URL}/lrt` },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "canonical", href: `${SITE_BASE_URL}/lrt` },
      { rel: "alternate", hrefLang: "ar-EG", href: `${SITE_BASE_URL}/lrt` },
      { rel: "alternate", hrefLang: "x-default", href: `${SITE_BASE_URL}/lrt` },
    ],
  }),
  component: LrtPage,
});

const norm = (s: string) =>
  s
    .toLowerCase()
    .replace(/[إأآا]/g, "ا")
    .replace(/[ىي]/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/\s+/g, " ")
    .trim();

function findStation(q: string): LrtRealStation | null {
  if (!q.trim()) return null;
  const n = norm(q);
  // مطابقة مباشرة بالاسم
  let hit = LRT_REAL_STATIONS.find((s) => norm(s.name) === n || norm(s.nameEn) === n);
  if (hit) return hit;
  // احتواء
  hit = LRT_REAL_STATIONS.find((s) => norm(s.name).includes(n) || norm(s.nameEn).includes(n));
  if (hit) return hit;
  // بحث بالمنطقة المخدومة
  hit = LRT_REAL_STATIONS.find((s) => s.areas.some((a) => norm(a.name).includes(n)));
  return hit ?? null;
}

function computeRoute(from: LrtRealStation, to: LrtRealStation) {
  // ترتيب المحطات على المسار: القسم المشترك 1..6 ثم الفرع
  // نبني قوائم لكل فرع
  const shared = LRT_REAL_STATIONS.filter((s) => s.branch === "shared");
  const capital = LRT_REAL_STATIONS.filter((s) => s.branch === "capital");
  const ramadan = LRT_REAL_STATIONS.filter((s) => s.branch === "10th_ramadan");

  const pathOf = (s: LrtRealStation): LrtRealStation[] => {
    if (s.branch === "shared") return shared.slice(0, s.order);
    if (s.branch === "capital") return [...shared, ...capital.filter((c) => c.order <= s.order)];
    return [...shared, ...ramadan.filter((c) => c.order <= s.order)];
  };

  const pf = pathOf(from);
  const pt = pathOf(to);

  // نقطة التشعّب المشتركة (آخر عنصر مشترك)
  let i = 0;
  while (i < pf.length && i < pt.length && pf[i].id === pt[i].id) i++;
  const commonIdx = i - 1;

  let stations: LrtRealStation[];
  let transfer: LrtRealStation | null = null;

  if (from.branch === to.branch || from.branch === "shared" || to.branch === "shared") {
    // مباشر بدون تبديل
    if (pf.length >= pt.length) {
      // to داخل مسار from — لكن الاتجاه قد يكون معكوس
      // نبني من from → to عبر pt
      const fromInPt = pt.findIndex((s) => s.id === from.id);
      if (fromInPt >= 0) stations = pt.slice(fromInPt);
      else stations = [...pf.slice().reverse(), ...pt.slice(1)];
    } else {
      const toInPf = pf.findIndex((s) => s.id === to.id);
      if (toInPf >= 0) stations = pf.slice(toInPf).reverse();
      else stations = [...pf.slice().reverse(), ...pt.slice(1)];
    }
  } else {
    // فرعان مختلفان — تبديل في محطة بدر (آخر مشترك)
    transfer = pf[commonIdx] ?? LRT_REAL_STATIONS.find((s) => s.id === "badr")!;
    const upToTransfer = pf.slice(commonIdx).reverse(); // from → transfer
    const fromTransfer = pt.slice(commonIdx + 1); // transfer+1 → to
    stations = [...upToTransfer, ...fromTransfer];
  }

  const hops = Math.max(0, stations.length - 1);
  const durationMin = Math.max(3, hops * 4); // ~4 دقائق بين المحطات
  return { stations, hops, durationMin, transfer };
}

function LrtPage() {
  const [fromQ, setFromQ] = useState("");
  const [toQ, setToQ] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const from = useMemo(() => findStation(fromQ), [fromQ]);
  const to = useMemo(() => findStation(toQ), [toQ]);

  const result = submitted && from && to && from.id !== to.id ? computeRoute(from, to) : null;

  const swap = () => {
    setFromQ(toQ);
    setToQ(fromQ);
    setSubmitted(false);
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-b from-sky-50 via-white to-white">
      <header className="sticky top-0 z-10 border-b bg-white/80 backdrop-blur">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-sky-500 to-indigo-600 text-white shadow">
              <TrainFront className="size-5" />
            </div>
            <div>
              <div className="text-base font-extrabold">القطار الكهربائي الخفيف (LRT)</div>
              <div className="text-[11px] text-muted-foreground">
                عدلي منصور ↔ العاصمة الإدارية / العاشر من رمضان
              </div>
            </div>
          </div>
          <Link
            to="/"
            className="inline-flex items-center gap-1 text-sm text-primary hover:underline"
          >
            <ArrowRight className="size-4" />
            الرئيسية
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-4 py-6">
        {/* Info cards */}
        <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <InfoCard
            icon={<MapPin className="size-5" />}
            title="الطول"
            value={`${LRT_META.totalKm} كم`}
            sub={`${LRT_META.totalStations} محطة`}
            color="sky"
          />
          <InfoCard
            icon={<Clock className="size-5" />}
            title="المواعيد"
            value="٦ ص – ١١ م"
            sub={`ذروة كل ${LRT_META.headwayPeak}`}
            color="emerald"
          />
          <InfoCard
            icon={<TrainFront className="size-5" />}
            title="السرعة"
            value={`${LRT_META.maxSpeedKmh} كم/س`}
            sub={`تشغيلية ~${LRT_META.commercialSpeedKmh}`}
            color="indigo"
          />
        </section>

        {/* Search from/to */}
        <section className="mt-6 rounded-2xl border-2 border-sky-200 bg-white p-5 shadow-sm">
          <h2 className="mb-3 flex items-center gap-2 text-lg font-bold">
            <Search className="size-5 text-sky-600" />
            ابحث عن رحلتك على LRT
          </h2>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setSubmitted(true);
            }}
            className="grid grid-cols-1 gap-3 sm:grid-cols-[1fr_auto_1fr_auto]"
          >
            <Field
              label="من"
              value={fromQ}
              onChange={setFromQ}
              match={from}
              placeholder="اسم محطة أو منطقة (مثال: عدلي منصور، بدر، مدينتي)"
            />
            <button
              type="button"
              onClick={swap}
              className="hidden self-end rounded-lg border bg-slate-50 px-3 py-2 text-slate-600 hover:bg-slate-100 sm:inline-flex"
              title="تبديل"
              aria-label="تبديل من/إلى"
            >
              <ArrowLeftRight className="size-4" />
            </button>
            <Field
              label="إلى"
              value={toQ}
              onChange={setToQ}
              match={to}
              placeholder="اسم محطة أو منطقة (مثال: مدينة الفنون والثقافة)"
            />
            <button
              type="submit"
              className="self-end rounded-lg bg-gradient-to-r from-sky-600 to-indigo-600 px-5 py-2 text-sm font-bold text-white shadow hover:opacity-95"
            >
              ابحث
            </button>
          </form>

          {/* Result */}
          {submitted && (!from || !to) && (
            <div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">
              لم نتعرف على {(!from && "محطة البداية") || ""}
              {!from && !to ? " و" : ""}
              {(!to && "محطة النهاية") || ""}. جرّب اسم محطة رسمي أو اسم منطقة قريبة.
            </div>
          )}
          {submitted && from && to && from.id === to.id && (
            <div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">
              محطة البداية والنهاية متطابقتان.
            </div>
          )}
          {result && (
            <div className="mt-5 rounded-xl border-2 border-emerald-300 bg-emerald-50/50 p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="text-sm font-bold text-emerald-900">
                  {from!.name} ← {to!.name}
                </div>
                <div className="flex flex-wrap gap-2 text-[11px]">
                  <Tag>{result.hops} محطة</Tag>
                  <Tag>~{result.durationMin} دقيقة</Tag>
                </div>
              </div>
              {result.transfer && (
                <div className="mt-2 rounded bg-amber-100 px-3 py-1.5 text-xs text-amber-900">
                  🔁 تبديل عند محطة <b>{result.transfer.name}</b> (نقطة تفرّع الفرعين)
                </div>
              )}
              <ol className="mt-3 flex flex-wrap items-center gap-1 text-xs">
                {result.stations.map((s, i) => (
                  <li key={s.id} className="flex items-center gap-1">
                    <span
                      className={`rounded-full px-2 py-0.5 font-semibold ${
                        s.id === from!.id || s.id === to!.id
                          ? "bg-emerald-600 text-white"
                          : result.transfer && s.id === result.transfer.id
                            ? "bg-amber-500 text-white"
                            : "bg-white border text-slate-700"
                      }`}
                    >
                      {s.name}
                    </span>
                    {i < result.stations.length - 1 && <span className="text-slate-400">←</span>}
                  </li>
                ))}
              </ol>
            </div>
          )}
        </section>

        {/* Stations list */}
        <section className="mt-6 rounded-2xl border bg-white p-5 shadow-sm">
          <h2 className="mb-4 text-lg font-bold">محطات الخط ({LRT_META.totalStations})</h2>
          <BranchGroup title="القطاع المشترك" color="sky" branch="shared" />
          <BranchGroup title="فرع العاصمة الإدارية" color="indigo" branch="capital" />
          <BranchGroup title="فرع العاشر من رمضان" color="emerald" branch="10th_ramadan" />
        </section>
        <section className="mt-6 rounded-2xl border bg-white p-5 shadow-sm">
          <h3 className="mb-2 mt-4 text-base font-bold">داخل القطار</h3>
          <div className="flex flex-wrap gap-2 text-[11px]">
            <Chip icon={<Snowflake className="size-3" />}>تكييف كامل</Chip>
            <Chip icon={<Wifi className="size-3" />}>Wi-Fi</Chip>
            <Chip icon={<Users className="size-3" />}>عربة سيدات</Chip>
            <Chip>
              {LRT_META.rollingStock.carsPerTrain} عربات · {LRT_META.rollingStock.capacity} راكب
            </Chip>
            <Chip>{LRT_META.rollingStock.manufacturer}</Chip>
          </div>
        </section>

        {/* Amenities & sources */}
        <section className="mt-6 rounded-2xl border bg-white p-5 shadow-sm">
          <h3 className="mb-3 text-base font-bold">خدمات المحطات</h3>
          <div className="flex flex-wrap gap-2 text-xs">
            {LRT_META.amenities.map((a) => (
              <span key={a} className="rounded-full border bg-slate-50 px-3 py-1 text-slate-700">
                {a}
              </span>
            ))}
          </div>
          <div className="mt-4 border-t pt-3 text-[11px] text-muted-foreground">
            المصادر: {LRT_META.sources.join(" · ")} · المشغل: {LRT_META.operator} · المالك:{" "}
            {LRT_META.owner} · افتتاح: {LRT_META.openedAt}
          </div>
        </section>
      </main>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  match,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  match: LrtRealStation | null;
  placeholder: string;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-semibold text-slate-600">{label}</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-lg border-2 border-slate-200 bg-white px-3 py-2 text-sm focus:border-sky-500 focus:outline-none"
      />
      {value && (
        <span className={`mt-1 block text-[11px] ${match ? "text-emerald-600" : "text-amber-600"}`}>
          {match ? `✓ ${match.name}` : "لم نتعرف على المحطة"}
        </span>
      )}
    </label>
  );
}

function InfoCard({
  icon,
  title,
  value,
  sub,
  color,
}: {
  icon: React.ReactNode;
  title: string;
  value: string;
  sub: string;
  color: "sky" | "emerald" | "amber" | "indigo";
}) {
  const colorMap = {
    sky: "text-sky-600",
    emerald: "text-emerald-600",
    amber: "text-amber-600",
    indigo: "text-indigo-600",
  };
  return (
    <div className="rounded-xl border bg-white p-3 shadow-sm">
      <div className={`flex items-center gap-2 ${colorMap[color]}`}>
        {icon}
        <span className="text-xs font-semibold">{title}</span>
      </div>
      <div className="mt-1 text-base font-bold">{value}</div>
      <div className="text-[11px] text-muted-foreground">{sub}</div>
    </div>
  );
}

function Tag({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full bg-white/80 border px-2 py-0.5 font-semibold text-slate-700">
      {children}
    </span>
  );
}

function Chip({ icon, children }: { icon?: React.ReactNode; children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full border bg-slate-50 px-2 py-1 text-slate-700">
      {icon}
      {children}
    </span>
  );
}

function BranchGroup({
  title,
  color,
  branch,
}: {
  title: string;
  color: "sky" | "indigo" | "emerald";
  branch: LrtRealStation["branch"];
}) {
  const items = LRT_REAL_STATIONS.filter((s) => s.branch === branch);
  const colorMap = {
    sky: { text: "text-sky-900", border: "border-sky-200", dot: "bg-sky-500" },
    indigo: { text: "text-indigo-900", border: "border-indigo-200", dot: "bg-indigo-500" },
    emerald: { text: "text-emerald-900", border: "border-emerald-200", dot: "bg-emerald-500" },
  }[color];
  return (
    <div className="mb-4">
      <h3 className={`mb-2 text-sm font-bold ${colorMap.text}`}>{title}</h3>
      <ol className={`relative space-y-3 border-r-2 pr-5 ${colorMap.border}`}>
        {items.map((s) => (
          <li key={s.id} className="relative">
            <span
              className={`absolute -right-[27px] top-1 flex h-4 w-4 items-center justify-center rounded-full ${colorMap.dot} text-[10px] font-bold text-white`}
            >
              {s.order}
            </span>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="text-sm font-bold">
                {s.name}
                <span className="ms-2 text-[10px] font-normal text-muted-foreground">
                  {s.nameEn}
                </span>
              </div>
              <a
                href={gmapsCoords(s.lat, s.lng)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-semibold text-slate-700 hover:bg-slate-100"
              >
                <Navigation className="size-3" />
                {s.lat.toFixed(4)}, {s.lng.toFixed(4)}
              </a>
            </div>
            {s.interchange && (
              <div className="mt-0.5 text-[11px] text-amber-700">🔁 {s.interchange}</div>
            )}
            <details className="mt-1">
              <summary className="cursor-pointer text-xs font-semibold text-slate-600 hover:underline">
                المناطق المخدومة ({s.areas.length})
              </summary>
              <ul className="mt-2 grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                {s.areas.map((a) => (
                  <li key={a.name}>
                    <a
                      href={gmapsCoords(a.lat, a.lng)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-between gap-2 rounded-md border border-slate-200 bg-slate-50 px-2 py-1 text-[11px] text-slate-700 hover:bg-white"
                    >
                      <span className="flex items-center gap-1 truncate">
                        <MapPin className="size-3 shrink-0 text-sky-500" />
                        <span className="truncate">{a.name}</span>
                      </span>
                      <span className="shrink-0 font-mono text-[10px] text-muted-foreground">
                        {a.lat.toFixed(3)},{a.lng.toFixed(3)}
                      </span>
                    </a>
                  </li>
                ))}
              </ul>
            </details>
          </li>
        ))}
      </ol>
    </div>
  );
}
