import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BarChart3, Download, Mail, ShieldCheck, Sparkles, ArrowRight } from "lucide-react";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/pulse")({
  head: () => ({
    meta: [
      { title: "نبض المدينة — تقارير شهرية" },
      {
        name: "description",
        content: "تقارير شهرية مفتوحة عن حركة المواصلات. مجانية للصحفيين والباحثين.",
      },
      { property: "og:title", content: "📊 نبض المدينة" },
      { property: "og:description", content: "تقارير شهرية مفتوحة بالكامل عن حركة المواصلات." },
      { property: "og:url", content: "/pulse" },
    ],
    links: [{ rel: "canonical", href: "/pulse" }],
  }),
  component: PulsePage,
});

function PulsePage() {
  const [article, setArticle] = useState<string | null>(null);
  const [countryName, setCountryName] = useState<string>("");

  useEffect(() => {
    (async () => {
      const { getActiveCountry } = await import("@/lib/active-country");
      const { COUNTRIES } = await import("@/config/countries");
      setCountryName(COUNTRIES[getActiveCountry()]?.nameAr ?? "");
    })();
  }, []);

  const generate = () => {
    setArticle(
      `في مايو ٢٠٢٦، رصدت منصة نبض المدينة حركة المواصلات${countryName ? ` في ${countryName}` : ""}... (مسودة مقال مولّدة تلقائياً من بيانات الشهر).`,
    );
  };

  return (
    <div dir="rtl" className="min-h-screen bg-background px-4 py-10">
      <div className="mx-auto max-w-3xl space-y-8">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowRight className="size-4" />
          العودة للرئيسية
        </Link>

        <header className="space-y-3 text-center">
          <h1 className="text-4xl font-extrabold tracking-tight md:text-5xl">
            📊 نبض{countryName ? ` ${countryName}` : " المدينة"}
          </h1>
          <p className="mx-auto max-w-xl text-muted-foreground">
            تقارير شهرية مفتوحة بالكامل عن حركة المواصلات. مجانية للصحفيين، الباحثين، وصُنّاع
            القرار.
          </p>
        </header>

        <Card className="space-y-5 p-6">
          <div className="flex items-center justify-between">
            <span className="rounded-full bg-secondary px-3 py-1 text-sm font-medium">
              مايو ٢٠٢٦
            </span>
            <BarChart3 className="size-5 text-muted-foreground" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">
              نبض{countryName ? ` ${countryName}` : " المدينة"} — 2026-05
            </h2>
            <p className="text-sm text-muted-foreground">
              تقرير شهري لحركة المواصلات{countryName ? ` في ${countryName}` : ""}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-lg border p-4 text-center">
              <div className="text-3xl font-extrabold">0</div>
              <div className="text-sm text-muted-foreground">تنبيه</div>
            </div>
            <div className="rounded-lg border p-4 text-center">
              <div className="text-3xl font-extrabold">0</div>
              <div className="text-sm text-muted-foreground">مستخدم نشط</div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button onClick={generate} className="gap-2">
              <Sparkles className="size-4" />
              ولّد مقال صحفي
            </Button>
            <Button variant="outline" className="gap-2">
              <Download className="size-4" />
              حمّل JSON
            </Button>
            <Button variant="outline" className="gap-2">
              <Download className="size-4" />
              حمّل CSV
            </Button>
          </div>

          {article && (
            <div className="rounded-lg bg-muted p-4 text-sm leading-relaxed">{article}</div>
          )}
        </Card>

        <Card className="space-y-3 p-6">
          <h3 className="text-lg font-bold">📥 صحفي أو باحث؟</h3>
          <p className="text-sm text-muted-foreground">
            كل التقارير مفتوحة المصدر. حمّلها، اقتبس منها، وارفقها في مقالاتك.
          </p>
          <Button variant="secondary" className="gap-2">
            <Mail className="size-4" />
            اتواصل معنا للحصول على بيانات مخصصة
          </Button>
        </Card>

        <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
          <ShieldCheck className="size-4" />
          نحترم خصوصيتك
        </div>
      </div>
    </div>
  );
}
