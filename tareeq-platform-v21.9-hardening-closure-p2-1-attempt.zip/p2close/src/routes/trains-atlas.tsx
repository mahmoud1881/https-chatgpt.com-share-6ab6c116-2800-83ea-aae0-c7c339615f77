import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { TrainFront, MapPin, Navigation, ArrowRight, Search } from "lucide-react";

import { egHead, getEgPage } from "@/lib/seo/eg-meta";
import { useRailLines, type RailLine, type LineStation } from "@/data/trainsResearch";
import { haversineKm } from "@/lib/geo/haversine";
import { gmapsCoords } from "@/lib/geo/gmaps";
import { normalizeArSearchLatin as norm } from "@/lib/text/normalize-ar";

export const Route = createFileRoute("/trains-atlas")({
  head: () => {
    const p = getEgPage("/trains-atlas")!;
    return egHead({
      path: p.path,
      titleAr: p.titleAr,
      descAr: p.descAr,
      breadcrumbLabel: "أطلس القطارات",
    });
  },
  component: TrainsAtlasPage,
});

type Poi = { name: string; lat: number; lng: number; gov?: string; kind?: string };

async function loadPois(): Promise<Poi[]> {
  const fetchJson = async (url: string) => {
    try {
      const r = await fetch(url);
      if (!r.ok) return null;
      return await r.json();
    } catch {
      return null;
    }
  };
  const [gov, informal, cairo] = await Promise.all([
    fetchJson("/data/eg-governorate-stations.json"),
    fetchJson("/data/eg-informal-stops.json"),
    fetchJson("/data/cairo-stations.json"),
  ]);
  const out: Poi[] = [];
  const push = (arr: unknown, kind: string) => {
    if (!Array.isArray(arr)) return;
    for (const s of arr as Array<Record<string, unknown>>) {
      const lat = Number(s.lat);
      const lng = Number(s.lng);
      if (!isFinite(lat) || !isFinite(lng)) continue;
      const name = (s.name_ar as string) || (s.name as string) || (s.name_en as string);
      if (!name) continue;
      out.push({
        name,
        lat,
        lng,
        gov: (s.governorate as string) || (s.gov as string),
        kind,
      });
    }
  };
  push(gov, "موقف رئيسي");
  push(informal, "موقف عشوائي");
  push(cairo, "محور نقل");
  return out;
}

function useNearest(pois: Poi[]) {
  return useMemo(() => {
    return (s: LineStation, k = 10): (Poi & { km: number })[] => {
      if (!s.lat || !s.lng || !pois.length) return [];
      const nStation = norm(s.name);
      const scored: (Poi & { km: number })[] = [];
      for (const p of pois) {
        const km = haversineKm({ lat: s.lat, lng: s.lng }, { lat: p.lat, lng: p.lng });
        if (km > 30) continue;
        if (norm(p.name) === nStation) continue;
        scored.push({ ...p, km });
      }
      scored.sort((a, b) => a.km - b.km);
      const seen = new Set<string>();
      const out: (Poi & { km: number })[] = [];
      for (const p of scored) {
        const key = norm(p.name);
        if (seen.has(key)) continue;
        seen.add(key);
        out.push(p);
        if (out.length >= k) break;
      }
      return out;
    };
  }, [pois]);
}

const CATEGORIES: { id: RailLine["category"]; label: string; color: string }[] = [
  { id: "intercity", label: "بين المدن", color: "bg-indigo-500" },
  { id: "delta", label: "الدلتا", color: "bg-emerald-500" },
  { id: "upper", label: "الصعيد", color: "bg-amber-500" },
  { id: "branch", label: "فرعية", color: "bg-slate-500" },
  { id: "sinai", label: "سيناء", color: "bg-orange-500" },
  { id: "hsr", label: "سريع HSR", color: "bg-rose-500" },
  { id: "metro", label: "مترو", color: "bg-blue-500" },
  { id: "tram", label: "ترام", color: "bg-cyan-500" },
  { id: "monorail", label: "مونوريل", color: "bg-violet-500" },
  { id: "lrt", label: "LRT", color: "bg-fuchsia-500" },
];

function TrainsAtlasPage() {
  const lines = useRailLines();
  const [pois, setPois] = useState<Poi[]>([]);
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string>("all");
  const [openLine, setOpenLine] = useState<string | null>(null);

  useEffect(() => {
    loadPois().then(setPois);
  }, []);

  const nearest = useNearest(pois);

  const filtered = useMemo(() => {
    const nq = norm(q);
    return lines.filter((l) => {
      if (cat !== "all" && l.category !== cat) return false;
      if (!nq) return true;
      if (norm(l.name).includes(nq)) return true;
      return l.stations.some((s) => norm(s.name).includes(nq));
    });
  }, [lines, q, cat]);

  const totalStations = useMemo(
    () => lines.reduce((sum, l) => sum + l.stations.length, 0),
    [lines],
  );

  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <header className="sticky top-0 z-10 border-b bg-white/85 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-rose-500 text-white shadow">
              <TrainFront className="size-5" />
            </div>
            <div>
              <div className="text-base font-extrabold">أطلس السكة الحديد</div>
              <div className="text-[11px] text-muted-foreground">
                {lines.length} خط · {totalStations} محطة · 10 مناطق مخدومة لكل محطة
              </div>
            </div>
          </div>
          <Link
            to="/trains"
            className="inline-flex items-center gap-1 text-sm text-primary hover:underline"
          >
            <ArrowRight className="size-4" />
            القطارات
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-5">
        <div className="mb-4 flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="ابحث بخط أو محطة (رمسيس، أسوان، طنطا...)"
              className="w-full rounded-xl border bg-white px-3 py-2 pr-9 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-300"
            />
          </div>
        </div>

        <div className="mb-5 flex flex-wrap gap-2">
          <button
            onClick={() => setCat("all")}
            className={`rounded-full px-3 py-1 text-xs font-semibold ${cat === "all" ? "bg-indigo-600 text-white" : "border bg-white text-slate-700"}`}
          >
            الكل ({lines.length})
          </button>
          {CATEGORIES.map((c) => {
            const n = lines.filter((l) => l.category === c.id).length;
            if (!n) return null;
            return (
              <button
                key={c.id}
                onClick={() => setCat(c.id)}
                className={`rounded-full px-3 py-1 text-xs font-semibold ${cat === c.id ? `${c.color} text-white` : "border bg-white text-slate-700"}`}
              >
                {c.label} ({n})
              </button>
            );
          })}
        </div>

        {!lines.length && (
          <div className="rounded-xl border bg-white p-8 text-center text-sm text-muted-foreground">
            جاري تحميل بيانات الخطوط...
          </div>
        )}

        <div className="space-y-3">
          {filtered.map((line) => {
            const cat = CATEGORIES.find((c) => c.id === line.category);
            const isOpen = openLine === line.id;
            return (
              <section key={line.id} className="rounded-2xl border bg-white shadow-sm">
                <button
                  onClick={() => setOpenLine(isOpen ? null : line.id)}
                  className="flex w-full items-start justify-between gap-3 p-4 text-right"
                >
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className={`inline-block h-2.5 w-2.5 rounded-full ${cat?.color ?? "bg-slate-400"}`}
                      />
                      <h2 className="text-base font-bold text-slate-900">{line.name}</h2>
                      <span className="rounded-full border bg-slate-50 px-2 py-0.5 text-[10px] font-semibold text-slate-600">
                        {line.stations.length} محطة
                      </span>
                      {line.status !== "operational" && (
                        <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-semibold text-amber-800">
                          {line.status === "under_construction"
                            ? "قيد الإنشاء"
                            : line.status === "planned"
                              ? "مخطط"
                              : line.status === "partial"
                                ? "جزئي"
                                : "موقوف"}
                        </span>
                      )}
                    </div>
                    {line.description && (
                      <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                        {line.description}
                      </p>
                    )}
                  </div>
                  <span className="text-xs font-semibold text-indigo-600">
                    {isOpen ? "إغلاق" : "تفاصيل"}
                  </span>
                </button>

                {isOpen && (
                  <div className="border-t bg-slate-50/50 p-4">
                    <ol className="relative space-y-4 border-r-2 border-indigo-200 pr-5">
                      {line.stations.map((s, i) => {
                        const near = nearest(s, 10);
                        const hasCoord = typeof s.lat === "number" && typeof s.lng === "number";
                        return (
                          <li key={`${line.id}-${i}-${s.name}`} className="relative">
                            <span className="absolute -right-[27px] top-1 flex h-4 w-4 items-center justify-center rounded-full bg-indigo-500 text-[10px] font-bold text-white">
                              {i + 1}
                            </span>
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <div className="text-sm font-bold text-indigo-900">
                                {s.name}
                                {s.gov && (
                                  <span className="mr-2 text-[11px] font-normal text-muted-foreground">
                                    — {s.gov}
                                  </span>
                                )}
                              </div>
                              {hasCoord && (
                                <a
                                  href={gmapsCoords(s.lat!, s.lng!)}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center gap-1 rounded-full border border-indigo-200 bg-white px-2 py-0.5 text-[10px] font-semibold text-indigo-700 hover:bg-indigo-50"
                                >
                                  <Navigation className="size-3" />
                                  خرائط
                                </a>
                              )}
                            </div>
                            {hasCoord ? (
                              near.length ? (
                                <ul className="mt-2 grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                                  {near.map((p, idx) => (
                                    <li key={`${p.name}-${idx}`}>
                                      <a
                                        href={gmapsCoords(p.lat, p.lng)}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="flex items-center justify-between gap-2 rounded-md border border-slate-200 bg-white px-2 py-1 text-[11px] text-slate-700 hover:border-indigo-300 hover:bg-indigo-50"
                                      >
                                        <span className="flex min-w-0 items-center gap-1">
                                          <MapPin className="size-3 shrink-0 text-indigo-500" />
                                          <span className="truncate">{p.name}</span>
                                        </span>
                                        <span className="shrink-0 font-mono text-[10px] text-muted-foreground">
                                          {p.km.toFixed(1)} كم
                                        </span>
                                      </a>
                                    </li>
                                  ))}
                                </ul>
                              ) : (
                                <p className="mt-2 text-[11px] text-muted-foreground">
                                  {pois.length
                                    ? "لا توجد نقاط مسجلة حول هذه المحطة."
                                    : "جاري تحميل نقاط الجوار..."}
                                </p>
                              )
                            ) : (
                              <p className="mt-2 text-[11px] text-muted-foreground">
                                إحداثيات المحطة غير متوفرة بعد.
                              </p>
                            )}
                          </li>
                        );
                      })}
                    </ol>
                  </div>
                )}
              </section>
            );
          })}
        </div>

        {lines.length > 0 && !filtered.length && (
          <div className="mt-4 rounded-xl border bg-white p-6 text-center text-sm text-muted-foreground">
            لا توجد نتائج مطابقة.
          </div>
        )}
      </main>
    </div>
  );
}
