import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { AdminPageShell } from "@/components/admin/AdminPageShell";
import { toast } from "sonner";
import {
  Loader2,
  Play,
  Pause,
  RefreshCw,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
} from "lucide-react";
import { listAreaAuditFn, submitAreaAuditFn } from "@/lib/route-planner/import-eg.functions";

export const Route = createFileRoute("/admin/area-audit")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "دقة تعبئة المنطقة — Tareeq Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AreaAuditPage,
});

type Addr = {
  neighbourhood?: string;
  suburb?: string;
  quarter?: string;
  city_district?: string;
  district?: string;
  city?: string;
  town?: string;
  village?: string;
  municipality?: string;
  county?: string;
  state?: string;
};

type Stop = {
  id: string;
  name_ar: string;
  latitude: number;
  longitude: number;
  city: string | null;
  area: string | null;
};

type Verdict = "match" | "corrected" | "aliased" | "mismatch" | "skipped";

type Row = {
  stop: Stop;
  verdict: Verdict;
  geoArea: string | null;
  geoCity: string | null;
  correctedArea?: string;
  aliases: string[];
};

const VAGUE = new Set(["", "غير محدد", "-", "—", "null", "undefined"]);

function norm(s: string | null | undefined): string {
  return (s ?? "")
    .trim()
    .toLowerCase()
    .replace(/[إأآا]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .replace(/\s+/g, " ");
}

function pickArea(a: Addr): string | null {
  return a.neighbourhood || a.suburb || a.quarter || a.city_district || a.district || null;
}
function pickCity(a: Addr): string | null {
  return a.city || a.town || a.village || a.municipality || a.county || null;
}
function collectAliases(a: Addr): string[] {
  return [
    a.neighbourhood,
    a.suburb,
    a.quarter,
    a.city_district,
    a.district,
    a.city,
    a.town,
    a.village,
    a.municipality,
  ].filter((v): v is string => typeof v === "string" && v.trim().length >= 2);
}

function classify(storedArea: string | null, geoArea: string | null): Verdict {
  const stored = norm(storedArea);
  const geo = norm(geoArea);
  if (VAGUE.has(stored)) return geo ? "corrected" : "skipped";
  if (!geo) return "skipped";
  if (stored === geo || stored.includes(geo) || geo.includes(stored)) return "match";
  // token overlap
  const a = new Set(stored.split(" ").filter((t) => t.length >= 3));
  const b = new Set(geo.split(" ").filter((t) => t.length >= 3));
  for (const t of a) if (b.has(t)) return "aliased";
  return "mismatch";
}

function AreaAuditPage() {
  const navigate = useNavigate();
  const [running, setRunning] = useState(false);
  const [onlyMissing, setOnlyMissing] = useState(false);
  const runningRef = useRef(false);
  const [remaining, setRemaining] = useState(0);
  const [counts, setCounts] = useState({
    processed: 0,
    match: 0,
    corrected: 0,
    aliased: 0,
    mismatch: 0,
    skipped: 0,
    errors: 0,
    aliasesInserted: 0,
  });
  const [mismatches, setMismatches] = useState<Row[]>([]);
  const [currentStop, setCurrentStop] = useState<string>("");

  const runList = useServerFn(listAreaAuditFn);
  const runSubmit = useServerFn(submitAreaAuditFn);

  async function reverse(lat: number, lng: number): Promise<Addr | null> {
    const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}&accept-language=ar&zoom=16`;
    try {
      const res = await fetch(url, { headers: { Accept: "application/json" } });
      if (!res.ok) return null;
      const j = (await res.json()) as { address?: Addr };
      return j.address ?? null;
    } catch {
      return null;
    }
  }
  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

  async function start() {
    if (runningRef.current) return;
    runningRef.current = true;
    setRunning(true);
    let afterId: string | undefined;
    try {
      let emptyRuns = 0;
      while (runningRef.current && emptyRuns < 2) {
        const { rows, remaining: rem } = await runList({
          data: { limit: 50, afterId, onlyMissing },
        });
        setRemaining(rem);
        if (!rows.length) {
          emptyRuns++;
          await sleep(1000);
          continue;
        }
        emptyRuns = 0;
        for (const stop of rows as Stop[]) {
          if (!runningRef.current) break;
          afterId = stop.id;
          setCurrentStop(stop.name_ar);
          const addr = await reverse(stop.latitude, stop.longitude);
          if (!addr) {
            setCounts((c) => ({ ...c, processed: c.processed + 1, errors: c.errors + 1 }));
            await sleep(1200);
            continue;
          }
          const geoArea = pickArea(addr);
          const geoCity = pickCity(addr);
          const verdict = classify(stop.area, geoArea);
          const aliases = collectAliases(addr);
          const correctedArea = verdict === "corrected" && geoArea ? geoArea : undefined;

          try {
            const res = await runSubmit({ data: { id: stop.id, verdict, correctedArea, aliases } });
            setCounts((c) => ({
              ...c,
              processed: c.processed + 1,
              match: c.match + (verdict === "match" ? 1 : 0),
              corrected: c.corrected + (verdict === "corrected" ? 1 : 0),
              aliased: c.aliased + (verdict === "aliased" ? 1 : 0),
              mismatch: c.mismatch + (verdict === "mismatch" ? 1 : 0),
              skipped: c.skipped + (verdict === "skipped" ? 1 : 0),
              aliasesInserted: c.aliasesInserted + res.aliasesInserted,
            }));
            if (verdict === "mismatch" || verdict === "aliased") {
              setMismatches((m) =>
                [{ stop, verdict, geoArea, geoCity, correctedArea, aliases }, ...m].slice(0, 100),
              );
            }
          } catch {
            setCounts((c) => ({ ...c, processed: c.processed + 1, errors: c.errors + 1 }));
          }
          await sleep(1100); // Nominatim <= 1 req/sec
        }
      }
      toast.success("انتهت جولة التدقيق");
    } catch (e) {
      toast.error(`توقّف المحرك: ${(e as Error).message}`);
    } finally {
      runningRef.current = false;
      setRunning(false);
      setCurrentStop("");
    }
  }

  function stop() {
    runningRef.current = false;
    setRunning(false);
  }

  async function refreshRemaining() {
    const r = await runList({ data: { limit: 1, onlyMissing } });
    setRemaining(r.remaining);
  }

  return (
    <AdminPageShell wrapperClassName="min-h-screen bg-slate-950 text-slate-100 p-4 pb-20">
      <div className="max-w-5xl mx-auto space-y-6">
        <header className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-emerald-400" /> محرّك دقة المنطقة
            </h1>
            <p className="text-sm text-slate-400 mt-1">
              يقارن حقل «المنطقة» في كل محطة بما تعود به إحداثياتها من OpenStreetMap، يصحّح الفارغ
              ويحوّل الأسماء البديلة إلى مرادفات بحث تلقائيًا.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <label className="flex items-center gap-2 text-sm text-slate-300">
              <input
                type="checkbox"
                checked={onlyMissing}
                disabled={running}
                onChange={(e) => setOnlyMissing(e.target.checked)}
              />
              فقط الفارغة
            </label>
            <button
              onClick={refreshRemaining}
              className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center gap-2 text-sm"
            >
              <RefreshCw className="w-4 h-4" /> تحديث
            </button>
            {running ? (
              <button
                onClick={stop}
                className="px-3 py-2 rounded-lg bg-red-600 hover:bg-red-500 flex items-center gap-2 text-sm"
              >
                <Pause className="w-4 h-4" /> إيقاف
              </button>
            ) : (
              <button
                onClick={start}
                className="px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 flex items-center gap-2 text-sm"
              >
                <Play className="w-4 h-4" /> تشغيل المحرّك
              </button>
            )}
          </div>
        </header>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Kpi label="محطات في الطابور" value={remaining} tone="slate" />
          <Kpi label="تمّت معالجتها" value={counts.processed} tone="slate" />
          <Kpi label="مطابقة ✓" value={counts.match} tone="emerald" />
          <Kpi label="صُحّحت" value={counts.corrected} tone="sky" />
          <Kpi label="أُضيفت كمرادف" value={counts.aliased} tone="indigo" />
          <Kpi label="تعارض" value={counts.mismatch} tone="amber" />
          <Kpi label="متخطاة" value={counts.skipped} tone="slate" />
          <Kpi label="مرادفات مخزّنة" value={counts.aliasesInserted} tone="fuchsia" />
        </div>

        {running && (
          <div className="rounded-xl bg-slate-900 border border-slate-800 p-3 text-sm text-slate-300 flex items-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin text-emerald-400" />
            جارٍ التحقّق من:{" "}
            <span className="font-semibold text-slate-100">{currentStop || "…"}</span>
          </div>
        )}

        <section>
          <h2 className="text-lg font-bold mb-2 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-400" /> تعارضات وأخر التحديثات
          </h2>
          {mismatches.length === 0 ? (
            <div className="text-sm text-slate-500 rounded-lg border border-dashed border-slate-800 p-6 text-center">
              لا تعارضات بعد. شغّل المحرّك ليبدأ فحص المحطات.
            </div>
          ) : (
            <div className="overflow-x-auto rounded-xl border border-slate-800">
              <table className="w-full text-sm">
                <thead className="bg-slate-900 text-slate-400">
                  <tr>
                    <th className="text-right p-2">المحطة</th>
                    <th className="text-right p-2">المنطقة المخزّنة</th>
                    <th className="text-right p-2">من الإحداثيات</th>
                    <th className="text-right p-2">الحكم</th>
                    <th className="text-right p-2">مرادفات</th>
                  </tr>
                </thead>
                <tbody>
                  {mismatches.map((r, i) => (
                    <tr key={`${r.stop.id}-${i}`} className="border-t border-slate-800">
                      <td className="p-2">
                        <div className="font-semibold">{r.stop.name_ar}</div>
                        <div className="text-xs text-slate-500 flex items-center gap-1">
                          <MapPin className="w-3 h-3" /> {r.stop.city ?? "—"}
                        </div>
                      </td>
                      <td className="p-2 text-slate-300">
                        {r.stop.area ?? <span className="text-slate-600">—</span>}
                      </td>
                      <td className="p-2 text-slate-300">
                        {r.geoArea ?? "—"}{" "}
                        {r.geoCity && <span className="text-slate-500">/ {r.geoCity}</span>}
                      </td>
                      <td className="p-2">
                        {r.verdict === "match" && <Badge tone="emerald">مطابق</Badge>}
                        {r.verdict === "corrected" && <Badge tone="sky">صُحّح</Badge>}
                        {r.verdict === "aliased" && <Badge tone="indigo">مرادف</Badge>}
                        {r.verdict === "mismatch" && <Badge tone="amber">تعارض</Badge>}
                        {r.verdict === "skipped" && <Badge tone="slate">تخطي</Badge>}
                      </td>
                      <td className="p-2 text-xs text-slate-400">
                        {r.aliases.slice(0, 4).join("، ")}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <div className="rounded-xl bg-slate-900/60 border border-slate-800 p-4 text-xs text-slate-400 leading-6">
          <div className="flex items-center gap-2 mb-1 text-slate-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" /> كيف يعمل؟
          </div>
          <ul className="list-disc pr-5 space-y-1">
            <li>يمرّ على كل محطة لها إحداثيات في مصر ويستعلم OSM Nominatim (طلب/ثانية).</li>
            <li>
              يقارن الحقل المخزّن بالحيّ/الضاحية المرجَعة، ويصنّف: مطابق، تصحيح، مرادف، تعارض.
            </li>
            <li>يكتب الاسم الصحيح تلقائيًا في المحطات ذات المنطقة الفارغة أو «غير محدد».</li>
            <li>
              يخزّن كل الأسماء المكتشفة (حيّ، ضاحية، مدينة) في <code>stop_aliases</code> بمصدر{" "}
              <code>area-audit</code> لتغذية محرّكات البحث.
            </li>
          </ul>
        </div>
      </div>
    </AdminPageShell>
  );
}

function Kpi({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone: "slate" | "emerald" | "sky" | "amber" | "indigo" | "fuchsia";
}) {
  const map = {
    slate: "bg-slate-900 border-slate-800 text-slate-100",
    emerald: "bg-emerald-950/50 border-emerald-900 text-emerald-200",
    sky: "bg-sky-950/50 border-sky-900 text-sky-200",
    amber: "bg-amber-950/50 border-amber-900 text-amber-200",
    indigo: "bg-indigo-950/50 border-indigo-900 text-indigo-200",
    fuchsia: "bg-fuchsia-950/50 border-fuchsia-900 text-fuchsia-200",
  }[tone];
  return (
    <div className={`rounded-xl border p-3 ${map}`}>
      <div className="text-xs opacity-70">{label}</div>
      <div className="text-2xl font-bold tabular-nums mt-1">{value.toLocaleString("ar-EG")}</div>
    </div>
  );
}

function Badge({
  tone,
  children,
}: {
  tone: "slate" | "emerald" | "sky" | "amber" | "indigo";
  children: React.ReactNode;
}) {
  const map = {
    slate: "bg-slate-800 text-slate-300",
    emerald: "bg-emerald-900/70 text-emerald-200",
    sky: "bg-sky-900/70 text-sky-200",
    amber: "bg-amber-900/70 text-amber-200",
    indigo: "bg-indigo-900/70 text-indigo-200",
  }[tone];
  return <span className={`inline-block px-2 py-0.5 rounded text-xs ${map}`}>{children}</span>;
}
