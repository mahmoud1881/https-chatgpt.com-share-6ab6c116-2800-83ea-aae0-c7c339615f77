import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { usePublishSnapshot } from "@/hooks/use-publish-snapshot";
import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowRight, Home, Briefcase, Repeat, Zap, Trash2, Save } from "lucide-react";
import {
  readCommute,
  saveCommute,
  clearCommute,
  hasCommute,
  autoDirection,
  type CommuteConfig,
} from "@/lib/transit/commute";
import { toast } from "sonner";

import { AuthGateLoading } from "@/components/AuthGateLoading";
import { useRequireAuth } from "@/hooks/useRequireAuth";

export const Route = createFileRoute("/commute")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "رحلتي اليومية — مواصلات مصر" },
      { name: "description", content: "اضبط رحلة بيت ↔ شغل وانطلق بضغطة واحدة." },
    ],
  }),
  component: CommuteRoute,
});

/** بوابة استخدام: يتطلب تسجيل دخول قبل عرض هذه الصفحة (مش مجرد تصفح). */
function CommuteRoute() {
  const authStatus = useRequireAuth();
  if (authStatus !== "authenticated") return <AuthGateLoading />;
  return <CommutePage />;
}

function CommutePage() {
  usePublishSnapshot({
    id: "eg:commute",
    source: "الرحلة اليومية",
    title: "بيت ↔ شغل",
    summary: "رحلتك اليومية جاهزة بضغطة واحدة",
    category: "transit",
    href: "/commute",
  });
  const navigate = useNavigate();
  const [cfg, setCfg] = useState<CommuteConfig>({
    home: null,
    work: null,
    morningDirection: "home-to-work",
  });
  const [homeText, setHomeText] = useState("");
  const [workText, setWorkText] = useState("");

  useEffect(() => {
    const c = readCommute();
    setCfg(c);
    setHomeText(c.home?.query ?? "");
    setWorkText(c.work?.query ?? "");
  }, []);

  const save = () => {
    if (!homeText.trim() || !workText.trim()) {
      toast.error("اكتب عنوان البيت والشغل");
      return;
    }
    const next: CommuteConfig = {
      home: { label: "البيت", query: homeText.trim() },
      work: { label: "الشغل", query: workText.trim() },
      morningDirection: cfg.morningDirection,
    };
    setCfg(next);
    saveCommute(next);
    toast.success("تم حفظ رحلتك اليومية");
  };

  const go = (direction?: "home-to-work" | "work-to-home") => {
    if (!hasCommute(cfg)) {
      toast.error("احفظ بياناتك أولاً");
      return;
    }
    const pair = direction
      ? direction === "home-to-work"
        ? { from: cfg.home!, to: cfg.work! }
        : { from: cfg.work!, to: cfg.home! }
      : autoDirection(cfg);
    if (!pair) return;
    navigate({
      to: "/explore",
      search: { q: `من ${pair.from.query} إلى ${pair.to.query}` } as never,
    });
  };

  const toggleDir = () => {
    const next: CommuteConfig = {
      ...cfg,
      morningDirection: cfg.morningDirection === "home-to-work" ? "work-to-home" : "home-to-work",
    };
    setCfg(next);
    saveCommute(next);
  };

  const reset = () => {
    clearCommute();
    setCfg({ home: null, work: null, morningDirection: "home-to-work" });
    setHomeText("");
    setWorkText("");
    toast.success("تم المسح");
  };

  return (
    <div dir="rtl" className="min-h-screen bg-background px-4 py-8">
      <div className="mx-auto max-w-2xl space-y-6">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowRight className="size-4" /> الرئيسية
        </Link>

        <header className="space-y-1">
          <h1 className="flex items-center gap-2 text-2xl font-extrabold">
            <Zap className="size-6 text-amber-500" /> رحلتي اليومية
          </h1>
          <p className="text-sm text-muted-foreground">
            احفظ عنوان البيت والشغل مرة واحدة — انطلق بضغطة واحدة كل يوم.
          </p>
        </header>

        {/* زر الانطلاق السريع */}
        {hasCommute(cfg) && (
          <Card className="bg-gradient-to-br from-amber-50 to-orange-50 p-5">
            <div className="mb-3 text-sm text-muted-foreground">الوقت الحالي يقترح:</div>
            <Button
              size="lg"
              className="w-full gap-2 bg-amber-500 text-white hover:bg-amber-600"
              onClick={() => go()}
            >
              <Zap className="size-5" />
              انطلق الآن
            </Button>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Button variant="outline" size="sm" onClick={() => go("home-to-work")}>
                <Home className="ml-1 size-3.5" />
                للشغل
              </Button>
              <Button variant="outline" size="sm" onClick={() => go("work-to-home")}>
                <Briefcase className="ml-1 size-3.5" />
                للبيت
              </Button>
            </div>
          </Card>
        )}

        {/* النموذج */}
        <Card className="p-5 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="home" className="flex items-center gap-2">
              <Home className="size-4 text-emerald-600" /> عنوان البيت
            </Label>
            <Input
              id="home"
              value={homeText}
              onChange={(e) => setHomeText(e.target.value)}
              placeholder="مثال: المعادي"
              dir="rtl"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="work" className="flex items-center gap-2">
              <Briefcase className="size-4 text-sky-600" /> عنوان الشغل
            </Label>
            <Input
              id="work"
              value={workText}
              onChange={(e) => setWorkText(e.target.value)}
              placeholder="مثال: التحرير"
              dir="rtl"
            />
          </div>

          <button
            type="button"
            onClick={toggleDir}
            className="flex w-full items-center justify-between rounded-lg border bg-muted/30 px-3 py-2 text-sm hover:bg-muted"
          >
            <span className="flex items-center gap-2">
              <Repeat className="size-4" />
              الاتجاه الصباحي
            </span>
            <span className="font-semibold">
              {cfg.morningDirection === "home-to-work" ? "بيت ← شغل" : "شغل ← بيت"}
            </span>
          </button>

          <div className="flex gap-2">
            <Button onClick={save} className="flex-1 gap-2">
              <Save className="size-4" /> حفظ
            </Button>
            {hasCommute(cfg) && (
              <Button variant="outline" onClick={reset} className="gap-2">
                <Trash2 className="size-4" /> مسح
              </Button>
            )}
          </div>
        </Card>

        <Card className="bg-muted/30 p-4 text-xs text-muted-foreground">
          🔒 كل البيانات محفوظة محلياً على جهازك فقط. لا نرسل عنوانك لأي خادم.
        </Card>
      </div>
    </div>
  );
}
