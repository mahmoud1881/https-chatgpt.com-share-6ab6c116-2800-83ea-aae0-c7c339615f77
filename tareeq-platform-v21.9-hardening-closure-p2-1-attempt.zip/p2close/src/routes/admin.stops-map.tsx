import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { AdminPageShell } from "@/components/admin/AdminPageShell";
import { toast } from "sonner";
import {
  listStopsWithoutCoords,
  geocodeStop,
  updateStopCoords,
} from "@/lib/route-planner/admin-editor.functions";
import { Loader2, MapPin, Search, CheckCircle2, ChevronRight, ChevronLeft } from "lucide-react";

export const Route = createFileRoute("/admin/stops-map")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "إحداثيات المحطات — Tareeq Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: StopsMapPage,
});

const COUNTRIES = [
  { code: "eg", label: "🇪🇬 مصر" },
  { code: "ly", label: "🇱🇾 ليبيا" },
  { code: "iq", label: "🇮🇶 العراق" },
  { code: "sy", label: "🇸🇾 سوريا" },
  { code: "sd", label: "🇸🇩 السودان" },
  { code: "ye", label: "🇾🇪 اليمن" },
];

type Stop = {
  id: string;
  name_ar: string;
  name_en: string | null;
  city: string | null;
  country: string;
  is_verified: boolean;
};
type GeoResult = {
  lat: number;
  lng: number;
  display_name: string;
  type: string;
  importance: number;
};

const PAGE = 20;

function StopsMapPage() {
  const navigate = useNavigate();
  const [country, setCountry] = useState("eg");
  const [rows, setRows] = useState<Stop[]>([]);
  const [total, setTotal] = useState(0);
  const [offset, setOffset] = useState(0);
  const [loading, setLoading] = useState(false);
  const [active, setActive] = useState<Stop | null>(null);
  const [geo, setGeo] = useState<GeoResult[]>([]);
  const [geoQuery, setGeoQuery] = useState("");
  const [geoLoading, setGeoLoading] = useState(false);
  const [manualLat, setManualLat] = useState("");
  const [manualLng, setManualLng] = useState("");
  const [saving, setSaving] = useState(false);

  const listFn = useServerFn(listStopsWithoutCoords);
  const geocodeFn = useServerFn(geocodeStop);
  const saveFn = useServerFn(updateStopCoords);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [country, offset]);

  async function load() {
    setLoading(true);
    try {
      const res = await listFn({ data: { country, limit: PAGE, offset } });
      setRows(res.rows as Stop[]);
      setTotal(res.total);
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  function openStop(s: Stop) {
    setActive(s);
    setGeo([]);
    setManualLat("");
    setManualLng("");
    setGeoQuery(`${s.name_ar}${s.city ? ", " + s.city : ""}`);
  }

  async function runGeocode() {
    if (!geoQuery.trim()) return;
    setGeoLoading(true);
    try {
      const res = await geocodeFn({ data: { query: geoQuery.trim(), country: active?.country } });
      setGeo(res.results);
      if (res.results.length === 0) toast.info("لا نتائج — جرّب صياغة مختلفة");
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setGeoLoading(false);
    }
  }

  async function saveCoords(lat: number, lng: number, verify: boolean) {
    if (!active) return;
    setSaving(true);
    try {
      await saveFn({ data: { id: active.id, lat, lng, verify } });
      toast.success("تم الحفظ");
      setRows((rs) => rs.filter((r) => r.id !== active.id));
      setActive(null);
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <AdminPageShell>
      <header className="px-4 pt-6 pb-4 flex items-center justify-between">
        <Link to="/admin/data-health" className="text-xs underline text-muted-foreground">
          ← صحّة البيانات
        </Link>
        <h1 className="text-lg font-bold flex items-center gap-2">
          <MapPin className="w-5 h-5" /> إحداثيات المحطات
        </h1>
      </header>

      <div className="px-4 flex items-center gap-2 flex-wrap">
        <select
          value={country}
          onChange={(e) => {
            setCountry(e.target.value);
            setOffset(0);
          }}
          className="rounded-xl border bg-background px-3 py-2 text-sm"
        >
          {COUNTRIES.map((c) => (
            <option key={c.code} value={c.code}>
              {c.label}
            </option>
          ))}
        </select>
        <span className="text-xs text-muted-foreground">
          {total.toLocaleString("ar-EG")} محطة بدون إحداثيات
        </span>
        {loading && <Loader2 className="w-4 h-4 animate-spin" />}
      </div>

      <ul className="px-4 mt-4 space-y-2">
        {rows.map((s) => (
          <li key={s.id}>
            <button
              onClick={() => openStop(s)}
              className="w-full text-right rounded-2xl border bg-card p-3 hover:bg-muted flex items-center justify-between"
            >
              <div className="min-w-0">
                <div className="text-sm font-bold">{s.name_ar}</div>
                <div className="text-[10px] text-muted-foreground">
                  {s.city ?? "—"} {s.is_verified && "· موثّق"}
                </div>
              </div>
              <MapPin className="w-4 h-4 text-muted-foreground shrink-0" />
            </button>
          </li>
        ))}
      </ul>

      {total > PAGE && (
        <div className="px-4 mt-4 flex items-center justify-between text-xs">
          <button
            onClick={() => setOffset((o) => Math.max(0, o - PAGE))}
            disabled={offset === 0}
            className="rounded-full border px-3 py-1.5 disabled:opacity-40"
          >
            <ChevronRight className="w-3 h-3 inline" /> السابق
          </button>
          <span className="text-muted-foreground">
            {offset + 1}–{Math.min(offset + PAGE, total)} من {total}
          </span>
          <button
            onClick={() => setOffset((o) => o + PAGE)}
            disabled={offset + PAGE >= total}
            className="rounded-full border px-3 py-1.5 disabled:opacity-40"
          >
            التالي <ChevronLeft className="w-3 h-3 inline" />
          </button>
        </div>
      )}

      {active && (
        <div
          dir="rtl"
          className="fixed inset-0 z-50 bg-black/50 grid place-items-end sm:place-items-center p-3"
        >
          <div className="w-full max-w-lg bg-card rounded-2xl border p-4 space-y-3 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-bold">{active.name_ar}</div>
                <div className="text-[10px] text-muted-foreground">
                  {active.city ?? "—"} · {active.country}
                </div>
              </div>
              <button onClick={() => setActive(null)} className="text-muted-foreground text-sm">
                إغلاق
              </button>
            </div>

            <div>
              <label className="text-[10px] text-muted-foreground">بحث في OpenStreetMap</label>
              <div className="flex items-center gap-1 bg-background rounded-xl border px-2 mt-1">
                <Search className="w-3.5 h-3.5 text-muted-foreground" />
                <input
                  value={geoQuery}
                  onChange={(e) => setGeoQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && runGeocode()}
                  className="flex-1 bg-transparent py-2 text-sm outline-none"
                />
                <button
                  onClick={runGeocode}
                  disabled={geoLoading}
                  className="text-xs rounded-lg bg-primary text-primary-foreground px-3 py-1 disabled:opacity-50"
                >
                  {geoLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : "ابحث"}
                </button>
              </div>
            </div>

            {geo.length > 0 && (
              <div className="space-y-1">
                {geo.map((g, i) => (
                  <div key={i} className="rounded-xl border p-2 bg-background">
                    <div className="text-xs">{g.display_name}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5 font-mono">
                      {g.lat.toFixed(5)}, {g.lng.toFixed(5)} · {g.type}
                    </div>
                    <div className="flex gap-1 mt-2 justify-end">
                      <button
                        onClick={() => saveCoords(g.lat, g.lng, false)}
                        disabled={saving}
                        className="text-[11px] rounded-full border px-2.5 py-1 hover:bg-muted"
                      >
                        احفظ
                      </button>
                      <button
                        onClick={() => saveCoords(g.lat, g.lng, true)}
                        disabled={saving}
                        className="text-[11px] rounded-full bg-emerald-600 text-white px-2.5 py-1"
                      >
                        <CheckCircle2 className="w-3 h-3 inline" /> احفظ + وثّق
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="pt-2 border-t">
              <label className="text-[10px] text-muted-foreground">أو أدخل الإحداثيات يدوياً</label>
              <div className="flex gap-1 mt-1">
                <input
                  value={manualLat}
                  onChange={(e) => setManualLat(e.target.value)}
                  placeholder="lat"
                  className="w-24 bg-background rounded-lg border px-2 py-1 text-xs"
                />
                <input
                  value={manualLng}
                  onChange={(e) => setManualLng(e.target.value)}
                  placeholder="lng"
                  className="w-24 bg-background rounded-lg border px-2 py-1 text-xs"
                />
                <button
                  onClick={() => {
                    const lat = parseFloat(manualLat);
                    const lng = parseFloat(manualLng);
                    if (isNaN(lat) || isNaN(lng)) return toast.error("قيم غير صحيحة");
                    saveCoords(lat, lng, false);
                  }}
                  disabled={saving}
                  className="text-[11px] rounded-lg border px-2 hover:bg-muted"
                >
                  حفظ
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </AdminPageShell>
  );
}
