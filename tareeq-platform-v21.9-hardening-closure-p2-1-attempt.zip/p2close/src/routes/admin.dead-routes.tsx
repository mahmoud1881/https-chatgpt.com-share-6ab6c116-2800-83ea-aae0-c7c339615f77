import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { AdminPageShell } from "@/components/admin/AdminPageShell";
import { toast } from "sonner";
import { listDeadRoutes, deleteRoute } from "@/lib/route-planner/admin-cleanup.functions";
import { Loader2, Trash2, AlertTriangle } from "lucide-react";

export const Route = createFileRoute("/admin/dead-routes")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "خطوط تالفة — Tareeq Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: DeadRoutesPage,
});

const COUNTRIES = [
  { code: "", label: "🌍 كل الدول" },
  { code: "eg", label: "🇪🇬 مصر" },
  { code: "ly", label: "🇱🇾 ليبيا" },
  { code: "iq", label: "🇮🇶 العراق" },
  { code: "sy", label: "🇸🇾 سوريا" },
  { code: "sd", label: "🇸🇩 السودان" },
  { code: "ye", label: "🇾🇪 اليمن" },
];

type Item = {
  id: string;
  route_code: string | null;
  route_name: string | null;
  country: string | null;
  city: string | null;
  stops_count: number;
  reasons: string[];
};

const REASON_LABEL: Record<string, string> = {
  no_start: "بدون بداية",
  no_end: "بدون نهاية",
  no_stops: "بدون محطات",
};

function DeadRoutesPage() {
  const navigate = useNavigate();
  const [country, setCountry] = useState("");
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);

  const listFn = useServerFn(listDeadRoutes);
  const delFn = useServerFn(deleteRoute);

  async function scan() {
    setLoading(true);
    try {
      const res = await listFn({
        data: { country: country || undefined, limit: 500 },
      });
      setItems((res.items ?? []) as Item[]);
      toast.success(`وُجد ${res.items?.length ?? 0} خطًا يحتاج مراجعة`);
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "فشل الفحص");
    } finally {
      setLoading(false);
    }
  }

  async function remove(id: string) {
    if (!confirm("حذف نهائي لهذا الخط؟")) return;
    setBusy(id);
    try {
      await delFn({ data: { id } });
      toast.success("تم الحذف");
      setItems((prev) => prev.filter((x) => x.id !== id));
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "فشل الحذف");
    } finally {
      setBusy(null);
    }
  }

  return (
    <AdminPageShell wrapperClassName="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">خطوط تحتاج مراجعة أو حذف</h1>
          <Link to="/admin/data-health" className="text-sm text-primary underline">
            ← لوحة صحة الداتا
          </Link>
        </div>

        <div className="flex gap-2 flex-wrap items-center">
          <select
            value={country}
            onChange={(e) => setCountry(e.target.value)}
            className="px-3 py-2 rounded-md bg-card border border-border text-sm"
          >
            {COUNTRIES.map((c) => (
              <option key={c.code} value={c.code}>
                {c.label}
              </option>
            ))}
          </select>
          <button
            onClick={scan}
            disabled={loading}
            className="px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm disabled:opacity-50"
          >
            {loading ? "جارٍ الفحص…" : "فحص"}
          </button>
        </div>

        {items.length === 0 && !loading ? (
          <div className="text-center py-12 text-muted-foreground">
            اضغط "فحص" لبدء البحث عن الخطوط الناقصة
          </div>
        ) : (
          <div className="space-y-2">
            {items.map((r) => (
              <div
                key={r.id}
                className="bg-card border border-border rounded-lg p-4 flex items-center justify-between gap-4"
              >
                <div className="flex-1 min-w-0">
                  <div className="font-semibold truncate">
                    {r.route_name || r.route_code || r.id.slice(0, 8)}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {r.country ?? "—"}
                    {r.city ? ` / ${r.city}` : ""} • {r.stops_count} محطة
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {r.reasons.map((rs) => (
                      <span
                        key={rs}
                        className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded bg-destructive/10 text-destructive"
                      >
                        <AlertTriangle className="h-3 w-3" />
                        {REASON_LABEL[rs] ?? rs}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="flex gap-2 shrink-0">
                  <Link
                    to="/admin/routes/$routeId/edit"
                    params={{ routeId: r.id }}
                    className="px-3 py-2 rounded-md border border-border text-sm hover:bg-muted"
                  >
                    تحرير
                  </Link>
                  <button
                    onClick={() => remove(r.id)}
                    disabled={busy === r.id}
                    className="px-3 py-2 rounded-md bg-destructive text-destructive-foreground text-sm disabled:opacity-50 flex items-center gap-1"
                  >
                    <Trash2 className="h-4 w-4" /> حذف
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AdminPageShell>
  );
}
