import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { getErrorMessage } from "@/lib/error-message";
import { getPair, POPULAR_PAIRS, type TripPair } from "@/data/popularPairs";
import { FloatingHomeButton } from "@/components/FloatingHomeButton";
import { isGrowthLoopsEnabled } from "@/lib/flags";
import { ShareTripCard } from "@/components/growth/ShareTripCard";
import { ShareRouteButton } from "@/components/growth/engines/ShareRouteButton";
import { VerifyRoutePrompt } from "@/components/growth/engines/VerifyRoutePrompt";

import { SITE_BASE_URL as BASE } from "@/lib/seo/site";

function buildHead(pair: TripPair) {
  const url = `${BASE}/trip/${pair.fromSlug}/${pair.toSlug}`;
  const flag = pair.country === "ma" ? "🇲🇦" : "🇪🇬";
  const title = `من ${pair.fromAr} إلى ${pair.toAr} ${flag} — وسائل النقل والوقت`;
  const desc = `دليل شامل للسفر من ${pair.fromAr} إلى ${pair.toAr}: ${pair.modes.join("، ")}${
    pair.distanceKm ? ` — ${pair.distanceKm} كم` : ""
  }${pair.approxMinutes ? ` — حوالي ${Math.round(pair.approxMinutes / 60)} ساعة` : ""}.`;
  const img = pair.country === "ma" ? `${BASE}/og-ma.jpg` : `${BASE}/og-eg.jpg`;

  return {
    meta: [
      { title },
      { name: "description", content: desc },
      { property: "og:title", content: title },
      { property: "og:description", content: desc },
      { property: "og:url", content: url },
      { property: "og:type", content: "article" },
      { property: "og:image", content: img },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: title },
      { name: "twitter:description", content: desc },
      { name: "twitter:image", content: img },
    ],
    links: [{ rel: "canonical", href: url }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "TouristTrip",
          name: `من ${pair.fromAr} إلى ${pair.toAr}`,
          description: desc,
          touristType: ["مسافرون", "ركاب نقل عام"],
          itinerary: {
            "@type": "ItemList",
            itemListElement: pair.modes.map((m, i) => ({
              "@type": "ListItem",
              position: i + 1,
              name: m,
            })),
          },
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: "الرئيسية", item: `${BASE}/` },
            { "@type": "ListItem", position: 2, name: pair.fromAr, item: `${BASE}/` },
            { "@type": "ListItem", position: 3, name: `إلى ${pair.toAr}`, item: url },
          ],
        }),
      },
    ],
  };
}

export const Route = createFileRoute("/trip/$from/$to")({
  ssr: false,
  loader: ({ params }) => {
    const pair = getPair(params.from, params.to);
    if (!pair) throw notFound();
    return { pair };
  },
  head: ({ loaderData }) =>
    loaderData ? buildHead(loaderData.pair) : { meta: [{ title: "Trip" }] },
  component: TripPage,
  errorComponent: ({ error, reset }) => (
    <div className="p-6 text-center" dir="rtl">
      <h1 className="text-2xl font-bold">تعذّر تحميل هذه الرحلة</h1>
      <p className="mt-2 text-sm text-muted-foreground">{getErrorMessage(error)}</p>
      <button
        onClick={reset}
        className="mt-4 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
      >
        إعادة المحاولة
      </button>
      <Link to="/explore" className="mt-2 block text-primary underline">
        العودة للاستكشاف
      </Link>
    </div>
  ),
  notFoundComponent: () => (
    <div className="p-6 text-center">
      <h1 className="text-2xl font-bold">لم نجد هذا المسار</h1>
      <Link to="/explore" className="mt-4 inline-block text-primary underline">
        ابحث عن مسار آخر
      </Link>
    </div>
  ),
});

function TripPage() {
  const { pair } = Route.useLoaderData();
  const growthOn = isGrowthLoopsEnabled();
  const related = POPULAR_PAIRS.filter(
    (p) =>
      p.country === pair.country &&
      (p.fromSlug === pair.fromSlug || p.toSlug === pair.toSlug) &&
      !(p.fromSlug === pair.fromSlug && p.toSlug === pair.toSlug),
  ).slice(0, 6);

  return (
    <div className="min-h-screen bg-background pb-24" dir="rtl">
      <FloatingHomeButton />
      <header className="bg-gradient-to-b from-primary/15 to-transparent px-4 py-8">
        <p className="text-sm text-muted-foreground">رحلة بين المدن</p>
        <h1 className="mt-2 text-3xl font-bold leading-tight">
          من {pair.fromAr} <span className="text-primary">→</span> {pair.toAr}
        </h1>
        {(pair.distanceKm || pair.approxMinutes) && (
          <p className="mt-3 text-sm text-muted-foreground">
            {pair.distanceKm && <span>📍 {pair.distanceKm} كم</span>}
            {pair.approxMinutes && (
              <span className="mr-3">
                ⏱️ {Math.floor(pair.approxMinutes / 60)} س {pair.approxMinutes % 60} د
              </span>
            )}
          </p>
        )}
      </header>

      {growthOn && (
        <ShareTripCard
          fromAr={pair.fromAr}
          toAr={pair.toAr}
          path={`/trip/${pair.fromSlug}/${pair.toSlug}`}
        />
      )}

      <section className="px-4 py-6">
        <h2 className="text-lg font-semibold">وسائل النقل المتاحة</h2>
        <ul className="mt-3 grid gap-2">
          {pair.modes.map((m: string) => (
            <li key={m} className="rounded-lg border border-border bg-card px-4 py-3 text-sm">
              🚌 {m}
            </li>
          ))}
        </ul>
      </section>

      {growthOn && (
        <ShareRouteButton
          fromAr={pair.fromAr}
          toAr={pair.toAr}
          path={`/trip/${pair.fromSlug}/${pair.toSlug}`}
          modes={pair.modes}
          approxMinutes={pair.approxMinutes}
        />
      )}

      {growthOn && (
        <VerifyRoutePrompt
          routeReference={`mixed:${pair.fromSlug}:${pair.toSlug}`}
          fromAr={pair.fromAr}
          toAr={pair.toAr}
        />
      )}

      <section className="px-4 py-6">
        <h2 className="text-lg font-semibold">خطط رحلتك الآن</h2>
        <div className="mt-3 grid gap-2">
          <Link
            to="/navigate"
            className="rounded-lg bg-primary px-4 py-3 text-center text-sm font-medium text-primary-foreground"
          >
            🗺️ الملاحة خطوة بخطوة
          </Link>
          <Link
            to="/explore"
            className="rounded-lg border border-border bg-card px-4 py-3 text-center text-sm"
          >
            🔎 بحث موحّد
          </Link>
        </div>
      </section>

      {related.length > 0 && (
        <section className="px-4 py-6">
          <h2 className="text-lg font-semibold">مسارات قريبة</h2>
          <div className="mt-3 grid gap-2">
            {related.map((r) => (
              <Link
                key={`${r.fromSlug}-${r.toSlug}`}
                to="/trip/$from/$to"
                params={{ from: r.fromSlug, to: r.toSlug }}
                className="rounded-lg border border-border bg-card px-4 py-3 text-sm"
              >
                من {r.fromAr} إلى {r.toAr} ←
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
