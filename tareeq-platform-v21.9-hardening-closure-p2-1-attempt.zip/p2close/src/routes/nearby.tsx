import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  ArrowRight,
  MapPin,
  Loader2,
  LocateFixed,
  Share2,
  Link2,
  User,
  MousePointerClick,
  Navigation,
} from "lucide-react";
import LazyTransitMap from "@/components/LazyTransitMap";
import type { MapPointInput } from "@/components/TransitMap";
import { SITE_BASE_URL as SITE_URL } from "@/lib/seo/site";

import { AuthGateLoading } from "@/components/AuthGateLoading";
import { useRequireAuth } from "@/hooks/useRequireAuth";

const searchSchema = z.object({
  lat: z.coerce.number().optional(),
  lng: z.coerce.number().optional(),
  label: z.string().optional(),
});

export const Route = createFileRoute("/nearby")({
  ssr: false,
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "أقرب المحطات من موقعي — مواصلات مصر" },
      {
        name: "description",
        content:
          "اعثر تلقائياً على أقرب محطات المترو، الأتوبيس والميكروباص من موقعك الحالي وشارك موقعك مع أصدقائك.",
      },
      { property: "og:title", content: "أقرب المحطات من موقعي — مواصلات مصر" },
      { property: "og:description", content: "خريطة تفاعلية تعرض أقرب محطات النقل العام لموقعك." },
      { property: "og:url", content: `${SITE_URL}/nearby` },
    ],
    links: [{ rel: "canonical", href: `${SITE_URL}/nearby` }],
  }),
  component: NearbyRoute,
});

type NearbyPoint = {
  id: string;
  name: string;
  lat: number;
  lng: number;
  distanceKm: number;
  type?: string;
};

/** بوابة استخدام: يتطلب تسجيل دخول قبل عرض هذه الصفحة (مش مجرد تصفح). */
function NearbyRoute() {
  const authStatus = useRequireAuth();
  if (authStatus !== "authenticated") return <AuthGateLoading />;
  return <NearbyPage />;
}

function NearbyPage() {
  const { lat: sharedLat, lng: sharedLng, label: sharedLabel } = Route.useSearch();
  const navigate = useNavigate();
  const sharedPin = useMemo(
    () =>
      typeof sharedLat === "number" &&
      typeof sharedLng === "number" &&
      Number.isFinite(sharedLat) &&
      Number.isFinite(sharedLng)
        ? { lat: sharedLat, lng: sharedLng, label: sharedLabel?.trim() || "موقع مشترك" }
        : null,
    [sharedLat, sharedLng, sharedLabel],
  );

  const [loc, setLoc] = useState<{ lat: number; lng: number } | null>(null);
  const [points, setPoints] = useState<NearbyPoint[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [distanceToShared, setDistanceToShared] = useState<number | null>(null);
  const [pickMode, setPickMode] = useState(false);
  const [pickedPoint, setPickedPoint] = useState<{ lat: number; lng: number } | null>(null);
  const [placeLabel, setPlaceLabel] = useState("");

  const colorFor = (t?: string) =>
    t === "metro" ? "#10b981" : t === "lrt" ? "#8b5cf6" : t === "brt" ? "#f59e0b" : "#2563eb";

  const computeNearby = async (here: { lat: number; lng: number }) => {
    const { nearestPoints } = await import("@/lib/transit/geo");
    const pts = await nearestPoints(here, 12, 8);
    setPoints(pts);
    if (pts.length === 0) setError("لم نعثر على محطات قريبة ضمن نطاق 8 كم.");
  };

  const requestLocation = async () => {
    setError(null);
    setLoading(true);
    try {
      const { getUserLocation, haversineKm } = await import("@/lib/transit/geo");
      const here = await getUserLocation();
      setLoc(here);
      if (sharedPin) setDistanceToShared(haversineKm(here, sharedPin));
      await computeNearby(here);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "تعذّر تحديد موقعك";
      setError(
        msg.includes("denied") || /Permission/i.test(msg)
          ? "تم رفض إذن الموقع. فعّله من إعدادات المتصفح ثم حاول مجدداً."
          : "تعذّر تحديد موقعك. تأكد من تفعيل خدمات الموقع.",
      );
    } finally {
      setLoading(false);
    }
  };

  // محاولة تلقائية عند فتح الصفحة
  useEffect(() => {
    void requestLocation();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // إذا فُتح برابط مشاركة وليس لدينا موقع للمستخدم، احسب أقرب المحطات من النقطة المشتركة نفسها
  useEffect(() => {
    if (!sharedPin || loc) return;
    void computeNearby({ lat: sharedPin.lat, lng: sharedPin.lng });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sharedPin]);

  const buildShareUrl = (pt: { lat: number; lng: number }, label: string) =>
    `${window.location.origin}/nearby?lat=${pt.lat.toFixed(5)}&lng=${pt.lng.toFixed(5)}&label=${encodeURIComponent(label)}`;

  const shareLocation = async (kind: "share" | "copy", source: "me" | "picked") => {
    let here: { lat: number; lng: number } | null = null;
    let label = "موقعي";
    if (source === "picked") {
      if (!pickedPoint) {
        toast.error("اختر نقطة على الخريطة أولاً");
        return;
      }
      here = pickedPoint;
      label = placeLabel.trim() || "المكان";
    } else {
      here = loc;
      if (!here) {
        try {
          const { getUserLocation } = await import("@/lib/transit/geo");
          here = await getUserLocation();
          setLoc(here);
        } catch {
          toast.error("لم نتمكن من تحديد موقعك للمشاركة");
          return;
        }
      }
    }
    const url = buildShareUrl(here, label);
    const shareData = { title: label, text: `📍 ${label}`, url };
    if (
      kind === "share" &&
      typeof navigator !== "undefined" &&
      typeof navigator.share === "function"
    ) {
      try {
        await navigator.share(shareData);
        return;
      } catch {
        return;
      }
    }
    try {
      await navigator.clipboard.writeText(url);
      toast.success("تم نسخ الرابط — أرسله لمن تريد");
    } catch {
      toast.error("تعذّر النسخ");
    }
  };

  const routeToShared = () => {
    if (!sharedPin) return;
    const nearest = points[0];
    const to = nearest?.name || `${sharedPin.lat.toFixed(4)},${sharedPin.lng.toFixed(4)}`;
    navigate({ to: "/explore", search: { to } as never });
    toast.success(nearest ? `جاري البحث عن مسار لأقرب محطة: ${nearest.name}` : "افتح بحث المسار");
  };

  const mapPoints: MapPointInput[] = [
    ...points.map((p) => ({
      id: p.id,
      name: p.name,
      lat: p.lat,
      lng: p.lng,
      color: colorFor(p.type),
      type: p.type,
    })),
    ...(sharedPin
      ? [
          {
            id: "__shared__",
            name: sharedPin.label,
            lat: sharedPin.lat,
            lng: sharedPin.lng,
            color: "#ef4444",
            type: "shared",
          } as MapPointInput,
        ]
      : []),
    ...(pickedPoint
      ? [
          {
            id: "__picked__",
            name: placeLabel.trim() || "نقطة محددة",
            lat: pickedPoint.lat,
            lng: pickedPoint.lng,
            color: "#f59e0b",
            type: "picked",
          } as MapPointInput,
        ]
      : []),
  ];

  return (
    <div dir="rtl" className="min-h-screen bg-background px-4 py-8">
      <div className="mx-auto max-w-4xl space-y-6">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowRight className="size-4" /> رجوع للرئيسية
        </Link>

        <header className="space-y-2">
          <h1 className="flex items-center gap-2 text-2xl font-extrabold md:text-3xl">
            <LocateFixed className="size-7 text-primary" /> أقرب المحطات من موقعي
          </h1>
          <p className="text-sm text-muted-foreground">
            خريطة تفاعلية مجانية تعرض أقرب محطات النقل العام لموقعك — وتقدر تشارك موقعك مع أي شخص
            برابط مباشر.
          </p>
        </header>

        {sharedPin && (
          <Card className="border-red-300 bg-red-50/60 p-4 dark:border-red-900 dark:bg-red-950/30">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2 text-sm">
                <User className="size-5 text-red-600" />
                <span className="font-bold">{sharedPin.label}</span>
                <Badge variant="outline" className="text-xs">
                  {sharedPin.lat.toFixed(4)}, {sharedPin.lng.toFixed(4)}
                </Badge>
                {distanceToShared !== null && (
                  <Badge variant="secondary" className="text-xs">
                    🚶{" "}
                    {distanceToShared < 1
                      ? `${Math.round(distanceToShared * 1000)} م`
                      : `${distanceToShared.toFixed(1)} كم`}{" "}
                    من موقعك
                  </Badge>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Button
                  size="sm"
                  onClick={routeToShared}
                  className="gap-1 bg-emerald-600 hover:bg-emerald-700"
                >
                  <Navigation className="size-4" /> كيف أصل لهنا
                </Button>
                <a
                  href={`https://www.openstreetmap.org/?mlat=${sharedPin.lat}&mlon=${sharedPin.lng}#map=17/${sharedPin.lat}/${sharedPin.lng}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-primary underline"
                >
                  فتح في OpenStreetMap
                </a>
              </div>
            </div>
          </Card>
        )}

        <Card className="p-4 space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <Button onClick={requestLocation} disabled={loading} className="gap-2">
              {loading ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <LocateFixed className="size-4" />
              )}
              {loading ? "جاري تحديد موقعك..." : loc ? "تحديث موقعي" : "📍 حدد موقعي"}
            </Button>
            <Button
              onClick={() => shareLocation("share", "me")}
              className="gap-2 bg-emerald-600 hover:bg-emerald-700"
            >
              <Share2 className="size-4" /> شارك موقعي
            </Button>
            <Button onClick={() => shareLocation("copy", "me")} variant="outline" className="gap-2">
              <Link2 className="size-4" /> نسخ الرابط
            </Button>
            {loc && (
              <Badge variant="outline" className="text-xs">
                {loc.lat.toFixed(4)}, {loc.lng.toFixed(4)}
              </Badge>
            )}
            {points.length > 0 && (
              <Badge variant="secondary" className="text-xs">
                {points.length} محطة قريبة
              </Badge>
            )}
          </div>

          <div className="rounded-lg border border-dashed border-primary/40 bg-primary/5 p-3 space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <Button
                size="sm"
                variant={pickMode ? "default" : "outline"}
                onClick={() => {
                  setPickMode((v) => !v);
                  if (!pickMode) toast.info("اضغط على أي مكان بالخريطة لتحديده");
                }}
                className="gap-2"
              >
                <MousePointerClick className="size-4" />
                {pickMode ? "إلغاء التحديد" : "🎯 اختر مكان من الخريطة"}
              </Button>
              {pickedPoint && (
                <Badge variant="outline" className="text-xs">
                  📌 {pickedPoint.lat.toFixed(4)}, {pickedPoint.lng.toFixed(4)}
                </Badge>
              )}
            </div>
            {pickedPoint && (
              <div className="flex flex-wrap items-center gap-2">
                <Input
                  value={placeLabel}
                  onChange={(e) => setPlaceLabel(e.target.value)}
                  placeholder="اسم المكان (مثل: البيت، المقهى، نقطة لقاء)"
                  className="max-w-xs h-9 text-sm"
                />
                <Button
                  size="sm"
                  onClick={() => shareLocation("share", "picked")}
                  className="gap-1 bg-emerald-600 hover:bg-emerald-700"
                >
                  <Share2 className="size-4" /> شارك المكان
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => shareLocation("copy", "picked")}
                  className="gap-1"
                >
                  <Link2 className="size-4" /> نسخ الرابط
                </Button>
              </div>
            )}
          </div>

          {error && (
            <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
              {error}
            </p>
          )}
          <p className="text-xs text-muted-foreground">
            كل شيء يحدث في متصفحك — لا تتبع لحظي ولا تخزين على الخادم. شارك الرابط مع من تريد ليرى
            المكان وأقرب محطات الوصول إليه.
          </p>
        </Card>

        <Card className="overflow-hidden p-0">
          <LazyTransitMap
            points={mapPoints}
            userLocation={loc}
            defaultCenter={
              loc ??
              (sharedPin
                ? { lat: sharedPin.lat, lng: sharedPin.lng }
                : { lat: 30.0444, lng: 31.2357 })
            }
            height={420}
            onMapClick={
              pickMode
                ? (c) => {
                    setPickedPoint(c);
                    setPickMode(false);
                    toast.success("تم تحديد النقطة — أضف اسماً وشارك");
                  }
                : undefined
            }
          />
        </Card>

        {points.length > 0 && (
          <section className="space-y-3">
            <h2 className="flex items-center gap-2 text-lg font-bold">
              <MapPin className="size-5" /> القائمة ({points.length})
            </h2>
            <div className="grid gap-2 sm:grid-cols-2">
              {points.map((p) => (
                <Card key={p.id} className="flex items-center justify-between p-3">
                  <div className="min-w-0">
                    <p className="truncate font-medium">{p.name}</p>
                    {p.type && <span className="text-xs text-muted-foreground">{p.type}</span>}
                  </div>
                  <Badge variant="outline" className="shrink-0 text-xs">
                    {p.distanceKm < 1
                      ? `${Math.round(p.distanceKm * 1000)} م`
                      : `${p.distanceKm.toFixed(1)} كم`}
                  </Badge>
                </Card>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
