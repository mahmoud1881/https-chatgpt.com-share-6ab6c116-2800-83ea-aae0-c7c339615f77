import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { AdminPageShell } from "@/components/admin/AdminPageShell";
import {
  listAdminRouteRequests,
  countAdminRouteRequests,
  moderateRouteRequest,
  type ModerateRouteRequestPayload,
} from "@/lib/admin-route-requests.functions";

export const Route = createFileRoute("/admin/route-requests")({
  head: () => ({
    meta: [{ title: "طلبات الرحلات — المراجعة | Tareeq" }],
  }),
  component: RouteRequestsAdminPage,
});

type Status = "pending" | "under_review" | "duplicate" | "published" | "rejected";
const STATUS_LABELS: Record<Status, string> = {
  pending: "قيد الانتظار",
  under_review: "تحت المراجعة",
  duplicate: "مكرر",
  published: "منشور",
  rejected: "مرفوض",
};

type Row = {
  id: string;
  from_text: string;
  to_text: string;
  area_hint: string | null;
  details: string | null;
  status: Status;
  source: string;
  locale: string;
  hit_count: number;
  created_at: string;
  updated_at: string;
  duplicate_of: string | null;
  linked_route_id: string | null;
  internal_note: string | null;
  reviewed_at: string | null;
};

function fmt(d: string): string {
  try {
    return new Date(d).toLocaleString("ar-EG", {
      dateStyle: "short",
      timeStyle: "short",
    });
  } catch {
    return d;
  }
}

function RouteRequestsAdminPage() {
  const [status, setStatus] = useState<Status | "all">("pending");
  const [q, setQ] = useState("");
  const qc = useQueryClient();

  const listFn = useServerFn(listAdminRouteRequests);
  const countFn = useServerFn(countAdminRouteRequests);
  const moderateFn = useServerFn(moderateRouteRequest);

  const listQ = useQuery({
    queryKey: ["admin", "route_requests", "list", status, q],
    queryFn: () => listFn({ data: { status, q: q || null, limit: 100 } }) as Promise<Row[]>,
    staleTime: 15_000,
  });

  const countQ = useQuery({
    queryKey: ["admin", "route_requests", "counts"],
    queryFn: () => countFn({}) as Promise<Record<string, number>>,
    staleTime: 30_000,
  });

  // Synchronous lock closes the double-click window before React Query's
  // isPending state has had a chance to re-render the controls. It is released
  // only after the mutation settles, so one UI gesture can create at most one
  // moderation request. Server-side authorization remains the final boundary.
  const mutationLockRef = useRef(false);
  const mutation = useMutation({
    mutationFn: (payload: ModerateRouteRequestPayload) =>
      moderateFn({ data: payload }) as Promise<{ ok: true }>,
    onSuccess: (_res, vars) => {
      toast.success("تم التنفيذ.");
      qc.invalidateQueries({ queryKey: ["admin", "route_requests"] });
      if (vars.action === "mark_duplicate") toast.info("تم دمج العدّاد في الطلب الهدف.");
    },
    onError: (e: unknown) => {
      const msg = e instanceof Error ? e.message : String(e);
      if (msg.includes("linked_route_required")) {
        toast.error("لازم تربطه برحلة قبل ما تحدده كمنشور.");
      } else if (msg.includes("forbidden")) {
        toast.error("غير مصرّح.");
      } else {
        toast.error("تعذّر تنفيذ الإجراء.");
      }
    },
    onSettled: () => {
      mutationLockRef.current = false;
    },
  });

  const submitMutation = (payload: ModerateRouteRequestPayload) => {
    if (mutationLockRef.current) return;
    mutationLockRef.current = true;
    mutation.mutate(payload);
  };

  const rows = listQ.data ?? [];
  const counts = countQ.data ?? {};

  return (
    <AdminPageShell>
      <div className="mx-auto max-w-6xl px-4 pt-6">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h1 className="text-2xl font-bold">طلبات الرحلات — المراجعة</h1>
            <p className="text-xs text-muted-foreground">
              مراجعة يدوية فقط. لا نشر تلقائي ولا إنشاء رحلات تلقائيًا من نص المستخدم.
            </p>
          </div>
          <Link to="/admin/data-health" className="text-xs text-primary underline">
            → لوحة الإدارة
          </Link>
        </div>

        {/* Status tabs */}
        <div className="mb-3 flex flex-wrap gap-2">
          {(["pending", "under_review", "duplicate", "published", "rejected", "all"] as const).map(
            (s) => {
              const active = status === s;
              const label = s === "all" ? "الكل" : STATUS_LABELS[s];
              const c = s === "all" ? undefined : counts[s];
              return (
                <button
                  key={s}
                  onClick={() => setStatus(s)}
                  className={`rounded-full border px-3 py-1 text-xs font-semibold ${
                    active
                      ? "border-emerald-600 bg-emerald-600 text-white"
                      : "border-muted bg-card text-foreground hover:bg-muted"
                  }`}
                >
                  {label}
                  {typeof c === "number" && (
                    <span className={`ms-1.5 ${active ? "opacity-90" : "text-muted-foreground"}`}>
                      ({c})
                    </span>
                  )}
                </button>
              );
            },
          )}
        </div>

        <div className="mb-3">
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="ابحث في من / إلى / المنطقة…"
            className="w-full max-w-sm rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:border-emerald-500"
          />
        </div>

        {listQ.isLoading && <p className="text-sm text-muted-foreground">جاري التحميل…</p>}
        {listQ.isError && (
          <p className="text-sm text-red-700">تعذّر تحميل الطلبات. تأكد من صلاحيات الأدمن.</p>
        )}

        {!listQ.isLoading && rows.length === 0 && (
          <p className="rounded-xl border border-dashed bg-card p-4 text-sm text-muted-foreground">
            لا يوجد طلبات في هذه الفئة.
          </p>
        )}

        <ul className="space-y-3">
          {rows.map((r) => (
            <RequestCard
              key={r.id}
              row={r}
              busy={mutation.isPending}
              onAction={submitMutation}
            />
          ))}
        </ul>
      </div>
    </AdminPageShell>
  );
}

function RequestCard({
  row,
  busy,
  onAction,
}: {
  row: Row;
  busy: boolean;
  onAction: (payload: ModerateRouteRequestPayload) => void;
}) {
  const [openMerge, setOpenMerge] = useState(false);
  const [openLink, setOpenLink] = useState(false);
  const [openReject, setOpenReject] = useState(false);
  const [targetId, setTargetId] = useState("");
  const [routeId, setRouteId] = useState("");
  const [reason, setReason] = useState("");

  const statusColor = useMemo(() => {
    switch (row.status) {
      case "pending":
        return "bg-amber-100 text-amber-900 border-amber-200";
      case "under_review":
        return "bg-blue-100 text-blue-900 border-blue-200";
      case "duplicate":
        return "bg-zinc-100 text-zinc-800 border-zinc-200";
      case "published":
        return "bg-emerald-100 text-emerald-900 border-emerald-200";
      case "rejected":
        return "bg-red-100 text-red-900 border-red-200";
    }
  }, [row.status]);

  return (
    <li className="rounded-xl border bg-card p-4">
      <div className="mb-2 flex flex-wrap items-start justify-between gap-2">
        <div>
          <p className="text-base font-bold text-zinc-900">
            {row.from_text} <span className="text-muted-foreground">←</span> {row.to_text}
          </p>
          <p className="mt-0.5 text-xs text-muted-foreground">
            {row.area_hint ? `المنطقة: ${row.area_hint} · ` : ""}
            {row.hit_count > 1 ? `عدد الطلبات: ${row.hit_count} · ` : ""}
            من {fmt(row.created_at)} إلى {fmt(row.updated_at)}
          </p>
        </div>
        <span
          className={`rounded-full border px-2 py-0.5 text-[11px] font-semibold ${statusColor}`}
        >
          {STATUS_LABELS[row.status]}
        </span>
      </div>

      {row.details && (
        <p className="mb-2 whitespace-pre-wrap rounded-lg bg-muted/50 p-2 text-xs text-zinc-800">
          {row.details}
        </p>
      )}

      <div className="mb-2 flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
        <span>المصدر: {row.source}</span>
        <span>اللغة: {row.locale}</span>
        {row.linked_route_id && <span>مربوط برحلة: {row.linked_route_id.slice(0, 8)}</span>}
        {row.duplicate_of && <span>مكرّر لـ: {row.duplicate_of.slice(0, 8)}</span>}
        {row.reviewed_at && <span>آخر مراجعة: {fmt(row.reviewed_at)}</span>}
      </div>

      {row.internal_note && (
        <p className="mb-2 rounded-lg border border-red-100 bg-red-50 p-2 text-xs text-red-900">
          ملاحظة داخلية: {row.internal_note}
        </p>
      )}

      <div className="flex flex-wrap gap-2">
        {row.status !== "under_review" && (
          <button
            disabled={busy}
            onClick={() => onAction({ action: "set_under_review", id: row.id })}
            className="rounded-full border border-blue-200 bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-800 hover:bg-blue-100 disabled:opacity-60"
          >
            تحت المراجعة
          </button>
        )}
        <button
          disabled={busy}
          onClick={() => setOpenMerge((v) => !v)}
          className="rounded-full border px-3 py-1 text-xs font-semibold hover:bg-muted disabled:opacity-60"
        >
          دمج كمكرر…
        </button>
        <button
          disabled={busy}
          onClick={() => setOpenLink((v) => !v)}
          className="rounded-full border px-3 py-1 text-xs font-semibold hover:bg-muted disabled:opacity-60"
        >
          ربط برحلة…
        </button>
        {row.linked_route_id && (
          <button
            disabled={busy}
            onClick={() => onAction({ action: "mark_published", id: row.id })}
            className="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-800 hover:bg-emerald-100 disabled:opacity-60"
          >
            تحديد كمنشور
          </button>
        )}
        <button
          disabled={busy}
          onClick={() => setOpenReject((v) => !v)}
          className="rounded-full border border-red-200 bg-red-50 px-3 py-1 text-xs font-semibold text-red-800 hover:bg-red-100 disabled:opacity-60"
        >
          رفض…
        </button>
        {row.status !== "pending" && (
          <button
            disabled={busy}
            onClick={() => onAction({ action: "mark_pending", id: row.id })}
            className="rounded-full border px-3 py-1 text-xs text-muted-foreground hover:bg-muted disabled:opacity-60"
          >
            إرجاع لقيد الانتظار
          </button>
        )}
      </div>

      {openMerge && (
        <InlineForm
          label="ID الطلب الهدف (سيحتفظ بالعداد المُجمَّع):"
          value={targetId}
          onChange={setTargetId}
          onSubmit={() => {
            if (!targetId) return;
            onAction({ action: "mark_duplicate", id: row.id, target_id: targetId.trim() });
            setOpenMerge(false);
            setTargetId("");
          }}
          onCancel={() => setOpenMerge(false)}
        />
      )}
      {openLink && (
        <InlineForm
          label="ID الرحلة الموجودة (public.routes.id):"
          value={routeId}
          onChange={setRouteId}
          onSubmit={() => {
            if (!routeId) return;
            onAction({ action: "link_route", id: row.id, route_id: routeId.trim() });
            setOpenLink(false);
            setRouteId("");
          }}
          onCancel={() => setOpenLink(false)}
        />
      )}
      {openReject && (
        <InlineForm
          label="سبب الرفض (داخلي، لا يظهر للمستخدم):"
          value={reason}
          onChange={setReason}
          textarea
          onSubmit={() => {
            if (!reason.trim()) return;
            onAction({ action: "reject", id: row.id, reason: reason.trim() });
            setOpenReject(false);
            setReason("");
          }}
          onCancel={() => setOpenReject(false)}
        />
      )}
    </li>
  );
}

function InlineForm({
  label,
  value,
  onChange,
  onSubmit,
  onCancel,
  textarea,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  onSubmit: () => void;
  onCancel: () => void;
  textarea?: boolean;
}) {
  return (
    <div className="mt-2 rounded-lg border border-dashed bg-background p-3">
      <label className="mb-1 block text-xs font-semibold">{label}</label>
      {textarea ? (
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value.slice(0, 300))}
          maxLength={300}
          rows={2}
          className="w-full rounded border bg-background px-2 py-1 text-sm outline-none focus:border-emerald-500"
        />
      ) : (
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full rounded border bg-background px-2 py-1 text-sm outline-none focus:border-emerald-500"
        />
      )}
      <div className="mt-2 flex gap-2">
        <button
          type="button"
          onClick={onSubmit}
          className="rounded-full bg-emerald-600 px-3 py-1 text-xs font-semibold text-white hover:bg-emerald-700"
        >
          تنفيذ
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="rounded-full border px-3 py-1 text-xs hover:bg-muted"
        >
          إلغاء
        </button>
      </div>
    </div>
  );
}
