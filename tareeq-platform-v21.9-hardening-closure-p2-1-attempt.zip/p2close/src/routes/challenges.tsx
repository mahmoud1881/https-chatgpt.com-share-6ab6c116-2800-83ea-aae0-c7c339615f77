import { createFileRoute, Link } from "@tanstack/react-router";
import { usePublishSnapshot } from "@/hooks/use-publish-snapshot";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AuthGateLoading } from "@/components/AuthGateLoading";
import { useRequireAuth } from "@/hooks/useRequireAuth";

import {
  Target,
  Sparkles,
  Users,
  CheckCircle2,
  ShieldCheck,
  ArrowRight,
  Award,
} from "lucide-react";

type Challenge = {
  title: string;
  description: string;
  points: number;
  badge: string;
  participants: number;
  completed: number;
};

const CHALLENGES: Challenge[] = [
  {
    title: "5 أحياء في يوم",
    description: "اقطع 5 أحياء مختلفة في القاهرة في يوم واحد",
    points: 200,
    badge: "صائد المدن",
    participants: 0,
    completed: 0,
  },
  {
    title: "بطل الميكروباص",
    description: "اركب 10 ميكروباصات مختلفة في أسبوع",
    points: 300,
    badge: "ملك الميكروباص",
    participants: 0,
    completed: 0,
  },
  {
    title: "صائد الزحمة الصباحي",
    description: "ابعت 5 تنبيهات زحمة دقيقة قبل الساعة 9 الصبح",
    points: 150,
    badge: "عين الصباح",
    participants: 0,
    completed: 0,
  },
];

const AI_CHALLENGES = [
  "اكتشف خط جديد لم تجرّبه — وابعت تقييم له بعد رحلتك.",
  "ساعد 3 مسافرين تايهين في محطة المترو اللي بتنزل فيها.",
  "اكتشف مسارًا جديدًا وشارك ملاحظاتك عنه.",
  "ابعت تنبيه دقيق عن محطة جديدة مش موجودة في الخريطة.",
  "اقطع طريق بدون أوبر/إن دريفر — وشارك قصة الرحلة.",
];

export const Route = createFileRoute("/challenges")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "تحديات أسبوعية — اربح شارات" },
      {
        name: "description",
        content: "تحدّيات حقيقية بالـ GPS — أكملها واربح شارات ونقاط وشارك إنجازك.",
      },
      { property: "og:title", content: "🎯 تحديات أسبوعية" },
      {
        property: "og:description",
        content: "تحدّيات حقيقية بالـ GPS — اربح شارات ونقاط.",
      },
    ],
  }),
  component: ChallengesRoute,
});

/** بوابة استخدام: يتطلب تسجيل دخول قبل عرض هذه الصفحة (مش مجرد تصفح). */
function ChallengesRoute() {
  const authStatus = useRequireAuth();
  if (authStatus !== "authenticated") return <AuthGateLoading />;
  return <ChallengesPage />;
}

function ChallengesPage() {
  usePublishSnapshot({
    id: "eg:challenges",
    source: "تحديات المجتمع",
    title: "تحديات فعالة",
    summary: "شارك في تحديات وفّر واكسب نقاط وشارات",
    category: "community",
    href: "/challenges",
  });
  const [aiChallenge, setAiChallenge] = useState<string | null>(null);

  const generate = () => {
    const idx = Math.floor(Math.random() * AI_CHALLENGES.length);
    setAiChallenge(AI_CHALLENGES[idx]);
  };

  return (
    <div dir="rtl" className="min-h-screen bg-background text-foreground">
      <header className="border-b">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
          <Link to="/" className="text-sm text-muted-foreground hover:underline">
            ← الرئيسية
          </Link>
          <h1 className="text-lg font-bold">تحديات أسبوعية</h1>
          <div className="w-16" />
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-10">
        <section className="mb-8 text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
            <Target className="size-4" />
            اربح شارات
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight md:text-4xl">🎯 اقبل التحدي</h2>
          <p className="mt-2 text-muted-foreground">
            تحدّيات حقيقية بالـ GPS — أكملها وشارك إنجازك على السوشيال
          </p>
        </section>

        {/* AI Challenge */}
        <Card className="mb-8 border-violet-500/30 bg-gradient-to-br from-violet-500/10 to-fuchsia-500/5 p-6">
          <div className="flex items-start gap-3">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-full bg-violet-500/20 text-violet-600">
              <Sparkles className="size-5" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-bold">تحدي شخصي مولّد بالذكاء</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                {aiChallenge ?? "اضغط للحصول على تحدي مخصص لك"}
              </p>
              <Button onClick={generate} className="mt-4 gap-2">
                <Sparkles className="size-4" />
                {aiChallenge ? "ولّد تاني" : "ولّد"}
              </Button>
            </div>
          </div>
        </Card>

        {/* Challenge list */}
        <div className="grid gap-4 md:grid-cols-3">
          {CHALLENGES.map((c) => (
            <Card key={c.title} className="flex flex-col p-5">
              <h3 className="text-lg font-bold">{c.title}</h3>
              <p className="mt-1 flex-1 text-sm text-muted-foreground">{c.description}</p>

              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-3xl font-extrabold text-primary">{c.points}</span>
                <span className="text-sm text-muted-foreground">نقطة</span>
              </div>

              <div className="mt-2 flex items-center gap-1.5 text-sm">
                <Award className="size-4 text-amber-500" />
                <span>
                  شارة: <span className="font-semibold">{c.badge}</span>
                </span>
              </div>

              <div className="mt-3 flex gap-2">
                <Badge variant="secondary" className="gap-1">
                  <Users className="size-3" />
                  {c.participants} مشارك
                </Badge>
                <Badge variant="secondary" className="gap-1">
                  <CheckCircle2 className="size-3" />
                  {c.completed} أكمل
                </Badge>
              </div>

              <Button className="mt-5 w-full" disabled aria-disabled="true" title="التحديات قيد الإعداد">ابدأ التحدي — قريباً</Button>
            </Card>
          ))}
        </div>

        <p className="mt-10 flex items-center justify-center gap-1 text-xs text-muted-foreground">
          <ShieldCheck className="size-3.5" />
          نحترم خصوصيتك
        </p>

        {/* Privacy consent */}
        <Card className="mt-6 p-5">
          <p className="mb-4 text-sm text-muted-foreground">
            نستخدم بيانات الموقع وملفات تعريف الارتباط لتحسين دقة الرحلات والمحطات.{" "}
            <Link to="/privacy" className="underline">
              سياسة الخصوصية
            </Link>{" "}
            ·{" "}
            <Link to="/terms" className="underline">
              الشروط
            </Link>
          </p>
          <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
            <Button variant="outline" size="sm" onClick={() => { localStorage.setItem("tareeq:consent", "essential"); }}>
              الأساسي فقط
            </Button>
            <Button size="sm" onClick={() => { localStorage.setItem("tareeq:consent", "all"); }}>موافق على الكل</Button>
          </div>
        </Card>

        <div className="mt-8 text-center">
          <Link to="/">
            <Button variant="ghost" className="gap-1">
              العودة للرئيسية
              <ArrowRight className="size-4 rotate-180" />
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
