import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { AdminPageShell } from "@/components/admin/AdminPageShell";
import { toast } from "sonner";
import {
  importEgyptFile,
  rollbackEgyptFile,
  getEgyptImportStatus,
  generateStopAliasesFn,
  listStopsNeedingAreaFn,
  patchStopAreaCityFn,
  listStopsNeedingCoordsFn,
  patchStopCoordsFn,
  logGeocodeFailureFn,
  clearGeocodeFailuresFn,
  syncTrainsToRoutesFn,
} from "@/lib/route-planner/import-eg.functions";
import {
  Loader2,
  Upload,
  Trash2,
  RefreshCw,
  Sparkles,
  MapPin,
  TrainFront,
  Compass,
  Eraser,
} from "lucide-react";

import { StatCard } from "@/components/admin/StatCard";

export const Route = createFileRoute("/admin/import-eg")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "استيراد بيانات مصر — Tareeq Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: ImportEgyptPage,
});

type FileId =
  | "cairo-stations"
  | "metro-stations"
  | "eg-governorate-stations"
  | "eg-informal-stops"
  | "egypt-stations"
  | "trains-stations"
  | "cairo-bus-lines"
  | "cairo-minibus-lines"
  | "governorate-bus-lines"
  | "microbus-lines"
  | "trains-routes"
  | "transit-routes"
  | "brt"
  | "pdf-bus-lines";

type Status = Awaited<ReturnType<typeof getEgyptImportStatus>>;

const FILES: Array<{ id: FileId; label: string; kind: "stops" | "routes"; hint: string }> = [
  { id: "metro-stations", label: "محطات المترو", kind: "stops", hint: "89 محطة، 5 خطوط" },
  { id: "cairo-stations", label: "محطات القاهرة الكبرى", kind: "stops", hint: "134 محطة رسمية" },
  {
    id: "eg-governorate-stations",
    label: "محطات المحافظات",
    kind: "stops",
    hint: "418 موقف رسمي في 24 محافظة",
  },
  {
    id: "eg-informal-stops",
    label: "المواقف العشوائية",
    kind: "stops",
    hint: "156 موقف عشوائي (27 محافظة)",
  },
  { id: "egypt-stations", label: "محطات مصر (متوسط)", kind: "stops", hint: "قائمة محطات موسّعة" },
  { id: "trains-stations", label: "محطات القطار", kind: "stops", hint: "429 محطة سكة حديد" },
  {
    id: "brt",
    label: "الأتوبيس الترددي (BRT)",
    kind: "routes",
    hint: "27 محطة + مسار الطريق الدائري، مع أسماء المناطق كـ aliases",
  },
  {
    id: "cairo-bus-lines",
    label: "خطوط باص القاهرة",
    kind: "routes",
    hint: "1194 خط — محطات وسطى من نص الـ route",
  },
  {
    id: "cairo-minibus-lines",
    label: "خطوط ميني باص القاهرة",
    kind: "routes",
    hint: "337 خط — محطات وسطى من نص الـ route",
  },
  {
    id: "governorate-bus-lines",
    label: "خطوط باص المحافظات",
    kind: "routes",
    hint: "388 خط بمحطات وسطى",
  },
  {
    id: "microbus-lines",
    label: "خطوط الميكروباص",
    kind: "routes",
    hint: "929 خط — 16% بمحطات وسطى",
  },
  { id: "pdf-bus-lines", label: "خطوط باص من PDF", kind: "routes", hint: "239 خط بمحطات وسطى" },
  { id: "trains-routes", label: "مسارات القطار", kind: "routes", hint: "18 مسار" },
  {
    id: "transit-routes",
    label: "transit-routes (Cairo)",
    kind: "routes",
    hint: "1117 خط — محطات وسطى غير موثوقة",
  },
];

function ImportEgyptPage() {
  const navigate = useNavigate();
  const [status, setStatus] = useState<Status | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const runImport = useServerFn(importEgyptFile);
  const runRollback = useServerFn(rollbackEgyptFile);
  const runStatus = useServerFn(getEgyptImportStatus);
  const runAliases = useServerFn(generateStopAliasesFn);
  const runListNeedArea = useServerFn(listStopsNeedingAreaFn);
  const runPatchArea = useServerFn(patchStopAreaCityFn);
  const runListNeedCoords = useServerFn(listStopsNeedingCoordsFn);
  const runPatchCoords = useServerFn(patchStopCoordsFn);
  const runLogFailure = useServerFn(logGeocodeFailureFn);
  const runClearFailures = useServerFn(clearGeocodeFailuresFn);
  const runSyncTrains = useServerFn(syncTrainsToRoutesFn);
  useEffect(() => {
    (async () => {
      await refresh();
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function refresh() {
    try {
      const s = await runStatus();
      setStatus(s);
    } catch (e) {
      toast.error(`فشل تحميل الحالة: ${(e as Error).message}`);
    }
  }

  async function doImport(file: FileId) {
    setBusy(`import:${file}`);
    try {
      const r = await runImport({ data: { file } });
      toast.success(
        `استيراد ${file}: ${r.stops} محطة، ${r.routes} خط، ${r.routeStops} ربط (${(r.durationMs / 1000).toFixed(1)}s)`,
      );
      await refresh();
    } catch (e) {
      toast.error(`فشل الاستيراد: ${(e as Error).message}`);
    } finally {
      setBusy(null);
    }
  }

  async function doRollback(file: FileId) {
    if (!confirm(`حذف كل بيانات "${file}" من قاعدة البيانات؟ (الملف الأصلي لا يتأثر)`)) return;
    setBusy(`rollback:${file}`);
    try {
      const r = await runRollback({ data: { file } });
      const keptMsg = r.stopsKept > 0 ? ` (تم الإبقاء على ${r.stopsKept} محطة مشتركة)` : "";
      toast.success(`حذف ${file}: ${r.routesDeleted} خط، ${r.stopsDeleted} محطة${keptMsg}`);
      await refresh();
    } catch (e) {
      toast.error(`فشل الحذف: ${(e as Error).message}`);
    } finally {
      setBusy(null);
    }
  }

  async function doAliases() {
    setBusy(`aliases`);
    try {
      const r = await runAliases();
      toast.success(
        `توليد المرادفات: ${r.aliasesInserted} مرادف من ${r.stops} محطة (${(r.durationMs / 1000).toFixed(1)}s)`,
      );
      await refresh();
    } catch (e) {
      toast.error(`فشل توليد المرادفات: ${(e as Error).message}`);
    } finally {
      setBusy(null);
    }
  }

  async function doGeocode() {
    setBusy(`geocode`);
    let totalUpdated = 0,
      totalProcessed = 0,
      totalErrors = 0,
      totalSkipped = 0,
      remaining = 0;
    const UA_HEADERS = { Accept: "application/json" } as const;
    type Addr = {
      neighbourhood?: string;
      suburb?: string;
      quarter?: string;
      city_district?: string;
      district?: string;
      city?: string;
      town?: string;
      village?: string;
      municipality?: string;
      county?: string;
    };
    const pickArea = (a: Addr) =>
      a.neighbourhood || a.suburb || a.quarter || a.city_district || a.district || null;
    const pickCity = (a: Addr) =>
      a.city || a.town || a.village || a.municipality || a.county || null;
    const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

    try {
      // Loop until the queue is drained. No hard batch cap — the loop stops
      // only when the server reports zero remaining rows.
      let consecutiveEmpty = 0;
      while (consecutiveEmpty < 2) {
        const { rows, remaining: rem } = await runListNeedArea({ data: { limit: 100 } });
        remaining = rem;
        if (!rows.length) {
          consecutiveEmpty++;
          if (rem === 0) break;
          await sleep(1500);
          continue;
        }
        consecutiveEmpty = 0;
        for (const s of rows as Array<{
          id: string;
          latitude: number;
          longitude: number;
          city: string | null;
          area: string | null;
        }>) {
          totalProcessed++;
          let attempt = 0;
          while (attempt < 3) {
            try {
              const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${s.latitude}&lon=${s.longitude}&accept-language=ar&zoom=16`;
              const res = await fetch(url, { headers: UA_HEADERS });
              if (!res.ok) {
                attempt++;
                await sleep(1500 * (attempt + 1));
                continue;
              }
              const j = (await res.json()) as {
                address?: Addr;
                name?: string;
                display_name?: string;
              };
              const addr = j.address ?? {};
              const fallbackArea = j.name || j.display_name?.split(",")[0]?.trim() || null;
              const area = pickArea(addr) || fallbackArea || pickCity(addr) || "غير محدد";
              const city = s.city && s.city.length > 0 ? null : pickCity(addr);
              const patch: { id: string; area?: string; city?: string } = { id: s.id };
              if (area && !s.area) patch.area = area;
              if (city) patch.city = city;
              if (patch.area || patch.city) {
                const patched = await runPatchArea({ data: patch });
                if (patched.updated > 0) totalUpdated++;
                else totalSkipped++;
              } else {
                totalSkipped++;
              }
              break;
            } catch {
              attempt++;
              await sleep(1500 * (attempt + 1));
            }
          }
          if (attempt >= 3) totalErrors++;
          if (totalProcessed % 5 === 0) {
            toast.message(
              `جارٍ التعبئة… ${totalUpdated} محدّثة · ${totalSkipped} متخطّاة · أخطاء ${totalErrors} · باقي ~${Math.max(0, remaining - totalUpdated - totalSkipped)}`,
              { id: "geocode" },
            );
          }
          await sleep(1100); // Nominatim: <= 1 req/sec
        }
      }
      toast.success(
        `اكتملت التعبئة: ${totalUpdated}/${totalProcessed} · متخطّى ${totalSkipped} · باقي ${Math.max(0, remaining - totalUpdated - totalSkipped)} · أخطاء ${totalErrors}`,
        { id: "geocode" },
      );
      await refresh();
    } catch (e) {
      toast.error(`توقف عند ${totalUpdated} محطة: ${(e as Error).message}`, { id: "geocode" });
    } finally {
      setBusy(null);
    }
  }

  async function doForwardGeocode() {
    setBusy(`fwd-geocode`);
    let totalUpdated = 0,
      totalProcessed = 0,
      totalErrors = 0,
      totalSkipped = 0,
      totalFailed = 0,
      remaining = 0;
    const UA_HEADERS = { Accept: "application/json" } as const;
    type Addr = {
      neighbourhood?: string;
      suburb?: string;
      quarter?: string;
      city_district?: string;
      district?: string;
      city?: string;
      town?: string;
      village?: string;
      municipality?: string;
      county?: string;
      state?: string;
    };
    const pickArea = (a: Addr) =>
      a.neighbourhood || a.suburb || a.quarter || a.city_district || a.district || null;
    const pickCity = (a: Addr) =>
      a.city || a.town || a.village || a.municipality || a.county || null;
    const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
    const normalizeDigits = (v: string) =>
      v.replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));
    // Egypt bounding box (west, south, east, north)
    const EG_BBOX = "24.7,22.0,36.9,31.7";

    // City viewbox cache (Photon/Nominatim result per city name)
    const cityBox = new Map<string, { lat: number; lon: number } | null>();
    const cityLookup = async (city: string): Promise<{ lat: number; lon: number } | null> => {
      const key = city.trim();
      if (!key) return null;
      if (cityBox.has(key)) return cityBox.get(key) ?? null;
      try {
        const u = `https://nominatim.openstreetmap.org/search?format=jsonv2&q=${encodeURIComponent(key + "، مصر")}&countrycodes=eg&limit=1&accept-language=ar`;
        const r = await fetch(u, { headers: UA_HEADERS });
        if (!r.ok) {
          cityBox.set(key, null);
          return null;
        }
        const arr = (await r.json()) as Array<{ lat: string; lon: string }>;
        const hit = arr[0];
        const v = hit ? { lat: Number(hit.lat), lon: Number(hit.lon) } : null;
        cityBox.set(key, v);
        await sleep(1100);
        return v;
      } catch {
        cityBox.set(key, null);
        return null;
      }
    };

    // Cleaner: only splits on strong separators (← , ،  /  \\). Keeps
    // Arabic words intact — avoids garbage like "اث الن مساكن".
    const cleanName = (v: string) =>
      normalizeDigits(v)
        .replace(/Mass transportation/gi, " ")
        .replace(/air conditioner/gi, " ")
        .replace(/رقم\s*الخط|المسار|المسـار/gi, " ")
        .replace(/[()[\]{}]/g, " ")
        .replace(/التجمعالأول/g, "التجمع الأول")
        .replace(/الجو\s+لف/g, "الجولف")
        .replace(/[.،؛;:]+$/g, " ")
        .replace(/\s+/g, " ")
        .trim();
    // Strips ANY leading numeric prefix (route numbers like "10", "100").
    const stripLeadingRouteNumber = (v: string) => v.replace(/^[\s)(-]*\d+[\s.-]+/, "").trim();
    const isJunk = (v: string) => {
      if (/رقم\s*الخط|المسار|المسـار|Mass transportation|air conditioner/i.test(v)) return true;
      const seps = (v.match(/[←]/g) ?? []).length;
      return seps >= 2;
    };

    // Haversine (km)
    const distKm = (a: { lat: number; lon: number }, b: { lat: number; lon: number }) => {
      const R = 6371,
        toRad = (x: number) => (x * Math.PI) / 180;
      const dLat = toRad(b.lat - a.lat),
        dLon = toRad(b.lon - a.lon);
      const s =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLon / 2) ** 2;
      return 2 * R * Math.asin(Math.sqrt(s));
    };

    const buildQueries = (s: {
      name_ar: string;
      name_en: string | null;
      city: string | null;
      area: string | null;
    }) => {
      if (isJunk(s.name_ar)) return [];
      const base = cleanName(s.name_ar);
      if (base.length < 2) return [];
      const withoutNumber = stripLeadingRouteNumber(base);
      const withoutPrefix = base.replace(/^(محطة|موقف|ميدان|كوبري|شارع)\s+/, "").trim();
      const city = s.city ? cleanName(s.city) : "";
      const area = s.area ? cleanName(s.area) : "";
      const context = [area, city].filter(Boolean).join(" ").trim();
      // Split only on strong route separators (← / \ |), NOT on _ or ،
      // (underscores appear inside real Arabic names in the source data).
      const parts = base
        .split(/[←/\\|]/)
        .map(cleanName)
        .filter((p) => p.length >= 2 && p.length <= 70);
      const candidates = [
        context && withoutPrefix ? `${withoutPrefix} ${context}` : "",
        city && withoutPrefix ? `${withoutPrefix}، ${city}` : "",
        withoutPrefix,
        withoutNumber,
        base,
        parts[0] && city ? `${parts[0]}، ${city}` : "",
        s.name_en ? cleanName(s.name_en) : "",
      ];
      return Array.from(
        new Set(candidates.map((q) => q.trim()).filter((q) => q.length >= 2 && q.length <= 90)),
      ).slice(0, 4);
    };

    // Photon (fast, no rate limit) → Nominatim fallback.
    type Hit = {
      lat: number;
      lon: number;
      addr?: Addr;
      source: "photon" | "nominatim";
      query: string;
    };
    const photonSearch = async (query: string): Promise<Hit | null> => {
      try {
        const u = `https://photon.komoot.io/api/?q=${encodeURIComponent(query)}&lang=ar&limit=3&osm_tag=!boundary`;
        const r = await fetch(u, { headers: UA_HEADERS });
        if (!r.ok) return null;
        const j = (await r.json()) as {
          features?: Array<{
            geometry?: { coordinates?: [number, number] };
            properties?: {
              countrycode?: string;
              country?: string;
              city?: string;
              state?: string;
              osm_key?: string;
            };
          }>;
        };
        for (const f of j.features ?? []) {
          const cc = f.properties?.countrycode?.toLowerCase();
          if (cc && cc !== "eg") continue;
          if (!cc && f.properties?.country && !/مصر|Egypt/i.test(f.properties.country)) continue;
          const c = f.geometry?.coordinates;
          if (!c || !Number.isFinite(c[0]) || !Number.isFinite(c[1])) continue;
          return {
            lat: c[1],
            lon: c[0],
            source: "photon",
            query,
            addr: { city: f.properties?.city, state: f.properties?.state },
          };
        }
        return null;
      } catch {
        return null;
      }
    };
    const nominatimSearch = async (query: string, viewbox?: string): Promise<Hit | null> => {
      try {
        const p = new URLSearchParams({
          format: "jsonv2",
          q: query,
          countrycodes: "eg",
          limit: "3",
          "accept-language": "ar",
          addressdetails: "1",
        });
        if (viewbox) {
          p.set("viewbox", viewbox);
          p.set("bounded", "1");
        }
        const r = await fetch(`https://nominatim.openstreetmap.org/search?${p.toString()}`, {
          headers: UA_HEADERS,
        });
        if (!r.ok) return null;
        const arr = (await r.json()) as Array<{
          lat: string;
          lon: string;
          address?: Addr;
          class?: string;
          type?: string;
        }>;
        for (const it of arr) {
          const lat = Number(it.lat),
            lon = Number(it.lon);
          if (!Number.isFinite(lat) || !Number.isFinite(lon)) continue;
          return { lat, lon, addr: it.address, source: "nominatim", query };
        }
        return null;
      } catch {
        return null;
      }
    };

    try {
      let afterId: string | undefined;
      while (true) {
        const { rows, remaining: rem } = await runListNeedCoords({ data: { limit: 100, afterId } });
        remaining = rem;
        if (!rows.length) break;
        for (const s of rows as Array<{
          id: string;
          name_ar: string;
          name_en: string | null;
          city: string | null;
          area: string | null;
        }>) {
          totalProcessed++;
          afterId = s.id;
          try {
            const queries = buildQueries(s);
            if (queries.length === 0) {
              totalSkipped++;
              await runLogFailure({
                data: { id: s.id, reason: "junk-name", lastQuery: s.name_ar.slice(0, 200) },
              });
              continue;
            }
            // City center for viewbox biasing + distance filter.
            const center = s.city ? await cityLookup(s.city) : null;
            let viewbox: string | undefined = EG_BBOX;
            if (center) {
              const d = 0.5; // ~55km box around city center
              viewbox = `${center.lon - d},${center.lat + d},${center.lon + d},${center.lat - d}`;
            }
            let hit: Hit | null = null;
            let triedQuery = "";
            for (const q of queries) {
              triedQuery = q;
              // Photon first (fast). Then Nominatim (authoritative).
              hit = await photonSearch(q);
              if (!hit) {
                await sleep(300);
                hit = await nominatimSearch(q, viewbox);
              }
              if (hit) {
                // Quality filter: reject hits far from expected city center.
                if (center) {
                  const km = distKm(center, { lat: hit.lat, lon: hit.lon });
                  if (km > 60) {
                    hit = null;
                    await sleep(1100);
                    continue;
                  }
                }
                break;
              }
              await sleep(1100);
            }
            if (!hit) {
              totalSkipped++;
              totalFailed++;
              await runLogFailure({
                data: { id: s.id, reason: "no-match", lastQuery: triedQuery.slice(0, 200) },
              });
              continue;
            }
            const addr = hit.addr ?? {};
            const area = s.area || pickArea(addr) || pickCity(addr) || undefined;
            const city = s.city || pickCity(addr) || undefined;
            const patched = await runPatchCoords({
              data: { id: s.id, latitude: hit.lat, longitude: hit.lon, area, city },
            });
            if (patched.updated > 0) totalUpdated++;
            else totalSkipped++;
          } catch (err) {
            totalErrors++;
            await runLogFailure({
              data: { id: s.id, reason: `error:${(err as Error).message}`.slice(0, 200) },
            }).catch(() => undefined);
            if (totalErrors % 10 === 0) await sleep(5000);
          }
          if (totalProcessed % 5 === 0) {
            toast.message(
              `جارٍ الجلب… ${totalUpdated} محدّثة · فشل ${totalFailed} · باقي ~${Math.max(0, remaining - totalUpdated - totalSkipped)}`,
              { id: "fwd-geocode" },
            );
          }
          await sleep(1100);
        }
      }

      const fresh = await runListNeedCoords({ data: { limit: 1 } });
      toast.success(
        `اكتملت الدورة: ${totalUpdated}/${totalProcessed} · فشل ${totalFailed} · باقي ${fresh.remaining} · أخطاء ${totalErrors}`,
        { id: "fwd-geocode" },
      );
      await refresh();
    } catch (e) {
      toast.error(`توقف عند ${totalUpdated} محطة: ${(e as Error).message}`, { id: "fwd-geocode" });
    } finally {
      setBusy(null);
    }
  }

  async function doClearFailures() {
    if (!confirm("مسح سجل الفشل حتى يعاد المحاولة على جميع المحطات؟")) return;
    setBusy("clear-fails");
    try {
      const r = await runClearFailures();
      toast.success(`تم مسح ${r.cleared} سجل فشل`);
      await refresh();
    } catch (e) {
      toast.error(`فشل المسح: ${(e as Error).message}`);
    } finally {
      setBusy(null);
    }
  }

  async function doSyncTrains() {
    setBusy(`sync-trains`);
    try {
      const r = await runSyncTrains();
      toast.success(
        `مزامنة القطارات: ${r.routes} خط · ${r.stops} محطة · ${r.routeStops} ربط (${(r.durationMs / 1000).toFixed(1)}s)`,
      );
      await refresh();
    } catch (e) {
      toast.error(`فشل مزامنة القطارات: ${(e as Error).message}`);
    } finally {
      setBusy(null);
    }
  }

  const stops = FILES.filter((f) => f.kind === "stops");
  const routes = FILES.filter((f) => f.kind === "routes");

  return (
    <AdminPageShell wrapperClassName="min-h-screen bg-slate-950 text-slate-100 p-4 pb-20">
      <div className="max-w-5xl mx-auto space-y-6">
        <header className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-2xl font-bold">استيراد بيانات مصر</h1>
            <p className="text-sm text-slate-400 mt-1">
              ينقل ملفات JSON إلى الجداول المهيكلة. لا يمسّ الواجهة الحالية.
            </p>
          </div>
          <button
            onClick={refresh}
            className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center gap-2 text-sm"
          >
            <RefreshCw className="w-4 h-4" /> تحديث
          </button>
        </header>

        {status && (
          <div className="grid grid-cols-3 gap-3">
            <StatCard label="المحطات" value={status.total.stops} tone="dark" />
            <StatCard label="الخطوط" value={status.total.routes} tone="dark" />
            <StatCard label="الروابط" value={status.total.routeStops} tone="dark" />
          </div>
        )}

        <Section
          title="المحطات (Stops)"
          items={stops}
          status={status}
          busy={busy}
          onImport={doImport}
          onRollback={doRollback}
        />
        <Section
          title="الخطوط (Routes)"
          items={routes}
          status={status}
          busy={busy}
          onImport={doImport}
          onRollback={doRollback}
        />

        <section className="space-y-2">
          <h2 className="text-lg font-semibold">إثراء البحث (Search enrichment)</h2>
          <div className="rounded-xl border border-slate-800 p-3 flex items-center justify-between gap-3 flex-wrap">
            <div className="min-w-0">
              <div className="font-medium">توليد مرادفات المحطات تلقائياً</div>
              <div className="text-xs text-slate-400">
                يستخرج متغيرات الاسم (إزالة "ميدان/شارع/محطة/كوبري…"، اختصار "التجمع الخامس ↔
                التجمع"، تقسيم الأسماء المركّبة) ويحفظها في <code>stop_aliases</code> — يفتح نتائج
                بحث فورية بدون بيانات خارجية.
              </div>
            </div>
            <button
              disabled={!!busy}
              onClick={doAliases}
              className="px-3 py-1.5 rounded-lg bg-violet-600 hover:bg-violet-500 disabled:opacity-50 text-sm flex items-center gap-1"
            >
              {busy === "aliases" ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Sparkles className="w-4 h-4" />
              )}
              توليد المرادفات
            </button>
          </div>
          <div className="rounded-xl border border-slate-800 p-3 flex items-center justify-between gap-3 flex-wrap">
            <div className="min-w-0">
              <div className="font-medium">تعبئة المنطقة (area) عبر الإحداثيات</div>
              <div className="text-xs text-slate-400">
                يستخدم OpenStreetMap Nominatim لعكس الإحداثيات إلى اسم الحي/المدينة للمحطات التي
                لديها lat/lng بدون area. يتخطّى السجلات المتعارضة أو التي تفشل مؤقتاً ويكمل تلقائياً
                حتى نهاية الدفعة.
              </div>
            </div>
            <button
              disabled={!!busy}
              onClick={doGeocode}
              className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-sm flex items-center gap-1"
            >
              {busy === "geocode" ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <MapPin className="w-4 h-4" />
              )}
              تعبئة المنطقة
            </button>
          </div>
          <div className="rounded-xl border border-slate-800 p-3 flex items-center justify-between gap-3 flex-wrap">
            <div className="min-w-0">
              <div className="font-medium">جلب الإحداثيات المفقودة (forward geocode)</div>
              <div className="text-xs text-slate-400">
                يبحث بالاسم في Photon ثم Nominatim مع تحديد نطاق حول مركز المدينة (viewbox) وفلترة
                النتائج بعيدة المسافة (&gt;60 كم). يسجّل المحاولات الفاشلة في{" "}
                <code>geocode_failures</code> ولا يعيدها لمدة 7 أيام لتوفير الحصة.
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                disabled={!!busy}
                onClick={doForwardGeocode}
                className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-sm flex items-center gap-1"
              >
                {busy === "fwd-geocode" ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Compass className="w-4 h-4" />
                )}
                جلب الإحداثيات
              </button>
              <button
                disabled={!!busy}
                onClick={doClearFailures}
                title="مسح سجل الفشل لإعادة المحاولة على الكل"
                className="px-2 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-sm flex items-center gap-1"
              >
                {busy === "clear-fails" ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Eraser className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>

          <div className="rounded-xl border border-slate-800 p-3 flex items-center justify-between gap-3 flex-wrap">
            <div className="min-w-0">
              <div className="font-medium">مزامنة القطارات إلى الخطوط الموحّدة</div>
              <div className="text-xs text-slate-400">
                ينسخ خطوط ومحطات القطار (٦ خطوط، ٢٠٣ محطة بترتيب كامل) إلى جدول <code>routes</code>{" "}
                و<code>route_stops</code> ليظهروا في البحث الموحّد مع كل المحطات الوسطى.
              </div>
            </div>
            <button
              disabled={!!busy}
              onClick={doSyncTrains}
              className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 disabled:opacity-50 text-sm flex items-center gap-1"
            >
              {busy === "sync-trains" ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <TrainFront className="w-4 h-4" />
              )}
              مزامنة القطارات
            </button>
          </div>
        </section>

        <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 text-sm text-amber-200">
          <strong>ملاحظة:</strong> استيراد الخطوط يحتاج المحطات ذات الصلة أن تكون مستوردة أولاً.
          الترتيب الموصى به: كل المحطات → ثم كل الخطوط → ثم توليد المرادفات.
        </div>
      </div>
    </AdminPageShell>
  );
}

function Section({
  title,
  items,
  status,
  busy,
  onImport,
  onRollback,
}: {
  title: string;
  items: typeof FILES;
  status: Status | null;
  busy: string | null;
  onImport: (f: FileId) => void;
  onRollback: (f: FileId) => void;
}) {
  const byFile = new Map((status?.byFile ?? []).map((r) => [r.file, r]));
  return (
    <section className="space-y-2">
      <h2 className="text-lg font-semibold">{title}</h2>
      <div className="rounded-xl border border-slate-800 divide-y divide-slate-800">
        {items.map((f) => {
          const row = byFile.get(f.id);
          const importing = busy === `import:${f.id}`;
          const rolling = busy === `rollback:${f.id}`;
          return (
            <div key={f.id} className="p-3 flex items-center justify-between gap-3 flex-wrap">
              <div className="min-w-0">
                <div className="font-medium">{f.label}</div>
                <div className="text-xs text-slate-400">{f.hint}</div>
                {row && (
                  <div className="text-xs text-emerald-400 mt-1">
                    في القاعدة: {row.stops} محطة، {row.routes} خط
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button
                  disabled={!!busy}
                  onClick={() => onImport(f.id)}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-sm flex items-center gap-1"
                >
                  {importing ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Upload className="w-4 h-4" />
                  )}
                  استيراد
                </button>
                {row && (row.stops > 0 || row.routes > 0) && (
                  <button
                    disabled={!!busy}
                    onClick={() => onRollback(f.id)}
                    className="px-3 py-1.5 rounded-lg bg-red-950 hover:bg-red-900 border border-red-800 disabled:opacity-50 text-sm flex items-center gap-1"
                  >
                    {rolling ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" />
                    )}
                    حذف
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
