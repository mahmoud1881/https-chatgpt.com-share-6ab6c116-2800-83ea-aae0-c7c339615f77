import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AlertTriangle, RefreshCw, Trash2, ArrowRight } from "lucide-react";
import {
  getRecentIncidents,
  clearIncidents,
  type StoredIncident,
} from "@/lib/data-service/monitoring";

export const Route = createFileRoute("/admin/health")({
  head: () => ({
    meta: [
      { title: "صحة النظام — لوحة الإدارة" },
      { name: "description", content: "آخر الحوادث ومعدل الفشل لكل مصدر بيانات." },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: HealthPage,
});

const KIND_LABEL: Record<string, string> = {
  api_error: "فشل API",
  api_timeout: "انتهاء المهلة",
  unexpected_zero: "عدّ صفري مفاجئ",
  cache_read_fail: "فشل قراءة الكاش",
  js_error: "خطأ JS",
};

const KIND_COLOR: Record<string, string> = {
  api_error: "bg-red-100 text-red-800 border-red-200",
  api_timeout: "bg-amber-100 text-amber-800 border-amber-200",
  unexpected_zero: "bg-orange-100 text-orange-800 border-orange-200",
  cache_read_fail: "bg-slate-100 text-slate-700 border-slate-200",
  js_error: "bg-rose-100 text-rose-800 border-rose-200",
};

function HealthPage() {
  const [items, setItems] = useState<StoredIncident[]>([]);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    setItems(getRecentIncidents());
  }, [tick]);

  const perSource = new Map<string, number>();
  for (const it of items) perSource.set(it.source, (perSource.get(it.source) ?? 0) + 1);
  const topSources = Array.from(perSource.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6);

  return (
    <div dir="rtl" className="mx-auto max-w-4xl px-4 py-8 space-y-6">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div>
          <Link
            to="/admin"
            className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
          >
            <ArrowRight className="size-3.5" /> لوحة الإدارة
          </Link>
          <h1 className="mt-1 flex items-center gap-2 text-2xl font-bold">
            <AlertTriangle className="size-6 text-amber-600" />
            صحة النظام
          </h1>
          <p className="text-xs text-muted-foreground mt-1">
            آخر {items.length} حادثة مُسجَّلة في هذه الجلسة. البيانات محلية — تُمسح مع إغلاق
            التبويب.
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setTick((t) => t + 1)}
            className="inline-flex items-center gap-1 rounded-lg border bg-card px-3 py-1.5 text-xs font-semibold hover:bg-accent"
          >
            <RefreshCw className="size-3.5" /> تحديث
          </button>
          <button
            onClick={() => {
              clearIncidents();
              setTick((t) => t + 1);
            }}
            className="inline-flex items-center gap-1 rounded-lg border border-red-200 bg-red-50 px-3 py-1.5 text-xs font-semibold text-red-700 hover:bg-red-100"
          >
            <Trash2 className="size-3.5" /> مسح
          </button>
        </div>
      </div>

      {topSources.length > 0 && (
        <section className="rounded-2xl border bg-card p-4">
          <h2 className="text-sm font-bold mb-3">أكثر المصادر فشلاً</h2>
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {topSources.map(([source, count]) => (
              <li
                key={source}
                className="flex items-center justify-between rounded-lg border bg-background px-3 py-2 text-sm"
              >
                <span className="truncate font-mono text-xs">{source}</span>
                <span className="shrink-0 rounded-full bg-red-100 px-2 py-0.5 text-xs font-bold text-red-700">
                  {count}
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}

      <section className="rounded-2xl border bg-card p-4">
        <h2 className="text-sm font-bold mb-3">سجل الحوادث</h2>
        {items.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">
            لا حوادث مسجّلة في هذه الجلسة — النظام يعمل بشكل طبيعي.
          </p>
        ) : (
          <ul className="divide-y">
            {items.map((it, i) => (
              <li key={i} className="py-2.5 space-y-1">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span
                    className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-semibold ${
                      KIND_COLOR[it.kind] ?? "bg-slate-100 text-slate-700 border-slate-200"
                    }`}
                  >
                    {KIND_LABEL[it.kind] ?? it.kind}
                  </span>
                  <time className="text-[11px] text-muted-foreground font-mono">
                    {new Date(it.at).toLocaleTimeString("ar-EG")}
                  </time>
                </div>
                <div className="text-xs font-mono text-slate-700">{it.source}</div>
                {it.message && <p className="text-xs text-muted-foreground">{it.message}</p>}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
