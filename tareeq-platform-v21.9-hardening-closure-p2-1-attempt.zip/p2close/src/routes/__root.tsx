import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  useRouterState,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import { Toaster } from "sonner";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { ErrorBoundary } from "../components/ErrorBoundary";
import { OfflineIndicator } from "../components/OfflineIndicator";
import { FloatingHomeButton } from "../components/FloatingHomeButton";
import { LazyGlobalSearchPalette } from "../components/LazyGlobalSearchPalette";
import { QaModeBanner } from "../components/QaModeBanner";
import { GrowthLoopsQaBanner } from "../components/growth/GrowthLoopsQaBanner";
import { useCanonicalRedirect } from "../hooks/useCanonicalRedirect";
import { useIdleBootstrap } from "../hooks/useIdleBootstrap";
import { useGlobalErrorReporting } from "../hooks/useGlobalErrorReporting";
import { SITE_BASE_URL as SITE_URL } from "../lib/seo/site";
// أداء: i18n يُحمَّل كسولاً من LangToggle عند أول تبديل لغة فعلي — لا حاجة للاستيراد هنا
import "../lib/pwa-register"; // Load PWA service worker registration logic

function NotFoundComponent() {
  return (
    <div dir="rtl" className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">الصفحة غير موجودة</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          الصفحة التي تبحث عنها غير متاحة أو تم نقلها.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            العودة للرئيسية
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: unknown; reset: () => void }) {
  // Log full details for developers/telemetry, but never surface raw
  // exception messages to end users — they can leak internal paths, SQL
  // fragments, or third-party library internals.
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    try {
      reportLovableError(error, { boundary: "tanstack_root_error_component" });
    } catch {
      /* reporting must never throw */
    }
  }, [error]);

  return (
    <div
      dir="rtl"
      role="alert"
      className="flex min-h-screen items-center justify-center bg-background px-4"
    >
      <div className="max-w-md text-center">
        <div
          className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-full bg-destructive/10 text-destructive text-xl font-bold"
          aria-hidden="true"
        >
          !
        </div>
        <h1 className="text-xl font-semibold tracking-tight text-foreground">تعذّر تحميل الصفحة</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          حدث خطأ غير متوقع. يمكنك إعادة المحاولة أو العودة إلى الصفحة الرئيسية.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              try {
                router.invalidate();
              } catch {
                /* ignore */
              }
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            إعادة المحاولة
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            العودة للرئيسية
          </a>
        </div>
      </div>
    </div>
  );
}

const SITE_NAME = "مواصلات مصر";
const SITE_TITLE = "مواصلات مصر — دليل خطوط ومواقف النقل العام";
const SITE_DESC =
  "دليل شامل لخطوط ومواقف النقل العام في كل محافظات مصر: مترو، أتوبيس، ميني باص، ميكروباص، BRT، قطار العاصمة، والسكة الحديد.";

// نفس نمط قراءة رابط Supabase المستخدم في src/integrations/supabase/client.ts:
// import.meta.env للمتصفح وقت البناء، وprocess.env كـ fallback لتنفيذ السيرفر (SSR).
// لا يوجد أي رابط مشروع Supabase مكتوب يدويًا هنا — القيمة تُقرأ من البيئة فقط،
// وإن لم تتوفر، لا تُضاف روابط preconnect/dns-prefetch لـ Supabase أصلًا.
function getSupabaseOrigin(): string | null {
  const url = import.meta.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
  if (!url) return null;
  try {
    return new URL(url).origin;
  } catch {
    return null;
  }
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => {
    const supabaseOrigin = getSupabaseOrigin();
    return {
      meta: [
        { charSet: "utf-8" },
        { name: "viewport", content: "width=device-width, initial-scale=1" },
        { name: "theme-color", content: "#0d4f53" },
        { title: SITE_TITLE },
        { name: "description", content: SITE_DESC },
        { name: "application-name", content: SITE_NAME },
        { name: "apple-mobile-web-app-title", content: SITE_NAME },
        { name: "apple-mobile-web-app-capable", content: "yes" },
        { name: "apple-mobile-web-app-status-bar-style", content: "default" },
        { property: "og:site_name", content: SITE_NAME },
        { property: "og:type", content: "website" },
        { property: "og:locale", content: "ar_EG" },
        { property: "og:title", content: SITE_TITLE },
        { property: "og:description", content: SITE_DESC },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:title", content: SITE_TITLE },
        { name: "twitter:description", content: SITE_DESC },
      ],
      links: [
        { rel: "stylesheet", href: appCss },
        { rel: "icon", href: "/favicon.ico", sizes: "any" },
        { rel: "icon", href: "/favicon.svg", type: "image/svg+xml" },
        { rel: "apple-touch-icon", href: "/apple-touch-icon.png", sizes: "180x180" },
        { rel: "manifest", href: "/api/manifest" },
        // Perf: DNS + TCP + TLS مبكرًا لمصادر البيانات الخارجية
        ...(supabaseOrigin
          ? [
              { rel: "preconnect", href: supabaseOrigin, crossOrigin: "anonymous" as const },
              { rel: "dns-prefetch", href: supabaseOrigin },
            ]
          : []),
        { rel: "dns-prefetch", href: "https://a.tile.openstreetmap.org" },
        { rel: "dns-prefetch", href: "https://b.tile.openstreetmap.org" },
        { rel: "dns-prefetch", href: "https://c.tile.openstreetmap.org" },
      ],
      scripts: [
        // Runs synchronously before first paint (blocking <head> script,
        // not a module import) so a returning EN/FR/ES/PT visitor's
        // <html> gets the correct dir/lang immediately. Without this, the
        // server always renders dir="rtl" (see RootShell below), and the
        // actual correction in src/lib/i18n.ts only runs once that module
        // executes on the client — after the browser has already painted
        // the RTL layout, causing a visible RTL→LTR flash/reflow for every
        // non-Arabic visitor on every page load. Mirrors the exact logic
        // of getInitialLang() in src/lib/lang-storage.ts; kept in sync
        // manually since this can't import that module (must be inline).
        {
          children: `(function(){try{var v=localStorage.getItem("app:lang");if(v&&v!=="ar"&&["en","fr","es","pt"].indexOf(v)!==-1){document.documentElement.lang=v;document.documentElement.dir="ltr";}}catch(e){}})();`,
        },
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebSite",
            name: SITE_NAME,
            alternateName: "Mawaslat Masr",
            url: SITE_URL,
            inLanguage: ["ar-EG", "ar-MA", "fr-MA", "en", "es"],
            description: SITE_DESC,
            potentialAction: {
              "@type": "SearchAction",
              target: `${SITE_URL}/explore?q={search_term_string}`,
              "query-input": "required name=search_term_string",
            },
          }),
        },
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Organization",
            name: SITE_NAME,
            url: SITE_URL,
            logo: `${SITE_URL}/icon-512.png`,
            sameAs: [`${SITE_URL}/`, `${SITE_URL}/ma`],
            areaServed: [
              { "@type": "Country", name: "Egypt" },
              { "@type": "Country", name: "Morocco" },
            ],
            description: SITE_DESC,
          }),
        },
      ],
    };
  },

  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

// ✅ تحسين #2: Route Transition Progress Bar
// يُظهر شريط تقدم أعلى الصفحة أثناء الانتقال بين المسارات.
// التأثير: يُعلم المستخدم أن شيئاً يحدث — يمنع الانطباع بأن التطبيق "مات".
// السلبي: لا شيء تقريباً — عبء ≈ 0.
function RouteProgressBar() {
  const isLoading = useRouterState({ select: (s) => s.isLoading });
  if (!isLoading) return null;
  return (
    <div className="fixed inset-x-0 top-0 z-[9999] h-1 overflow-hidden" aria-hidden="true">
      <div className="h-full animate-[routeProgress_1.5s_ease-in-out_infinite] bg-primary" />
    </div>
  );
}

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  useCanonicalRedirect();
  useIdleBootstrap(queryClient);
  useGlobalErrorReporting();

  useEffect(() => {
    // Growth Loops: capture ?ref= once. Safe to call unconditionally —
    // no-op when the URL has no ref, no DB writes, never throws.
    import("@/lib/growth/referral")
      .then((m) => m.captureReferralFromUrl())
      .catch(() => {
        /* progressive enhancement — ignore */
      });
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <RouteProgressBar />
      <SiteHeader />
      <ErrorBoundary boundary="root_outlet">
        {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
        <Outlet />
      </ErrorBoundary>
      <Toaster richColors position="top-center" closeButton dir="rtl" />
      <OfflineIndicator />
      <FloatingHomeButton />
      <LazyGlobalSearchPalette />
      <QaModeBanner />
      <GrowthLoopsQaBanner />
    </QueryClientProvider>
  );
}

const NAV_LINKS: ReadonlyArray<{
  to: "/" | "/metro" | "/trains" | "/brt" | "/stops" | "/navigate";
  label: string;
  exact?: boolean;
}> = [
  { to: "/", label: "الرئيسية", exact: true },
  { to: "/metro", label: "المترو" },
  { to: "/trains", label: "القطارات" },
  { to: "/brt", label: "BRT" },
  { to: "/stops", label: "المواقف" },
  { to: "/navigate", label: "التنقّل" },
];

function SiteHeader() {
  return (
    <header
      dir="rtl"
      className="sticky top-0 z-40 border-b border-border/60 bg-background/90 backdrop-blur supports-[backdrop-filter]:bg-background/70"
    >
      <nav
        aria-label="التنقّل الرئيسي"
        className="mx-auto flex max-w-5xl items-center gap-1 overflow-x-auto px-3 py-2 [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden"
      >
        {NAV_LINKS.map((item) => (
          <Link
            key={item.to}
            to={item.to}
            activeOptions={item.exact ? { exact: true } : undefined}
            className="shrink-0 rounded-md px-3 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-foreground data-[status=active]:bg-primary/10 data-[status=active]:text-primary"
          >
            {item.label}
          </Link>
        ))}
      </nav>
    </header>
  );
}
