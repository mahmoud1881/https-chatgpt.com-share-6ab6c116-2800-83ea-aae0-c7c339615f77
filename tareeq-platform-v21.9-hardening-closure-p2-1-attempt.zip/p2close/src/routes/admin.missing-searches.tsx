import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { AdminPageShell } from "@/components/admin/AdminPageShell";
import { toast } from "sonner";
import {
  listMissingSearches,
  searchStops,
  resolveMissingSearch,
} from "@/lib/route-planner/admin-missing.functions";
import { Loader2, Search, X, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/admin/missing-searches")({
  ssr: false,
  head: () => ({
    meta: [{ title: "بحث فاشل — Tareeq Admin" }, { name: "robots", content: "noindex, nofollow" }],
  }),
  component: MissingSearchesPage,
});

type Row = {
  id: string;
  from_query: string;
  to_query: string;
  from_stop_id: string | null;
  to_stop_id: string | null;
  country: string | null;
  city: string | null;
  hits: number;
  status: string;
  created_at: string;
};

type Stop = {
  id: string;
  name_ar: string;
  name_en: string | null;
  city: string | null;
  country: string;
  is_verified: boolean;
};

function MissingSearchesPage() {
  const navigate = useNavigate();
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(false);
  const [selection, setSelection] = useState<{ rowId: string; side: "from" | "to" } | null>(null);
  const [selected, setSelected] = useState<Record<string, { from?: Stop; to?: Stop }>>({});

  const list = useServerFn(listMissingSearches);
  const searchFn = useServerFn(searchStops);
  const resolveFn = useServerFn(resolveMissingSearch);
  useEffect(() => {
    (async () => {
      await refresh();
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function refresh() {
    setLoading(true);
    try {
      const res = await list();
      setRows(res.rows as Row[]);
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  async function apply(row: Row, mode: "link" | "alias") {
    const sel = selected[row.id];
    if (!sel?.from && !sel?.to) return toast.error("اختر محطة على الأقل");
    try {
      if (mode === "alias") {
        if (sel.from)
          await resolveFn({
            data: {
              id: row.id,
              action: "alias_from",
              fromStopId: sel.from.id,
              toStopId: sel.to?.id,
            },
          });
        if (sel.to)
          await resolveFn({
            data: { id: row.id, action: "alias_to", toStopId: sel.to.id, fromStopId: sel.from?.id },
          });
      } else {
        await resolveFn({
          data: { id: row.id, action: "link", fromStopId: sel.from?.id, toStopId: sel.to?.id },
        });
      }
      toast.success("تم");
      setRows((rs) => rs.filter((r) => r.id !== row.id));
      setSelected((s) => {
        const c = { ...s };
        delete c[row.id];
        return c;
      });
    } catch (err) {
      toast.error((err as Error).message);
    }
  }

  async function ignore(row: Row) {
    try {
      await resolveFn({ data: { id: row.id, action: "ignore" } });
      setRows((rs) => rs.filter((r) => r.id !== row.id));
    } catch (err) {
      toast.error((err as Error).message);
    }
  }

  return (
    <AdminPageShell>
      <header className="px-4 pt-6 pb-4 flex items-center justify-between">
        <Link to="/admin/data-health" className="text-xs underline text-muted-foreground">
          ← صحّة البيانات
        </Link>
        <h1 className="text-lg font-bold">عمليات البحث الفاشلة</h1>
      </header>

      <div className="px-4 mb-3 flex items-center gap-2">
        <button
          onClick={refresh}
          disabled={loading}
          className="text-xs rounded-full border px-3 py-1.5 hover:bg-muted disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-3 h-3 inline animate-spin" /> : "🔄"} تحديث
        </button>
        <span className="text-xs text-muted-foreground">{rows.length} صف معلّق</span>
      </div>

      {rows.length === 0 && !loading && (
        <p className="px-4 text-sm text-muted-foreground text-center py-8">
          لا توجد عمليات معلّقة 🎉
        </p>
      )}

      <ul className="px-4 space-y-3">
        {rows.map((row) => (
          <li key={row.id} className="rounded-2xl border bg-card p-3">
            <div className="flex items-center justify-between mb-2">
              <div className="text-[11px] text-muted-foreground">
                {row.country ?? "—"} · {row.hits} مرة ·{" "}
                {new Date(row.created_at).toLocaleDateString("ar-EG")}
              </div>
              <button
                onClick={() => ignore(row)}
                className="text-[10px] text-muted-foreground hover:text-destructive"
              >
                <X className="w-3 h-3 inline" /> تجاهل
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-sm">
              <SidePicker
                label="من"
                query={row.from_query}
                selected={selected[row.id]?.from}
                onPick={() => setSelection({ rowId: row.id, side: "from" })}
                onClear={() =>
                  setSelected((s) => ({ ...s, [row.id]: { ...s[row.id], from: undefined } }))
                }
              />
              <SidePicker
                label="إلى"
                query={row.to_query}
                selected={selected[row.id]?.to}
                onPick={() => setSelection({ rowId: row.id, side: "to" })}
                onClear={() =>
                  setSelected((s) => ({ ...s, [row.id]: { ...s[row.id], to: undefined } }))
                }
              />
            </div>

            <div className="flex gap-2 mt-3 justify-end">
              <button
                onClick={() => apply(row, "alias")}
                className="text-xs rounded-full border px-3 py-1.5 hover:bg-muted"
              >
                أضف كمرادف
              </button>
              <button
                onClick={() => apply(row, "link")}
                className="text-xs rounded-full bg-primary text-primary-foreground px-3 py-1.5"
              >
                <CheckCircle2 className="w-3 h-3 inline" /> اربط وأغلق
              </button>
            </div>
          </li>
        ))}
      </ul>

      {selection && (
        <StopPicker
          country={rows.find((r) => r.id === selection.rowId)?.country ?? undefined}
          initialQuery={
            selection.side === "from"
              ? (rows.find((r) => r.id === selection.rowId)?.from_query ?? "")
              : (rows.find((r) => r.id === selection.rowId)?.to_query ?? "")
          }
          onClose={() => setSelection(null)}
          onPick={(stop) => {
            setSelected((s) => ({
              ...s,
              [selection.rowId]: { ...s[selection.rowId], [selection.side]: stop },
            }));
            setSelection(null);
          }}
          searchFn={async (q, country) => {
            const res = await searchFn({ data: { q, country } });
            return res.rows as Stop[];
          }}
        />
      )}
    </AdminPageShell>
  );
}

function SidePicker({
  label,
  query,
  selected,
  onPick,
  onClear,
}: {
  label: string;
  query: string;
  selected?: Stop;
  onPick: () => void;
  onClear: () => void;
}) {
  return (
    <div className="rounded-xl border bg-background p-2">
      <div className="text-[10px] text-muted-foreground mb-1">
        {label}: <span className="font-bold text-foreground">{query}</span>
      </div>
      {selected ? (
        <div className="flex items-center justify-between gap-1">
          <span className="text-xs truncate">
            {selected.name_ar}
            {selected.city ? ` — ${selected.city}` : ""}
          </span>
          <button
            onClick={onClear}
            aria-label="إلغاء الاختيار"
            className="text-muted-foreground hover:text-destructive"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      ) : (
        <button
          onClick={onPick}
          className="text-xs w-full rounded-md border-dashed border py-1 hover:bg-muted"
        >
          اختر محطة…
        </button>
      )}
    </div>
  );
}

function StopPicker({
  country,
  initialQuery,
  onClose,
  onPick,
  searchFn,
}: {
  country?: string;
  initialQuery: string;
  onClose: () => void;
  onPick: (s: Stop) => void;
  searchFn: (q: string, country?: string) => Promise<Stop[]>;
}) {
  const [q, setQ] = useState(initialQuery);
  const [results, setResults] = useState<Stop[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const t = setTimeout(async () => {
      if (!q.trim()) return setResults([]);
      setLoading(true);
      try {
        setResults(await searchFn(q.trim(), country));
      } finally {
        setLoading(false);
      }
    }, 250);
    return () => clearTimeout(t);
  }, [q, country, searchFn]);

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-50 bg-black/40 grid place-items-end sm:place-items-center p-3"
    >
      <div className="w-full max-w-md bg-card rounded-2xl border p-3 space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold">اختر محطة</h3>
          <button onClick={onClose} aria-label="إغلاق">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="flex items-center gap-1 bg-background rounded-xl border px-2">
          <Search className="w-3.5 h-3.5 text-muted-foreground" />
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="ابحث بالاسم…"
            className="flex-1 bg-transparent py-2 text-sm outline-none"
          />
        </div>
        <div className="max-h-72 overflow-y-auto space-y-1">
          {loading && (
            <div className="text-center text-xs text-muted-foreground py-2">
              <Loader2 className="w-3 h-3 inline animate-spin" />
            </div>
          )}
          {!loading && results.length === 0 && q && (
            <div className="text-xs text-muted-foreground text-center py-4">لا نتائج</div>
          )}
          {results.map((s) => (
            <button
              key={s.id}
              onClick={() => onPick(s)}
              className="w-full text-right rounded-lg border p-2 hover:bg-muted flex items-center justify-between"
            >
              <span className="text-sm">
                {s.name_ar}
                {s.city && <span className="text-[10px] text-muted-foreground"> — {s.city}</span>}
              </span>
              {s.is_verified && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
