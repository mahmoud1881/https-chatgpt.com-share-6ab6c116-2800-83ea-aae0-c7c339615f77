import { createFileRoute, Link } from "@tanstack/react-router";
import { usePublishSnapshot } from "@/hooks/use-publish-snapshot";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Sparkles, Search, ShieldCheck, ArrowRight, Lightbulb } from "lucide-react";

export const Route = createFileRoute("/forecast")({
  head: () => ({
    meta: [
      { title: "توقعات الزحمة — مدعوم بالذكاء الاصطناعي" },
      {
        name: "description",
        content: "اعرف زحمة طريقك قبل ما تنزل من البيت — توقعات مدعومة بالذكاء الاصطناعي.",
      },
      { property: "og:title", content: "🔮 توقعات الزحمة" },
      {
        property: "og:description",
        content: "توقعات زحمة مدعومة بالذكاء الاصطناعي.",
      },
    ],
  }),
  component: ForecastPage,
});

function ForecastPage() {
  usePublishSnapshot({
    id: "eg:forecast",
    source: "توقعات الزحمة",
    title: "توقعات الطرق",
    summary: "بحث لحظي عن توقعات زحمة الطرق بالذكاء الاصطناعي",
    category: "transit",
    href: "/forecast",
  });
  const [query, setQuery] = useState("");
  const [submitted, setSubmitted] = useState("");

  return (
    <div dir="rtl" className="min-h-screen bg-background text-foreground">
      <header className="border-b">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
          <Link to="/" className="text-sm text-muted-foreground hover:underline">
            ← الرئيسية
          </Link>
          <h1 className="text-lg font-bold">مدعوم بالذكاء الاصطناعي</h1>
          <div className="w-16" />
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 py-10">
        <section className="mb-8 text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-violet-500/10 px-3 py-1 text-xs font-medium text-violet-600">
            <Sparkles className="size-4" />
            مدعوم بالذكاء الاصطناعي
            <span className="rounded-full bg-amber-500/20 px-2 py-0.5 text-[10px] font-bold text-amber-700">
              نسخة تجريبية
            </span>
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight md:text-4xl">🔮 توقعات الزحمة</h2>
          <p className="mt-2 text-muted-foreground">اعرف زحمة طريقك قبل ما تنزل من البيت</p>
        </section>

        <Card className="mb-6 border-amber-300 bg-amber-50/60 p-4">
          <p className="text-sm text-amber-900">
            ⚠️ هذه ميزة تجريبية قيد التطوير. نموذج التنبؤ لا يزال يجمع بيانات كافية، ولا نعرض حالياً
            نسب ثقة أو مصادر رسمية. لا تعتمد على النتائج في اتخاذ قرارات حرجة.
          </p>
        </Card>

        <Card className="mb-6 p-6">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setSubmitted(query.trim());
            }}
            className="flex flex-col gap-3 sm:flex-row"
          >
            <Input
              dir="rtl"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ابحث عن منطقة (مثلاً: المعادي، وسط البلد)"
              className="flex-1"
            />
            <Button type="submit" size="lg" className="gap-2">
              <Search className="size-4" />
              توقّع
            </Button>
          </form>
        </Card>

        {submitted && (
          <Card className="mb-6 border-dashed p-8 text-center">
            <div className="mx-auto mb-3 flex size-12 items-center justify-center rounded-full bg-violet-500/10 text-violet-600">
              <Sparkles className="size-6" />
            </div>
            <p className="text-base font-medium">
              لسه ما عندناش بيانات كافية للتنبؤ في <span className="font-bold">{submitted}</span> —
              شارك تنبيهات وساعد الموديل يتعلم!
            </p>
          </Card>
        )}

        <Card className="mb-6 bg-amber-500/10 p-4">
          <p className="flex items-start gap-2 text-sm">
            <Lightbulb className="mt-0.5 size-4 shrink-0 text-amber-600" />
            <span>
              💡 الموديل يتحسّن كل ما يدخل بيانات جديدة. كل تنبيه تبعثه = توقع أدق لكل المستخدمين.
            </span>
          </p>
        </Card>

        <p className="mt-10 flex items-center justify-center gap-1 text-xs text-muted-foreground">
          <ShieldCheck className="size-3.5" />
          نحترم خصوصيتك
        </p>

        <div className="mt-6 text-center">
          <Link to="/">
            <Button variant="ghost" className="gap-1">
              العودة للرئيسية
              <ArrowRight className="size-4 rotate-180" />
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
