import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Award, LogIn, ShieldCheck, ArrowRight, Check, Share2, Copy } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

import { AuthGateLoading } from "@/components/AuthGateLoading";
import { useRequireAuth } from "@/hooks/useRequireAuth";

type Tier = {
  name: string;
  color: string;
  invites: string;
  reward: string;
  perks: string[];
};

const TIERS: Tier[] = [
  {
    name: "برونزي",
    color: "bg-amber-700",
    invites: "5+ دعوة",
    reward: "50 نقطة مكافأة",
    perks: [],
  },
  {
    name: "فضي",
    color: "bg-slate-400",
    invites: "10+ دعوة",
    reward: "100 نقطة مكافأة",
    perks: ["تعديل المحطات"],
  },
  {
    name: "ذهبي",
    color: "bg-yellow-500",
    invites: "20+ دعوة",
    reward: "200 نقطة مكافأة",
    perks: ["تعديل المحطات"],
  },
  {
    name: "بلاتيني",
    color: "bg-cyan-500",
    invites: "50+ دعوة",
    reward: "500 نقطة مكافأة",
    perks: ["تعديل المحطات"],
  },
];

export const Route = createFileRoute("/ambassador")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "سفير الحيّ — ادعُ واكسب" },
      {
        name: "description",
        content: "كن بطل حيّك — ادعُ ناسك لأحسن مواصلات واكسب نقاط ومراتب من برونزي حتى بلاتيني.",
      },
      { property: "og:title", content: "سفير الحيّ — ادعُ واكسب" },
      {
        property: "og:description",
        content: "كن بطل حيّك — ادعُ ناسك واكسب نقاط ومراتب.",
      },
    ],
  }),
  component: AmbassadorRoute,
});

/** بوابة استخدام: يتطلب تسجيل دخول قبل عرض هذه الصفحة (مش مجرد تصفح). */
function AmbassadorRoute() {
  const authStatus = useRequireAuth();
  if (authStatus !== "authenticated") return <AuthGateLoading />;
  return <AmbassadorPage />;
}

function AmbassadorPage() {
  const [email, setEmail] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!mounted) return;
      setEmail(data.session?.user.email ?? null);
      setUserId(data.session?.user.id ?? null);
      setReady(true);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setEmail(session?.user.email ?? null);
      setUserId(session?.user.id ?? null);
    });
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const inviteLink =
    typeof window !== "undefined" && userId
      ? `${window.location.origin}/?ref=${userId.slice(0, 8)}`
      : "";

  async function copyInvite() {
    try {
      await navigator.clipboard.writeText(inviteLink);
      toast.success("تم نسخ رابط الدعوة");
    } catch {
      toast.error("تعذّر نسخ الرابط");
    }
  }

  async function shareInvite() {
    if (typeof navigator !== "undefined" && "share" in navigator) {
      try {
        await navigator.share({
          title: "طريقك — مواصلاتك",
          text: "جرّب تطبيق مواصلاتك — دليل شامل للنقل في مدينتك",
          url: inviteLink,
        });
      } catch {
        /* user cancelled */
      }
    } else {
      void copyInvite();
    }
  }

  return (
    <div dir="rtl" className="min-h-screen bg-background text-foreground">
      <header className="border-b">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
          <Link to="/" className="text-sm text-muted-foreground hover:underline">
            ← الرئيسية
          </Link>
          <h1 className="text-lg font-bold">سفير الحيّ</h1>
          <div className="w-16" />
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-10">
        <section className="mb-10 text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
            <Award className="size-4" />
            ادعُ واكسب
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight md:text-4xl">
            كن بطل حيّك — وادي ناسك أحسن مواصلات
          </h2>

          {!ready ? (
            <p className="mt-3 text-muted-foreground">…</p>
          ) : !email ? (
            <>
              <p className="mt-3 text-muted-foreground">سجّل دخول عشان تبدأ تكون سفير</p>
              <div className="mt-6">
                <Link to="/auth">
                  <Button size="lg" className="gap-2">
                    <LogIn className="size-4" />
                    سجّل دخول
                  </Button>
                </Link>
              </div>
            </>
          ) : (
            <>
              <p className="mt-3 text-muted-foreground">
                أهلاً {email.split("@")[0]} — شارك رابطك واكسب نقاط
              </p>
              <div className="mx-auto mt-6 flex max-w-xl flex-col items-center gap-3">
                <div className="w-full truncate rounded-lg border bg-muted px-3 py-2 text-sm text-muted-foreground">
                  {inviteLink}
                </div>
                <div className="flex flex-wrap justify-center gap-2">
                  <Button size="lg" className="gap-2" onClick={shareInvite}>
                    <Share2 className="size-4" />
                    شارك الرابط
                  </Button>
                  <Button size="lg" variant="outline" className="gap-2" onClick={copyInvite}>
                    <Copy className="size-4" />
                    انسخ
                  </Button>
                </div>
              </div>
            </>
          )}
        </section>

        <section>
          <h3 className="mb-4 text-center text-sm font-semibold text-muted-foreground">المراتب</h3>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {TIERS.map((t) => (
              <Card key={t.name} className="p-5">
                <div className="mb-3 flex items-center gap-3">
                  <span
                    className={`flex size-10 items-center justify-center rounded-full ${t.color} text-white`}
                  >
                    <Award className="size-5" />
                  </span>
                  <span className="text-lg font-bold">{t.name}</span>
                </div>
                <p className="text-sm font-medium">{t.invites}</p>
                <p className="text-sm text-muted-foreground">{t.reward}</p>
                {t.perks.length > 0 && (
                  <ul className="mt-3 space-y-1">
                    {t.perks.map((p) => (
                      <li key={p} className="flex items-center gap-2 text-sm text-foreground">
                        <Check className="size-4 text-primary" />
                        {p}
                      </li>
                    ))}
                  </ul>
                )}
              </Card>
            ))}
          </div>
        </section>

        <p className="mt-10 flex items-center justify-center gap-1 text-xs text-muted-foreground">
          <ShieldCheck className="size-3.5" />
          نحترم خصوصيتك
        </p>

        <div className="mt-8 text-center">
          <Link to="/">
            <Button variant="ghost" className="gap-1">
              العودة للرئيسية
              <ArrowRight className="size-4 rotate-180" />
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
