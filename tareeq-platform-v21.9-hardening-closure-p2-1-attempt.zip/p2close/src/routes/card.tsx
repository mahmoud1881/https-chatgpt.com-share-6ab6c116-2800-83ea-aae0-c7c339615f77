import { createFileRoute, Link } from "@tanstack/react-router";
import { usePublishSnapshot } from "@/hooks/use-publish-snapshot";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CreditCard, Wallet, ShieldCheck, ArrowRight, QrCode } from "lucide-react";

import { AuthGateLoading } from "@/components/AuthGateLoading";
import { useRequireAuth } from "@/hooks/useRequireAuth";

const FEATURES = [
  "تحديث تلقائي للرصيد المتوفّر",
  "تنبيهات Push على شاشة القفل عند الزحمة",
  "QR لمشاركة الإنجاز مع الأصحاب",
  "يفتح بلمسة من قفل الموبايل قبل المحطة",
];

export const Route = createFileRoute("/card")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "بطاقتي الذكية — مواصلاتي" },
      {
        name: "description",
        content:
          "بطاقتك دائماً في جيبك — توفير تقديري، خطوط، وتنبيهات. متوافقة مع Apple Wallet وGoogle Wallet.",
      },
      { property: "og:title", content: "بطاقتي الذكية" },
      {
        property: "og:description",
        content: "توفير تقديري، خطوط، وتنبيهات — في جيبك.",
      },
    ],
  }),
  component: CardRoute,
});

/** بوابة استخدام: يتطلب تسجيل دخول قبل عرض هذه الصفحة (مش مجرد تصفح). */
function CardRoute() {
  const authStatus = useRequireAuth();
  if (authStatus !== "authenticated") return <AuthGateLoading />;
  return <CardPage />;
}

function CardPage() {
  usePublishSnapshot({
    id: "eg:card",
    source: "الكارت الموحد",
    title: "الكارت الذكي",
    summary: "معلومات الكارت الذكي وأسعار الشحن",
    category: "economy",
    href: "/card",
  });
  return (
    <div dir="rtl" className="min-h-screen bg-background text-foreground">
      <header className="border-b">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
          <Link to="/" className="text-sm text-muted-foreground hover:underline">
            ← الرئيسية
          </Link>
          <h1 className="text-lg font-bold">بطاقتي الذكية</h1>
          <div className="w-16" />
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 py-10">
        <section className="mb-8 text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
            <CreditCard className="size-4" />
            بطاقتي
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight md:text-4xl">
            بطاقتك دائماً في جيبك
          </h2>
          <p className="mt-2 text-muted-foreground">توفير تقديري، خطوط، وتنبيهات</p>
        </section>

        {/* Smart Card Visual */}
        <div className="mb-8">
          <Card className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6 text-white shadow-xl">
            <div className="absolute -left-10 -top-10 size-40 rounded-full bg-primary/20 blur-3xl" />
            <div className="absolute -bottom-10 -right-10 size-40 rounded-full bg-emerald-500/20 blur-3xl" />

            <div className="relative flex items-start justify-between">
              <div>
                <p className="text-sm text-white/70">مواصلاتي</p>
                <p className="mt-1 text-xs text-white/50">بطاقة العضو</p>
              </div>
              <div className="flex size-10 items-center justify-center rounded-md bg-white/10">
                <QrCode className="size-5" />
              </div>
            </div>

            <div className="relative mt-8">
              <p className="text-xs uppercase tracking-wider text-white/60">
                توفير تقديري هذا الشهر
              </p>
              <p className="mt-1 text-4xl font-extrabold tracking-tight">
                87 <span className="text-2xl font-bold text-white/80">ج</span>
              </p>
            </div>

            <div className="relative mt-6 grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-xs text-white/50">الخط المفضل</p>
                <p className="mt-0.5 font-semibold">M2 — المترو</p>
              </div>
              <div>
                <p className="text-xs text-white/50">حيّك</p>
                <p className="mt-0.5 font-semibold">المعادي</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Wallet buttons — Feature not implemented yet. Disabled until end-to-end pass is wired. */}
        <div className="mb-8 grid gap-3 sm:grid-cols-2">
          <Button
            size="lg"
            className="relative gap-2 bg-black text-white hover:bg-black/90"
            disabled
            aria-disabled="true"
            title="سيتم تفعيل الإضافة إلى المحفظة قريباً بعد اعتماد ملف بطاقة رسمي"
          >
            <Wallet className="size-4" />
            أضف لـ Apple Wallet
            <span className="ms-2 rounded-full bg-white/20 px-2 py-0.5 text-[10px] font-semibold">
              قريباً
            </span>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="relative gap-2"
            disabled
            aria-disabled="true"
            title="سيتم تفعيل الإضافة إلى المحفظة قريباً بعد اعتماد ملف بطاقة رسمي"
          >
            <Wallet className="size-4" />
            أضف لـ Google Wallet
            <span className="ms-2 rounded-full bg-slate-200 px-2 py-0.5 text-[10px] font-semibold text-slate-700">
              قريباً
            </span>
          </Button>
        </div>
        <p className="mb-6 text-center text-xs text-muted-foreground">
          ميزة الإضافة إلى Apple/Google Wallet قيد التطوير — سنعلن عن الإطلاق فور اعتماد ملف البطاقة
          الرسمي.
        </p>

        {/* Features */}
        <Card className="mb-6 p-6">
          <h3 className="mb-4 text-lg font-bold">مميزات البطاقة</h3>
          <ul className="space-y-2.5">
            {FEATURES.map((f) => (
              <li key={f} className="flex items-start gap-2 text-sm">
                <span className="text-emerald-600">✅</span>
                <span>{f}</span>
              </li>
            ))}
          </ul>
        </Card>

        <Card className="mb-6 bg-amber-500/10 p-4">
          <p className="text-sm">
            🚀 إضافة البطاقة إلى المحافظ الرقمية لن تُفعّل إلا بعد اعتماد تكامل رسمي واختباره؛
            الصفحة الحالية تعرض نموذجًا توضيحيًا فقط.
          </p>
        </Card>

        <p className="flex items-center justify-center gap-1 text-xs text-muted-foreground">
          <ShieldCheck className="size-3.5" />
          نحترم خصوصيتك
        </p>

        {/* Privacy consent */}
        <Card className="mt-8 p-5">
          <p className="mb-4 text-sm text-muted-foreground">
            نستخدم بيانات الموقع وملفات تعريف الارتباط لتحسين دقة الرحلات والمحطات.{" "}
            <Link to="/privacy" className="underline">
              سياسة الخصوصية
            </Link>{" "}
            ·{" "}
            <Link to="/terms" className="underline">
              الشروط
            </Link>
          </p>
          <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
            <Button variant="outline" size="sm">
              الأساسي فقط
            </Button>
            <Button size="sm">موافق على الكل</Button>
          </div>
        </Card>

        <div className="mt-8 text-center">
          <Link to="/">
            <Button variant="ghost" className="gap-1">
              العودة للرئيسية
              <ArrowRight className="size-4 rotate-180" />
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
