import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { TrainFront, MapPin, Clock, ArrowRight, Star } from "lucide-react";
import { getTrainLineFn, type TrainLineDetails } from "@/lib/trains/queries.functions";
import { safeAsync } from "@/lib/safe";
import { NotFoundState } from "@/components/NotFoundState";

const SLUG_TITLES: Record<string, { title: string; desc: string }> = {
  "cairo-alexandria": {
    title: "قطارات القاهرة — الإسكندرية",
    desc: "كل مواعيد قطارات القاهرة الإسكندرية (تالجو، VIP، مكيّف، روسي) بمحطاتها.",
  },
  "cairo-luxor": {
    title: "قطارات القاهرة — الأقصر",
    desc: "مواعيد قطارات القاهرة الأقصر النهارية والليلية بمحطاتها الكاملة.",
  },
  "cairo-aswan": {
    title: "قطارات القاهرة — أسوان",
    desc: "كل مواعيد قطارات القاهرة أسوان بمحطاتها وفئاتها.",
  },
  "cairo-port-said": {
    title: "قطارات القاهرة — بورسعيد",
    desc: "مواعيد قطارات خط القاهرة بورسعيد بمحطاتها الكاملة.",
  },
  "cairo-suez": {
    title: "قطارات القاهرة — السويس",
    desc: "مواعيد قطارات القاهرة السويس بمحطاتها الكاملة.",
  },
  "alexandria-luxor": {
    title: "قطارات الإسكندرية — الأقصر",
    desc: "مواعيد قطارات الإسكندرية الأقصر بمحطاتها الكاملة.",
  },
};

export const Route = createFileRoute("/trains/$slug")({
  ssr: false,
  head: ({ params }) => {
    const meta = SLUG_TITLES[params.slug] ?? {
      title: `قطارات ${params.slug.replace(/-/g, " ")}`,
      desc: "جدول القطارات ومحطاتها الكاملة لهذا الخط.",
    };
    const fullTitle = `${meta.title} — مواصلات مصر`;
    return {
      meta: [
        { title: fullTitle },
        { name: "description", content: meta.desc },
        { property: "og:title", content: fullTitle },
        { property: "og:description", content: meta.desc },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: TrainLinePage,
  notFoundComponent: () => (
    <NotFoundState
      title="خط القطار غير موجود"
      description="لم نجد هذا الخط في أطلس القطارات. اختر خطًا من القائمة أو ابحث عن رحلتك."
      suggestions={[
        { to: "/trains", label: "كل خطوط القطارات" },
        { to: "/trains-atlas", label: "أطلس القطارات" },
        { to: "/intercity", label: "التنقل بين المحافظات" },
      ]}
    />
  ),
});

function TrainLinePage() {
  const { slug } = Route.useParams();
  const run = useServerFn(getTrainLineFn);
  const [data, setData] = useState<TrainLineDetails>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    void safeAsync(() => run({ data: { slug } }), {
      label: "تحميل بيانات الخط",
      scope: "trains.$slug",
    })
      .then((d) => {
        if (alive) setData(d ?? null);
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [slug, run]);

  if (loading) {
    return (
      <div dir="rtl" className="p-6 text-sm text-muted-foreground">
        جاري التحميل…
      </div>
    );
  }
  if (!data) {
    return (
      <div dir="rtl" className="p-6">
        <p className="text-sm">لم يتم العثور على هذا الخط.</p>
        <Link to="/trains" className="text-emerald-700 underline text-sm">
          العودة لكل خطوط القطار
        </Link>
      </div>
    );
  }

  return (
    <div dir="rtl" className="mx-auto max-w-3xl px-3 py-4 pb-24">
      <Link to="/trains" className="text-xs text-muted-foreground underline">
        ← كل خطوط القطار
      </Link>

      <header className="mt-2 mb-4 flex items-center gap-3">
        <div className="rounded-2xl bg-emerald-100 p-3">
          <TrainFront className="w-6 h-6 text-emerald-700" />
        </div>
        <div>
          <h1 className="text-lg font-black">{data.nameAr}</h1>
          <p className="text-xs text-muted-foreground">
            {data.fromCity} <ArrowRight className="inline w-3 h-3" /> {data.toCity} ·{" "}
            {data.trains.length} قطار · {data.stations.length} محطة
          </p>
        </div>
      </header>

      {/* Trains table */}
      <section className="rounded-2xl border bg-card p-3 shadow-sm mb-4">
        <div className="flex items-center gap-2 mb-2">
          <Clock className="w-4 h-4 text-emerald-700" />
          <h2 className="text-sm font-bold">جدول القطارات</h2>
        </div>
        <div className="overflow-x-auto -mx-1">
          <table className="w-full text-[11px]">
            <thead className="text-muted-foreground">
              <tr className="text-right">
                <th className="px-1.5 py-1 font-medium">رقم</th>
                <th className="px-1.5 py-1 font-medium">النوع</th>
                <th className="px-1.5 py-1 font-medium">مغادرة</th>
                <th className="px-1.5 py-1 font-medium">وصول</th>
                <th className="px-1.5 py-1 font-medium">المدة</th>
                <th className="px-1.5 py-1 font-medium">محطات</th>
              </tr>
            </thead>
            <tbody>
              {data.trains.map((t) => (
                <tr key={t.number} className="border-t border-border/50">
                  <td className="px-1.5 py-1.5 font-bold text-emerald-700">{t.number}</td>
                  <td className="px-1.5 py-1.5">{t.type}</td>
                  <td className="px-1.5 py-1.5 whitespace-nowrap">{t.departure}</td>
                  <td className="px-1.5 py-1.5 whitespace-nowrap">{t.arrival}</td>
                  <td className="px-1.5 py-1.5 whitespace-nowrap">{t.duration}</td>
                  <td className="px-1.5 py-1.5">{t.stops}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Stations list */}
      <section className="rounded-2xl border bg-card p-3 shadow-sm">
        <div className="flex items-center gap-2 mb-2">
          <MapPin className="w-4 h-4 text-emerald-700" />
          <h2 className="text-sm font-bold">محطات الخط بالترتيب</h2>
        </div>
        <ol className="text-[12px] divide-y">
          {data.stations.map((s) => (
            <li key={s.order} className="flex items-center gap-2 py-1.5">
              <span className="w-6 text-muted-foreground text-[10px] font-mono">{s.order}</span>
              {s.isMajor && <Star className="w-3 h-3 fill-amber-400 text-amber-500" />}
              <span className={s.isMajor ? "font-bold" : ""}>{s.name}</span>
              {s.city && (
                <span className="mr-auto text-[10px] text-muted-foreground">{s.city}</span>
              )}
            </li>
          ))}
        </ol>
      </section>
    </div>
  );
}
