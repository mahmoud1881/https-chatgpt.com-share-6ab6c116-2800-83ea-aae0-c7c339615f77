import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { usePublishSnapshot } from "@/hooks/use-publish-snapshot";
import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { ArrowRight, Heart, Repeat, Trash2, Search } from "lucide-react";
import {
  listFavorites,
  removeFavorite,
  listFrequentTrips,
  removeTrip,
  clearTrips,
  type FavoriteRoute,
  type TripEntry,
} from "@/lib/transit/favorites";
import { getLocalRoute } from "@/lib/local-data";
import { AuthGateLoading } from "@/components/AuthGateLoading";
import { useRequireAuth } from "@/hooks/useRequireAuth";

export const Route = createFileRoute("/favorites")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "خطوطي ورحلاتي — مواصلات مصر" },
      { name: "description", content: "خطوطك المفضلة ورحلاتك المتكررة في مكان واحد." },
    ],
  }),
  component: FavoritesRoute,
});

/** المفضلة والرحلات المتكررة ميزة استخدام فعلية، فبتتطلب تسجيل دخول. */
function FavoritesRoute() {
  const authStatus = useRequireAuth();
  if (authStatus !== "authenticated") return <AuthGateLoading />;
  return <FavoritesPage />;
}

function FavoritesPage() {
  usePublishSnapshot({
    id: "eg:favorites",
    source: "المفضلة",
    title: "خطوطي ورحلاتي",
    summary: "خطوطك ورحلاتك المفضلة محفوظة محلياً",
    category: "transit",
    href: "/favorites",
  });
  const [favs, setFavs] = useState<FavoriteRoute[]>([]);
  const [trips, setTrips] = useState<TripEntry[]>([]);
  const navigate = useNavigate();

  const refresh = () => {
    setFavs(listFavorites());
    setTrips(listFrequentTrips(20));
  };
  useEffect(refresh, []);

  return (
    <div dir="rtl" className="min-h-screen bg-background px-4 py-8">
      <div className="mx-auto max-w-3xl space-y-6">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowRight className="size-4" /> الرئيسية
        </Link>

        <header className="space-y-1">
          <h1 className="flex items-center gap-2 text-2xl font-extrabold">
            <Heart className="size-6 text-red-500" /> خطوطي ورحلاتي
          </h1>
          <p className="text-sm text-muted-foreground">
            خطوط مفضّلة ورحلات بتكررها — التخزين نفسه يفضل محلياً على جهازك، وتسجيل الدخول هنا بوابة
            دخول فقط.
          </p>
        </header>

        {/* المفضلة */}
        <section className="space-y-3">
          <h2 className="text-lg font-bold">الخطوط المفضلة ({favs.length})</h2>
          {favs.length === 0 ? (
            <Card className="p-6 text-center text-sm text-muted-foreground">
              مفيش خطوط مفضّلة لسة. افتح صفحة أي خط واضغط زر القلب لإضافته.
            </Card>
          ) : (
            <ul className="space-y-2">
              {favs.map((f) => {
                const r = getLocalRoute(f.id) as {
                  name_ar?: string | null;
                  transport_mode?: string | null;
                } | null;
                const label = r?.name_ar || f.label;
                return (
                  <li key={f.id}>
                    <Card className="flex items-center gap-3 p-3">
                      <Link
                        to="/route/$routeId"
                        params={{ routeId: f.id }}
                        className="flex-1 min-w-0"
                      >
                        <div className="truncate font-medium hover:underline">{label}</div>
                        {(r?.transport_mode || f.mode) && (
                          <Badge variant="outline" className="mt-1 text-[10px]">
                            {r?.transport_mode || f.mode}
                          </Badge>
                        )}
                      </Link>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => {
                          // ✅ تحسين #8: Optimistic UI — نحذف الكارت فوراً ونتيح Undo
                          setFavs((prev) => prev.filter((x) => x.id !== f.id));
                          const removed = f;
                          removeFavorite(f.id);
                          toast("تم الحذف", {
                            action: {
                              label: "تراجع",
                              onClick: () => {
                                import("@/lib/transit/favorites").then(({ toggleFavorite }) => {
                                  toggleFavorite({
                                    id: removed.id,
                                    label: removed.label,
                                    mode: removed.mode,
                                  });
                                  refresh();
                                });
                              },
                            },
                          });
                        }}
                        aria-label="إزالة"
                      >
                        <Trash2 className="size-4" />
                      </Button>
                    </Card>
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        {/* الرحلات المتكررة */}
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-lg font-bold">
              <Repeat className="size-5" /> رحلات متكررة ({trips.length})
            </h2>
            {trips.length > 0 && (
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  clearTrips();
                  refresh();
                }}
              >
                مسح الكل
              </Button>
            )}
          </div>
          {trips.length === 0 ? (
            <Card className="p-6 text-center text-sm text-muted-foreground">
              لما تبحث "من X إلى Y" في المستكشف، الرحلة هتتسجل هنا تلقائياً.
            </Card>
          ) : (
            <ul className="space-y-2">
              {trips.map((t) => (
                <li key={t.key}>
                  <Card className="flex items-center gap-3 p-3">
                    <button
                      type="button"
                      className="flex-1 min-w-0 text-right"
                      onClick={() =>
                        navigate({
                          to: "/explore",
                          search: { q: `من ${t.from} إلى ${t.to}` } as never,
                        })
                      }
                    >
                      <div className="truncate font-medium">
                        <span>{t.from}</span>
                        <span className="mx-2 text-muted-foreground">←</span>
                        <span>{t.to}</span>
                      </div>
                      <div className="mt-0.5 text-xs text-muted-foreground">
                        تكررت {t.count} مرة
                      </div>
                    </button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() =>
                        navigate({
                          to: "/explore",
                          search: { q: `من ${t.from} إلى ${t.to}` } as never,
                        })
                      }
                      aria-label="بحث"
                    >
                      <Search className="size-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => {
                        removeTrip(t.key);
                        refresh();
                      }}
                      aria-label="إزالة"
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </Card>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
