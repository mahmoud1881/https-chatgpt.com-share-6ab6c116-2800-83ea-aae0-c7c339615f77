import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, useMemo } from "react";
import { loadOsmStops, type OsmFile, type OsmStop } from "@/lib/osm-stops";

export const Route = createFileRoute("/eg/osm")({
  component: EgOsm,
  head: () => ({
    meta: [
      { title: "مواقف مصر من OpenStreetMap | طريق" },
      {
        name: "description",
        content:
          "تغطية موسعة لمواقف ومحطات النقل في مصر مأخوذة من OpenStreetMap (ODbL) مع إزالة التكرار.",
      },
    ],
  }),
});

const TYPE_LABEL: Record<string, string> = {
  bus_stop: "موقف باص",
  bus_station: "محطة باصات",
  train: "محطة قطار",
  tram: "ترام",
  taxi: "موقف تاكسي",
  ferry: "ميناء/معدية",
  transit_station: "محطة نقل",
  other: "أخرى",
  stop: "موقف",
};

function EgOsm() {
  const [file, setFile] = useState<OsmFile | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [city, setCity] = useState<string>("all");
  const [type, setType] = useState<string>("all");

  useEffect(() => {
    loadOsmStops("eg")
      .then((f) => {
        if (!f) setErr("لم يتم توليد البيانات بعد. شغّل scripts/osm-ingest.py eg");
        else setFile(f);
      })
      .catch((e) => setErr(String(e?.message || e)));
  }, []);

  const cities = useMemo(() => {
    if (!file) return [] as string[];
    return Array.from(new Set(file.stops.map((s) => s.city))).sort();
  }, [file]);

  const filtered = useMemo(() => {
    if (!file) return [] as OsmStop[];
    const t = q.trim().toLowerCase();
    return file.stops
      .filter((s) => {
        if (city !== "all" && s.city !== city) return false;
        if (type !== "all" && s.type !== type) return false;
        if (!t) return true;
        return (
          (s.name || "").toLowerCase().includes(t) ||
          (s.name_ar || "").toLowerCase().includes(t) ||
          (s.name_en || "").toLowerCase().includes(t)
        );
      })
      .slice(0, 500);
  }, [file, q, city, type]);

  return (
    <div className="min-h-screen bg-background p-4 max-w-5xl mx-auto" dir="rtl">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold">🗺️ مواقف مصر — OpenStreetMap</h1>
        <Link to="/" className="text-sm text-primary underline">
          الرئيسية
        </Link>
      </div>
      <p className="text-sm text-muted-foreground mb-4">
        مصدر مفتوح مجاني (Overpass / ODbL). تم استبعاد المكررات مع بياناتنا المنسقة.
      </p>

      {err && (
        <div className="rounded border border-destructive/50 bg-destructive/10 p-3 text-sm">
          {err}
        </div>
      )}

      {file && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mb-4">
            <input
              className="rounded border bg-card px-3 py-2 text-sm"
              placeholder="بحث بالاسم…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
            <select
              className="rounded border bg-card px-3 py-2 text-sm"
              value={city}
              onChange={(e) => setCity(e.target.value)}
            >
              <option value="all">كل المدن ({cities.length})</option>
              {cities.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
            <select
              className="rounded border bg-card px-3 py-2 text-sm"
              value={type}
              onChange={(e) => setType(e.target.value)}
            >
              <option value="all">كل الأنواع</option>
              {Object.keys(TYPE_LABEL).map((t) => (
                <option key={t} value={t}>
                  {TYPE_LABEL[t]}
                </option>
              ))}
            </select>
          </div>

          <div className="text-xs text-muted-foreground mb-2">
            الإجمالي: {file.count.toLocaleString("ar-EG")} موقف · معروض: {filtered.length}
          </div>

          <div className="space-y-2">
            {filtered.map((s) => (
              <div key={s.id} className="rounded border bg-card p-3">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <div className="font-medium">
                      {s.name_ar || s.name || s.name_en || "بدون اسم"}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {TYPE_LABEL[s.type] || s.type} · {s.city}
                      {s.operator ? ` · ${s.operator}` : ""}
                    </div>
                  </div>
                  <a
                    className="text-xs text-primary underline whitespace-nowrap"
                    href={
                      s.map_url ||
                      `https://www.openstreetmap.org/?mlat=${s.lat}&mlon=${s.lng}#map=18/${s.lat}/${s.lng}`
                    }
                    target="_blank"
                    rel="noreferrer"
                  >
                    خريطة
                  </a>
                </div>
                {s.served_areas && s.served_areas.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {s.served_areas.slice(0, 8).map((a, i) => (
                      <span
                        key={i}
                        className="text-[10px] rounded-full bg-primary/10 text-primary px-2 py-0.5"
                      >
                        {a}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
            {filtered.length === 0 && <div className="text-sm text-muted-foreground">لا نتائج</div>}
          </div>
        </>
      )}
    </div>
  );
}
