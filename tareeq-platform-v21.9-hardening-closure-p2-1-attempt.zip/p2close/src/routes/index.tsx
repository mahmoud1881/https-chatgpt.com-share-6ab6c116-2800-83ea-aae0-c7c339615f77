/** Footer sitemap — main sections reachable from the bottom of every home visit. */
const FOOTER_SECTIONS: Array<{ title: string; links: Array<{ to: string; label: string }> }> = [
  {
    title: "وسائل النقل",
    links: [
      { to: "/metro", label: "مترو الأنفاق" },
      { to: "/brt", label: "الأتوبيس الترددي" },
      { to: "/trains", label: "القطارات" },
      { to: "/lrt", label: "القطار الكهربائي" },
      { to: "/capital-train", label: "قطار العاصمة" },
      { to: "/bus-stations", label: "مواقف الأتوبيسات" },
    ],
  },
  {
    title: "أدوات الرحلة",
    links: [
      { to: "/nearby", label: "قريب مني" },
      { to: "/live", label: "الزحمة المباشرة" },
      { to: "/commute", label: "رحلتي اليومية" },
      { to: "/semantic-search", label: "البحث الذكي" },
      { to: "/planner", label: "مخطط الرحلة" },
      { to: "/my-tracks", label: "مساراتي المسجلة" },
      { to: "/favorites", label: "خطوطي المحفوظة" },
    ],
  },
  {
    title: "المجتمع",
    links: [
      { to: "/community-routes", label: "الخطوط المجتمعية" },
      { to: "/ask", label: "اسأل المجتمع" },
      { to: "/ambassador", label: "سفير الحي" },
      { to: "/challenge", label: "تحدي الحي" },
      { to: "/deals", label: "عروض وخصومات" },
      { to: "/card", label: "كارت المواصلات" },
      { to: "/dark-data", label: "الداتا المظلمة" },
      { to: "/intercity", label: "التنقل بين المحافظات" },
    ],
  },
];

import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Bus,
  Flame,
  Crown,
  Trophy,
  Target,
  Wallet,
  Brain,
  Share2,
  AlertTriangle,
  MapPin,
  Hash,
  Users,
  MessageCircle,
  Search,
  TrainFront,
  BusFront,
  Train,
  Map as MapIcon,
  Tag,
  BarChart3,
  Eye,
  EyeOff,
  Heart,
  Zap,
} from "lucide-react";
import { useFeatureVisibility } from "@/lib/feature-visibility";
import { FeatureVisibilityPanel } from "@/components/FeatureVisibilityPanel";
// i18n مُهيَّأ من __root.tsx — لا حاجة لاستيراد مكرر
import { LangToggle } from "@/components/LangToggle";
import { CountrySwitch } from "@/components/CountrySwitch";
import { AuthChip } from "@/components/AuthChip";
import { InstagateSponsorCard } from "@/components/InstagateSponsorCard";

import { egHead, getEgPage } from "@/lib/seo/eg-meta";
import { clientOnlyLazy } from "@/components/client-only-lazy";
const SmartDigest = clientOnlyLazy<Record<string, never>>(() =>
  import("@/components/smart-digest").then((m) => ({ default: m.SmartDigest })),
);
const TransportSearch = clientOnlyLazy<Record<string, never>>(() =>
  import("@/components/TransportSearch").then((m) => ({ default: m.TransportSearch })),
);

export const Route = createFileRoute("/")({
  head: () => {
    const p = getEgPage("/")!;
    return egHead({ path: p.path, titleAr: p.titleAr, descAr: p.descAr, ogImage: p.ogImage });
  },
  component: Index,
});

type Tone = "rose" | "fuchsia" | "sky" | "amber" | "emerald" | "violet" | "teal";

/**
 * Visual identity rule: shortcut tiles are NOT color-coded per item.
 * They share one calm brand surface; only transport modes carry a
 * semantic color (see MODE_COLOR below). This kills the rainbow noise.
 */
const TONE_TILE: Record<
  Tone,
  { bg: string; border: string; icon: string; title: string; sub: string }
> = (() => {
  const brandTile = {
    bg: "bg-sand",
    border: "border-brand/10",
    icon: "bg-brand",
    title: "text-brand",
    sub: "text-muted-foreground",
  };
  const goldTile = {
    bg: "bg-sand",
    border: "border-gold/30",
    icon: "bg-gold text-gold-foreground",
    title: "text-brand",
    sub: "text-muted-foreground",
  };
  return {
    rose: brandTile,
    fuchsia: brandTile,
    sky: brandTile,
    amber: goldTile,
    emerald: brandTile,
    violet: brandTile,
    teal: brandTile,
  };
})();

/** One color per transport mode, used everywhere that mode appears. */
const MODE_COLOR = {
  metro: "bg-mode-metro",
  bus: "bg-mode-bus",
  brt: "bg-mode-brt",
  rail: "bg-mode-rail",
  stop: "bg-mode-stop",
} as const;

type TileProps = {
  to: string;
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  tone: Tone;
};

function Tile({ to, title, subtitle, icon, tone }: TileProps) {
  const t = TONE_TILE[tone];
  return (
    <Link
      to={to}
      className={`group flex flex-col gap-3 rounded-3xl border ${t.bg} ${t.border} p-4 transition-all active:scale-95 hover:shadow-md`}
    >
      <div
        className={`flex size-10 items-center justify-center rounded-2xl text-mode-foreground shadow-md transition-transform group-hover:scale-110 ${t.icon} [&_svg]:size-5`}
      >
        {icon}
      </div>
      <div className="min-w-0">
        <p className={`truncate text-sm font-bold ${t.title}`}>{title}</p>
        <p className={`truncate text-[11px] ${t.sub}`}>{subtitle}</p>
      </div>
    </Link>
  );
}

function ChipLink({
  to,
  icon,
  label,
  tone = "ghost",
  size = "sm",
}: {
  to: string;
  icon: React.ReactNode;
  label: string;
  tone?: "ghost" | "primary" | "danger";
  size?: "sm" | "lg";
}) {
  const toneClass =
    tone === "primary"
      ? "bg-gold text-gold-foreground border-gold/60 hover:brightness-105"
      : tone === "danger"
        ? "bg-brand-foreground text-destructive border-brand-foreground/60 hover:brightness-105"
        : "bg-brand-foreground/10 text-brand-foreground border-brand-foreground/20 backdrop-blur-md hover:bg-brand-foreground/20";
  const sizeClass =
    size === "lg" ? "px-4 py-2 text-sm font-semibold" : "px-3.5 py-1.5 text-xs font-medium";
  return (
    <Link
      to={to}
      className={`inline-flex shrink-0 items-center gap-1.5 rounded-full border shadow-sm transition-transform active:scale-95 ${sizeClass} ${toneClass}`}
    >
      {icon}
      <span>{label}</span>
    </Link>
  );
}

function ShareTripChip() {
  const handleShare = async () => {
    const shareData = {
      title: "مواصلات — شير رحلتك",
      text: "تعالوا نتنافس على تحدي الحي في تطبيق مواصلات 🚌",
      url: typeof window !== "undefined" ? window.location.origin + "/challenge" : "/challenge",
    };
    try {
      if (typeof navigator !== "undefined" && typeof navigator.share === "function") {
        await navigator.share(shareData);
        return;
      }
      if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(shareData.url);
        const { toast } = await import("sonner");
        toast.success("تم نسخ رابط رحلتك — شاركه مع جيرانك");
        return;
      }
      window.open(
        `https://wa.me/?text=${encodeURIComponent(shareData.text + " " + shareData.url)}`,
        "_blank",
        "noopener,noreferrer",
      );
    } catch {
      // المستخدم ألغى المشاركة — تجاهل بهدوء
    }
  };
  return (
    <button
      type="button"
      onClick={handleShare}
      className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-white/60 bg-white/95 px-3.5 py-1.5 text-xs font-medium text-emerald-700 shadow-sm transition-transform hover:bg-white active:scale-95"
      aria-label="شير رحلتك"
    >
      <Share2 className="size-3.5" />
      <span>شير رحلتك</span>
    </button>
  );
}

const TILES_PREF_KEY = "home:tiles:visible";
// Flag used to gate tiles that are intentionally disabled in the UI right
// now but kept in code so re-enabling is a one-line change.
const FEATURE_OFF: boolean = false;

/**
 * Trust layer — the strongest card the platform holds is its coverage.
 * These numbers reflect the verified dataset (routes cleaned of duplicates)
 * and are surfaced right under the search box, where doubt peaks.
 */
const DATA_LAST_UPDATED = "أغسطس ٢٠٢٦";
const TRUST_STATS: Array<{ value: string; label: string; icon: React.ReactNode }> = [
  { value: "٥,٠٦٣", label: "خط مواصلات موثّق", icon: <Bus /> },
  { value: "٢٧", label: "محافظة مغطّاة", icon: <MapPin /> },
  { value: "٩٨", label: "محطة مترو ومسار", icon: <TrainFront /> },
  { value: "٤", label: "محركات بحث متوافقة", icon: <Target /> },
];

function TrustBand() {
  return (
    <section
      aria-label="أرقام الثقة"
      className="mt-6 rounded-3xl border-2 border-brand/10 bg-white p-5 shadow-sm"
    >
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {TRUST_STATS.map((s) => (
          <div key={s.label} className="flex flex-col items-center gap-1 text-center">
            <div className="flex size-8 items-center justify-center rounded-xl bg-brand/10 text-brand [&_svg]:size-4">
              {s.icon}
            </div>
            <div className="text-2xl font-black leading-none text-brand">{s.value}</div>
            <div className="text-[11px] font-semibold text-muted-foreground">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="mt-5 flex flex-wrap items-center justify-center gap-x-4 gap-y-2 border-t border-slate-100 pt-4 text-[11px] font-semibold">
        <span className="inline-flex items-center gap-1.5 text-emerald-700">
          <span className="size-2 animate-pulse rounded-full bg-emerald-500" aria-hidden="true" />
          آخر تحديث للبيانات: {DATA_LAST_UPDATED}
        </span>
        <span className="inline-flex items-center gap-1.5 text-muted-foreground">
          <Users className="size-3.5" />
          بمساهمة الركاب وسفراء الأحياء
        </span>
        <Link
          to="/community-routes"
          className="inline-flex items-center gap-1.5 text-brand hover:underline"
        >
          <Hash className="size-3.5" />
          ساهم بتوثيق خط جديد
        </Link>
      </div>
    </section>
  );
}

function Index() {
  const [tilesVisible, setTilesVisible] = useState(true);
  const { isVisible } = useFeatureVisibility();

  useEffect(() => {
    try {
      const v = localStorage.getItem(TILES_PREF_KEY);
      if (v === "0") setTilesVisible(false);
    } catch {
      /* ignore */
    }
  }, []);

  const toggleTiles = () => {
    setTilesVisible((prev) => {
      const next = !prev;
      try {
        localStorage.setItem(TILES_PREF_KEY, next ? "1" : "0");
      } catch {
        /* ignore */
      }
      return next;
    });
  };

  return (
    <div className="flex min-h-screen flex-col bg-sand pb-24 sm:pb-8">
      <InstagateSponsorCard />

      {/* Header — glass gradient */}
      <header className="relative overflow-hidden bg-gradient-to-br from-brand via-brand-deep to-black pb-20 text-brand-foreground sm:pb-32">
        {/* gold horizon accent — nile/sand identity */}
        <div
          className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-gold/70"
          aria-hidden="true"
        />
        {/* subtle decorative curves */}
        <div className="pointer-events-none absolute inset-0 opacity-10" aria-hidden="true">
          <svg className="h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path
              d="M0 100 C 20 0 50 0 100 100"
              stroke="currentColor"
              fill="transparent"
              strokeWidth="0.5"
            />
            <path
              d="M0 80 C 30 20 70 20 100 80"
              stroke="currentColor"
              fill="transparent"
              strokeWidth="0.5"
            />
          </svg>
        </div>

        <div className="relative mx-auto max-w-6xl px-4 pb-10 pt-5">
          {/* Hero Content — Value Proposition */}
          <div className="mb-8 mt-4 text-center sm:text-right">
            <h1 className="text-3xl font-black tracking-tighter sm:text-5xl lg:text-6xl">
              توهت؟ <span className="text-gold">طريقك</span> يبدأ من هنا
            </h1>
            <p className="mt-4 max-w-2xl text-lg font-medium text-brand-foreground/90 sm:text-xl">
              دليلك الشامل لـ{" "}
              <span className="underline decoration-gold/50 decoration-2 underline-offset-4">
                ٥,٠٦٣ خط مواصلات
              </span>{" "}
              في مصر. فين هما وفين تلاقيهم.. كل المسارات في جيبك.
            </p>
          </div>

          {/* Top row: brand + tools */}
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 opacity-90">
            <div className="flex min-w-0 items-center gap-3">
              <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-gold/20 backdrop-blur-md ring-1 ring-gold/40">
                <Bus className="size-5 text-gold" />
              </div>
              <div className="min-w-0 leading-tight">
                <div className="truncate text-xs font-bold uppercase tracking-widest text-gold/80">
                  Tareeq.world
                </div>
                <div className="truncate text-[11px] text-brand-foreground/60">
                  نسخة الـ QA التجريبية
                </div>
              </div>
            </div>

            <div className="flex shrink-0 items-center gap-1.5">
              <AuthChip />
            </div>
          </div>

          {/* Chip rail — tier 1 (primary actions) + tier 2 (collapsed extras) */}
          <div className="mt-5">
            {/* Tier 1: أهم ٤ إجراءات — بارزة ولا تُخفى أبدًا */}
            <div className="relative">
              <div className="-mx-4 overflow-x-auto px-4 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                <div className="flex gap-2 sm:flex-wrap">
                  {isVisible("chip:live") && (
                    <ChipLink
                      to="/live"
                      icon={<Flame className="size-4" />}
                      label="الزحمة المباشرة"
                      tone="danger"
                      size="lg"
                    />
                  )}
                  {isVisible("chip:nearby") && (
                    <ChipLink
                      to="/nearby"
                      icon={<MapPin className="size-4" />}
                      label="قريب مني"
                      tone="primary"
                      size="lg"
                    />
                  )}
                  {isVisible("chip:commute") && (
                    <ChipLink
                      to="/commute"
                      icon={<Zap className="size-4" />}
                      label="رحلتي اليومية"
                      tone="primary"
                      size="lg"
                    />
                  )}
                  {isVisible("chip:favorites") && (
                    <ChipLink
                      to="/favorites"
                      icon={<Heart className="size-4" />}
                      label="خطوطي"
                      size="lg"
                    />
                  )}
                </div>
              </div>
              {/* مؤشر تمرير على الموبايل — تلاشي عند الحافة */}
              <div
                className="pointer-events-none absolute inset-y-0 left-0 w-8 bg-gradient-to-l from-brand-deep to-transparent sm:hidden"
                aria-hidden="true"
              />
            </div>

            {/* Tier 2: باقي الأقسام — مطوية افتراضيًا لإزالة الضجيج */}
            <details className="group mt-3">
              <summary className="inline-flex cursor-pointer list-none items-center gap-1.5 rounded-full border border-brand-foreground/20 bg-brand-foreground/10 px-3 py-1 text-[11px] font-semibold text-brand-foreground/90 backdrop-blur-md transition hover:bg-brand-foreground/20">
                <Hash className="size-3" />
                <span className="group-open:hidden">كل الأقسام</span>
                <span className="hidden group-open:inline">إخفاء الأقسام</span>
              </summary>

              <div className="relative mt-3">
                <div className="-mx-4 overflow-x-auto px-4 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                  <div className="flex gap-2 sm:flex-wrap">
                    <ChipLink to="/" icon={<Bus className="size-3.5" />} label="الرئيسية" />
                    {isVisible("chip:share") && <ShareTripChip />}
                    {isVisible("chip:alerts") && (
                      <ChipLink
                        to="/alerts"
                        icon={<AlertTriangle className="size-3.5" />}
                        label="التنبيهات"
                      />
                    )}
                    {isVisible("chip:navigate") && (
                      <ChipLink
                        to="/navigate"
                        icon={<MapPin className="size-3.5" />}
                        label="الملاحة"
                      />
                    )}
                    {isVisible("chip:explore") && (
                      <ChipLink
                        to="/explore"
                        icon={<MapPin className="size-3.5" />}
                        label="استكشف"
                      />
                    )}
                    {isVisible("chip:community-routes") && (
                      <ChipLink
                        to="/community-routes"
                        icon={<Hash className="size-3.5" />}
                        label="الخطوط المجتمعية"
                      />
                    )}
                    {isVisible("chip:bus-stations") && (
                      <ChipLink
                        to="/bus-stations"
                        icon={<Bus className="size-3.5" />}
                        label="مواقف الأتوبيسات"
                      />
                    )}
                    {isVisible("chip:ask") && (
                      <ChipLink
                        to="/ask"
                        icon={<MessageCircle className="size-3.5" />}
                        label="اسأل المجتمع"
                      />
                    )}
                    <ChipLink
                      to="/ambassador"
                      icon={<Crown className="size-3.5" />}
                      label="سفير الحي"
                    />
                    {isVisible("chip:challenge") && (
                      <ChipLink
                        to="/challenge"
                        icon={<Trophy className="size-3.5" />}
                        label="تحدي الحي"
                        tone="primary"
                      />
                    )}
                  </div>
                </div>
                <div
                  className="pointer-events-none absolute inset-y-0 left-0 w-8 bg-gradient-to-l from-brand-deep to-transparent sm:hidden"
                  aria-hidden="true"
                />
              </div>
            </details>
          </div>
        </div>
      </header>

      {/* Main content — elevated over header */}
      <main className="mx-auto flex w-full max-w-6xl flex-1 flex-col px-4 pb-6">
        <div className="relative z-10 -mt-20 sm:-mt-24">
          <TransportSearch />
        </div>

        {/* Trust layer — coverage numbers + freshness + social proof */}
        <TrustBand />

        {/* موجز اليوم الذكي */}
        <div className="mt-6">
          <SmartDigest />
        </div>

        <div className="mb-3 mt-8 flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900">الاختصارات السريعة</h2>
          <button
            type="button"
            onClick={toggleTiles}
            className="inline-flex items-center gap-1.5 rounded-full border bg-white px-3 py-1 text-xs font-medium text-slate-600 shadow-sm transition hover:bg-slate-50"
            aria-pressed={tilesVisible}
          >
            {tilesVisible ? <EyeOff className="size-3.5" /> : <Eye className="size-3.5" />}
            <span>{tilesVisible ? "إخفاء" : "إظهار"}</span>
          </button>
        </div>
        {tilesVisible && (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {isVisible("tile:live") && (
              <Tile to="/live" title="حرارة الزحمة" subtitle="مباشر" icon={<Flame />} tone="rose" />
            )}
            {isVisible("tile:ambassador") && (
              <Tile
                to="/ambassador"
                title="كن سفير"
                subtitle="ادعو وكسب"
                icon={<Crown />}
                tone="fuchsia"
              />
            )}
            {FEATURE_OFF && isVisible("tile:challenge") && (
              <Tile
                to="/challenge"
                title="تحدي الحي"
                subtitle="بطل أسبوعك"
                icon={<Trophy />}
                tone="amber"
              />
            )}
            {FEATURE_OFF && isVisible("tile:challenges") && (
              <Tile
                to="/challenges"
                title="تحديات"
                subtitle="اربح شارات"
                icon={<Target />}
                tone="emerald"
              />
            )}
            {isVisible("tile:forecast") && (
              <Tile
                to="/forecast"
                title="توقعات الزحمة"
                subtitle="AI"
                icon={<Brain />}
                tone="sky"
              />
            )}
            {FEATURE_OFF && isVisible("tile:community-routes") && (
              <Tile
                to="/community-routes"
                title="خطوط مجتمعية"
                subtitle="ساهم"
                icon={<MapIcon />}
                tone="violet"
              />
            )}
            {FEATURE_OFF && isVisible("tile:pulse") && (
              <Tile
                to="/pulse"
                title="نبض المدينة"
                subtitle="تقارير"
                icon={<BarChart3 />}
                tone="teal"
              />
            )}
          </div>
        )}

        {/* Ask section */}
        {FEATURE_OFF && isVisible("section:ask") && (
          <section className="mt-8 rounded-2xl border bg-white p-5 shadow-sm">
            <h2 className="mb-1 text-lg font-bold">اسال</h2>
            <p className="mb-3 text-sm text-muted-foreground">
              مثال: «أسرع طريق من المعادي إلى التحرير»
            </p>
            <Link
              to="/explore"
              className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90"
            >
              <Search className="size-4" />
              اقترح / ابحث في قاعدة البيانات (21K+)
            </Link>
          </section>
        )}

        {/* Transit modes section */}
        {isVisible("section:transit-modes") && (
          <section className="mt-6">
            <div className="mb-3 flex items-end justify-between">
              <div>
                <h2 className="text-lg font-bold">مواقف القاهرة الكبرى</h2>
                <p className="text-sm text-muted-foreground">مرتّبة حسب المنطقة ونوع المواصلة</p>
              </div>
              <Link to="/stops" className="text-sm font-semibold text-primary hover:underline">
                عرض الكل
              </Link>
            </div>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                {
                  to: "/metro",
                  icon: <TrainFront />,
                  title: "مترو القاهرة",
                  color: MODE_COLOR.metro,
                },
                {
                  to: "/brt",
                  icon: <Bus />,
                  title: "الأتوبيس الترددي",
                  color: MODE_COLOR.brt,
                },
                { to: "/trains", icon: <Train />, title: "القطارات", color: MODE_COLOR.rail },
                {
                  to: "/capital-train",
                  icon: <TrainFront />,
                  title: "قطار العاصمة",
                  color: MODE_COLOR.rail,
                },
                {
                  to: "/lrt",
                  icon: <TrainFront />,
                  title: "القطار الكهربائي الخفيف",
                  color: MODE_COLOR.metro,
                },
                {
                  to: "/bus-stations",
                  icon: <BusFront />,
                  title: "مواقف الأتوبيسات",
                  color: MODE_COLOR.bus,
                },
                {
                  to: "/intercity",
                  icon: <BusFront />,
                  title: "التنقل بين المحافظات",
                  color: MODE_COLOR.bus,
                },
                { to: "/stops", icon: <MapPin />, title: "المواقف", color: MODE_COLOR.stop },
              ].map((m) => (
                <Link
                  key={m.to}
                  to={m.to}
                  className="group flex flex-col items-center gap-2 rounded-2xl border bg-card p-4 text-center shadow-sm transition-all active:scale-95 hover:shadow-md"
                >
                  <div
                    className={`flex size-10 items-center justify-center rounded-xl text-mode-foreground shadow-md transition-transform group-hover:scale-110 ${m.color} [&_svg]:size-5`}
                  >
                    {m.icon}
                  </div>
                  <div className="text-sm font-bold text-foreground">{m.title}</div>
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Secondary tiles */}
        {isVisible("section:secondary") && (
          <section
            className={`mt-6 grid gap-3 ${FEATURE_OFF ? "grid-cols-1 sm:grid-cols-2" : "grid-cols-1"}`}
          >
            <Link
              to="/community-routes"
              className="flex items-center gap-3 rounded-xl border bg-white p-4 shadow-sm hover:shadow-md"
            >
              <MapIcon className="size-6 text-purple-600" />
              <div>
                <div className="font-bold">خطوط مجتمعية</div>
                <div className="text-xs text-muted-foreground">ساهم بتوثيق خط</div>
              </div>
            </Link>
            {FEATURE_OFF && (
              <Link
                to="/pulse"
                className="flex items-center gap-3 rounded-xl border bg-white p-4 shadow-sm hover:shadow-md"
              >
                <BarChart3 className="size-6 text-teal-600" />
                <div>
                  <div className="font-bold">نبض المدينة</div>
                  <div className="text-xs text-muted-foreground">تقارير</div>
                </div>
              </Link>
            )}
          </section>
        )}

        {/* Footer — real sitemap, not a faint single line */}
        <footer className="mt-16 rounded-t-3xl border-t-2 border-brand/10 bg-white pb-12 pt-10 text-sm sm:pb-8">
          <div className="mx-auto grid max-w-5xl gap-8 px-6 sm:grid-cols-2 lg:grid-cols-4">
            <div className="sm:col-span-2 lg:col-span-1">
              <div className="flex items-center gap-2 text-lg font-black text-brand">
                <Bus className="size-5" />
                <span>Tareeq.world</span>
              </div>
              <p className="mt-3 max-w-xs text-xs leading-relaxed text-muted-foreground">
                دليل مواصلات مصر — ٥,٠٦٣ خط موثّق عبر ٢٧ محافظة، بمساهمة الركاب وسفراء الأحياء.
              </p>
            </div>

            {FOOTER_SECTIONS.map((group) => (
              <nav key={group.title} aria-label={group.title}>
                <h3 className="mb-3 text-xs font-black uppercase tracking-widest text-brand/70">
                  {group.title}
                </h3>
                <ul className="space-y-2">
                  {group.links.map((l) => (
                    <li key={l.to}>
                      <Link
                        to={l.to}
                        className="text-xs font-semibold text-slate-600 transition-colors hover:text-brand hover:underline"
                      >
                        {l.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </nav>
            ))}
          </div>

          <div className="mx-auto mt-10 flex max-w-5xl flex-col items-center gap-3 border-t border-slate-100 px-6 pt-6 text-center text-[11px] text-muted-foreground sm:flex-row sm:justify-between sm:text-start">
            <p className="opacity-80">جميع الحقوق محفوظة © {new Date().getFullYear()}</p>
            <div className="flex flex-wrap items-center justify-center gap-4 font-semibold text-brand">
              <a href="/privacy" className="hover:underline">
                سياسة الخصوصية
              </a>
              <span className="h-1 w-1 rounded-full bg-slate-300" aria-hidden="true" />
              <a href="/terms" className="hover:underline">
                شروط الاستخدام
              </a>
              <span className="h-1 w-1 rounded-full bg-slate-300" aria-hidden="true" />
              <a href="/contact" className="hover:underline">
                تواصل معنا
              </a>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
