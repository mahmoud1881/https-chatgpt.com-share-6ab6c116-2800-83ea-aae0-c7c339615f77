// Egypt sub-sitemap.
import { createFileRoute } from "@tanstack/react-router";
import { EG_PAGES } from "@/lib/seo/eg-meta";
import { getAllLocalRouteIds, getAllLocalStopIds } from "@/lib/local-data";

import { SITE_BASE_URL as BASE } from "@/lib/seo/site";
const esc = (s: string) => s.replace(/&/g, "&amp;");

const TRAIN_LINE_SLUGS = [
  "cairo-alexandria",
  "cairo-luxor",
  "cairo-aswan",
  "cairo-port-said",
  "cairo-suez",
  "alexandria-luxor",
];

export const Route = createFileRoute("/sitemap-eg.xml")({
  server: {
    handlers: {
      GET: async () => {
        const pages = EG_PAGES.map(
          (p) =>
            `  <url><loc>${BASE}${p.path}</loc><changefreq>${p.changefreq}</changefreq><priority>${p.priority}</priority></url>`,
        );
        const routes = getAllLocalRouteIds().map(
          (id) =>
            `  <url><loc>${esc(BASE + "/route/" + encodeURIComponent(id))}</loc><changefreq>monthly</changefreq><priority>0.6</priority></url>`,
        );
        const stops = getAllLocalStopIds().map(
          (id) =>
            `  <url><loc>${esc(BASE + "/stop/" + encodeURIComponent(id))}</loc><changefreq>monthly</changefreq><priority>0.5</priority></url>`,
        );
        const trainLines = TRAIN_LINE_SLUGS.map(
          (slug) =>
            `  <url><loc>${BASE}/trains/${slug}</loc><changefreq>monthly</changefreq><priority>0.7</priority></url>`,
        );
        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...pages,
          ...routes,
          ...stops,
          ...trainLines,
          `</urlset>`,
        ].join("\n");
        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml; charset=utf-8",
            "Cache-Control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
