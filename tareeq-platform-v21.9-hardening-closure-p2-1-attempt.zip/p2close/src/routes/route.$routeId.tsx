import { SITE_BASE_URL } from "@/lib/seo/site";
import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { getErrorMessage } from "@/lib/error-message";
import { supabase } from "@/integrations/supabase/client";
import { FloatingHomeButton } from "@/components/FloatingHomeButton";
import { RouteDetailsEnhancement } from "@/components/search/RouteDetailsEnhancement";
import { ServicePlacesPanel } from "@/components/service-places/ServicePlacesPanel";
import { MapPin, CheckCircle2, AlertCircle, ArrowRight } from "lucide-react";
import { NotFoundState } from "@/components/NotFoundState";

export const Route = createFileRoute("/route/$routeId")({
  ssr: false,
  loader: async ({ params }) => {
    const { data: route, error } = await supabase
      .from("routes")
      .select(
        "id, route_code, route_name, transport_type_id, country, city, estimated_duration, is_verified, notes, start_stop_id, end_stop_id",
      )
      .eq("id", params.routeId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!route) throw notFound();

    const { data: rs } = await supabase
      .from("route_stops")
      .select("stop_order, direction, stop_id")
      .eq("route_id", route.id)
      .order("stop_order", { ascending: true });

    const stopIds = Array.from(
      new Set((rs ?? []).map((r) => r.stop_id).filter((x): x is string => !!x)),
    );
    let stopsMap: Record<
      string,
      {
        id: string;
        name_ar: string;
        name_en: string | null;
        city: string | null;
        latitude: number | null;
        longitude: number | null;
      }
    > = {};
    if (stopIds.length) {
      const { data: stops } = await supabase
        .from("stops")
        .select("id, name_ar, name_en, city, latitude, longitude")
        .in("id", stopIds);
      stopsMap = Object.fromEntries((stops ?? []).map((s) => [s.id, s]));
    }
    const stopsList = (rs ?? []).map((r) => ({
      ...r,
      stop: r.stop_id ? (stopsMap[r.stop_id] ?? null) : null,
    }));
    return { route, stopsList };
  },
  head: ({ params, loaderData }) => {
    const r = loaderData?.route;
    const title = r ? `${r.route_name} — Tareeq` : "Tareeq";
    const desc = r
      ? `${r.city ?? ""} • ${r.route_code ?? ""} — تفاصيل الخط والمحطات بالترتيب على Tareeq.`
      : "تفاصيل خط النقل على Tareeq.";
    const url = `${SITE_BASE_URL}/route/${params.routeId}`;
    const img = `${SITE_BASE_URL}/og-eg-bus.jpg`;
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:type", content: "article" },
        { property: "og:url", content: url },
        { property: "og:image", content: img },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:image", content: img },
      ],
      links: [{ rel: "canonical", href: url }],
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "الرئيسية", item: `${SITE_BASE_URL}/` },
              {
                "@type": "ListItem",
                position: 2,
                name: r?.route_name ?? "خط النقل",
                item: url,
              },
            ],
          }),
        },
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Service",
            name: r?.route_name ?? "خط نقل",
            serviceType: "BusOrCoach",
            identifier: r?.route_code ?? undefined,
            areaServed: r?.city ? { "@type": "City", name: r.city } : undefined,
            provider: { "@type": "Organization", name: "Tareeq" },
            url,
          }),
        },
      ],
    };
  },
  errorComponent: ({ error }) => (
    <div className="min-h-screen flex items-center justify-center p-6 text-center">
      <div>
        <h1 className="text-xl font-bold mb-2">تعذّر تحميل الخط</h1>
        <p className="text-sm text-muted-foreground">{getErrorMessage(error)}</p>
        <Link to="/" className="text-primary underline mt-3 inline-block">
          العودة للرئيسية
        </Link>
      </div>
    </div>
  ),
  notFoundComponent: () => (
    <NotFoundState
      title="لم يُعثر على هذا الخط"
      description="الخط الذي تبحث عنه غير متاح حاليًا. جرّب البحث عن خط آخر أو أضف الخط الناقص."
      suggestions={[
        { to: "/explore", label: "استكشف الخطوط" },
        { to: "/community-routes", label: "خطوط المجتمع" },
        { to: "/ask", label: "اسأل المجتمع" },
      ]}
    />
  ),
  component: RouteDetailPage,
});

function RouteDetailPage() {
  const { route, stopsList } = Route.useLoaderData();
  return (
    <div className="min-h-screen bg-background p-6" dir="rtl">
      <FloatingHomeButton />
      <div className="max-w-2xl mx-auto space-y-4">
        <div className="bg-card border border-border rounded-2xl p-5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="text-xs text-muted-foreground mb-1">
                {route.country ?? ""}
                {route.city ? ` / ${route.city}` : ""}
                {route.transport_type_id ? ` • ${route.transport_type_id}` : ""}
              </div>
              <h1 className="text-xl font-bold">{route.route_name}</h1>
              {route.route_code && (
                <div className="text-sm text-muted-foreground mt-1">
                  رمز الخط: {route.route_code}
                </div>
              )}
            </div>
            {route.is_verified ? (
              <span className="inline-flex items-center gap-1 text-xs bg-emerald-500/10 text-emerald-600 px-2 py-1 rounded">
                <CheckCircle2 className="h-3 w-3" /> موثّق
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-xs bg-amber-500/10 text-amber-600 px-2 py-1 rounded">
                <AlertCircle className="h-3 w-3" /> قيد المراجعة
              </span>
            )}
          </div>

          <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
            {route.estimated_duration != null && (
              <div>
                <div className="text-xs text-muted-foreground">الزمن التقديري</div>
                <div className="font-semibold">{route.estimated_duration} د</div>
              </div>
            )}
          </div>

          {route.notes && !route.notes.startsWith("imported:") && (
            <p className="text-sm text-muted-foreground mt-4 whitespace-pre-line">{route.notes}</p>
          )}
          <RouteDetailsEnhancement
            rt={{
              route_code: route.route_code,
              route_name: route.route_name,
              transport_type_id: route.transport_type_id,
              estimated_duration: route.estimated_duration,
              is_verified: route.is_verified,
              stops_count: stopsList.length,
            }}
          />
        </div>

        <div className="bg-card border border-border rounded-2xl p-5">
          <h2 className="font-bold mb-3 flex items-center gap-2">
            <MapPin className="h-4 w-4" /> المحطات ({stopsList.length})
          </h2>
          {stopsList.length === 0 ? (
            <p className="text-sm text-muted-foreground">لم تُضَف محطات لهذا الخط بعد.</p>
          ) : (
            <ol className="relative space-y-2 pr-4 border-r-2 border-border">
              {stopsList.map((s, i: number) => (
                <li key={`${s.stop_id}-${i}`} className="relative pr-4">
                  <span className="absolute right-[-6px] top-2 h-2 w-2 rounded-full bg-primary" />
                  <div className="text-sm font-medium">{s.stop?.name_ar ?? "محطة غير مرتبطة"}</div>
                  {s.stop?.name_en && (
                    <div className="text-xs text-muted-foreground">{s.stop.name_en}</div>
                  )}
                  <ServicePlacesPanel stopName={s.stop?.name_ar} variant="compact" initialCap={5} />
                </li>
              ))}
            </ol>
          )}
        </div>

        <Link
          to="/planner"
          className="inline-flex items-center gap-2 text-sm text-primary underline"
        >
          <ArrowRight className="h-4 w-4" /> ابحث عن خط آخر
        </Link>
      </div>
    </div>
  );
}
