import { createFileRoute, Navigate } from "@tanstack/react-router";

// Former calculator URL: keep existing bookmarks usable for the journey planner.
export const Route = createFileRoute("/budget")({
  component: () => <Navigate to="/planner" replace />,
});
