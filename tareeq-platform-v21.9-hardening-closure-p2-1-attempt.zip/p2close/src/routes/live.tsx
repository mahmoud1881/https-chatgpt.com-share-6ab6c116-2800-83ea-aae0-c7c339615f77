import { SITE_BASE_URL } from "@/lib/seo/site";
import { createFileRoute, Link, useSearch } from "@tanstack/react-router";
import { usePublishSnapshot } from "@/hooks/use-publish-snapshot";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Flame, MapPin, ShieldCheck, ArrowRight, Copy, Check, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { pubsub } from "@/lib/free-realtime";
import { toast } from "sonner";
import { z } from "zod";

const EMBED_CODE = `<iframe src="${SITE_BASE_URL}/live?embed=1" width="100%" height="500" frameborder="0"></iframe>`;

const SEVERITIES = [
  { value: "clear", label: "سالك", color: "bg-emerald-500", emoji: "🟢" },
  { value: "medium", label: "متوسط", color: "bg-amber-500", emoji: "🟡" },
  { value: "heavy", label: "زحمة", color: "bg-orange-500", emoji: "🟠" },
  { value: "stuck", label: "واقف", color: "bg-rose-600", emoji: "🔴" },
] as const;

type Severity = (typeof SEVERITIES)[number]["value"];

type TrafficReport = {
  id: string;
  area: string;
  severity: Severity;
  notes: string | null;
  created_at: string;
};

const reportSchema = z.object({
  area: z.string().trim().min(1, "اكتب اسم المنطقة").max(120, "الاسم طويل جداً"),
  severity: z.enum(["clear", "medium", "heavy", "stuck"]),
  notes: z.string().trim().max(280, "الملاحظات طويلة").optional(),
});

type LiveSearch = { embed?: "1" };

export const Route = createFileRoute("/live")({
  ssr: false,
  validateSearch: (s: Record<string, unknown>): LiveSearch => ({
    embed: s.embed === "1" ? "1" : undefined,
  }),
  head: () => ({
    meta: [
      { title: "حرارة الزحمة مباشر" },
      {
        name: "description",
        content: "بيانات حقيقية لزحمة الشوارع من بلاغات المواطنين في آخر 4 ساعات.",
      },
      { property: "og:title", content: "🔥 حرارة الزحمة مباشر" },
      {
        property: "og:description",
        content: "بيانات حقيقية من بلاغات المواطنين في آخر 4 ساعات.",
      },
    ],
  }),

  component: LivePage,
});

function timeAgo(iso: string) {
  const diff = Math.max(0, Date.now() - new Date(iso).getTime());
  const m = Math.floor(diff / 60000);
  if (m < 1) return "الآن";
  if (m < 60) return `منذ ${m} دقيقة`;
  const h = Math.floor(m / 60);
  return `منذ ${h} ساعة`;
}

function LivePage() {
  const { embed } = useSearch({ from: "/live" });
  const isEmbed = embed === "1";

  usePublishSnapshot({
    id: "eg:live",
    source: "الخريطة الحية",
    title: "زحمة لحظية",
    summary: "خريطة حرارية لحظية للبلاغات والزحمة",
    category: "alerts",
    href: "/live",
  });
  const [copied, setCopied] = useState(false);
  const [open, setOpen] = useState(false);
  const [reports, setReports] = useState<TrafficReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [countryName, setCountryName] = useState<string>("");

  const loadReports = async () => {
    const { getActiveCountry } = await import("@/lib/active-country");
    const { COUNTRIES } = await import("@/config/countries");
    const code = getActiveCountry();
    setCountryName(COUNTRIES[code]?.nameAr ?? "");
    // قراءة عامة عبر دالة آمنة: بدون هوية المُبلِّغ ولا إحداثيات دقيقة
    const { data, error } = await supabase.rpc("get_public_traffic_reports", {
      p_country: code,
      p_limit: 50,
    });
    if (!error && data) setReports(data as unknown as TrafficReport[]);
    setLoading(false);
  };

  useEffect(() => {
    loadReports();
    let unsub: (() => void) | null = null;
    (async () => {
      const { getActiveCountry } = await import("@/lib/active-country");
      unsub = pubsub.subscribe(`traffic_reports/${getActiveCountry()}`, "insert", (payload) => {
        setReports((prev) => [payload as TrafficReport, ...prev].slice(0, 50));
      });
    })();
    return () => {
      unsub?.();
    };
  }, []);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(EMBED_CODE);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("تعذّر نسخ الكود");
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-background text-foreground">
      {!isEmbed && (
        <header className="border-b">
          <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
            <Link to="/" className="text-sm text-muted-foreground hover:underline">
              ← الرئيسية
            </Link>
            <h1 className="text-lg font-bold">مباشر</h1>
            <div className="w-16" />
          </div>
        </header>
      )}

      <main className={`mx-auto max-w-5xl px-4 ${isEmbed ? "py-4" : "py-10"}`}>
        <section className="mb-8 text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-orange-500/10 px-3 py-1 text-xs font-medium text-orange-600">
            <Flame className="size-4" />
            مباشر الآن
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight md:text-4xl">
            🔥 حرارة الزحمة{countryName ? ` في ${countryName}` : ""}
          </h2>
          <p className="mt-2 text-muted-foreground">
            بيانات حقيقية من بلاغات المواطنين في آخر 4 ساعات
          </p>
        </section>

        <Card className="mb-8 overflow-hidden">
          <div className="flex items-center justify-between border-b px-4 py-3">
            <h3 className="font-bold">آخر البلاغات ({reports.length})</h3>
            <Button size="sm" onClick={() => setOpen(true)} className="gap-1">
              <Flame className="size-3.5" /> أبلغ
            </Button>
          </div>

          {loading ? (
            <div className="flex h-40 items-center justify-center">
              <Loader2 className="size-5 animate-spin text-muted-foreground" />
            </div>
          ) : reports.length === 0 ? (
            <div className="flex h-40 flex-col items-center justify-center text-center">
              <MapPin className="mb-3 size-8 text-muted-foreground" />
              <p className="font-semibold">مفيش بلاغات في آخر 4 ساعات — الطريق سالك! 🎉</p>
            </div>
          ) : (
            <ul className="divide-y">
              {reports.map((r) => {
                const sev = SEVERITIES.find((s) => s.value === r.severity);
                return (
                  <li key={r.id} className="flex items-start gap-3 px-4 py-3">
                    <span
                      className={`mt-1 inline-flex h-2.5 w-2.5 shrink-0 rounded-full ${sev?.color ?? "bg-muted"}`}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="truncate font-semibold">{r.area}</span>
                        <span className="shrink-0 text-xs text-muted-foreground">
                          {timeAgo(r.created_at)}
                        </span>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {sev?.emoji} {sev?.label}
                        {r.notes ? ` — ${r.notes}` : ""}
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>

        {!isEmbed && (
          <Card className="mb-8 p-6">
            <h3 className="mb-1 text-lg font-bold">ضع الخريطة على موقعك أو بلوجك</h3>
            <p className="mb-4 text-sm text-muted-foreground">
              انسخ الكود ده وحطّه في أي صفحة HTML — الخريطة تتحدّث تلقائياً
            </p>
            <div className="relative">
              <pre dir="ltr" className="overflow-x-auto rounded-md border bg-muted p-4 text-xs">
                <code>{EMBED_CODE}</code>
              </pre>
              <Button
                size="sm"
                variant="secondary"
                onClick={copy}
                className="absolute left-2 top-2 gap-1"
              >
                {copied ? (
                  <>
                    <Check className="size-3.5" /> تم النسخ
                  </>
                ) : (
                  <>
                    <Copy className="size-3.5" /> نسخ
                  </>
                )}
              </Button>
            </div>
          </Card>
        )}

        <Card className="bg-primary/5 p-6 text-center">
          <h3 className="mb-2 text-lg font-bold">ساعدنا نحدّث الخريطة</h3>
          <p className="mb-4 text-sm text-muted-foreground">
            أبلغ عن زحمة في منطقتك — البلاغ يستمر 4 ساعات
          </p>
          <Button size="lg" className="gap-2" onClick={() => setOpen(true)}>
            <Flame className="size-4" /> أبلغ عن زحمة
          </Button>
        </Card>

        <p className="mt-10 flex items-center justify-center gap-1 text-xs text-muted-foreground">
          <ShieldCheck className="size-3.5" />
          نحترم خصوصيتك
        </p>

        {!isEmbed && (
          <div className="mt-6 text-center">
            <Link to="/">
              <Button variant="ghost" className="gap-1">
                العودة للرئيسية
                <ArrowRight className="size-4 rotate-180" />
              </Button>
            </Link>
          </div>
        )}
      </main>

      <ReportDialog open={open} onOpenChange={setOpen} onSubmitted={loadReports} />
    </div>
  );
}

function ReportDialog({
  open,
  onOpenChange,
  onSubmitted,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onSubmitted: () => void;
}) {
  const [area, setArea] = useState("");
  const [severity, setSeverity] = useState<Severity>("heavy");
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    const parsed = reportSchema.safeParse({ area, severity, notes });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "بيانات غير صالحة");
      return;
    }
    setBusy(true);
    let coords: { lat: number; lng: number } | null = null;
    if (typeof navigator !== "undefined" && navigator.geolocation) {
      coords = await new Promise<{ lat: number; lng: number } | null>((res) => {
        const t = setTimeout(() => res(null), 3500);
        navigator.geolocation.getCurrentPosition(
          (p) => {
            clearTimeout(t);
            res({ lat: p.coords.latitude, lng: p.coords.longitude });
          },
          () => {
            clearTimeout(t);
            res(null);
          },
          { maximumAge: 60000, timeout: 3000 },
        );
      });
    }

    const { getActiveCountry } = await import("@/lib/active-country");
    const country = getActiveCountry();
    const row = {
      area: parsed.data.area,
      severity: parsed.data.severity,
      notes: parsed.data.notes || null,
      lat: coords?.lat ?? null,
      lng: coords?.lng ?? null,
      country,
    };
    const { data: inserted, error } = await supabase
      .from("traffic_reports")
      .insert(row)
      // Never select user_id or precise lat/lng — reporter identity must not travel to other clients.
      .select("id, area, severity, notes, lat_coarse, lng_coarse, country, created_at")
      .single();
    setBusy(false);

    if (error) {
      toast.error(
        error.message?.includes("rate_limited")
          ? "بلاغات كتير في وقت قصير — استنى شوية وحاول تاني"
          : "تعذّر إرسال البلاغ، حاول مرة أخرى",
      );
      return;
    }
    if (inserted) {
      pubsub.publish(`traffic_reports/${country}`, "insert", inserted);
      pubsub.publish("traffic_reports", "insert", inserted);
    }
    toast.success("تم استلام بلاغك — شكراً 🙏");
    setArea("");
    setNotes("");
    setSeverity("heavy");
    onOpenChange(false);
    onSubmitted();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent dir="rtl" className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>أبلغ عن زحمة</DialogTitle>
          <DialogDescription>
            البلاغ يساعد جيرانك يختاروا أفضل طريق. ينتهي تلقائياً بعد 4 ساعات.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label htmlFor="area">المنطقة أو الشارع</Label>
            <Input
              id="area"
              value={area}
              onChange={(e) => setArea(e.target.value)}
              placeholder="مثال: ميدان لبنان"
              maxLength={120}
            />
          </div>

          <div>
            <Label className="mb-2 block">شدة الزحمة</Label>
            <div className="grid grid-cols-4 gap-2">
              {SEVERITIES.map((s) => (
                <button
                  key={s.value}
                  type="button"
                  onClick={() => setSeverity(s.value)}
                  className={`flex flex-col items-center gap-1 rounded-md border p-2 text-xs transition ${
                    severity === s.value
                      ? "border-primary bg-primary/10 font-bold"
                      : "border-border hover:bg-muted"
                  }`}
                >
                  <span className="text-lg">{s.emoji}</span>
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="notes">ملاحظات (اختياري)</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="حادثة، تحويلة، شغل في الطريق..."
              maxLength={280}
              rows={3}
            />
            <div className="mt-1 text-left text-[10px] text-muted-foreground">
              {notes.length}/280
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={busy}>
            إلغاء
          </Button>
          <Button onClick={submit} disabled={busy} className="gap-1">
            {busy && <Loader2 className="size-3.5 animate-spin" />}
            إرسال البلاغ
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
