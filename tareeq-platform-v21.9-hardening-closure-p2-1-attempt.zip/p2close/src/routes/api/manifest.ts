import { createFileRoute } from "@tanstack/react-router";

// المانيفست يُقدَّم من هنا بنوع MIME الصحيح لضمان تفعيل PWA.
// الاستضافة الافتراضية تُقدّم /manifest.webmanifest كـ application/octet-stream
// فيرفضه المتصفح ولا يظهر زر التثبيت.
const MANIFEST = {
  name: "طريق — دليل النقل في شمال أفريقيا والمشرق",
  short_name: "طريق",
  description:
    "دليل خطوط ومواقف النقل العام في مصر والمغرب والجزائر وتونس وليبيا والعراق وسوريا واليمن والسودان — يعمل بدون إنترنت.",
  lang: "ar",
  dir: "rtl",
  start_url: "/",
  id: "/",
  scope: "/",
  display: "standalone",
  display_override: ["standalone", "minimal-ui"],
  orientation: "portrait",
  background_color: "#0d4f53",
  theme_color: "#0d4f53",
  icons: [
    { src: "/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
    { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
    { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
  ],
  shortcuts: [
    {
      name: "مصر",
      short_name: "مصر",
      url: "/",
      icons: [{ src: "/icon-192.png", sizes: "192x192" }],
    },
    {
      name: "المغرب",
      short_name: "المغرب",
      url: "/ma",
      icons: [{ src: "/icon-192.png", sizes: "192x192" }],
    },
    {
      name: "الجزائر",
      short_name: "الجزائر",
      url: "/dz",
      icons: [{ src: "/icon-192.png", sizes: "192x192" }],
    },
    {
      name: "تونس",
      short_name: "تونس",
      url: "/tn",
      icons: [{ src: "/icon-192.png", sizes: "192x192" }],
    },
    {
      name: "ليبيا",
      short_name: "ليبيا",
      url: "/ly",
      icons: [{ src: "/icon-192.png", sizes: "192x192" }],
    },
    {
      name: "العراق",
      short_name: "العراق",
      url: "/iq",
      icons: [{ src: "/icon-192.png", sizes: "192x192" }],
    },
  ],
  categories: ["travel", "navigation", "utilities"],
};

export const Route = createFileRoute("/api/manifest")({
  server: {
    handlers: {
      GET: () =>
        new Response(JSON.stringify(MANIFEST), {
          status: 200,
          headers: {
            "content-type": "application/manifest+json; charset=utf-8",
            "cache-control": "public, max-age=3600",
          },
        }),
    },
  },
});
