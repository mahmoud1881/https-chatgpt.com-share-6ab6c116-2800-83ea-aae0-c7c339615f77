import { createFileRoute } from "@tanstack/react-router";

/**
 * Retained only as a compatibility endpoint for old deployments.
 * Server-side AI/embedding warmup was intentionally removed.
 */
export const Route = createFileRoute("/api/public/warmup-stops-embeddings")({
  server: {
    handlers: {
      POST: async () => new Response("server_side_ai_disabled", { status: 410 }),
    },
  },
});
