/**
 * ✅ تحسين Brotli: يخدم ملفات البيانات الثابتة مضغوطة مسبقًا (q=11)
 * عند تطابق Accept-Encoding، وإلا يرجع للملف العادي.
 *
 * المسار العام: /api/public/data/:file  (مثال: /api/public/data/cairo-stations.compact.json)
 *
 * - يقرأ من public/data
 * - يدعم br و gzip حسب أولوية المتصفح
 * - Cache-Control طويل (أسبوع) + immutable
 * - حماية: filename whitelist regex (لا path traversal)
 * - ✅ كاش في الذاكرة: الملفات ثابتة (immutable) فلا داعي لقراءتها من
 *   القرص في كل طلب. LRU بسيط محدود بعدد الإدخالات لمنع تسرّب الذاكرة.
 */
import { createFileRoute } from "@tanstack/react-router";
import { readFile } from "node:fs/promises";
import { join } from "node:path";

const SAFE_NAME = /^[a-z0-9][a-z0-9._-]{0,80}\.compact\.json$/i;

// Module-scoped cache: path → Uint8Array | null (null = confirmed missing).
// Bound to CACHE_MAX entries so a burst of unique 404s can't grow unbounded.
const CACHE_MAX = 64;
const fileCache = new Map<string, Uint8Array | null>();

async function tryRead(path: string): Promise<Uint8Array | null> {
  const hit = fileCache.get(path);
  if (hit !== undefined) {
    // LRU touch
    fileCache.delete(path);
    fileCache.set(path, hit);
    return hit;
  }
  let value: Uint8Array | null;
  try {
    const b = await readFile(path);
    value = new Uint8Array(b);
  } catch {
    value = null;
  }
  if (fileCache.size >= CACHE_MAX) {
    const oldest = fileCache.keys().next().value;
    if (oldest !== undefined) fileCache.delete(oldest);
  }
  fileCache.set(path, value);
  return value;
}

export const Route = createFileRoute("/api/public/data/$file")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        const file = params.file;
        if (!SAFE_NAME.test(file)) {
          return new Response("Bad request", { status: 400 });
        }
        const base = join(process.cwd(), "public", "data", file);
        const accept = (request.headers.get("accept-encoding") || "").toLowerCase();

        const headers: Record<string, string> = {
          "Content-Type": "application/json; charset=utf-8",
          "Cache-Control": "public, max-age=604800, stale-while-revalidate=86400, immutable",
          // Wildcard CORS is intentional here: this route serves only static,
          // non-sensitive, filename-allowlisted (`SAFE_NAME`) public data.
          // Do NOT copy this pattern to any endpoint that reads user state,
          // secrets, or performs writes.
          "Access-Control-Allow-Origin": "*",
          Vary: "Accept-Encoding",
        };

        if (accept.includes("br")) {
          const buf = await tryRead(base + ".br");
          if (buf) {
            headers["Content-Encoding"] = "br";
            return new Response(buf.buffer as ArrayBuffer, { headers });
          }
        }
        if (accept.includes("gzip")) {
          const buf = await tryRead(base + ".gz");
          if (buf) {
            headers["Content-Encoding"] = "gzip";
            return new Response(buf.buffer as ArrayBuffer, { headers });
          }
        }
        const buf = await tryRead(base);
        if (!buf) return new Response("Not found", { status: 404 });
        return new Response(buf.buffer as ArrayBuffer, { headers });
      },
    },
  },
});
