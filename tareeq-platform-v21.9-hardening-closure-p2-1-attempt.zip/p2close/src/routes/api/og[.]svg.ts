// Dynamic OG image generator — returns SVG (no native deps, edge-friendly).
// Usage: /api/og.svg?title=...&subtitle=...&badge=🇪🇬
import { createFileRoute } from "@tanstack/react-router";

function escapeXml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function wrapLines(text: string, maxChars: number, maxLines = 3): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let cur = "";
  for (const w of words) {
    if ((cur + " " + w).trim().length > maxChars) {
      if (cur) lines.push(cur);
      cur = w;
      if (lines.length === maxLines - 1) break;
    } else {
      cur = (cur + " " + w).trim();
    }
  }
  if (cur && lines.length < maxLines) lines.push(cur);
  return lines;
}

export const Route = createFileRoute("/api/og.svg")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const title = url.searchParams.get("title") ?? "مواصلات مصر و المغرب";
        const subtitle = url.searchParams.get("subtitle") ?? "";
        const badge = url.searchParams.get("badge") ?? "🚌";
        const theme = url.searchParams.get("theme") ?? "eg"; // eg | ma | ly | dz | tn

        const palettes: Record<string, [string, string]> = {
          eg: ["#0a6b2f", "#d4af37"],
          ma: ["#c1272d", "#006233"],
          ly: ["#000000", "#239e46"],
          dz: ["#006233", "#d21034"],
          tn: ["#e70013", "#000000"],
        };
        const [gradFrom, gradTo] = palettes[theme] ?? palettes.eg;

        const titleLines = wrapLines(title, 28, 3);

        const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${gradFrom}"/>
      <stop offset="100%" stop-color="${gradTo}"/>
    </linearGradient>
  </defs>
  <rect width="1200" height="630" fill="url(#g)"/>
  <rect x="40" y="40" width="1120" height="550" rx="32" fill="rgba(0,0,0,0.25)" stroke="rgba(255,255,255,0.2)" stroke-width="2"/>
  <text x="100" y="160" font-family="Tahoma, Arial" font-size="84" fill="white">${escapeXml(badge)}</text>
  ${titleLines
    .map(
      (line, i) =>
        `<text x="100" y="${290 + i * 80}" font-family="Tahoma, Arial, sans-serif" font-size="64" font-weight="700" fill="white" direction="rtl">${escapeXml(line)}</text>`,
    )
    .join("\n  ")}
  ${
    subtitle
      ? `<text x="100" y="540" font-family="Tahoma, Arial, sans-serif" font-size="32" fill="rgba(255,255,255,0.85)" direction="rtl">${escapeXml(subtitle)}</text>`
      : ""
  }
  <text x="1100" y="560" text-anchor="end" font-family="Arial" font-size="28" fill="rgba(255,255,255,0.75)">tariq.app</text>
</svg>`;

        return new Response(svg, {
          headers: {
            "Content-Type": "image/svg+xml; charset=utf-8",
            "Cache-Control": "public, max-age=86400, s-maxage=86400",
          },
        });
      },
    },
  },
});
