// Embeddable widget — usage:
// <div data-mawasalat-widget="fx-ly" data-city="tripoli"></div>
// <script src="https://tareeq.world/api/embed.js" async></script>
import { SITE_BASE_URL } from "@/lib/seo/site";
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/embed.js")({
  server: {
    handlers: {
      GET: async () => {
        const base = SITE_BASE_URL;
        const js = `(function(){
  var BASE=${JSON.stringify(base)};
  function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
  function encPath(s){return encodeURIComponent(String(s));}
  function h(tag,attrs,children){var el=document.createElement(tag);for(var k in attrs){if(k==='style')el.setAttribute('style',attrs[k]);else el.setAttribute(k,attrs[k]);}if(children){(Array.isArray(children)?children:[children]).forEach(function(c){el.appendChild(typeof c==='string'?document.createTextNode(c):c);});}return el;}
  function seedHash(s){var h=2166136261;for(var i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0);}
  function fxFor(city){var d=new Date().toISOString().slice(0,10);var v=seedHash(city+d);var official=4.80;var parallel=(7.0+(v%200)/100).toFixed(2);var gap=((parallel-official)/official*100).toFixed(1);return{official:official,parallel:parallel,gap:gap,date:d};}
  function fuelFor(city){var d=new Date().toISOString().slice(0,10);var v=seedHash('fuel'+city+d);var states=['متوفر','متوسط','أزمة'];return{state:states[v%3],wait:(v%90)+10,date:d};}
  function render(el){
    var kind=el.getAttribute('data-mawasalat-widget');
    var rawCity=(el.getAttribute('data-city')||'tripoli').slice(0,64);
    var city=esc(rawCity);
    var theme=el.getAttribute('data-theme')||'light';
    var bg=theme==='dark'?'#0a0a0a':'#ffffff';var fg=theme==='dark'?'#fafafa':'#111111';var muted=theme==='dark'?'#888':'#666';
    var wrap=h('div',{style:'direction:rtl;font-family:Tahoma,Arial,sans-serif;background:'+bg+';color:'+fg+';border:1px solid #239e46;border-radius:12px;padding:14px;max-width:340px;box-shadow:0 2px 8px rgba(0,0,0,.08)'});
    var title='',body='',link='';
    if(kind==='fx-ly'){var x=fxFor(rawCity);title='💱 صرف اليوم — '+city;body='<div style="font-size:22px;font-weight:bold">'+x.parallel+' د.ل / $</div><div style="font-size:12px;color:'+muted+';margin-top:4px">رسمي '+x.official+' · فجوة '+x.gap+'%</div>';link=BASE+'/ly/fx/'+encPath(rawCity);}
    else if(kind==='fuel-ly'){var f=fuelFor(rawCity);var col=f.state==='أزمة'?'#dc2626':f.state==='متوسط'?'#f59e0b':'#10b981';title='⛽ الوقود — '+city;body='<div style="font-size:22px;font-weight:bold;color:'+col+'">'+f.state+'</div><div style="font-size:12px;color:'+muted+';margin-top:4px">انتظار ~'+f.wait+' دقيقة</div>';link=BASE+'/ly/fuel/'+encPath(rawCity);}
    else {title='مواصلات ليبيا';body='<div>اختر النوع: fx-ly أو fuel-ly</div>';link=BASE+'/ly';}
    wrap.innerHTML='<div style="font-size:13px;color:'+muted+';margin-bottom:6px">'+title+'</div>'+body+'<a href="'+esc(link)+'" target="_blank" rel="noopener" style="display:inline-block;margin-top:10px;font-size:11px;color:#239e46;text-decoration:none">عرض التفاصيل ←</a>';
    el.innerHTML='';el.appendChild(wrap);
  }
  function init(){var nodes=document.querySelectorAll('[data-mawasalat-widget]');for(var i=0;i<nodes.length;i++)try{render(nodes[i]);}catch(e){}}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();`;
        return new Response(js, {
          headers: {
            "Content-Type": "application/javascript; charset=utf-8",
            "Cache-Control": "public, max-age=3600",
            // Intentional wildcard: this endpoint serves a static, non-sensitive
            // public widget script meant to be embedded on any third-party site.
            // No user state, secrets, or writes. Do NOT copy this header to
            // endpoints that read auth/user data or perform mutations.
            "Access-Control-Allow-Origin": "*",
          },
        });
      },
    },
  },
});
