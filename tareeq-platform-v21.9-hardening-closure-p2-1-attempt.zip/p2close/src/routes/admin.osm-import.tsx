import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Loader2, Download, Eye, MapPin, RefreshCw } from "lucide-react";
import { FloatingHomeButton } from "@/components/FloatingHomeButton";
import {
  previewOsmImport,
  importOsmStations,
  listOsmGovernorates,
} from "@/lib/route-planner/osm-import.functions";

export const Route = createFileRoute("/admin/osm-import")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "استيراد محطات من OpenStreetMap — Tareeq Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: OsmImportPage,
});

type ModeId = "metro" | "train" | "tram" | "bus";
type PreviewResult = Awaited<ReturnType<typeof previewOsmImport>>;

function OsmImportPage() {
  const [meta, setMeta] = useState<Awaited<ReturnType<typeof listOsmGovernorates>> | null>(null);
  const [governorate, setGovernorate] = useState<string>("cairo");
  const [mode, setMode] = useState<ModeId>("metro");
  const [preview, setPreview] = useState<PreviewResult | null>(null);
  const [busy, setBusy] = useState<"preview" | "import" | null>(null);

  const listMeta = useServerFn(listOsmGovernorates);
  const runPreview = useServerFn(previewOsmImport);
  const runImport = useServerFn(importOsmStations);

  useEffect(() => {
    (async () => {
      try {
        const m = await listMeta();
        setMeta(m);
      } catch (e) {
        toast.error(`تعذّر تحميل القوائم: ${(e as Error).message}`);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function doPreview() {
    setBusy("preview");
    setPreview(null);
    try {
      const r = await runPreview({ data: { governorateId: governorate, mode } });
      setPreview(r);
      toast.success(`جُلبت ${r.fetched} محطة — ${r.willInsert} جديدة`);
    } catch (e) {
      toast.error(`فشل الجلب: ${(e as Error).message}`);
    } finally {
      setBusy(null);
    }
  }

  async function doImport() {
    if (!preview || preview.willInsert === 0) return;
    if (!confirm(`سيتم إضافة ${preview.willInsert} محطة جديدة إلى قاعدة البيانات. متابعة؟`)) return;
    setBusy("import");
    try {
      const r = await runImport({ data: { governorateId: governorate, mode } });
      toast.success(`تمت إضافة ${r.inserted} محطة، تخطّي ${r.skipped}`);
      setPreview(null);
    } catch (e) {
      toast.error(`فشل الاستيراد: ${(e as Error).message}`);
    } finally {
      setBusy(null);
    }
  }

  if (!meta) {
    return (
      <div className="min-h-screen grid place-items-center bg-slate-950 text-slate-300">
        <Loader2 className="w-6 h-6 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 pb-20" dir="rtl">
      <FloatingHomeButton />
      <div className="max-w-4xl mx-auto space-y-6">
        <header>
          <h1 className="text-2xl font-bold">استيراد محطات من OpenStreetMap</h1>
          <p className="text-sm text-slate-400 mt-1">
            سحب محطات المواصلات العامة من OSM لكل محافظة ووسيلة، مع فحص تلقائي للتكرار قبل الإضافة.
          </p>
        </header>

        <div className="rounded-xl border border-slate-800 bg-slate-900 p-4 space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="block">
              <span className="text-xs text-slate-400">المحافظة</span>
              <select
                value={governorate}
                onChange={(e) => setGovernorate(e.target.value)}
                className="mt-1 w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-sm"
              >
                {meta.governorates.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name_ar}
                  </option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="text-xs text-slate-400">نوع المواصلة</span>
              <select
                value={mode}
                onChange={(e) => setMode(e.target.value as ModeId)}
                className="mt-1 w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-sm"
              >
                {meta.modes.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.label_ar}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={doPreview}
              disabled={busy !== null}
              className="px-3 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-sm flex items-center gap-2"
            >
              {busy === "preview" ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Eye className="w-4 h-4" />
              )}
              معاينة
            </button>
            <button
              onClick={doImport}
              disabled={busy !== null || !preview || preview.willInsert === 0}
              className="px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-sm flex items-center gap-2"
            >
              {busy === "import" ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Download className="w-4 h-4" />
              )}
              استيراد {preview ? `(${preview.willInsert})` : ""}
            </button>
            {preview && (
              <button
                onClick={() => setPreview(null)}
                className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-sm flex items-center gap-2"
              >
                <RefreshCw className="w-4 h-4" /> إعادة تعيين
              </button>
            )}
          </div>
        </div>

        {preview && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-3">
              <Stat label="جُلبت" value={preview.fetched} tone="slate" />
              <Stat label="جديدة" value={preview.willInsert} tone="emerald" />
              <Stat label="مكررة" value={preview.willSkip} tone="amber" />
            </div>

            <section className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-4">
              <h2 className="text-sm font-semibold mb-2 text-emerald-300">
                عيّنة من المحطات الجديدة (أول {preview.samplesInsert.length})
              </h2>
              {preview.samplesInsert.length === 0 ? (
                <p className="text-xs text-slate-400">لا توجد محطات جديدة — كل النتائج مكررة.</p>
              ) : (
                <ul className="space-y-1.5 text-sm">
                  {preview.samplesInsert.map((s, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span className="font-medium">{s.name_ar}</span>
                      {s.name_en && <span className="text-xs text-slate-400">({s.name_en})</span>}
                      {s.area && <span className="text-xs text-slate-500">— {s.area}</span>}
                    </li>
                  ))}
                </ul>
              )}
            </section>

            {preview.samplesSkip.length > 0 && (
              <section className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4">
                <h2 className="text-sm font-semibold mb-2 text-amber-300">
                  عيّنة من المكررات (أول {preview.samplesSkip.length})
                </h2>
                <ul className="space-y-1 text-sm">
                  {preview.samplesSkip.map((s, i) => (
                    <li key={i} className="text-slate-300">
                      {s.name_ar}
                      <span className="text-xs text-slate-500 mr-2">
                        {s.reason === "near_existing" ? "قريبة من محطة موجودة" : "اسم مكرر"}
                      </span>
                    </li>
                  ))}
                </ul>
              </section>
            )}
          </div>
        )}

        <div className="rounded-xl border border-slate-700 bg-slate-900/50 p-4 text-xs text-slate-400 leading-relaxed">
          <p>
            <strong className="text-slate-300">كيف يعمل الاستيراد؟</strong>
          </p>
          <ul className="list-disc list-inside mt-2 space-y-1">
            <li>البيانات تُسحب من OpenStreetMap (Overpass API) للمحافظة والوسيلة المحددة.</li>
            <li>
              يتم تجاهل أي محطة نفس اسمها موجود بالفعل ضمن 500 متر، أو نفس الاسم بدون إحداثيات.
            </li>
            <li>
              المحطات الجديدة تُضاف بعلامة "غير مُدقّقة" وتحتاج مراجعة يدوية قبل ربطها بالخطوط.
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone: "slate" | "emerald" | "amber";
}) {
  const cls =
    tone === "emerald"
      ? "text-emerald-300"
      : tone === "amber"
        ? "text-amber-300"
        : "text-slate-200";
  return (
    <div className="rounded-xl bg-slate-900 border border-slate-800 p-4">
      <div className="text-xs text-slate-400">{label}</div>
      <div className={`text-2xl font-bold mt-1 ${cls}`}>{value.toLocaleString("ar-EG")}</div>
    </div>
  );
}
