import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Search, Sparkles, Loader2, Database, Eye } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { EG_CITIES } from "@/data/cityCatalog";
import { getSnapshots } from "@/lib/local-ai/data-registry";
import { semanticSearch } from "@/lib/local-ai/embedder";

import { AuthGateLoading } from "@/components/AuthGateLoading";
import { useRequireAuth } from "@/hooks/useRequireAuth";

export const Route = createFileRoute("/semantic-search")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "البحث الدلالي — طريقك" },
      {
        name: "description",
        content: "بحث دلالي محلي بالكامل داخل متصفحك بدون خادم AI.",
      },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: SemanticSearchRoute,
});

type Item = {
  id: string;
  title: string;
  text: string;
  source: string;
  kind: "live" | "dark";
  href: string;
};

type Result = Item & { score: number };

function collectItems(): Item[] {
  const live = EG_CITIES.map((c) => ({
    id: `city:${c.slug}`,
    title: c.ar,
    text: `مدينة ${c.ar}${c.rail ? " — بها محطة قطار" : ""}`,
    source: "cities",
    kind: "live" as const,
    href: `/eg/city/${c.slug}`,
  }));

  const dark = getSnapshots().map((s) => ({
    id: `snap:${s.id}`,
    title: s.title,
    text: s.summary,
    source: s.source,
    kind: "dark" as const,
    href: s.href ?? "#",
  }));

  return [...live, ...dark].slice(0, 200);
}

/** بوابة استخدام: يتطلب تسجيل دخول قبل عرض هذه الصفحة (مش مجرد تصفح). */
function SemanticSearchRoute() {
  const authStatus = useRequireAuth();
  if (authStatus !== "authenticated") return <AuthGateLoading />;
  return <SemanticSearchPage />;
}

function SemanticSearchPage() {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [modelLoading, setModelLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [results, setResults] = useState<Result[] | null>(null);

  async function search(e: React.FormEvent) {
    e.preventDefault();
    const q = query.trim();
    if (!q) return;
    setLoading(true);
    setModelLoading(true);
    setError(null);
    try {
      const items = collectItems();
      if (items.length === 0) {
        setError("لا توجد عناصر للبحث فيها بعد.");
        return;
      }
      const hits = await semanticSearch(q, items, (item) => `${item.title} — ${item.text}`, {
        topK: 20,
        minScore: 0.2,
      });
      setResults(hits.map(({ item, score }) => ({ ...item, score })));
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setModelLoading(false);
      setLoading(false);
    }
  }

  const liveHits = results?.filter((r) => r.kind === "live").length ?? 0;
  const darkHits = results?.filter((r) => r.kind === "dark").length ?? 0;

  return (
    <div className="mx-auto max-w-3xl space-y-6 p-6" dir="rtl">
      <header className="space-y-2">
        <h1 className="flex items-center gap-2 text-2xl font-bold">
          <Sparkles className="size-6 text-primary" />
          البحث الدلالي عبر المنصة
        </h1>
        <p className="text-sm text-muted-foreground">
          البحث الدلالي يعمل محليًا داخل متصفحك باستخدام نموذج صغير محفوظ على جهازك. لا يوجد AI
          Server.
        </p>
      </header>

      <form onSubmit={search} className="flex gap-2">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="مثال: وسيلة مباشرة من القاهرة للإسكندرية"
            className="pr-9"
            disabled={loading}
          />
        </div>
        <Button type="submit" disabled={loading || !query.trim()}>
          {loading ? <Loader2 className="size-4 animate-spin" /> : "ابحث"}
        </Button>
      </form>

      {modelLoading && (
        <p className="text-xs text-muted-foreground">يتم تحميل نموذج البحث المحلي لأول مرة…</p>
      )}

      {error && (
        <div className="rounded border border-destructive/50 bg-destructive/10 p-3 text-sm text-destructive">
          {error}
        </div>
      )}

      {results && (
        <div className="flex flex-wrap gap-2 text-xs">
          <Badge variant="outline">إجمالي النتائج: {results.length}</Badge>
          <Badge className="gap-1 bg-emerald-500/10 text-emerald-700 hover:bg-emerald-500/10">
            <Eye className="size-3" /> ظاهرة: {liveHits}
          </Badge>
          <Badge className="gap-1 bg-blue-500/10 text-blue-700 hover:bg-blue-500/10">
            <Database className="size-3" /> محلية: {darkHits}
          </Badge>
        </div>
      )}

      {results && results.length === 0 && !error && (
        <p className="text-sm text-muted-foreground">لا توجد نتائج مطابقة دلاليًا.</p>
      )}

      {results && results.length > 0 && (
        <ul className="space-y-2">
          {results.map((r) => (
            <li
              key={r.id}
              className="flex items-start justify-between gap-3 rounded border p-3 hover:bg-muted/40"
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  {r.kind === "dark" ? (
                    <Database className="size-3.5 shrink-0 text-blue-600" />
                  ) : (
                    <Eye className="size-3.5 shrink-0 text-emerald-600" />
                  )}
                  {r.href && r.href !== "#" ? (
                    <a href={r.href} className="truncate font-medium text-primary hover:underline">
                      {r.title}
                    </a>
                  ) : (
                    <span className="truncate font-medium">{r.title}</span>
                  )}
                </div>
                <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{r.text}</p>
              </div>
              <span className="shrink-0 font-mono text-xs text-muted-foreground">
                {r.score.toFixed(3)}
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
