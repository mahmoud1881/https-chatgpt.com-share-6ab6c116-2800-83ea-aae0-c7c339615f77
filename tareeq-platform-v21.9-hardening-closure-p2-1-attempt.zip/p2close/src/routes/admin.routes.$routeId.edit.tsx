import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { AdminPageShell } from "@/components/admin/AdminPageShell";
import { toast } from "sonner";
import {
  getRouteForEdit,
  reorderRouteStops,
  updateRouteMeta,
  searchStopsForEditor,
} from "@/lib/route-planner/admin-editor.functions";
import { Loader2, GripVertical, X, Plus, CheckCircle2, Save } from "lucide-react";

export const Route = createFileRoute("/admin/routes/$routeId/edit")({
  ssr: false,
  head: () => ({
    meta: [{ title: "تحرير خط — Tareeq Admin" }, { name: "robots", content: "noindex, nofollow" }],
  }),
  component: RouteEditPage,
});

type StopRow = {
  id: string;
  stop_id: string;
  stop_order: number;
  direction: string;
  name_ar: string;
  city: string | null;
  is_verified: boolean;
  latitude: number | null;
  longitude: number | null;
};

type StopSearchResult = {
  id: string;
  name_ar: string;
  city: string | null;
  country: string;
  is_verified: boolean;
};

function RouteEditPage() {
  const { routeId } = Route.useParams();
  const navigate = useNavigate();
  const [route, setRoute] = useState<Awaited<ReturnType<typeof getRoute>>["route"] | null>(null);
  const [stopsForward, setStopsForward] = useState<StopRow[]>([]);
  const [stopsBackward, setStopsBackward] = useState<StopRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [dragIdx, setDragIdx] = useState<{ dir: "forward" | "backward"; idx: number } | null>(null);
  const [dirty, setDirty] = useState(false);

  // Meta editing
  const [meta, setMeta] = useState<{
    route_code: string;
    route_name: string;
    transport_type_id: string;
    estimated_duration: string;
    notes: string;
    is_verified: boolean;
  } | null>(null);

  const getRoute = useServerFn(getRouteForEdit);
  const reorderFn = useServerFn(reorderRouteStops);
  const updateMeta = useServerFn(updateRouteMeta);
  const searchFn = useServerFn(searchStopsForEditor);
  useEffect(() => {
    (async () => {
      await load();
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    setLoading(true);
    try {
      const res = await getRoute({ data: { routeId } });
      setRoute(res.route);
      setStopsForward((res.stops as StopRow[]).filter((s) => s.direction === "forward"));
      setStopsBackward((res.stops as StopRow[]).filter((s) => s.direction === "backward"));
      setMeta({
        route_code: res.route?.route_code ?? "",
        route_name: res.route?.route_name ?? "",
        transport_type_id: res.route?.transport_type_id ?? "",
        estimated_duration: res.route?.estimated_duration?.toString() ?? "",
        notes: res.route?.notes ?? "",
        is_verified: !!res.route?.is_verified,
      });
      setDirty(false);
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  function moveItem(dir: "forward" | "backward", from: number, to: number) {
    const setter = dir === "forward" ? setStopsForward : setStopsBackward;
    setter((list) => {
      const copy = [...list];
      const [item] = copy.splice(from, 1);
      copy.splice(to, 0, item);
      return copy;
    });
    setDirty(true);
  }

  function removeStop(dir: "forward" | "backward", idx: number) {
    const setter = dir === "forward" ? setStopsForward : setStopsBackward;
    setter((list) => list.filter((_, i) => i !== idx));
    setDirty(true);
  }

  async function saveDirection(dir: "forward" | "backward") {
    const list = dir === "forward" ? stopsForward : stopsBackward;
    setSaving(true);
    try {
      await reorderFn({
        data: {
          routeId,
          direction: dir,
          orderedStopIds: list.map((s) => s.stop_id),
        },
      });
      toast.success(`تم حفظ ترتيب ${dir === "forward" ? "الذهاب" : "الرجوع"}`);
      setDirty(false);
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setSaving(false);
    }
  }

  async function saveMeta() {
    if (!meta) return;
    setSaving(true);
    try {
      await updateMeta({
        data: {
          routeId,
          patch: {
            route_code: meta.route_code || null,
            route_name: meta.route_name,
            transport_type_id: meta.transport_type_id || null,
            estimated_duration: meta.estimated_duration ? Number(meta.estimated_duration) : null,
            notes: meta.notes || null,
            is_verified: meta.is_verified,
          },
        },
      });
      toast.success("تم حفظ بيانات الخط");
      setRoute((prev) =>
        prev
          ? {
              ...prev,
              route_code: meta.route_code || null,
              route_name: meta.route_name,
              transport_type_id: meta.transport_type_id || null,
              estimated_duration: meta.estimated_duration ? Number(meta.estimated_duration) : null,
              notes: meta.notes || null,
              is_verified: meta.is_verified,
            }
          : prev,
      );
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setSaving(false);
    }
  }

  if (loading)
    return (
      <div dir="rtl" className="min-h-screen grid place-items-center">
        <Loader2 className="w-6 h-6 animate-spin" />
      </div>
    );
  if (!route || !meta) return null;

  return (
    <AdminPageShell wrapperClassName="min-h-screen bg-gradient-to-b from-background to-muted/30 pb-24">
      <header className="px-4 pt-6 pb-3">
        <Link to="/admin/routes" className="text-xs underline text-muted-foreground">
          ← قائمة الخطوط
        </Link>
        <h1 className="text-lg font-bold mt-2 flex items-center justify-between gap-2">
          <span className="truncate">{route.route_name}</span>
          {route.is_verified && <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />}
        </h1>
        <div className="text-[10px] text-muted-foreground">
          {route.country} · {route.city ?? "—"} · {route.route_code ?? "بدون رقم"}
        </div>
      </header>

      {/* Meta editor */}
      <section className="px-4">
        <div className="rounded-2xl border bg-card p-3 space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <LabeledInput
              label="اسم الخط"
              value={meta.route_name}
              onChange={(v) => setMeta({ ...meta, route_name: v })}
            />
            <LabeledInput
              label="رقم الخط"
              value={meta.route_code}
              onChange={(v) => setMeta({ ...meta, route_code: v })}
            />
            <LabeledInput
              label="نوع النقل"
              value={meta.transport_type_id}
              onChange={(v) => setMeta({ ...meta, transport_type_id: v })}
              placeholder="bus / metro / shared_taxi..."
            />
            <LabeledInput
              label="المدة (دقيقة)"
              value={meta.estimated_duration}
              onChange={(v) => setMeta({ ...meta, estimated_duration: v })}
              type="number"
            />
          </div>
          <div>
            <label className="text-[10px] text-muted-foreground">ملاحظات</label>
            <textarea
              value={meta.notes}
              onChange={(e) => setMeta({ ...meta, notes: e.target.value })}
              rows={2}
              className="w-full bg-background rounded-xl border px-2 py-1.5 text-xs"
            />
          </div>
          <label className="flex items-center gap-2 text-xs">
            <input
              type="checkbox"
              checked={meta.is_verified}
              onChange={(e) => setMeta({ ...meta, is_verified: e.target.checked })}
            />
            موثّق (يظهر للجمهور)
          </label>
          <button
            onClick={saveMeta}
            disabled={saving}
            className="w-full rounded-xl bg-primary text-primary-foreground py-2 text-xs font-bold disabled:opacity-50"
          >
            {saving ? (
              <Loader2 className="w-3 h-3 inline animate-spin" />
            ) : (
              <Save className="w-3 h-3 inline" />
            )}{" "}
            حفظ بيانات الخط
          </button>
        </div>
      </section>

      {/* Forward stops */}
      <DirectionSection
        title="محطات الذهاب"
        dir="forward"
        stops={stopsForward}
        onMove={(from, to) => moveItem("forward", from, to)}
        onRemove={(idx) => removeStop("forward", idx)}
        onAdd={(s) => {
          setStopsForward((list) => [
            ...list,
            {
              ...s,
              id: "",
              stop_id: s.id,
              stop_order: list.length,
              direction: "forward",
              is_verified: s.is_verified,
              latitude: null,
              longitude: null,
              city: s.city,
            },
          ]);
          setDirty(true);
        }}
        onSave={() => saveDirection("forward")}
        saving={saving}
        dragIdx={dragIdx?.dir === "forward" ? dragIdx.idx : null}
        setDragIdx={(i) => setDragIdx(i == null ? null : { dir: "forward", idx: i })}
        country={route.country}
        searchFn={async (q) => (await searchFn({ data: { q, country: route.country } })).rows}
      />

      {/* Backward stops */}
      <DirectionSection
        title="محطات الرجوع"
        dir="backward"
        stops={stopsBackward}
        onMove={(from, to) => moveItem("backward", from, to)}
        onRemove={(idx) => removeStop("backward", idx)}
        onAdd={(s) => {
          setStopsBackward((list) => [
            ...list,
            {
              ...s,
              id: "",
              stop_id: s.id,
              stop_order: list.length,
              direction: "backward",
              is_verified: s.is_verified,
              latitude: null,
              longitude: null,
              city: s.city,
            },
          ]);
          setDirty(true);
        }}
        onSave={() => saveDirection("backward")}
        saving={saving}
        dragIdx={dragIdx?.dir === "backward" ? dragIdx.idx : null}
        setDragIdx={(i) => setDragIdx(i == null ? null : { dir: "backward", idx: i })}
        emptyHint="اترك فارغة إذا الخط باتجاه واحد فقط."
        country={route.country}
        searchFn={async (q) => (await searchFn({ data: { q, country: route.country } })).rows}
      />

      {dirty && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 rounded-full bg-amber-500 text-white text-xs px-4 py-2 shadow-lg">
          هناك تغييرات غير محفوظة — لا تنسَ الحفظ
        </div>
      )}
    </AdminPageShell>
  );
}

function LabeledInput({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <div>
      <label className="text-[10px] text-muted-foreground">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-background rounded-xl border px-2 py-1.5 text-xs"
      />
    </div>
  );
}

function DirectionSection({
  title,
  dir,
  stops,
  onMove,
  onRemove,
  onAdd,
  onSave,
  saving,
  dragIdx,
  setDragIdx,
  emptyHint,
  country,
  searchFn,
}: {
  title: string;
  dir: "forward" | "backward";
  stops: StopRow[];
  onMove: (from: number, to: number) => void;
  onRemove: (idx: number) => void;
  onAdd: (s: {
    id: string;
    name_ar: string;
    city: string | null;
    country: string;
    is_verified: boolean;
  }) => void;
  onSave: () => void;
  saving: boolean;
  dragIdx: number | null;
  setDragIdx: (i: number | null) => void;
  emptyHint?: string;
  country: string;
  searchFn: (q: string) => Promise<StopSearchResult[]>;
}) {
  const [picking, setPicking] = useState(false);
  const [q, setQ] = useState("");
  const [results, setResults] = useState<StopSearchResult[]>([]);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    if (!picking) return;
    const t = setTimeout(async () => {
      if (!q.trim()) return setResults([]);
      setSearching(true);
      try {
        setResults(await searchFn(q.trim()));
      } finally {
        setSearching(false);
      }
    }, 250);
    return () => clearTimeout(t);
  }, [q, picking, searchFn]);

  return (
    <section className="px-4 mt-4">
      <div className="rounded-2xl border bg-card p-3">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-bold">{title}</h3>
          <div className="flex gap-1">
            <button
              onClick={() => setPicking(true)}
              className="text-[11px] rounded-full border px-2.5 py-1 hover:bg-muted"
            >
              <Plus className="w-3 h-3 inline" /> إضافة
            </button>
            <button
              onClick={onSave}
              disabled={saving}
              className="text-[11px] rounded-full bg-primary text-primary-foreground px-2.5 py-1 disabled:opacity-50"
            >
              {saving ? (
                <Loader2 className="w-3 h-3 inline animate-spin" />
              ) : (
                <Save className="w-3 h-3 inline" />
              )}{" "}
              حفظ الترتيب
            </button>
          </div>
        </div>
        {stops.length === 0 ? (
          <p className="text-[11px] text-muted-foreground text-center py-4">
            {emptyHint ?? "لا توجد محطات"}
          </p>
        ) : (
          <ol className="space-y-1">
            {stops.map((s, idx) => (
              <li
                key={`${s.stop_id}-${idx}`}
                draggable
                onDragStart={() => setDragIdx(idx)}
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => {
                  if (dragIdx != null && dragIdx !== idx) onMove(dragIdx, idx);
                  setDragIdx(null);
                }}
                className={`flex items-center gap-2 rounded-lg border bg-background p-2 ${dragIdx === idx ? "opacity-40" : ""}`}
              >
                <GripVertical className="w-3.5 h-3.5 text-muted-foreground cursor-grab" />
                <span className="text-[10px] font-mono text-muted-foreground w-5 text-center">
                  {idx + 1}
                </span>
                <span className="flex-1 text-sm truncate">
                  {s.name_ar}
                  {s.city && <span className="text-[10px] text-muted-foreground"> — {s.city}</span>}
                </span>
                {s.latitude != null && <span className="text-[10px] text-emerald-600">📍</span>}
                {s.is_verified && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
                <button
                  onClick={() => onRemove(idx)}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </li>
            ))}
          </ol>
        )}
      </div>

      {picking && (
        <div
          dir="rtl"
          className="fixed inset-0 z-50 bg-black/50 grid place-items-end sm:place-items-center p-3"
        >
          <div className="w-full max-w-md bg-card rounded-2xl border p-3 space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold">إضافة محطة لـ {title}</h3>
              <button onClick={() => setPicking(false)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={`ابحث بالاسم في ${country}...`}
              className="w-full bg-background rounded-xl border px-3 py-2 text-sm"
            />
            <div className="max-h-72 overflow-y-auto space-y-1">
              {searching && (
                <div className="text-center py-2">
                  <Loader2 className="w-3 h-3 inline animate-spin" />
                </div>
              )}
              {!searching && results.length === 0 && q && (
                <p className="text-xs text-muted-foreground text-center py-4">لا نتائج</p>
              )}
              {results.map((s) => (
                <button
                  key={s.id}
                  onClick={() => {
                    onAdd(s);
                    setPicking(false);
                    setQ("");
                    setResults([]);
                  }}
                  className="w-full text-right rounded-lg border p-2 hover:bg-muted flex items-center justify-between"
                >
                  <span className="text-sm">
                    {s.name_ar}
                    {s.city && (
                      <span className="text-[10px] text-muted-foreground"> — {s.city}</span>
                    )}
                  </span>
                  {s.is_verified && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
