import { SITE_BASE_URL } from "@/lib/seo/site";
import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "شروط الاستخدام — مواصلات مصر" },
      {
        name: "description",
        content:
          "الشروط التي تحكم استخدامك لتطبيق مواصلات مصر: دقة البيانات، المسؤولية، المساهمات المجتمعية، وحقوق الملكية.",
      },
      { property: "og:title", content: "شروط الاستخدام — مواصلات مصر" },
      {
        property: "og:description",
        content: "قواعد استخدام مواصلات مصر ومسؤولية المستخدم والمنصة.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { rel: "canonical", href: `${SITE_BASE_URL}/terms` } as unknown as {
        name: string;
        content: string;
      },
    ],
  }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <main dir="rtl" className="mx-auto max-w-3xl px-4 py-10 text-right leading-loose">
      <h1 className="text-3xl font-bold text-foreground">شروط الاستخدام</h1>
      <p className="mt-2 text-sm text-muted-foreground">آخر تحديث: 12 يوليو 2026</p>

      <section className="mt-8 space-y-4">
        <h2 className="text-xl font-semibold">قبول الشروط</h2>
        <p className="text-sm">
          باستخدامك موقع «مواصلات مصر» فإنك توافق على هذه الشروط. إن لم توافق، يُرجى التوقف عن
          الاستخدام.
        </p>
      </section>

      <section className="mt-8 space-y-4">
        <h2 className="text-xl font-semibold">طبيعة الخدمة</h2>
        <p className="text-sm">
          نقدّم دليلاً مرجعياً لخطوط ومحطات النقل العام. البيانات مجموعة من مصادر رسمية ومساهمات
          مجتمعية، وقد تتغير أو تصبح غير محدّثة. نُشير بوضوح إلى مصدر كل بيان وتاريخ آخر تحقق.
        </p>
      </section>

      <section className="mt-8 space-y-4">
        <h2 className="text-xl font-semibold">دقة البيانات وحدود المسؤولية</h2>
        <ul className="list-disc space-y-2 pr-6 text-sm">
          <li>نبذل جهدنا في التحقق من صحة البيانات لكن لا نضمن دقتها بنسبة 100%.</li>
          <li>
            لا نتحمل مسؤولية أي خسائر ناتجة عن الاعتماد على معلومات الموقع دون التأكد من الجهة
            الرسمية.
          </li>
          <li>المواعيد قد تتغير — تأكد دائماً من المشغّل الرسمي قبل السفر.</li>
        </ul>
      </section>

      <section className="mt-8 space-y-4">
        <h2 className="text-xl font-semibold">المساهمات المجتمعية</h2>
        <ul className="list-disc space-y-2 pr-6 text-sm">
          <li>عند إضافة خط أو محطة، أنت تُقرّ بأن المعلومات صحيحة على حدّ علمك.</li>
          <li>يُمنع إضافة بيانات مضللة أو مسيئة أو انتهاك حقوق الغير.</li>
          <li>تحتفظ بحقوقك في المحتوى الذي تُساهم به، وتمنحنا ترخيصاً لعرضه على المنصة.</li>
        </ul>
      </section>

      <section className="mt-8 space-y-4">
        <h2 className="text-xl font-semibold">الاستخدام المقبول</h2>
        <ul className="list-disc space-y-2 pr-6 text-sm">
          <li>يُمنع محاولة اختراق الموقع أو تعطيل خدماته.</li>
          <li>يُمنع الاستخراج الآلي (Scraping) بمعدلات تُثقل الخوادم.</li>
          <li>يُمنع استخدام الموقع لأي غرض غير قانوني.</li>
        </ul>
      </section>

      <section className="mt-8 space-y-4">
        <h2 className="text-xl font-semibold">الملكية الفكرية</h2>
        <p className="text-sm">
          اسم «مواصلات مصر» / «Tareeq» والشعار والتصميم مملوكة للمنصة. البيانات العامة (كأسماء
          الخطوط والمحطات) ليست حصرية لأحد.
        </p>
      </section>

      <section className="mt-8 space-y-4">
        <h2 className="text-xl font-semibold">تعديل الشروط</h2>
        <p className="text-sm">
          قد نُحدّث هذه الشروط. سنُشير إلى تاريخ آخر تحديث أعلى الصفحة. الاستمرار في الاستخدام يعني
          قبول التعديلات.
        </p>
      </section>

      <section className="mt-8 space-y-4">
        <h2 className="text-xl font-semibold">التواصل</h2>
        <p className="text-sm">
          لأي استفسار قانوني:{" "}
          <a href="mailto:legal@tareeq.world" className="text-primary underline">
            legal@tareeq.world
          </a>
        </p>
      </section>

      <div className="mt-10 flex flex-wrap gap-3 border-t pt-6 text-sm">
        <Link to="/privacy" className="text-primary hover:underline">
          سياسة الخصوصية
        </Link>
        <span aria-hidden="true">·</span>
        <Link to="/" className="text-primary hover:underline">
          العودة للرئيسية
        </Link>
      </div>
    </main>
  );
}
