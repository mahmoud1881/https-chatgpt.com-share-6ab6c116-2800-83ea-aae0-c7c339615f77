import { createFileRoute, Link } from "@tanstack/react-router";
import { lazy, Suspense, useEffect, useMemo, useRef, useState } from "react";
import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { ArrowRight, Bus, Search, ShieldCheck, X, ChevronLeft, ChevronRight } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { localData } from "@/lib/local-data";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { RouteCard } from "@/components/shared/RouteCard";
import { ListSkeleton } from "@/components/shared/ListSkeleton";
import { CountBadge } from "@/components/shared/CountBadge";
import { SearchInput } from "@/components/shared/SearchInput";
import { MODE_LABEL_AR as MODE_LABEL } from "@/lib/transit/types";
import { loadCairoBusLines } from "@/data/cairoBusLines";
import { loadCairoMinibusLines } from "@/data/cairoMinibusLines";
import { loadMicrobusLines } from "@/data/microbusLines";
import { loadGovBusLines } from "@/data/governorateBusLines";
import { AllBusLinesGrouped } from "@/components/AllBusLinesGrouped";

async function ensureCairoDatasets() {
  await Promise.allSettled([
    loadCairoBusLines(),
    loadCairoMinibusLines(),
    loadMicrobusLines(),
    loadGovBusLines(),
  ]);
}

const CairoStationsDirectory = lazy(() =>
  import("@/components/CairoStationsDirectory").then((m) => ({
    default: m.CairoStationsDirectory,
  })),
);
const BusTerminalsSection = lazy(() =>
  import("@/components/BusTerminalsSection").then((m) => ({ default: m.BusTerminalsSection })),
);

import { egHead, getEgPage } from "@/lib/seo/eg-meta";

export const Route = createFileRoute("/bus-stations")({
  head: () => {
    const p = getEgPage("/bus-stations")!;
    return egHead({
      path: p.path,
      titleAr: p.titleAr,
      descAr: p.descAr,
      ogImage: p.ogImage,
      breadcrumbLabel: "خطوط الأتوبيس",
    });
  },
  component: BusStationsPage,
});

type RouteRow = {
  id: string;
  route_code: string | null;
  transport_mode: string | null;
  origin_name: string | null;
  destination_name: string | null;
  name_ar: string | null;
};

type StopRow = {
  route_id: string;
  sequence_order: number | null;
  stop_name: string | null;
  lat: number | null;
  lng: number | null;
};

const PAGE_SIZE = 25;
const MODE_FILTERS = ["all", "bus", "minibus", "microbus", "bus_minibus", "private_bus", "tram"];

function escapeOr(v: string) {
  // PostgREST .or() requires escaping commas and parens inside values
  return v.replace(/([(),])/g, "\\$1");
}

function BusStationsPage() {
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [mode, setMode] = useState<string>("all");
  const [page, setPage] = useState(0);
  const [linesOnly, setLinesOnly] = useState(false);

  // Debounce with max-wait
  const lastFlush = useRef<number>(Date.now());
  useEffect(() => {
    const sinceFlush = Date.now() - lastFlush.current;
    const delay = Math.max(0, Math.min(250, 600 - sinceFlush));
    const t = setTimeout(() => {
      lastFlush.current = Date.now();
      setSearch(searchInput);
      setPage(0);
    }, delay);
    return () => clearTimeout(t);
  }, [searchInput]);

  // Counts per mode for the header
  const countsQ = useQuery({
    queryKey: ["routes", "counts", "v2"],
    queryFn: async () => {
      await ensureCairoDatasets();
      const modes = ["bus", "minibus", "microbus"];
      const entries = await Promise.all(
        modes.map(async (m) => {
          const { count } = await localData
            .from("transit_routes")
            .select("id", { count: "exact", head: true })
            .eq("transport_mode", m);
          return [m, count ?? 0] as const;
        }),
      );
      return Object.fromEntries(entries) as Record<string, number>;
    },
  });

  // Step 1: when searching, find extra route_ids whose stops match
  const extraIdsQ = useQuery({
    queryKey: ["routes", "stopSearch", search],
    enabled: search.trim().length > 0,
    queryFn: async () => {
      const q = search.trim();
      // ✅ تحسين #1: Bloom pre-check — لو الاسم غير موجود نهائياً في فهرس
      // المواقف/الخطوط المخبأ، نوفّر طلب Supabase فوراً. آمن: يعمل فقط
      // للاستعلامات النصية العربية الطويلة، ولا يتدخّل في أرقام الخطوط.
      if (q.length >= 3 && /[\u0600-\u06FF]/.test(q)) {
        try {
          const { mayHaveName, getStationsBloom } = await import("@/lib/bloom-filter");
          if (getStationsBloom() && !mayHaveName(q)) return [];
        } catch {
          /* noop */
        }
      }
      const { data, error } = await localData
        .from("route_stops_full")
        .select("route_id")
        .ilike("stop_name", `%${q}%`)
        .limit(2000);
      if (error) throw error;
      return Array.from(
        new Set(
          ((data ?? []) as Array<{ route_id: string | null }>)
            .map((r) => r.route_id)
            .filter(Boolean) as string[],
        ),
      );
    },
  });

  // Step 2: main routes query (paginated, filtered)
  const routesQ = useQuery({
    queryKey: ["routes", "list", "v2", mode, search, page, extraIdsQ.data ?? null],
    placeholderData: keepPreviousData,
    queryFn: async () => {
      await ensureCairoDatasets();
      let q = localData
        .from("transit_routes")
        .select("id,route_code,transport_mode,origin_name,destination_name,name_ar", {
          count: "exact",
        });

      if (mode !== "all") q = q.eq("transport_mode", mode);

      const term = search.trim();
      if (term) {
        const e = escapeOr(term);
        const extraIds = extraIdsQ.data ?? [];
        const orParts = [
          `route_code.ilike.%${e}%`,
          `origin_name.ilike.%${e}%`,
          `destination_name.ilike.%${e}%`,
          `name_ar.ilike.%${e}%`,
        ];
        if (extraIds.length > 0) {
          // chunk to avoid URL bloat
          const ids = extraIds
            .slice(0, 300)
            .map((x) => `"${x.replace(/"/g, '\\"')}"`)
            .join(",");
          orParts.push(`id.in.(${ids})`);
        }
        q = q.or(orParts.join(","));
      }

      const from = page * PAGE_SIZE;
      const to = from + PAGE_SIZE - 1;
      const { data, error, count } = await q
        .order("transport_mode", { ascending: true })
        .order("route_code", { ascending: true })
        .range(from, to);
      if (error) throw error;
      return { rows: (data ?? []) as RouteRow[], total: count ?? 0 };
    },
  });

  const visibleIds = useMemo(() => (routesQ.data?.rows ?? []).map((r) => r.id), [routesQ.data]);

  // Step 3: stops for visible routes
  const stopsQ = useQuery({
    queryKey: ["routes", "stops", visibleIds],
    enabled: visibleIds.length > 0,
    queryFn: async () => {
      const { data, error } = await localData
        .from("route_stops_full")
        .select("route_id,sequence_order,stop_name,lat,lng")
        .in("route_id", visibleIds)
        .order("sequence_order", { ascending: true });
      if (error) throw error;
      const byRoute: Record<string, StopRow[]> = {};
      (data ?? []).forEach((s: StopRow) => {
        (byRoute[s.route_id] ??= []).push(s as StopRow);
      });
      return byRoute;
    },
  });

  const total = routesQ.data?.total ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const hasFilter = search !== "" || mode !== "all";

  return (
    <div dir="rtl" className="min-h-screen bg-background px-4 py-10">
      <div className="mx-auto max-w-3xl space-y-6">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowRight className="size-4" />
          العودة للرئيسية
        </Link>

        <header className="space-y-3 text-center">
          <div className="inline-flex items-center justify-center rounded-full bg-primary/10 p-3">
            <Bus className="size-7 text-primary" />
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight md:text-4xl">
            خطوط النقل العام بالقاهرة الكبرى
          </h1>
          <p className="mx-auto max-w-xl text-muted-foreground">
            ابحث برقم الخط أو باسم أي محطة على المسار
          </p>
          <div className="flex flex-wrap justify-center gap-2 pt-1">
            {(["bus", "minibus", "microbus"] as const).map((m) => {
              const labelAr = m === "bus" ? "أتوبيس" : m === "minibus" ? "ميني باص" : "ميكروباص";
              const val = countsQ.data?.[m];
              const status: "loading" | "error" | "success" = countsQ.isLoading
                ? "loading"
                : countsQ.isError
                  ? "error"
                  : "success";
              return (
                <button
                  key={m}
                  type="button"
                  onClick={() => {
                    setMode(m);
                    setPage(0);
                  }}
                  className={`inline-flex items-center gap-1 rounded-full border px-3 py-1 text-xs transition ${mode === m ? "border-primary bg-primary text-primary-foreground" : "border-border bg-secondary text-secondary-foreground hover:bg-accent"}`}
                >
                  {labelAr}{" "}
                  <CountBadge
                    value={typeof val === "number" ? val : null}
                    status={status}
                    onRetry={countsQ.isError ? () => countsQ.refetch() : undefined}
                  />
                </button>
              );
            })}
          </div>
        </header>

        <Card className="p-4 border-primary/40 bg-gradient-to-br from-primary/5 to-transparent">
          <button
            type="button"
            onClick={() => setLinesOnly((v) => !v)}
            aria-expanded={linesOnly}
            className="flex w-full items-center justify-between gap-3 text-right"
          >
            <div className="flex items-center gap-3">
              <div className="rounded-full bg-primary/10 p-2">
                <Bus className="size-5 text-primary" />
              </div>
              <div>
                <h2 className="text-base font-bold text-foreground">الخطوط فقط</h2>
                <p className="text-xs text-muted-foreground">
                  بداية ونهاية كل خط مع كل المحطات على المسار
                </p>
              </div>
            </div>
            <Badge variant={linesOnly ? "default" : "secondary"}>
              {linesOnly ? "مفعّل — اضغط للإخفاء" : "افتح الخطوط"}
            </Badge>
          </button>
        </Card>

        {!linesOnly && (
          <>
            <ErrorBoundary boundary="BusTerminalsSection">
              <Suspense fallback={<ListSkeleton count={2} />}>
                <BusTerminalsSection />
              </Suspense>
            </ErrorBoundary>

            <Card className="space-y-3 p-4">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <h2 className="text-base font-bold text-foreground">
                  مواقف القاهرة الكبرى (القاهرة / الجيزة / القليوبية)
                </h2>
              </div>
              <p className="text-xs text-muted-foreground">
                دليل شامل لمحاور النقل والتجمعات ومحطات الأتوبيس الترددي. لكل موقف يظهر نوع المركبات
                التي تخدمه (أتوبيس / ميني باص / ميكروباص / BRT / أقاليم) — اضغط الاسم للذهاب لموقعه
                على Google Maps.
              </p>
              <ErrorBoundary boundary="CairoStationsDirectory">
                <Suspense
                  fallback={<div className="text-xs text-muted-foreground">جارٍ التحميل…</div>}
                >
                  <CairoStationsDirectory />
                </Suspense>
              </ErrorBoundary>
            </Card>
          </>
        )}

        <Card className="space-y-3 p-4">
          <SearchInput
            value={searchInput}
            onChange={setSearchInput}
            placeholder="مثال: 1003، رمسيس، المنيب، التجمع…"
          />
          <div className="grid gap-2 sm:grid-cols-3">
            <Select
              value={mode}
              onValueChange={(v) => {
                setMode(v);
                setPage(0);
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="نوع التشغيل" />
              </SelectTrigger>
              <SelectContent>
                {MODE_FILTERS.map((m) => (
                  <SelectItem key={m} value={m}>
                    {m === "all" ? "كل الأنواع" : (MODE_LABEL[m] ?? m)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              onClick={() => {
                setSearchInput("");
                setSearch("");
                setMode("all");
                setPage(0);
              }}
              disabled={!hasFilter}
              className="gap-2 sm:col-span-2"
            >
              <X className="size-4" />
              مسح التصفية
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            النتائج: {total} خط{hasFilter ? " (مُصفّاة)" : ""}
            {totalPages > 1 && ` — صفحة ${page + 1} من ${totalPages}`}
          </p>
        </Card>

        {routesQ.error && (
          <Card className="p-6 text-center text-destructive">
            خطأ: {(routesQ.error as Error).message}
          </Card>
        )}

        {routesQ.isLoading && <ListSkeleton count={5} />}

        {!routesQ.isLoading && (routesQ.data?.rows.length ?? 0) === 0 && (
          <Card className="p-8 text-center text-muted-foreground">لا توجد خطوط مطابقة.</Card>
        )}

        <div className="space-y-3">
          {(routesQ.data?.rows ?? []).map((r) => {
            const stops = (stopsQ.data?.[r.id] ?? [])
              .filter((s) => s.stop_name)
              .map((s) => ({ name: s.stop_name as string, lat: s.lat, lng: s.lng }));
            return (
              <RouteCard
                key={r.id}
                id={r.id}
                routeCode={r.route_code}
                transportMode={r.transport_mode}
                originName={r.origin_name}
                destinationName={r.destination_name}
                stops={stops}
              />
            );
          })}
        </div>

        <AllBusLinesGrouped />

        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 pt-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={page === 0}
            >
              <ChevronRight className="size-4" />
              السابق
            </Button>
            <span className="text-sm text-muted-foreground">
              {page + 1} / {totalPages}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
              disabled={page >= totalPages - 1}
            >
              التالي
              <ChevronLeft className="size-4" />
            </Button>
          </div>
        )}

        <div className="flex items-center justify-center gap-2 pt-4 text-xs text-muted-foreground">
          <ShieldCheck className="size-4" />
          نحترم خصوصيتك
        </div>
      </div>
    </div>
  );
}
