import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Search, ArrowRight, MapPin, Bus, Train } from "lucide-react";
import { egHead } from "@/lib/seo/eg-meta";
import {
  EG_GOV_STATIONS,
  loadEgGovStations,
  onEgGovStationsLoaded,
  listEgGovernorates,
  type EgGovStation,
} from "@/data/egGovernorateStations";
import {
  EGYPT_STATIONS,
  loadEgyptStations,
  onEgyptStationsLoaded,
  type EgyptStation,
} from "@/data/egyptStations";
import {
  GOV_BUS_LINES,
  loadGovBusLines,
  onGovBusLinesLoaded,
  type GovBusLine,
} from "@/data/governorateBusLines";
import {
  CAIRO_STATIONS,
  loadCairoStations,
  onCairoStationsLoaded,
  type CairoStation,
} from "@/data/cairoStations";

export const Route = createFileRoute("/eg/explore")({
  head: () =>
    egHead({
      path: "/eg/explore",
      titleAr: "ابحث في مواصلات مصر — خطوط، محطات، مدن",
      descAr: "بحث موحّد عبر خطوط الأتوبيس والميكروباص والمترو والقطارات والمحطات في محافظات مصر.",
      breadcrumbLabel: "بحث",
    }),
  component: ExplorePage,
});

const ALL = "__all__";
const CAIRO_LABEL = "القاهرة الكبرى";

function useEgyptData() {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    loadEgGovStations();
    loadEgyptStations();
    loadGovBusLines();
    loadCairoStations();
    const unsubs = [
      onEgGovStationsLoaded(() => setTick((t) => t + 1)),
      onEgyptStationsLoaded(() => setTick((t) => t + 1)),
      onGovBusLinesLoaded(() => setTick((t) => t + 1)),
      onCairoStationsLoaded(() => setTick((t) => t + 1)),
    ];
    return () => unsubs.forEach((u) => u());
  }, []);
  // return current snapshots (mutable exports; re-read on each tick)
  return {
    tick,
    govStations: EG_GOV_STATIONS,
    egyptStations: EGYPT_STATIONS,
    busLines: GOV_BUS_LINES,
    cairoStations: CAIRO_STATIONS,
  };
}

function ExplorePage() {
  const [q, setQ] = useState("");
  const [gov, setGov] = useState<string>(ALL);
  const { govStations, egyptStations, busLines, cairoStations } = useEgyptData();

  const governorates = useMemo(() => {
    const set = new Set<string>();
    for (const s of govStations) if (s.governorate) set.add(s.governorate);
    for (const s of egyptStations) if (s.governorate) set.add(s.governorate);
    for (const l of busLines) if (l.governorate) set.add(l.governorate);
    for (const c of cairoStations) if (c.gov) set.add(c.gov);
    const arr = Array.from(set).sort((a, b) => a.localeCompare(b, "ar"));
    // ensure Cairo group at top if present
    return arr;
  }, [govStations, egyptStations, busLines, cairoStations]);

  const results = useMemo(() => {
    const t = q.trim();
    const tLower = t.toLowerCase();
    const matchGov = (g?: string | null) => (gov === ALL ? true : (g ?? "") === gov);

    const filterText = (hay: string) => (!t ? true : hay.toLowerCase().includes(tLower));

    const govHits: EgGovStation[] = govStations
      .filter((s) => matchGov(s.governorate))
      .filter((s) =>
        filterText(
          [s.name_ar, s.name_en ?? "", s.city, s.governorate, ...(s.served_areas ?? [])].join(" "),
        ),
      )
      .slice(0, 25);

    const egHits: EgyptStation[] = egyptStations
      .filter((s) => matchGov(s.governorate))
      .filter((s) =>
        filterText(
          [s.name, s.area, s.governorate, ...(s.served_areas ?? []), ...(s.modes ?? [])].join(" "),
        ),
      )
      .slice(0, 25);

    const cairoHits: CairoStation[] = cairoStations
      .filter((s) => matchGov(s.gov))
      .filter((s) =>
        filterText(
          [s.name, s.area, s.gov, s.kind_ar, ...(s.served_areas ?? []), ...(s.modes ?? [])].join(
            " ",
          ),
        ),
      )
      .slice(0, 25);

    const routeHits: GovBusLine[] = busLines
      .filter((l) => matchGov(l.governorate))
      .filter((l) =>
        filterText(
          [
            l.route_code,
            l.name_ar ?? "",
            l.origin_name,
            l.destination_name,
            l.governorate,
            l.transport_mode,
            ...l.stops,
          ].join(" "),
        ),
      )
      .slice(0, 30);

    return { govHits, egHits, cairoHits, routeHits };
  }, [q, gov, govStations, egyptStations, busLines, cairoStations]);

  const totalResults =
    results.govHits.length +
    results.egHits.length +
    results.cairoHits.length +
    results.routeHits.length;

  return (
    <div dir="rtl" className="min-h-screen bg-background pb-10">
      <header className="px-4 pt-5 pb-3 border-b">
        <Link to="/" className="text-xs text-muted-foreground">
          ← مواصلات مصر
        </Link>
        <h1 className="text-xl font-bold mt-2 flex items-center gap-2">
          <Search className="w-5 h-5 text-primary" /> ابحث في مواصلات مصر
        </h1>
        <p className="text-xs text-muted-foreground mt-1">
          خطوط الأتوبيس والميكروباص والمترو والقطارات والمحطات في كل المحافظات.
        </p>
      </header>

      <section className="px-4 py-4 max-w-2xl mx-auto space-y-4">
        {/* Search input */}
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="حي، خط، محطة، أو رمز خط…"
            className="w-full pr-9 pl-3 py-3 rounded-xl border bg-card text-sm focus:ring-2 focus:ring-primary outline-none"
            autoFocus
          />
        </div>

        {/* Governorate chips */}
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1 -mx-1 px-1">
          <button
            onClick={() => setGov(ALL)}
            className={`shrink-0 rounded-full px-3 py-1.5 text-xs border ${
              gov === ALL
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-card hover:bg-primary/5"
            }`}
          >
            كل المحافظات
          </button>
          {governorates.map((g) => (
            <button
              key={g}
              onClick={() => setGov(g)}
              className={`shrink-0 rounded-full px-3 py-1.5 text-xs border ${
                gov === g
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-card hover:bg-primary/5"
              }`}
            >
              {g}
            </button>
          ))}
        </div>

        {/* Suggestions when empty */}
        {!q.trim() && (
          <div className="grid grid-cols-2 gap-2 text-sm">
            {["المعادي", "التحرير", "رمسيس", "الجيزة", "الإسكندرية", "أسيوط"].map((s) => (
              <button
                key={s}
                onClick={() => setQ(s)}
                className="rounded-lg border bg-card p-3 text-right hover:bg-primary/5"
              >
                {s}
              </button>
            ))}
          </div>
        )}

        {/* Results */}
        {q.trim() && (
          <div className="space-y-4">
            {/* Cairo stations */}
            {results.cairoHits.length > 0 && (
              <div>
                <h3 className="text-xs font-bold text-muted-foreground mb-1.5">
                  🚏 محطات القاهرة الكبرى ({results.cairoHits.length})
                </h3>
                <div className="space-y-1.5">
                  {results.cairoHits.map((s, i) => (
                    <div key={`c-${i}-${s.name}`} className="rounded-lg border bg-card p-3">
                      <div className="font-semibold text-sm flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-primary" />
                        {s.name}
                      </div>
                      <div className="text-[11px] text-muted-foreground mt-0.5">
                        {s.gov} · {s.area} · {s.kind_ar}
                      </div>
                      {s.modes?.length > 0 && (
                        <div className="text-[11px] text-muted-foreground mt-0.5">
                          {s.modes.join(" · ")}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Egypt stations (hubs/terminals) */}
            {results.egHits.length > 0 && (
              <div>
                <h3 className="text-xs font-bold text-muted-foreground mb-1.5">
                  🏢 محطات ومحاور ({results.egHits.length})
                </h3>
                <div className="space-y-1.5">
                  {results.egHits.map((s, i) => (
                    <div key={`e-${i}-${s.name}`} className="rounded-lg border bg-card p-3">
                      <div className="font-semibold text-sm">{s.name}</div>
                      <div className="text-[11px] text-muted-foreground mt-0.5">
                        {s.governorate} · {s.area}
                      </div>
                      {s.modes?.length > 0 && (
                        <div className="text-[11px] text-muted-foreground mt-0.5">
                          {s.modes.join(" · ")}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Governorate stations (24 محافظة) */}
            {results.govHits.length > 0 && (
              <div>
                <h3 className="text-xs font-bold text-muted-foreground mb-1.5">
                  🚌 مواقف المحافظات ({results.govHits.length})
                </h3>
                <div className="space-y-1.5">
                  {results.govHits.map((s, i) => (
                    <div key={`g-${i}-${s.name_ar}`} className="rounded-lg border bg-card p-3">
                      <div className="font-semibold text-sm">{s.name_ar}</div>
                      <div className="text-[11px] text-muted-foreground mt-0.5">
                        {s.governorate} · {s.city} · {s.type}
                      </div>
                      {s.served_areas && s.served_areas.length > 0 && (
                        <div className="text-[11px] text-muted-foreground mt-0.5">
                          {s.served_areas.slice(0, 5).join(" · ")}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Routes */}
            {results.routeHits.length > 0 && (
              <div>
                <h3 className="text-xs font-bold text-muted-foreground mb-1.5">
                  🛣️ خطوط ({results.routeHits.length})
                </h3>
                <div className="space-y-1.5">
                  {results.routeHits.map((r, i) => (
                    <div key={`r-${i}-${r.route_code}`} className="rounded-lg border bg-card p-3">
                      <div className="font-semibold text-sm flex items-center gap-1.5">
                        {r.transport_mode === "bus" ? (
                          <Bus className="w-3.5 h-3.5 text-primary" />
                        ) : r.transport_mode === "microbus" ? (
                          <Bus className="w-3.5 h-3.5 text-primary" />
                        ) : (
                          <Train className="w-3.5 h-3.5 text-primary" />
                        )}
                        <span className="text-primary font-mono">{r.route_code}</span>
                        <span>{r.origin_name}</span>
                        <ArrowRight className="w-3 h-3" />
                        <span>{r.destination_name}</span>
                      </div>
                      {r.stops?.length > 0 && (
                        <div className="text-[11px] text-muted-foreground mt-0.5">
                          {r.stops.slice(0, 8).join(" · ")}
                          {r.stops.length > 8 && ` … +${r.stops.length - 8}`}
                        </div>
                      )}
                      <div className="text-[11px] text-muted-foreground mt-0.5">
                        {r.governorate} · {r.transport_mode}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {totalResults === 0 && (
              <p className="text-sm text-muted-foreground text-center py-6">
                لا نتائج. جرّب اسم حي أو محطة مختلفة، أو غيّر المحافظة.
              </p>
            )}
          </div>
        )}

        {/* Quick links to existing Egypt pages */}
        {!q.trim() && (
          <div className="pt-4 border-t space-y-2">
            <h3 className="text-xs font-bold text-muted-foreground mb-1">صفحات سريعة</h3>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <Link
                to="/metro"
                className="rounded-lg border bg-card p-3 text-right hover:bg-primary/5"
              >
                🚇 مترو القاهرة
              </Link>
              <Link
                to="/trains"
                className="rounded-lg border bg-card p-3 text-right hover:bg-primary/5"
              >
                🚄 القطارات
              </Link>
              <Link
                to="/bus-stations"
                className="rounded-lg border bg-card p-3 text-right hover:bg-primary/5"
              >
                🚌 محطات الأتوبيس
              </Link>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
