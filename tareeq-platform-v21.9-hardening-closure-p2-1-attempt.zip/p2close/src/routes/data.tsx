// Open Data Hub — published JSON datasets to attract backlinks
import { usePublishSnapshot } from "@/hooks/use-publish-snapshot";
// (Wikipedia citations, OpenStreetMap mappers, researchers).
import { createFileRoute, Link } from "@tanstack/react-router";
import { FloatingHomeButton } from "@/components/FloatingHomeButton";

import { SITE_BASE_URL as BASE } from "@/lib/seo/site";

type Dataset = {
  title: string;
  description: string;
  path: string;
  format: string;
  license: string;
  country: "eg" | "ma" | "both";
};

const DATASETS: Dataset[] = [
  {
    title: "محطات مترو القاهرة",
    description: "89 محطة على الخطوط 1/2/3 مع الإحداثيات.",
    path: "/data/metro-stations.json",
    format: "JSON",
    license: "CC-BY 4.0",
    country: "eg",
  },
  {
    title: "محطات وموانئ مصر",
    description: "350+ موقف ومحطة في 24 محافظة مصرية.",
    path: "/data/egypt-stations.json",
    format: "JSON",
    license: "CC-BY 4.0",
    country: "eg",
  },
  {
    title: "خطوط أتوبيس القاهرة",
    description: "كل خطوط CTA في القاهرة الكبرى.",
    path: "/data/cairo-bus-lines.json",
    format: "JSON",
    license: "CC-BY 4.0",
    country: "eg",
  },
  {
    title: "خطوط الميني باص",
    description: "خطوط الميني باص في القاهرة الكبرى.",
    path: "/data/cairo-minibus-lines.json",
    format: "JSON",
    license: "CC-BY 4.0",
    country: "eg",
  },
  {
    title: "خطوط الميكروباص في مصر",
    description: "1166 خط ميكروباص يغطي 26 محافظة.",
    path: "/data/microbus-lines.json",
    format: "JSON",
    license: "CC-BY 4.0",
    country: "eg",
  },
  {
    title: "محطات القاهرة الكبرى",
    description: "219 محطة ومحول مواصلات في القاهرة والجيزة والقليوبية.",
    path: "/data/cairo-stations.json",
    format: "JSON",
    license: "CC-BY 4.0",
    country: "eg",
  },
  {
    title: "خطوط أتوبيسات المحافظات",
    description: "خطوط الأتوبيس في كل محافظات مصر.",
    path: "/data/governorate-bus-lines.json",
    format: "JSON",
    license: "CC-BY 4.0",
    country: "eg",
  },
  {
    title: "مواقف الأتوبيس والميكروباص - المحافظات",
    description:
      "418 موقف أتوبيس/ميني باص/ميكروباص في 24 محافظة (خارج القاهرة الكبرى) مع الإحداثيات والمناطق المخدومة.",
    path: "/data/eg-governorate-stations.json",
    format: "JSON",
    license: "CC-BY 4.0",
    country: "eg",
  },
  {
    title: "المواقف العشوائية - كل المحافظات",
    description:
      "156 نقطة تجمع عشوائية (ميكروباص/توك توك/سوزوكي) في 27 محافظة مصرية، جمعها 27 وكيل بحث من جوجل ماب و OSM ومصادر محلية.",
    path: "/data/eg-informal-stops.json",
    format: "JSON",
    license: "CC-BY 4.0",
    country: "eg",
  },
  {
    title: "خطوط السكة الحديد المصرية",
    description: "خطوط ENR الرئيسية مع المحطات.",
    path: "/data/trains.json",
    format: "JSON",
    license: "CC-BY 4.0",
    country: "eg",
  },
  {
    title: "مسارات النقل الموحدة",
    description: "كل المسارات بصيغة موحدة (مترو + أتوبيس + ميكروباص).",
    path: "/data/transit-routes.json",
    format: "JSON",
    license: "CC-BY 4.0",
    country: "both",
  },
];

export const Route = createFileRoute("/data")({
  head: () => ({
    meta: [
      { title: "Open Data Hub — بيانات النقل العام المفتوحة لمصر والمغرب" },
      {
        name: "description",
        content:
          "بيانات مفتوحة للنقل العام: محطات المترو، خطوط الأتوبيس، الميكروباص، السكة الحديد، الترامواي و ONCF. مرخصة CC-BY 4.0 للباحثين والصحفيين ومحرري ويكيبيديا.",
      },
      { property: "og:title", content: "Open Data Hub — Egypt & Morocco Transit Open Data" },
      {
        property: "og:description",
        content: "Free, CC-BY-licensed transit datasets for Egypt and Morocco.",
      },
      { property: "og:url", content: `${BASE}/data` },
      { property: "og:type", content: "article" },
      {
        property: "og:image",
        content: `${BASE}/api/og.svg?title=Open%20Data%20Hub&subtitle=Egypt%20%26%20Morocco%20transit%20datasets&badge=📂&theme=eg`,
      },
    ],
    links: [{ rel: "canonical", href: `${BASE}/data` }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "DataCatalog",
          name: "Tariq Open Data Hub",
          description: "Open transit datasets for Egypt and Morocco.",
          url: `${BASE}/data`,
          dataset: DATASETS.map((d) => ({
            "@type": "Dataset",
            name: d.title,
            description: d.description,
            license: "https://creativecommons.org/licenses/by/4.0/",
            distribution: {
              "@type": "DataDownload",
              encodingFormat: "application/json",
              contentUrl: `${BASE}${d.path}`,
            },
          })),
        }),
      },
    ],
  }),
  component: DataPage,
});

function DataPage() {
  usePublishSnapshot({
    id: "eg:data",
    source: "بيانات مفتوحة",
    title: "OpenData",
    summary: "بيانات مواصلات مفتوحة قابلة للتصدير",
    category: "other",
    href: "/data",
  });
  return (
    <div className="min-h-screen bg-background pb-24" dir="rtl">
      <FloatingHomeButton />
      <header className="bg-gradient-to-b from-primary/10 to-transparent px-4 py-8">
        <p className="text-sm text-muted-foreground">📂 Open Data Hub</p>
        <h1 className="mt-2 text-3xl font-bold">بيانات النقل العام المفتوحة</h1>
        <p className="mt-3 text-sm text-muted-foreground">
          مرخصة <strong>CC-BY 4.0</strong> — استخدمها في ويكيبيديا، الصحافة، الأبحاث، OpenStreetMap،
          مع نسبة المصدر إلى <span className="font-mono">tariq.app</span>.
        </p>
      </header>

      <section className="px-4 py-6">
        <h2 className="text-lg font-semibold">🇪🇬 مصر</h2>
        <div className="mt-3 space-y-3">
          {DATASETS.filter((d) => d.country === "eg" || d.country === "both").map((d) => (
            <DatasetCard key={d.path} d={d} />
          ))}
        </div>
      </section>

      <section className="px-4 py-6">
        <h2 className="text-lg font-semibold">كيف تستخدم البيانات؟</h2>
        <ul className="mt-3 list-inside list-disc space-y-2 text-sm">
          <li>الأكاديميون والباحثون: استشهد بها مباشرةً في الدراسات.</li>
          <li>OpenStreetMap: استورد المسارات والمحطات (مع التحقق ميدانياً).</li>
          <li>ويكيبيديا: استخدمها كمصدر في صفحات المترو والأتوبيس.</li>
          <li>الصحافة: حلل تغطية النقل في محافظتك.</li>
        </ul>
      </section>
    </div>
  );
}

function DatasetCard({ d }: { d: Dataset }) {
  return (
    <article className="rounded-lg border border-border bg-card p-4">
      <h3 className="font-semibold">{d.title}</h3>
      <p className="mt-1 text-sm text-muted-foreground">{d.description}</p>
      <div className="mt-3 flex items-center justify-between text-xs">
        <span className="rounded bg-muted px-2 py-1 font-mono">{d.format}</span>
        <span className="text-muted-foreground">{d.license}</span>
      </div>
      <a
        href={d.path}
        download
        className="mt-3 inline-block rounded bg-primary px-3 py-2 text-sm font-medium text-primary-foreground"
      >
        ⬇️ تحميل JSON
      </a>
    </article>
  );
}
