import { createFileRoute, Link } from "@tanstack/react-router";
import { lazy, Suspense, useEffect, useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import {
  Train,
  ShieldCheck,
  ArrowRight,
  Clock,
  Ticket,
  Search,
  MapPin,
  ArrowLeft,
} from "lucide-react";
import {
  TRAIN_STATIONS,
  TRAIN_ROUTES,
  loadTrains,
  onTrainsLoaded,
  type TrainStation,
} from "@/data/trains";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { ListSkeleton } from "@/components/shared/ListSkeleton";

import trainHero from "@/assets/trains/train.webp.asset.json";
import imgTalgo from "@/assets/trains/Talgo.webp.asset.json";
import imgVIP from "@/assets/trains/VIP.webp.asset.json";
import imgAC from "@/assets/trains/AC.webp.asset.json";
import imgImproved from "@/assets/trains/Improved.webp.asset.json";
import imgRussian from "@/assets/trains/Russian.webp.asset.json";
import imgSleep from "@/assets/trains/Sleep.webp.asset.json";
import imgCairoAlex from "@/assets/trains/cairo-alexandria.webp.asset.json";
import imgCairoLuxor from "@/assets/trains/cairo-luxor.webp.asset.json";
import imgCairoAswan from "@/assets/trains/cairo-aswan.webp.asset.json";
import imgCairoAssiut from "@/assets/trains/cairo-assiut.webp.asset.json";
import imgCairoMinya from "@/assets/trains/cairo-minya.webp.asset.json";
import imgCairoPortSaid from "@/assets/trains/cairo-port-said.webp.asset.json";
import imgCairoSuez from "@/assets/trains/cairo-suez.webp.asset.json";
import imgAlexLuxor from "@/assets/trains/alexandria-luxor.webp.asset.json";

const TrainsResearchSections = lazy(() =>
  import("@/components/TrainsResearchSections").then((m) => ({
    default: m.TrainsResearchSections,
  })),
);

import { egHead, getEgPage } from "@/lib/seo/eg-meta";

export const Route = createFileRoute("/trains")({
  head: () => {
    const p = getEgPage("/trains")!;
    return egHead({
      path: p.path,
      titleAr: p.titleAr,
      descAr: p.descAr,
      ogImage: p.ogImage,
      breadcrumbLabel: "السكة الحديد",
    });
  },
  component: TrainsPage,
});

const classes = [
  {
    name: "تالجو",
    desc: "الأسرع بين القاهرة والإسكندرية والأقصر",
    img: imgTalgo.url,
  },
  {
    name: "VIP / خاص مميز",
    desc: "أرقى الفئات — كراسي فاخرة وخدمة كاملة",
    img: imgVIP.url,
  },
  {
    name: "مكيف درجة أولى / ثانية",
    desc: "الأكثر استخداماً بين المسافرين",
    img: imgAC.url,
  },
  {
    name: "روسي مطور",
    desc: "قطارات حديثة للرحلات اليومية",
    img: imgImproved.url,
  },
  {
    name: "روسي عادي",
    desc: "الفئة الاقتصادية للرحلات الطويلة",
    img: imgRussian.url,
  },
  { name: "نوم", desc: "عربات نوم للرحلات الليلية الطويلة", img: imgSleep.url },
];

const popularRoutes: Array<{ from: string; to: string; img: string; slug?: string }> = [
  { from: "القاهرة", to: "الإسكندرية", img: imgCairoAlex.url, slug: "cairo-alexandria" },
  { from: "القاهرة", to: "الأقصر", img: imgCairoLuxor.url, slug: "cairo-luxor" },
  { from: "القاهرة", to: "أسوان", img: imgCairoAswan.url, slug: "cairo-aswan" },
  { from: "القاهرة", to: "أسيوط", img: imgCairoAssiut.url },
  { from: "القاهرة", to: "المنيا", img: imgCairoMinya.url },
  { from: "القاهرة", to: "بورسعيد", img: imgCairoPortSaid.url, slug: "cairo-port-said" },
  { from: "القاهرة", to: "السويس", img: imgCairoSuez.url, slug: "cairo-suez" },
  { from: "الإسكندرية", to: "الأقصر", img: imgAlexLuxor.url, slug: "alexandria-luxor" },
];

import { normalizeArSearchLatin as norm } from "@/lib/text/normalize-ar";

function fmtDuration(min: number | null) {
  if (!min || min <= 0) return "—";
  const h = Math.floor(min / 60);
  const m = min % 60;
  if (h && m) return `${h} س ${m} د`;
  if (h) return `${h} ساعة`;
  return `${m} دقيقة`;
}

import { gmapsCoords, gmapsSearch } from "@/lib/geo/gmaps";

function TrainsPage() {
  const [q, setQ] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [, setTick] = useState(0);

  useEffect(() => {
    loadTrains();
    return onTrainsLoaded(() => setTick((n) => n + 1));
  }, []);

  const stationsById = useMemo(() => {
    const m = new Map<string, TrainStation>();
    for (const s of TRAIN_STATIONS) m.set(s.id, s);
    return m;
  }, []);

  const filteredRoutes = useMemo(() => {
    const nq = norm(q);
    return TRAIN_ROUTES.filter((r) => {
      if (from && r.from_station_id !== from) return false;
      if (to && r.to_station_id !== to) return false;
      if (!nq) return true;
      const fs = r.from_station_id ? stationsById.get(r.from_station_id) : null;
      const ts = r.to_station_id ? stationsById.get(r.to_station_id) : null;
      const hay = norm(
        [fs?.name, fs?.city, ts?.name, ts?.city, r.schedule_text, r.operator, r.notes]
          .filter(Boolean)
          .join(" "),
      );
      return hay.includes(nq);
    });
  }, [q, from, to, stationsById]);

  const filteredStations = useMemo(() => {
    const nq = norm(q);
    if (!nq) return TRAIN_STATIONS;
    return TRAIN_STATIONS.filter((s) => {
      const areas = (s.served_areas ?? []).map((a) => a.name).join(" ");
      return norm([s.name, s.city, s.address, areas].filter(Boolean).join(" ")).includes(nq);
    });
  }, [q]);

  const sortedStations = useMemo(
    () =>
      [...TRAIN_STATIONS].sort(
        (a, b) => (b.confirmations_count ?? 0) - (a.confirmations_count ?? 0),
      ),
    [],
  );

  return (
    <div dir="rtl" className="min-h-screen bg-background px-4 py-10">
      <div className="mx-auto max-w-4xl space-y-8">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowRight className="size-4" />
          العودة للرئيسية
        </Link>

        <header className="space-y-3 text-center">
          <div className="relative overflow-hidden rounded-2xl mb-4">
            <img
              src={trainHero.url}
              alt="قطارات مصر"
              className="w-full h-40 md:h-56 object-cover"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <h1 className="absolute bottom-3 right-4 text-3xl md:text-4xl font-extrabold text-white drop-shadow">
              🚆 القطارات
            </h1>
          </div>
          <p className="mx-auto max-w-xl text-muted-foreground">
            دليل قطارات هيئة سكة حديد مصر — {TRAIN_STATIONS.length} محطة · {TRAIN_ROUTES.length} خط
            قطار.
          </p>
          <Link
            to="/trains-atlas"
            className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-indigo-600 to-rose-500 px-4 py-2 text-sm font-bold text-white shadow hover:opacity-90"
          >
            <Train className="size-4" />
            أطلس شامل — كل الخطوط والمحطات و10 مناطق مخدومة لكل محطة
          </Link>
        </header>

        <div
          role="note"
          className="rounded-xl border border-sky-200 bg-sky-50 p-3 text-xs leading-relaxed text-sky-900"
        >
          <div className="font-bold mb-1">مصدر البيانات</div>
          <p>
            المحطات والخطوط مُجمَّعة من الهيئة القومية لسكك حديد مصر ومساهمات مجتمعية. المواعيد قد
            تتغيّر — يُرجى التأكد من تطبيق{" "}
            <a
              href="https://enr.gov.eg"
              target="_blank"
              rel="noopener noreferrer"
              className="font-semibold underline"
            >
              ENR الرسمي
            </a>{" "}
            قبل الرحلة.
          </p>
        </div>

        <section className="space-y-3">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <h2 className="flex items-center gap-2 text-xl font-bold">
              <Ticket className="size-5" /> فئات القطارات
            </h2>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {classes.map((c) => (
              <Card key={c.name} className="overflow-hidden">
                <img src={c.img} alt={c.name} className="w-full h-32 object-cover" loading="lazy" />
                <div className="flex items-center justify-between gap-3 p-4">
                  <div>
                    <div className="font-bold">{c.name}</div>
                    <div className="text-sm text-muted-foreground">{c.desc}</div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>

        <section className="space-y-3">
          <h2 className="flex items-center gap-2 text-xl font-bold">
            <MapPin className="size-5" /> أشهر الرحلات
          </h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {popularRoutes.map((r) => {
              const inner = (
                <Card key={`${r.from}-${r.to}`} className="overflow-hidden group cursor-pointer">
                  <div className="relative">
                    <img
                      src={r.img}
                      alt={`${r.from} إلى ${r.to}`}
                      className="w-full h-36 object-cover transition-transform group-hover:scale-105"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                    <div className="absolute bottom-2 right-3 left-3 flex items-center justify-between text-white font-bold">
                      <span>{r.from}</span>
                      <ArrowLeft className="h-4 w-4" />
                      <span>{r.to}</span>
                    </div>
                  </div>
                </Card>
              );
              return r.slug ? (
                <Link key={`${r.from}-${r.to}`} to="/trains/$slug" params={{ slug: r.slug }}>
                  {inner}
                </Link>
              ) : (
                <div key={`${r.from}-${r.to}`}>{inner}</div>
              );
            })}
          </div>
        </section>

        <section className="rounded-2xl border bg-card p-4 space-y-3">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="ابحث: محطة، مدينة، مشغّل، منطقة…"
              className="w-full rounded-lg border bg-background pr-9 pl-3 py-2 text-sm"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <select
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              className="rounded-lg border bg-background px-3 py-2 text-sm"
            >
              <option value="">من: كل المحطات</option>
              {sortedStations.map((s) => (
                <option key={`f-${s.id}`} value={s.id}>
                  {s.name} {s.city ? `· ${s.city}` : ""}
                </option>
              ))}
            </select>
            <select
              value={to}
              onChange={(e) => setTo(e.target.value)}
              className="rounded-lg border bg-background px-3 py-2 text-sm"
            >
              <option value="">إلى: كل المحطات</option>
              {sortedStations.map((s) => (
                <option key={`t-${s.id}`} value={s.id}>
                  {s.name} {s.city ? `· ${s.city}` : ""}
                </option>
              ))}
            </select>
          </div>
          {(q || from || to) && (
            <button
              onClick={() => {
                setQ("");
                setFrom("");
                setTo("");
              }}
              className="text-xs text-sky-600 hover:underline"
            >
              مسح الفلاتر
            </button>
          )}
        </section>

        <section className="space-y-2">
          <h2 className="flex items-center gap-2 text-xl font-bold">
            <Train className="size-5" /> خطوط القطار ({filteredRoutes.length})
          </h2>
          {filteredRoutes.length === 0 ? (
            <p className="text-sm text-muted-foreground">لا توجد خطوط مطابقة.</p>
          ) : (
            <ul className="space-y-2">
              {filteredRoutes.map((r) => {
                const fs = r.from_station_id ? stationsById.get(r.from_station_id) : null;
                const ts = r.to_station_id ? stationsById.get(r.to_station_id) : null;
                return (
                  <li
                    key={r.id}
                    className="rounded-xl border bg-card p-3 space-y-1.5 hover:shadow-sm"
                  >
                    <div className="flex items-center gap-2 text-sm font-semibold">
                      <span>{fs?.name ?? "—"}</span>
                      <ArrowLeft className="h-3.5 w-3.5 text-muted-foreground" />
                      <span>{ts?.name ?? "—"}</span>
                    </div>
                    <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                      <span className="inline-flex items-center gap-1">
                        <Clock className="h-3 w-3" /> {fmtDuration(r.duration_min)}
                      </span>
                      {r.operator && <span>المشغّل: {r.operator}</span>}
                      {r.confirmations_count > 0 && <span>تأكيدات: {r.confirmations_count}</span>}
                    </div>
                    {r.schedule_text && (
                      <p className="text-xs text-slate-700">
                        <span className="font-semibold">المواعيد:</span> {r.schedule_text}
                      </p>
                    )}
                    {r.notes && <p className="text-xs text-slate-500">{r.notes}</p>}
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        <section className="space-y-2">
          <h2 className="flex items-center gap-2 text-xl font-bold">
            <MapPin className="size-5" /> محطات القطار ({filteredStations.length})
          </h2>
          {filteredStations.length === 0 ? (
            <p className="text-sm text-muted-foreground">لا توجد محطات مطابقة.</p>
          ) : (
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {filteredStations.map((s) => (
                <li key={s.id} className="rounded-xl border bg-card p-3 space-y-1">
                  <div className="flex items-center gap-2 font-semibold text-sm">
                    <Train className="h-4 w-4 text-orange-600" />
                    {s.name}
                  </div>
                  <div className="text-xs text-muted-foreground flex flex-wrap gap-2">
                    {s.city && (
                      <span className="inline-flex items-center gap-1">
                        <MapPin className="h-3 w-3" /> {s.city}
                      </span>
                    )}
                    {s.confirmations_count > 0 && <span>تأكيدات: {s.confirmations_count}</span>}
                  </div>
                  {s.address && <p className="text-xs text-slate-600">{s.address}</p>}
                  {s.served_areas && s.served_areas.length > 0 && (
                    <div className="pt-1">
                      <p className="text-[11px] font-semibold text-slate-700 mb-1">
                        مناطق تخدمها المحطة:
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {s.served_areas.map((a, i) => (
                          <a
                            key={`${s.id}-a-${i}`}
                            href={gmapsSearch([a.name, s.city, "Egypt"].filter(Boolean).join(" "))}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-[11px] rounded-full bg-orange-50 text-orange-700 px-2 py-0.5 border border-orange-100 hover:bg-orange-100 hover:border-orange-300 transition-colors"
                            title={`افتح ${a.name} في الخريطة${a.km != null ? ` · ${a.km} كم` : ""}`}
                          >
                            <MapPin className="h-3 w-3 text-orange-500" />
                            {a.name}
                            {a.km != null && <span className="text-orange-400"> · {a.km} كم</span>}
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                  {s.lat != null && s.lng != null && (
                    <a
                      href={gmapsCoords(s.lat, s.lng)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-sky-600 hover:underline inline-flex items-center gap-1"
                    >
                      <MapPin className="h-3 w-3" /> افتح في الخريطة
                    </a>
                  )}
                </li>
              ))}
            </ul>
          )}
        </section>

        <Card className="flex items-start gap-3 p-4 text-sm">
          <Clock className="mt-1 size-4 text-muted-foreground" />
          <p className="text-muted-foreground">
            يمكن حجز التذاكر من تطبيق <strong>ENR</strong> أو من شباك التذاكر في المحطات الرئيسية.
          </p>
        </Card>

        {/* بيانات بحثية موسّعة من 37 وكيل بحث (تُحمَّل عند الحاجة) */}
        <ErrorBoundary boundary="TrainsResearchSections">
          <Suspense fallback={<ListSkeleton count={3} />}>
            <TrainsResearchSections />
          </Suspense>
        </ErrorBoundary>

        <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
          <ShieldCheck className="size-4" />
          نحترم خصوصيتك
        </div>
      </div>
    </div>
  );
}
