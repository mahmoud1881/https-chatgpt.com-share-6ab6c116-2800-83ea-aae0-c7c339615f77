import { createFileRoute, Outlet, redirect, isRedirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { verifyAdminAccess } from "@/lib/admin-guard.functions";

/**
 * Admin layout — server-verified gate.
 * Every /admin/* route inherits this guard. Runs client-side (ssr:false) because
 * Supabase session lives in localStorage, but the actual admin check calls a
 * server function with requireSupabaseAuth + has_role RPC, so it cannot be
 * bypassed by tampering with client state.
 */
export const Route = createFileRoute("/admin")({
  ssr: false,
  head: () => ({
    meta: [{ title: "لوحة الإدارة — طريق" }, { name: "robots", content: "noindex, nofollow" }],
  }),
  beforeLoad: async () => {
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) throw redirect({ to: "/auth" });
    try {
      const { isAdmin } = await verifyAdminAccess();
      if (!isAdmin) throw redirect({ to: "/" });
    } catch (err) {
      // Auth or role check failed — redirect to home.
      if (isRedirect(err)) throw err;
      throw redirect({ to: "/" });
    }
  },
  component: () => <Outlet />,
});
