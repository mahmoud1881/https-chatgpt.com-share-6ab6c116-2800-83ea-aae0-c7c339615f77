import { createFileRoute, Link } from "@tanstack/react-router";
import { usePublishSnapshot } from "@/hooks/use-publish-snapshot";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tag, Store, ShieldCheck, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/deals")({
  head: () => ({
    meta: [
      { title: "عروض قريبة — وفّر أكتر" },
      {
        name: "description",
        content: "كوبونات حصرية من محلات قريبة من محطاتك. عروض حقيقية حوالين طريقك.",
      },
      { property: "og:title", content: "🏷️ عروض قريب منك" },
      {
        property: "og:description",
        content: "كوبونات حصرية من محلات قريبة من محطاتك.",
      },
    ],
  }),
  component: DealsPage,
});

function DealsPage() {
  usePublishSnapshot({
    id: "eg:deals",
    source: "عروض قريبة",
    title: "كوبونات وعروض",
    summary: "عروض حصرية من محلات قريبة من محطاتك",
    category: "economy",
    href: "/deals",
  });
  return (
    <div dir="rtl" className="min-h-screen bg-background text-foreground">
      <header className="border-b">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
          <Link to="/" className="text-sm text-muted-foreground hover:underline">
            ← الرئيسية
          </Link>
          <h1 className="text-lg font-bold">عروض قريبة</h1>
          <div className="w-16" />
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 py-10">
        <section className="mb-8 text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-pink-500/10 px-3 py-1 text-xs font-medium text-pink-600">
            <Tag className="size-4" />
            وفّر أكتر
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight md:text-4xl">🏷️ عروض قريب منك</h2>
          <p className="mt-2 text-muted-foreground">كوبونات حصرية من محلات قريبة من محطاتك</p>
        </section>

        <Card className="mb-6 bg-primary/5 p-6">
          <div className="flex items-start gap-3">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary">
              <Store className="size-5" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold">أنت تاجر؟</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                سجّل محلك مجاناً واوصل لآلاف الراكبين كل يوم
              </p>
              <Button className="mt-4 gap-2">
                <Store className="size-4" />
                سجّل محلك مجاناً
              </Button>
            </div>
          </div>
        </Card>

        <Card className="border-dashed p-10 text-center">
          <div className="mx-auto mb-4 flex size-14 items-center justify-center rounded-full bg-muted">
            <Tag className="size-7 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-bold">لسه مفيش عروض</h3>
          <p className="mt-2 text-sm text-muted-foreground">اطلب من تاجرك المفضّل يسجّل!</p>
        </Card>

        <p className="mt-10 flex items-center justify-center gap-1 text-xs text-muted-foreground">
          <ShieldCheck className="size-3.5" />
          نحترم خصوصيتك
        </p>

        <div className="mt-6 text-center">
          <Link to="/">
            <Button variant="ghost" className="gap-1">
              العودة للرئيسية
              <ArrowRight className="size-4 rotate-180" />
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
