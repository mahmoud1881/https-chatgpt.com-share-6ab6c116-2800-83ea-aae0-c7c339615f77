import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { AdminPageShell } from "@/components/admin/AdminPageShell";
import { toast } from "sonner";
import { listRoutesByScope, bulkVerifyRoutes } from "@/lib/route-planner/admin-editor.functions";
import { Loader2, CheckCircle2, Edit3, ChevronRight, ChevronLeft } from "lucide-react";

export const Route = createFileRoute("/admin/routes")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "قائمة الخطوط — Tareeq Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: RoutesListPage,
});

const COUNTRIES = [
  { code: "eg", label: "🇪🇬 مصر" },
  { code: "ly", label: "🇱🇾 ليبيا" },
  { code: "iq", label: "🇮🇶 العراق" },
  { code: "sy", label: "🇸🇾 سوريا" },
  { code: "sd", label: "🇸🇩 السودان" },
  { code: "ye", label: "🇾🇪 اليمن" },
];

type Row = {
  id: string;
  route_code: string | null;
  route_name: string;
  transport_type_id: string | null;
  city: string | null;
  country: string;
  is_verified: boolean;
  status: string;
};

const PAGE = 40;

function RoutesListPage() {
  const navigate = useNavigate();
  const [country, setCountry] = useState("eg");
  const [filter, setFilter] = useState<"all" | "verified" | "unverified">("unverified");
  const [rows, setRows] = useState<Row[]>([]);
  const [total, setTotal] = useState(0);
  const [offset, setOffset] = useState(0);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);

  const listFn = useServerFn(listRoutesByScope);
  const verifyFn = useServerFn(bulkVerifyRoutes);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [country, filter, offset]);

  async function load() {
    setLoading(true);
    setSelected(new Set());
    try {
      const res = await listFn({ data: { country, verified: filter, limit: PAGE, offset } });
      setRows(res.rows as Row[]);
      setTotal(res.total);
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  function toggle(id: string) {
    setSelected((s) => {
      const c = new Set(s);
      if (c.has(id)) {
        c.delete(id);
      } else {
        c.add(id);
      }
      return c;
    });
  }

  function selectAll() {
    if (selected.size === rows.length) setSelected(new Set());
    else setSelected(new Set(rows.map((r) => r.id)));
  }

  async function bulkVerify(verify: boolean) {
    if (selected.size === 0) return;
    if (!confirm(`${verify ? "توثيق" : "إلغاء توثيق"} ${selected.size} خط؟`)) return;
    setBusy(true);
    try {
      const res = await verifyFn({ data: { routeIds: Array.from(selected), verify } });
      toast.success(`تم تحديث ${res.updated} خط`);
      await load();
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <AdminPageShell wrapperClassName="min-h-screen bg-gradient-to-b from-background to-muted/30 pb-24">
      <header className="px-4 pt-6 pb-3 flex items-center justify-between">
        <Link to="/admin/data-health" className="text-xs underline text-muted-foreground">
          ← صحّة البيانات
        </Link>
        <h1 className="text-lg font-bold">قائمة الخطوط</h1>
      </header>

      <div className="px-4 flex flex-wrap items-center gap-2">
        <select
          value={country}
          onChange={(e) => {
            setCountry(e.target.value);
            setOffset(0);
          }}
          className="rounded-xl border bg-background px-3 py-2 text-sm"
        >
          {COUNTRIES.map((c) => (
            <option key={c.code} value={c.code}>
              {c.label}
            </option>
          ))}
        </select>
        <select
          value={filter}
          onChange={(e) => {
            setFilter(e.target.value as "all" | "verified" | "unverified");
            setOffset(0);
          }}
          className="rounded-xl border bg-background px-3 py-2 text-sm"
        >
          <option value="unverified">قيد المراجعة فقط</option>
          <option value="verified">الموثّقة فقط</option>
          <option value="all">الكل</option>
        </select>
        <span className="text-xs text-muted-foreground">{total.toLocaleString("ar-EG")} خط</span>
        {loading && <Loader2 className="w-4 h-4 animate-spin" />}
      </div>

      {rows.length > 0 && (
        <div className="px-4 mt-3 flex items-center justify-between text-xs">
          <label className="flex items-center gap-1.5">
            <input
              type="checkbox"
              checked={selected.size === rows.length && rows.length > 0}
              onChange={selectAll}
            />
            <span>
              حدد الكل ({selected.size}/{rows.length})
            </span>
          </label>
          <div className="flex gap-1">
            <button
              onClick={() => bulkVerify(true)}
              disabled={selected.size === 0 || busy}
              className="rounded-full bg-emerald-600 text-white px-3 py-1.5 disabled:opacity-40"
            >
              {busy ? (
                <Loader2 className="w-3 h-3 inline animate-spin" />
              ) : (
                <CheckCircle2 className="w-3 h-3 inline" />
              )}{" "}
              وثّق
            </button>
            <button
              onClick={() => bulkVerify(false)}
              disabled={selected.size === 0 || busy}
              className="rounded-full border px-3 py-1.5 disabled:opacity-40"
            >
              إلغاء التوثيق
            </button>
          </div>
        </div>
      )}

      <ul className="px-4 mt-3 space-y-1.5">
        {rows.map((r) => (
          <li key={r.id} className="flex items-center gap-2 rounded-2xl border bg-card p-2.5">
            <input type="checkbox" checked={selected.has(r.id)} onChange={() => toggle(r.id)} />
            <div className="flex-1 min-w-0">
              <div className="text-sm font-bold truncate">
                {r.route_code && <span className="text-primary">{r.route_code} · </span>}
                {r.route_name}
              </div>
              <div className="text-[10px] text-muted-foreground">
                {r.transport_type_id ?? "—"} · {r.city ?? "—"} · {r.status}
              </div>
            </div>
            {r.is_verified && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
            <Link
              to="/admin/routes/$routeId/edit"
              params={{ routeId: r.id }}
              className="text-[10px] rounded-full border px-2 py-1 hover:bg-muted shrink-0"
            >
              <Edit3 className="w-3 h-3 inline" /> تحرير
            </Link>
          </li>
        ))}
      </ul>

      {total > PAGE && (
        <div className="px-4 mt-4 flex items-center justify-between text-xs">
          <button
            onClick={() => setOffset((o) => Math.max(0, o - PAGE))}
            disabled={offset === 0}
            className="rounded-full border px-3 py-1.5 disabled:opacity-40"
          >
            <ChevronRight className="w-3 h-3 inline" /> السابق
          </button>
          <span className="text-muted-foreground">
            {offset + 1}–{Math.min(offset + PAGE, total)} من {total}
          </span>
          <button
            onClick={() => setOffset((o) => o + PAGE)}
            disabled={offset + PAGE >= total}
            className="rounded-full border px-3 py-1.5 disabled:opacity-40"
          >
            التالي <ChevronLeft className="w-3 h-3 inline" />
          </button>
        </div>
      )}
    </AdminPageShell>
  );
}
