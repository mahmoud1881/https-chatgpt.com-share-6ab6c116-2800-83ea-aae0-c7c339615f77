import { createFileRoute, Link } from "@tanstack/react-router";
import { usePublishSnapshot } from "@/hooks/use-publish-snapshot";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { AsyncState } from "@/components/shared/AsyncState";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { MessageCircle, Plus, Send, User } from "lucide-react";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { pubsub } from "@/lib/free-realtime";
import { localCache } from "@/lib/cache";
import { SemanticSearchBox } from "@/components/semantic-search-box";
import { clientOnlyLazy } from "@/components/client-only-lazy";
import type { LocalAIChatProps } from "@/components/local-ai-chat";
import { AuthGateLoading } from "@/components/AuthGateLoading";
import { useRequireAuth } from "@/hooks/useRequireAuth";

const LocalAIChat = clientOnlyLazy<LocalAIChatProps>(() =>
  import("@/components/local-ai-chat").then((m) => ({ default: m.LocalAIChat })),
);

// تخزين دائم لنتائج "اسأل المجتمع":
//  - المصدر الدائم الفعلي: جدولا community_questions و community_answers
//    في قاعدة بيانات Lovable Cloud (لا ينتهي محتواهما).
//  - الكاش المحلي يستخدم TTL = 0 (بدون انتهاء) ليُحمَّل فوراً من الجهاز،
//    ثم يُحدَّث بأي نسخة أحدث تأتي من قاعدة البيانات أو Realtime.
const QA_TTL = 0;
const QA_QUESTIONS_KEY = "qa:questions:verified-v2";
const QA_ANSWERS_KEY = (qid: string) => `qa:answers:verified-v2:${qid}`;

type Question = {
  id: string;
  title: string;
  body: string | null;
  author_name: string | null;
  answers_count: number;
  created_at: string;
};

type Answer = {
  id: string;
  question_id: string;
  body: string;
  author_name: string | null;
  created_at: string;
};

const QuestionSchema = z.object({
  title: z.string().trim().min(5, "السؤال قصير جداً").max(140),
  body: z.string().trim().max(1000).optional(),
  author: z.string().trim().max(40).optional(),
});

const AnswerSchema = z.object({
  body: z.string().trim().min(2, "الإجابة قصيرة جداً").max(1000),
  author: z.string().trim().max(40).optional(),
});

export const Route = createFileRoute("/ask")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "اسأل المجتمع — مواصلات مصر" },
      {
        name: "description",
        content:
          "اطرح سؤالك عن المواصلات في مصر واحصل على إجابات من المجتمع — مواعيد، أفضل المسارات.",
      },
      { property: "og:title", content: "💬 اسأل المجتمع" },
      {
        property: "og:description",
        content: "اطرح سؤالك عن المواصلات في مصر واحصل على إجابات من المجتمع.",
      },
    ],
  }),
  component: AskRoute,
});

function timeAgo(iso: string): string {
  const s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return "الآن";
  const m = Math.floor(s / 60);
  if (m < 60) return `منذ ${m} د`;
  const h = Math.floor(m / 60);
  if (h < 24) return `منذ ${h} س`;
  const d = Math.floor(h / 24);
  return `منذ ${d} يوم`;
}

/** بوابة استخدام: يتطلب تسجيل دخول قبل عرض هذه الصفحة (مش مجرد تصفح). */
function AskRoute() {
  const authStatus = useRequireAuth();
  if (authStatus !== "authenticated") return <AuthGateLoading />;
  return <AskPage />;
}

function AskPage() {
  usePublishSnapshot({
    id: "eg:ask",
    source: "اسأل المجتمع",
    title: "أسئلة نشطة",
    summary: "اسأل المجتمع واحصل على إجابات فورية",
    category: "community",
    href: "/ask",
  });
  // Hydrate instantly from persistent cache so returning users see content
  // before the network round-trip completes.
  const [questions, setQuestions] = useState<Question[]>(
    () => localCache.get<Question[]>(QA_QUESTIONS_KEY) ?? [],
  );
  const [answers, setAnswers] = useState<Record<string, Answer[]>>({});
  const [loading, setLoading] = useState(
    () => (localCache.get<Question[]>(QA_QUESTIONS_KEY)?.length ?? 0) === 0,
  );
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [author, setAuthor] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [filtered, setFiltered] = useState<Question[] | null>(null);

  // Keep questions cache in sync with state.
  useEffect(() => {
    if (questions.length > 0) {
      localCache.set(QA_QUESTIONS_KEY, questions, QA_TTL);
    }
  }, [questions]);

  useEffect(() => {
    let active = true;
    (async () => {
      const { getActiveCountry } = await import("@/lib/active-country");
      const { data, error } = await supabase
        .from("community_questions")
        .select("id, title, body, author_name, answers_count, country, created_at")
        .eq("country", getActiveCountry())
        .order("created_at", { ascending: false })
        .limit(50);
      if (!active) return;
      if (error) {
        // Network failed but cached copy is already on screen; warn quietly.
        if (questions.length === 0) toast.error("تعذر تحميل الأسئلة");
      } else {
        const rows = (data ?? []) as Question[];
        setQuestions(rows);
        localCache.set(QA_QUESTIONS_KEY, rows, QA_TTL);
      }
      setLoading(false);
    })();

    const unsubs: Array<() => void> = [];
    (async () => {
      const { getActiveCountry } = await import("@/lib/active-country");
      const country = getActiveCountry();
      unsubs.push(
        pubsub.subscribe(`community_questions/${country}`, "insert", (payload) => {
          const row = payload as Question;
          setQuestions((prev) =>
            prev.some((q) => q.id === row.id) ? prev : [row, ...prev].slice(0, 50),
          );
        }),
        pubsub.subscribe(`community_questions/${country}`, "update", (payload) => {
          const row = payload as Question;
          setQuestions((prev) => prev.map((q) => (q.id === row.id ? row : q)));
        }),
        pubsub.subscribe(`community_answers/${country}`, "insert", (payload) => {
          const row = payload as Answer;
          setAnswers((prev) => {
            const list = prev[row.question_id] ?? [];
            if (list.some((a) => a.id === row.id)) return prev;
            const next = { ...prev, [row.question_id]: [...list, row] };
            localCache.set(QA_ANSWERS_KEY(row.question_id), next[row.question_id], QA_TTL);
            return next;
          });
        }),
      );
    })();

    return () => {
      active = false;
      unsubs.forEach((u) => u());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadAnswers = async (qid: string) => {
    if (answers[qid]) return;
    // Hydrate from cache first for instant UI.
    const cached = localCache.get<Answer[]>(QA_ANSWERS_KEY(qid));
    if (cached) setAnswers((p) => ({ ...p, [qid]: cached }));

    const { data, error } = await supabase
      .from("community_answers")
      .select("id, question_id, body, author_name, country, created_at")
      .eq("question_id", qid)
      .order("created_at", { ascending: true });
    if (error) {
      if (!cached) toast.error("تعذر تحميل الإجابات");
      return;
    }
    const rows = (data ?? []) as Answer[];
    setAnswers((p) => ({ ...p, [qid]: rows }));
    localCache.set(QA_ANSWERS_KEY(qid), rows, QA_TTL);
  };

  const toggleExpand = (qid: string) => {
    if (expanded === qid) {
      setExpanded(null);
    } else {
      setExpanded(qid);
      loadAnswers(qid);
    }
  };

  const submitQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = QuestionSchema.safeParse({ title, body, author });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "بيانات غير صالحة");
      return;
    }
    setSubmitting(true);
    const { getActiveCountry } = await import("@/lib/active-country");
    const country = getActiveCountry();
    const { data: inserted, error } = await supabase
      .from("community_questions")
      .insert({
        title: parsed.data.title,
        body: parsed.data.body || null,
        author_name: parsed.data.author || null,
        answers_count: 0,
        country,
      })
      .select()
      .single();
    setSubmitting(false);
    if (error) {
      toast.error("تعذر إرسال السؤال");
      return;
    }
    if (inserted) pubsub.publish(`community_questions/${country}`, "insert", inserted);
    toast.success("تم نشر سؤالك");
    setTitle("");
    setBody("");
    setOpen(false);
  };

  return (
    <div dir="rtl" className="min-h-screen bg-background text-foreground">
      <header className="border-b">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-4">
          <Link to="/" className="text-sm text-muted-foreground hover:underline">
            ← الرئيسية
          </Link>
          <h1 className="text-lg font-bold">اسأل المجتمع</h1>
          <div className="w-16" />
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 py-8">
        <section className="mb-6 text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-blue-500/10 px-3 py-1 text-xs font-medium text-blue-600">
            <MessageCircle className="size-4" />
            مجتمع المواصلات
          </div>
          <h2 className="text-2xl font-extrabold md:text-3xl">💬 اسأل واحصل على إجابات</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            مواعيد، أفضل المسارات — اسأل والمجتمع يجاوبك
          </p>
        </section>

        <div className="mb-6 flex justify-center">
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="lg" className="gap-2">
                <Plus className="size-4" />
                اطرح سؤال
              </Button>
            </DialogTrigger>
            <DialogContent dir="rtl">
              <DialogHeader>
                <DialogTitle>اطرح سؤالك</DialogTitle>
              </DialogHeader>
              <form onSubmit={submitQuestion} className="space-y-3">
                <div>
                  <label className="mb-1 block text-sm">السؤال *</label>
                  <Input
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="مثلاً: إزاي أوصل من المعادي للهرم؟"
                    maxLength={140}
                    required
                  />
                </div>
                <div>
                  <label className="mb-1 block text-sm">تفاصيل إضافية (اختياري)</label>
                  <Textarea
                    value={body}
                    onChange={(e) => setBody(e.target.value)}
                    placeholder="أي معلومات تساعد في الإجابة..."
                    maxLength={1000}
                    rows={3}
                  />
                </div>
                <div>
                  <label className="mb-1 block text-sm">اسمك (اختياري)</label>
                  <Input
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                    placeholder="مجهول"
                    maxLength={40}
                  />
                </div>
                <DialogFooter>
                  <Button type="submit" className="w-full" disabled={submitting}>
                    {submitting ? "جاري النشر..." : "انشر السؤال"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="hidden" aria-hidden="true">
          <LocalAIChat
            title="اسأل المساعد الذكي مباشرة"
            placeholder="مثال: أين أركب من رمسيس إلى المعادي؟"
          />
        </div>

        {questions.length > 0 && (
          <SemanticSearchBox
            items={questions}
            getText={(q) => `${q.title} ${q.body ?? ""}`}
            onFilter={setFiltered}
            placeholder="ابحث في الأسئلة..."
          />
        )}

        {loading ? (
          <AsyncState status="loading" skeletonCount={4} />
        ) : questions.length === 0 ? (
          <AsyncState status="empty" emptyMessage="لا توجد أسئلة بعد — كن أول من يسأل!" />
        ) : (filtered ?? questions).length === 0 ? (
          <AsyncState status="empty" emptyMessage="لا توجد نتائج مطابقة" />
        ) : (
          <div className="space-y-3">
            {(filtered ?? questions).map((q) => (
              <QuestionCard
                key={q.id}
                question={q}
                answers={answers[q.id] ?? []}
                expanded={expanded === q.id}
                onToggle={() => toggleExpand(q.id)}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

function QuestionCard({
  question,
  answers,
  expanded,
  onToggle,
}: {
  question: Question;
  answers: Answer[];
  expanded: boolean;
  onToggle: () => void;
}) {
  const [body, setBody] = useState("");
  const [author, setAuthor] = useState("");
  const [sending, setSending] = useState(false);

  const submitAnswer = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = AnswerSchema.safeParse({ body, author });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "إجابة غير صالحة");
      return;
    }
    setSending(true);
    const { getActiveCountry } = await import("@/lib/active-country");
    const country = getActiveCountry();
    const { data: inserted, error } = await supabase
      .from("community_answers")
      .insert({
        question_id: question.id,
        body: parsed.data.body,
        author_name: parsed.data.author || null,
        country,
      })
      .select()
      .single();
    setSending(false);
    if (error) {
      toast.error("تعذر إرسال الإجابة");
      return;
    }
    if (inserted) pubsub.publish(`community_answers/${country}`, "insert", inserted);
    toast.success("شكراً لمساهمتك");
    setBody("");
  };

  return (
    <Card className="p-4">
      <button onClick={onToggle} className="w-full text-right">
        <div className="flex items-start justify-between gap-3">
          <h3 className="font-bold leading-snug">{question.title}</h3>
          <Badge variant="secondary" className="shrink-0">
            {question.answers_count} رد
          </Badge>
        </div>
        {question.body && <p className="mt-1 text-sm text-muted-foreground">{question.body}</p>}
        <p className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
          <User className="size-3" />
          {question.author_name || "مجهول"} · {timeAgo(question.created_at)}
        </p>
      </button>

      {expanded && (
        <div className="mt-4 space-y-3 border-t pt-4">
          {answers.length === 0 ? (
            <p className="text-sm text-muted-foreground">لا توجد إجابات بعد — كن أول من يجيب</p>
          ) : (
            answers.map((a) => (
              <div key={a.id} className="rounded-md bg-muted/50 p-3">
                <p className="text-sm">{a.body}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {a.author_name || "مجهول"} · {timeAgo(a.created_at)}
                </p>
              </div>
            ))
          )}

          <form onSubmit={submitAnswer} className="space-y-2">
            <Textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="اكتب إجابتك..."
              maxLength={1000}
              rows={2}
              required
            />
            <div className="flex gap-2">
              <Input
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                placeholder="اسمك (اختياري)"
                maxLength={40}
                className="flex-1"
              />
              <Button type="submit" size="sm" disabled={sending} className="gap-1">
                <Send className="size-3.5" />
                {sending ? "..." : "أجب"}
              </Button>
            </div>
          </form>
        </div>
      )}
    </Card>
  );
}
