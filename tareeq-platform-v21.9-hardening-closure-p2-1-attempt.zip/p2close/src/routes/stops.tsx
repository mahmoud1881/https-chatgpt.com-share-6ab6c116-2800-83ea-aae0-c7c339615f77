import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useDebounce } from "@/hooks/use-debounce";
import { useWindowedList } from "@/hooks/use-windowed-list";
import { TableSkeleton } from "@/components/shared/TableSkeleton";
import { useQuery, queryOptions } from "@tanstack/react-query";
import { ShieldCheck, ArrowRight, MapPin, Search } from "lucide-react";
import { gmapsQuery } from "@/lib/geo/gmaps";
import { safeMapUrl } from "@/lib/geo/safe-map-url";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { localData } from "@/lib/local-data";
import { SearchInput } from "@/components/shared/SearchInput";
import { loadEgyptStations } from "@/data/egyptStations";
import { loadCairoStations } from "@/data/cairoStations";
import { loadEgGovStations } from "@/data/egGovernorateStations";
import { loadEgInformalStops } from "@/data/egInformalStops";

import { egHead, getEgPage } from "@/lib/seo/eg-meta";

export const Route = createFileRoute("/stops")({
  head: () => {
    const p = getEgPage("/stops")!;
    return egHead({
      path: p.path,
      titleAr: p.titleAr,
      descAr: p.descAr,
      ogImage: p.ogImage,
      breadcrumbLabel: "المواقف والمحطات",
    });
  },
  component: StopsPage,
  errorComponent: ({ error: _error }) => (
    <div dir="rtl" className="p-8 text-center text-destructive">
      حدث خطأ في التحميل، يرجى المحاولة مجدداً
    </div>
  ),
  notFoundComponent: () => (
    <div dir="rtl" className="p-8">
      غير موجود
    </div>
  ),
});

// كل محافظات مصر الـ27 (مع دمج القاهرة/الجيزة/القليوبية تحت "القاهرة الكبرى")
const EGYPT_GOVERNORATES: string[] = [
  "القاهرة الكبرى",
  "الإسكندرية",
  "البحيرة",
  "الغربية",
  "المنوفية",
  "كفر الشيخ",
  "الدقهلية",
  "دمياط",
  "الشرقية",
  "بورسعيد",
  "الإسماعيلية",
  "السويس",
  "شمال سيناء",
  "جنوب سيناء",
  "البحر الأحمر",
  "مطروح",
  "الوادي الجديد",
  "الفيوم",
  "بني سويف",
  "المنيا",
  "أسيوط",
  "سوهاج",
  "قنا",
  "الأقصر",
  "أسوان",
];

type StationLines = {
  area?: string;
  modes?: string[];
  priority?: string;
  maps_url?: string;
};

type Station = {
  id: string;
  name: string | null;
  type: string | null;
  lat: number | null;
  lng: number | null;
  governorate: string | null;
  lines: unknown;
};

const stationsQuery = queryOptions({
  queryKey: ["user_stations", "all"],
  queryFn: async (): Promise<Station[]> => {
    await Promise.all([
      loadEgyptStations(),
      loadCairoStations(),
      loadEgGovStations(),
      loadEgInformalStops(),
    ]);
    const { data, error } = await localData
      .from("user_stations")
      .select("id,name,type,lat,lng,governorate,lines")
      .order("type", { ascending: true })
      .order("name", { ascending: true });
    if (error) throw error;
    return (data ?? []) as Station[];
  },
});

const TYPE_AR: Record<string, string> = {
  brt_station: "محطة أتوبيس ترددي",
  metro_station: "محطة مترو",
  transport_hub: "محور نقل",
  stop_cluster: "تجمّع مواقف",
  intercity_terminal: "موقف أقاليم",
  rail_station: "محطة سكة حديد",
  port_terminal: "محطة بحرية / ميناء",
  simple_stop: "موقف بسيط",
};

const PRIORITY_AR: Record<string, { label: string; cls: string }> = {
  P0: { label: "أولوية عالية", cls: "bg-red-500/15 text-red-600 dark:text-red-400" },
  P1: { label: "أولوية متوسطة", cls: "bg-amber-500/15 text-amber-700 dark:text-amber-400" },
  P2: { label: "أولوية عادية", cls: "bg-blue-500/15 text-blue-600 dark:text-blue-400" },
};

const MODE_AR: Record<string, string> = {
  brt: "brt",
  metro: "metro",
  lrt: "lrt",
  rail: "rail",
  microbus: "ميكروباص",
  minibus: "ميني باص",
  bus: "أتوبيس",
  intercity: "أقاليم",
};

function deriveGovernorate(s: Station): string {
  const g = s.governorate?.trim();
  if (g && (g === "القاهرة" || g === "الجيزة" || g === "القليوبية")) return "القاهرة الكبرى";
  if (g) return g;
  const lat = s.lat ?? 0;
  const lng = s.lng ?? 0;
  // fallback geo-derive: نطاق القاهرة الكبرى
  if (lat >= 29.8 && lat <= 30.35 && lng >= 30.8 && lng <= 31.9) return "القاهرة الكبرى";
  return "غير محدد";
}

function StopsPage() {
  const { data, isLoading, error, refetch } = useQuery(stationsQuery);
  const initialGov =
    typeof window !== "undefined"
      ? (new URLSearchParams(window.location.search).get("gov") ?? "")
      : "";
  const [q, setQ] = useState("");
  const debouncedQ = useDebounce(q, 220);
  const [gov, setGov] = useState<string>(initialGov);
  const [type, setType] = useState<string>("");

  const rows = useMemo(() => {
    if (!data) return [];
    const norm = (s: string) => s.toLowerCase().trim();
    return data
      .map((s) => {
        const lines = (s.lines && typeof s.lines === "object" ? s.lines : {}) as StationLines;
        const area: string = lines.area ?? "—";
        const modes: string[] = Array.isArray(lines.modes) ? lines.modes : [];
        const priority: string | undefined = lines.priority;
        const maps_url: string | undefined = lines.maps_url;
        return {
          ...s,
          area,
          modes,
          priority,
          maps_url,
          governorate: deriveGovernorate(s),
        };
      })
      .filter((r) => {
        if (gov && r.governorate !== gov) return false;
        if (type && r.type !== type) return false;
        if (debouncedQ) {
          const needle = norm(debouncedQ);
          if (
            !norm(r.name ?? "").includes(needle) &&
            !norm(r.area ?? "").includes(needle) &&
            !norm(r.governorate ?? "").includes(needle)
          )
            return false;
        }
        return true;
      })
      .sort((a, b) => {
        // priority order P0 < P1 < P2 < none
        const p = (x: { priority?: string }) =>
          x.priority === "P0" ? 0 : x.priority === "P1" ? 1 : x.priority === "P2" ? 2 : 3;
        if (p(a) !== p(b)) return p(a) - p(b);
        return (a.governorate ?? "").localeCompare(b.governorate ?? "", "ar");
      });
  }, [data, debouncedQ, gov, type]);

  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    (data ?? []).forEach((s) => {
      const g = deriveGovernorate(s as Station);
      c[g] = (c[g] ?? 0) + 1;
    });
    return c;
  }, [data]);

  const {
    visibleItems: visibleRows,
    hasMore,
    total,
    SentinelComponent,
  } = useWindowedList(rows, { initial: 60, batch: 60 });

  return (
    <div dir="rtl" className="min-h-screen bg-background px-4 py-10">
      <div className="mx-auto max-w-6xl space-y-6">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowRight className="size-4" />
          العودة للرئيسية
        </Link>

        <header className="space-y-3 text-center">
          <h1 className="text-4xl font-extrabold tracking-tight md:text-5xl">
            🚐 مواقف ومحطات النقل في مصر
          </h1>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            {data ? `${data.length} موقف ومحطة` : "جارٍ التحميل…"} موزعة على محافظات مصر
          </p>
          <div className="flex flex-wrap justify-center gap-2 text-xs">
            {EGYPT_GOVERNORATES.filter((g) => (counts[g] ?? 0) > 0).map((g) => (
              <Badge key={g} variant="secondary">
                {g}: {counts[g] ?? 0}
              </Badge>
            ))}
          </div>
        </header>

        <Card className="p-4">
          <div className="grid gap-3 md:grid-cols-4">
            <SearchInput
              value={q}
              onChange={setQ}
              placeholder="ابحث باسم الموقف أو المنطقة…"
              className="md:col-span-2"
            />
            <select
              value={gov}
              onChange={(e) => setGov(e.target.value)}
              className="rounded-md border bg-background px-3 py-2 text-sm"
            >
              <option value="">كل المحافظات</option>
              {EGYPT_GOVERNORATES.map((g) => (
                <option key={g} value={g}>
                  {g}
                  {counts[g] ? ` (${counts[g]})` : ""}
                </option>
              ))}
            </select>

            <select
              value={type}
              onChange={(e) => setType(e.target.value)}
              className="rounded-md border bg-background px-3 py-2 text-sm"
            >
              <option value="">كل الأنواع</option>
              {Object.entries(TYPE_AR).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </select>
          </div>
        </Card>

        {error && (
          <Card className="p-6 text-center" role="alert">
            <p className="mb-3 text-destructive">تعذر تحميل قائمة المواقف — تحقق من اتصالك.</p>
            <button
              type="button"
              onClick={() => refetch()}
              className="inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-1.5 text-xs font-semibold hover:bg-accent"
            >
              إعادة المحاولة
            </button>
          </Card>
        )}

        {isLoading ? (
          <TableSkeleton rows={8} cols={6} />
        ) : (
          <Card className="overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">المحافظة</TableHead>
                  <TableHead className="text-right">الموقف</TableHead>
                  <TableHead className="text-right">النوع</TableHead>
                  <TableHead className="text-right">المنطقة</TableHead>
                  <TableHead className="text-right">وسائل النقل</TableHead>
                  <TableHead className="text-right">الأولوية</TableHead>
                  <TableHead className="text-right">الموقع</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="py-10 text-center text-muted-foreground">
                      لا توجد نتائج
                    </TableCell>
                  </TableRow>
                )}
                {visibleRows.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="whitespace-nowrap text-muted-foreground">
                      {r.governorate}
                    </TableCell>
                    <TableCell className="font-semibold">
                      <div className="flex items-start gap-1.5">
                        <MapPin className="mt-0.5 size-3.5 shrink-0 text-primary" />
                        <span>{r.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">
                      {TYPE_AR[r.type ?? ""] ?? r.type ?? "—"}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{r.area}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {r.modes.length === 0 ? (
                          <span className="text-muted-foreground">—</span>
                        ) : (
                          r.modes.map((m) => (
                            <Badge key={m} variant="outline" className="text-xs">
                              {MODE_AR[m] ?? m}
                            </Badge>
                          ))
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {r.priority && PRIORITY_AR[r.priority] ? (
                        <span
                          className={`rounded-full px-2 py-0.5 text-xs font-medium ${PRIORITY_AR[r.priority].cls}`}
                        >
                          {PRIORITY_AR[r.priority].label}
                        </span>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-xs">
                      {r.lat != null && r.lng != null ? (
                        <div className="flex flex-wrap gap-1">
                          <a
                            href={safeMapUrl(r.maps_url, { lat: r.lat, lng: r.lng })}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="rounded-md bg-emerald-600/10 px-2 py-0.5 text-emerald-700 hover:bg-emerald-600/20 dark:text-emerald-300"
                          >
                            📍 خرائط جوجل
                          </a>
                          <a
                            href={`https://www.openstreetmap.org/?mlat=${r.lat}&mlon=${r.lng}#map=17/${r.lat}/${r.lng}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="rounded-md bg-indigo-600/10 px-2 py-0.5 text-indigo-700 hover:bg-indigo-600/20 dark:text-indigo-300"
                          >
                            🗺️
                          </a>
                        </div>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <SentinelComponent />
            {hasMore && (
              <div className="py-2 text-center text-xs text-muted-foreground">
                يتم تحميل المزيد… ({visibleRows.length} / {total})
              </div>
            )}
          </Card>
        )}

        <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
          <ShieldCheck className="size-4" />
          نحترم خصوصيتك
        </div>
      </div>
    </div>
  );
}
