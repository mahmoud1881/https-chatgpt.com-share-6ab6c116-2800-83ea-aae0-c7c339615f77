import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { AdminPageShell } from "@/components/admin/AdminPageShell";
import { useWindowedList } from "@/hooks/use-windowed-list";
import { toast } from "sonner";
import {
  listAliasSuggestions,
  approveAliasSuggestion,
  rejectAliasSuggestion,
} from "@/lib/route-planner/admin-cleanup.functions";
import { Loader2, Check, X } from "lucide-react";

export const Route = createFileRoute("/admin/alias-suggestions")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "مقترحات الأسماء البديلة — Tareeq Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AliasSuggestionsPage,
});

type Item = {
  id: string;
  stop_id: string | null;
  suggested_alias: string;
  status: string;
  created_at: string;
  stop: { id: string; name_ar: string; city: string | null; country: string | null } | null;
};

function AliasSuggestionsPage() {
  const navigate = useNavigate();
  const [status, setStatus] = useState<"pending" | "approved" | "rejected">("pending");
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);

  const listFn = useServerFn(listAliasSuggestions);
  const approveFn = useServerFn(approveAliasSuggestion);
  const rejectFn = useServerFn(rejectAliasSuggestion);
  const { visibleItems, SentinelComponent } = useWindowedList(items, {
    initial: 50,
    batch: 50,
  });

  async function load() {
    setLoading(true);
    try {
      const res = await listFn({ data: { status, limit: 200 } });
      setItems((res.items ?? []) as Item[]);
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "فشل التحميل");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  async function approve(id: string) {
    setBusy(id);
    try {
      await approveFn({ data: { id } });
      toast.success("تمت الموافقة");
      setItems((prev) => prev.filter((x) => x.id !== id));
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "فشل الحفظ");
    } finally {
      setBusy(null);
    }
  }
  async function reject(id: string) {
    setBusy(id);
    try {
      await rejectFn({ data: { id } });
      toast.success("تم الرفض");
      setItems((prev) => prev.filter((x) => x.id !== id));
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "فشل");
    } finally {
      setBusy(null);
    }
  }

  return (
    <AdminPageShell wrapperClassName="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">مقترحات الأسماء البديلة</h1>
          <Link to="/admin/data-health" className="text-sm text-primary underline">
            ← لوحة صحة الداتا
          </Link>
        </div>

        <div className="flex gap-2">
          {(["pending", "approved", "rejected"] as const).map((s) => (
            <button
              key={s}
              onClick={() => setStatus(s)}
              className={`px-4 py-2 rounded-lg text-sm border transition ${
                status === s
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-card border-border hover:bg-muted"
              }`}
            >
              {s === "pending" ? "قيد الانتظار" : s === "approved" ? "مقبول" : "مرفوض"}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="text-center py-12">
            <Loader2 className="animate-spin mx-auto" />
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">لا توجد عناصر</div>
        ) : (
          <div className="space-y-2">
            {visibleItems.map((it) => (
              <div
                key={it.id}
                className="bg-card border border-border rounded-lg p-4 flex items-center justify-between gap-4"
              >
                <div className="flex-1 min-w-0">
                  <div className="font-semibold truncate">{it.suggested_alias}</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {it.stop ? (
                      <>
                        محطة: {it.stop.name_ar}
                        {it.stop.city ? ` — ${it.stop.city}` : ""}
                        {it.stop.country ? ` (${it.stop.country})` : ""}
                      </>
                    ) : (
                      <span className="text-destructive">لا توجد محطة مرتبطة</span>
                    )}
                  </div>
                </div>
                {status === "pending" && (
                  <div className="flex gap-2 shrink-0">
                    <button
                      onClick={() => approve(it.id)}
                      disabled={busy === it.id || !it.stop_id}
                      className="px-3 py-2 rounded-md bg-primary text-primary-foreground text-sm disabled:opacity-50 flex items-center gap-1"
                    >
                      <Check className="h-4 w-4" /> قبول
                    </button>
                    <button
                      onClick={() => reject(it.id)}
                      disabled={busy === it.id}
                      className="px-3 py-2 rounded-md border border-border text-sm disabled:opacity-50 flex items-center gap-1"
                    >
                      <X className="h-4 w-4" /> رفض
                    </button>
                  </div>
                )}
              </div>
            ))}
            <SentinelComponent />
          </div>
        )}
      </div>
    </AdminPageShell>
  );
}
