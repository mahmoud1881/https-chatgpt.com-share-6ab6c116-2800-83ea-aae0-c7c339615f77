import { createFileRoute, Link, useRouter, useSearch } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { translateAuthError } from "@/lib/auth-errors";

type AuthSearch = { redirect?: string };

/**
 * Only ever accept a same-origin relative path here. `redirect` comes
 * straight from the URL — fully attacker-controlled via a crafted link
 * (e.g. `/auth?redirect=//evil.example/phish`) sent to a victim. Without
 * this check, a successful real login on this site would immediately
 * navigate the user away to an external phishing page. `//host/path` is
 * rejected too: browsers treat a leading `//` as protocol-relative, i.e.
 * still an external redirect even though it doesn't start with `http`.
 */
function safeRedirect(path: unknown): string | undefined {
  if (typeof path !== "string") return undefined;
  if (path.startsWith("/") && !path.startsWith("//")) return path;
  return undefined;
}

export const Route = createFileRoute("/auth")({
  ssr: false,
  validateSearch: (s: Record<string, unknown>): AuthSearch => ({
    redirect: safeRedirect(s.redirect),
  }),
  head: () => ({
    meta: [
      { title: "تسجيل الدخول — طريقك" },
      {
        name: "description",
        content: "سجّل الدخول بجوجل أو أبل لاستخدام أدوات المنصة. التصفح متاح بدون تسجيل.",
      },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AuthPage,
});

/** زر دخول موحّد لأي مزوّد OAuth مدعوم (جوجل، أبل، ...). */
function OAuthButton({
  provider,
  label,
  busyLabel,
  icon,
  busy,
  onBusyChange,
  onSuccess,
}: {
  provider: "google" | "apple";
  label: string;
  busyLabel: string;
  icon: React.ReactNode;
  busy: boolean;
  onBusyChange: (busy: boolean) => void;
  onSuccess: () => void;
}) {
  return (
    <button
      type="button"
      disabled={busy}
      onClick={async () => {
        if (busy) return;
        onBusyChange(true);
        try {
          const result = await lovable.auth.signInWithOAuth(provider, {
            redirect_uri: window.location.origin,
          });
          if (result.error) {
            toast.error(
              translateAuthError((result.error as Error).message ?? `فشل الدخول بـ${label}`),
            );
            onBusyChange(false);
            return;
          }
          if (result.redirected) return; // ينتظر الرجوع من مزوّد الدخول
          toast.success("مرحباً بك!");
          onSuccess();
        } catch (err) {
          toast.error(translateAuthError(err instanceof Error ? err.message : String(err)));
        } finally {
          onBusyChange(false);
        }
      }}
      className="w-full flex items-center justify-center gap-2 rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground hover:bg-muted disabled:opacity-60"
    >
      {icon}
      {busy ? busyLabel : label}
    </button>
  );
}

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
      <path
        fill="#FFC107"
        d="M43.6 20.5H42V20H24v8h11.3c-1.6 4.7-6.1 8-11.3 8-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.3 6.1 29.4 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.2-.1-2.4-.4-3.5z"
      />
      <path
        fill="#FF3D00"
        d="M6.3 14.7l6.6 4.8C14.6 15.1 18.9 12 24 12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.3 6.1 29.4 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"
      />
      <path
        fill="#4CAF50"
        d="M24 44c5.3 0 10.1-2 13.7-5.3l-6.3-5.2C29.4 34.9 26.8 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"
      />
      <path
        fill="#1976D2"
        d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.2 4.2-4 5.6l6.3 5.2C41.1 35.6 44 30.3 44 24c0-1.2-.1-2.4-.4-3.5z"
      />
    </svg>
  );
}

function AppleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" fill="currentColor">
      <path d="M16.365 1.43c0 1.14-.493 2.27-1.177 3.08-.744.9-1.99 1.57-3.014 1.57-.12 0-.24-.02-.34-.03-.01-.11-.04-.23-.04-.35 0-1.09.5-2.2 1.14-2.98.72-.9 1.99-1.6 3.06-1.66.03.13.06.25.06.37h.315zm4.328 16.94c-.36.84-.79 1.63-1.29 2.36-.68 1-1.24 1.7-1.68 2.1-.68.66-1.4 1-2.17 1.02-.55.02-1.21-.16-1.99-.53-.78-.37-1.5-.55-2.16-.55-.68 0-1.42.18-2.22.55-.8.37-1.44.56-1.94.58-.74.03-1.47-.32-2.19-1.03-.47-.44-1.06-1.17-1.77-2.2-.76-1.1-1.39-2.38-1.88-3.84-.53-1.58-.8-3.11-.8-4.6 0-1.71.37-3.19 1.11-4.42.58-1 1.35-1.78 2.32-2.35.96-.57 2-.86 3.12-.88.6 0 1.38.19 2.35.56.96.38 1.58.57 1.85.57.2 0 .89-.22 2.05-.66 1.1-.41 2.03-.58 2.79-.51 2.06.17 3.6.98 4.63 2.44-1.85 1.12-2.76 2.68-2.75 4.7.01 1.57.57 2.88 1.68 3.93.5.48 1.05.85 1.68 1.11-.13.4-.28.79-.44 1.17z" />
    </svg>
  );
}

function AuthPage() {
  const router = useRouter();
  const { redirect } = useSearch({ from: "/auth" });
  const [mode, setMode] = useState<"signin" | "signup" | "forgot">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [busy, setBusy] = useState(false);

  function goToDestination() {
    void router.navigate({ to: redirect ?? "/" });
  }

  // إذا كان المستخدم مسجّل دخوله بالفعل، أعده لوجهته
  useEffect(() => {
    let mounted = true;
    supabase.auth
      .getSession()
      .then(({ data }) => {
        if (mounted && data.session) {
          void router.navigate({ to: redirect ?? "/" });
        }
      })
      .catch((err) => {
        console.warn("[auth] getSession failed:", err);
      });
    return () => {
      mounted = false;
    };
  }, [router, redirect]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: window.location.origin,
            data: displayName ? { display_name: displayName } : undefined,
          },
        });
        if (error) throw error;
        toast.success("تم إنشاء الحساب! تحقق من بريدك لتأكيد الحساب إذا لزم الأمر.");
        void router.navigate({ to: redirect ?? "/" });
      } else if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("مرحباً بعودتك!");
        void router.navigate({ to: redirect ?? "/" });
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        toast.success("أرسلنا رابط إعادة التعيين إلى بريدك.");
        setMode("signin");
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "حدث خطأ غير متوقع";
      toast.error(translateAuthError(msg));
    } finally {
      setBusy(false);
    }
  }

  const title =
    mode === "signup" ? "إنشاء حساب" : mode === "forgot" ? "استعادة كلمة المرور" : "تسجيل الدخول";

  return (
    <div
      dir="rtl"
      className="min-h-screen bg-background flex items-center justify-center px-4 py-10"
    >
      <div className="w-full max-w-md rounded-xl border border-border bg-card p-6 shadow-sm">
        <div className="mb-6 text-center">
          <h1 className="text-2xl font-bold text-foreground">{title}</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {mode === "forgot"
              ? "أدخل بريدك وسنرسل لك رابطاً لإعادة التعيين."
              : "التصفح متاح للجميع بدون تسجيل — الدخول مطلوب فقط لاستخدام أدوات المنصة (المخطط، المفضلة، المساعد الذكي، وغيرها)."}
          </p>
        </div>

        {mode !== "forgot" && (
          <>
            <div className="space-y-2">
              <OAuthButton
                provider="google"
                label="المتابعة عبر جوجل"
                busyLabel="جارٍ الانتقال…"
                icon={<GoogleIcon />}
                busy={busy}
                onBusyChange={setBusy}
                onSuccess={goToDestination}
              />
              <OAuthButton
                provider="apple"
                label="المتابعة عبر أبل"
                busyLabel="جارٍ الانتقال…"
                icon={<AppleIcon />}
                busy={busy}
                onBusyChange={setBusy}
                onSuccess={goToDestination}
              />
            </div>

            <div className="my-4 flex items-center gap-3 text-xs text-muted-foreground">
              <span className="h-px flex-1 bg-border" />
              أو بالبريد الإلكتروني
              <span className="h-px flex-1 bg-border" />
            </div>
          </>
        )}

        <form onSubmit={onSubmit} className="space-y-4">
          {mode === "signup" && (
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">اسم العرض</label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                placeholder="اسمك (اختياري)"
                autoComplete="name"
              />
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-foreground mb-1">
              البريد الإلكتروني
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              placeholder="you@example.com"
              autoComplete="email"
              dir="ltr"
            />
          </div>

          {mode !== "forgot" && (
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">كلمة المرور</label>
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                placeholder="••••••••"
                autoComplete={mode === "signup" ? "new-password" : "current-password"}
                dir="ltr"
              />
              {mode === "signup" && (
                <p className="mt-1 text-xs text-muted-foreground">٦ أحرف على الأقل</p>
              )}
            </div>
          )}

          <button
            type="submit"
            disabled={busy}
            className="w-full rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-60"
          >
            {busy
              ? "جارٍ المعالجة…"
              : mode === "signup"
                ? "إنشاء الحساب"
                : mode === "forgot"
                  ? "إرسال الرابط"
                  : "دخول"}
          </button>
        </form>

        <div className="mt-6 space-y-2 text-center text-sm">
          {mode === "signin" && (
            <>
              <button
                type="button"
                onClick={() => setMode("forgot")}
                className="text-primary hover:underline"
              >
                نسيت كلمة المرور؟
              </button>
              <div className="text-muted-foreground">
                لا تملك حساباً؟{" "}
                <button
                  type="button"
                  onClick={() => setMode("signup")}
                  className="text-primary hover:underline"
                >
                  أنشئ واحداً
                </button>
              </div>
            </>
          )}
          {mode === "signup" && (
            <div className="text-muted-foreground">
              لديك حساب بالفعل؟{" "}
              <button
                type="button"
                onClick={() => setMode("signin")}
                className="text-primary hover:underline"
              >
                سجّل الدخول
              </button>
            </div>
          )}
          {mode === "forgot" && (
            <button
              type="button"
              onClick={() => setMode("signin")}
              className="text-primary hover:underline"
            >
              العودة لتسجيل الدخول
            </button>
          )}
          <div className="pt-2 border-t border-border mt-4">
            <Link to="/" className="text-muted-foreground hover:text-foreground">
              ← العودة للصفحة الرئيسية (بدون تسجيل)
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
