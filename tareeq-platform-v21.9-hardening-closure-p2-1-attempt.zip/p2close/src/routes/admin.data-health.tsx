import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { AdminPageShell } from "@/components/admin/AdminPageShell";
import { toast } from "sonner";
import { seedRoutePlannerCountry, getDataHealthCounts } from "@/lib/route-planner/seed.functions";
import { Database, Loader2, Upload } from "lucide-react";
import { StatCard } from "@/components/admin/StatCard";

export const Route = createFileRoute("/admin/data-health")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "صحّة البيانات — Tareeq Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: DataHealthPage,
});

type Counts = Awaited<ReturnType<typeof getDataHealthCounts>>;

const COUNTRIES: Array<{
  code: "eg" | "ly" | "iq" | "sy" | "sd" | "ye";
  label: string;
  hint: string;
}> = [
  { code: "eg", label: "🇪🇬 مصر", hint: "1117 خط من transit-routes.json مع كل المحطات" },
  { code: "ly", label: "🇱🇾 ليبيا", hint: "خطوط بين المدن" },
  { code: "iq", label: "🇮🇶 العراق", hint: "خطوط بين المدن" },
  { code: "sy", label: "🇸🇾 سوريا", hint: "خطوط بين المدن" },
  { code: "sd", label: "🇸🇩 السودان", hint: "خطوط بين المدن" },
  { code: "ye", label: "🇾🇪 اليمن", hint: "خطوط بين المدن" },
];

function DataHealthPage() {
  const navigate = useNavigate();
  const [counts, setCounts] = useState<Counts | null>(null);
  const [loading, setLoading] = useState(false);
  const [seedingCountry, setSeedingCountry] = useState<string | null>(null);

  const fetchCounts = useServerFn(getDataHealthCounts);
  const seedFn = useServerFn(seedRoutePlannerCountry);
  useEffect(() => {
    (async () => {
      await refreshCounts();
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function refreshCounts() {
    setLoading(true);
    try {
      const c = await fetchCounts();
      setCounts(c);
    } catch (err) {
      toast.error(`فشل تحميل العدّادات: ${(err as Error).message}`);
    } finally {
      setLoading(false);
    }
  }

  async function runSeed(country: (typeof COUNTRIES)[number]["code"]) {
    if (!confirm(`تشغيل الاستيراد لـ ${country}؟ الصفوف تدخل بحالة "غير مؤكد" وتحتاج مراجعة.`))
      return;
    setSeedingCountry(country);
    try {
      const res = await seedFn({ data: { country } });
      toast.success(
        `تم لـ ${country}: ${res.stops} محطة، ${res.routes} خط، ${res.routeStops} ربط (${(res.durationMs / 1000).toFixed(1)}ث)`,
      );
      await refreshCounts();
    } catch (err) {
      toast.error(`فشل الاستيراد: ${(err as Error).message}`);
    } finally {
      setSeedingCountry(null);
    }
  }

  return (
    <AdminPageShell>
      <header className="px-4 pt-6 pb-4 flex items-center justify-between">
        <Link to="/admin/stats" className="text-xs underline text-muted-foreground">
          ← الإحصائيات
        </Link>
        <h1 className="text-lg font-bold flex items-center gap-2">
          <Database className="w-5 h-5" /> صحّة البيانات
        </h1>
      </header>

      {/* Counts grid */}
      <section className="px-4 grid grid-cols-2 md:grid-cols-4 gap-2">
        <StatCard
          label="محطات"
          value={counts?.stops.total}
          sub={`موثّق: ${counts?.stops.verified ?? 0}`}
        />
        <StatCard label="بدون إحداثيات" value={counts?.stops.noCoords} tone="warn" />
        <StatCard
          label="خطوط"
          value={counts?.routes.total}
          sub={`موثّق: ${counts?.routes.verified ?? 0}`}
        />
        <StatCard label="مرادفات" value={counts?.aliases} />
        <StatCard
          label="بحث فاشل معلّق"
          value={counts?.pending.missingSearches}
          tone={counts && counts.pending.missingSearches > 0 ? "warn" : undefined}
        />
        <StatCard
          label="بلاغات خطأ"
          value={counts?.pending.corrections}
          tone={counts && counts.pending.corrections > 0 ? "warn" : undefined}
        />
        <StatCard label="اقتراحات مستخدمين" value={counts?.pending.suggestions} />
        <button
          onClick={refreshCounts}
          disabled={loading}
          className="rounded-2xl border bg-card p-3 text-xs font-bold hover:bg-muted disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-4 h-4 mx-auto animate-spin" /> : "🔄 تحديث"}
        </button>
      </section>

      {/* Seed section */}
      <section className="px-4 mt-6">
        <div className="rounded-2xl border bg-card p-4">
          <h2 className="text-sm font-bold mb-1 flex items-center gap-1.5">
            <Upload className="w-4 h-4" /> استيراد الداتا الحالية إلى الجداول الجديدة
          </h2>
          <p className="text-[11px] text-muted-foreground mb-3">
            كل صف يدخل بحالة <strong>غير مؤكد</strong> ولن يُعرض للمستخدم إلا بعد المراجعة. آمن
            للتشغيل أكثر من مرة (idempotent).
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {COUNTRIES.map((c) => (
              <button
                key={c.code}
                onClick={() => runSeed(c.code)}
                disabled={seedingCountry !== null}
                className="text-right rounded-xl border bg-background p-3 hover:bg-muted disabled:opacity-50 flex items-center justify-between gap-2"
              >
                <div>
                  <div className="text-sm font-bold">{c.label}</div>
                  <div className="text-[10px] text-muted-foreground">{c.hint}</div>
                </div>
                {seedingCountry === c.code ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <span className="text-xs">▶</span>
                )}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="px-4 mt-6 grid grid-cols-1 sm:grid-cols-3 gap-2">
        <Link to="/planner" className="rounded-2xl border bg-card p-3 hover:bg-muted">
          <div className="text-sm font-bold">🗺️ مخطط الرحلات</div>
          <div className="text-[10px] text-muted-foreground mt-0.5">ابحث بمحرك stop_id الجديد</div>
        </Link>
        <Link
          to="/admin/missing-searches"
          className="rounded-2xl border bg-card p-3 hover:bg-muted"
        >
          <div className="text-sm font-bold">🔎 عمليات البحث الفاشلة</div>
          <div className="text-[10px] text-muted-foreground mt-0.5">
            اربط، أضف مرادفات، أو تجاهل
          </div>
        </Link>
        <Link to="/admin/stops-merge" className="rounded-2xl border bg-card p-3 hover:bg-muted">
          <div className="text-sm font-bold">🔗 دمج محطات مكررة</div>
          <div className="text-[10px] text-muted-foreground mt-0.5">ادمج التسميات المتشابهة</div>
        </Link>
        <Link to="/admin/stops-map" className="rounded-2xl border bg-card p-3 hover:bg-muted">
          <div className="text-sm font-bold">📍 إحداثيات المحطات</div>
          <div className="text-[10px] text-muted-foreground mt-0.5">
            أضف lat/lng عبر Nominatim أو يدوياً
          </div>
        </Link>
        <Link to="/admin/routes" className="rounded-2xl border bg-card p-3 hover:bg-muted">
          <div className="text-sm font-bold">🛣️ الخطوط & التوثيق الجماعي</div>
          <div className="text-[10px] text-muted-foreground mt-0.5">
            وثّق مجموعة كاملة أو حرّر خطاً بمفرده
          </div>
        </Link>
        <Link
          to="/admin/alias-suggestions"
          className="rounded-2xl border bg-card p-3 hover:bg-muted"
        >
          <div className="text-sm font-bold">💬 مقترحات الأسماء البديلة</div>
          <div className="text-[10px] text-muted-foreground mt-0.5">
            راجع مقترحات المستخدمين واقبلها
          </div>
        </Link>
        <Link to="/admin/dead-routes" className="rounded-2xl border bg-card p-3 hover:bg-muted">
          <div className="text-sm font-bold">🗑️ خطوط تالفة</div>
          <div className="text-[10px] text-muted-foreground mt-0.5">
            خطوط بدون بداية/نهاية/محطات
          </div>
        </Link>
        <Link to="/admin/search-debug" className="rounded-2xl border bg-card p-3 hover:bg-muted">
          <div className="text-sm font-bold">🔬 تشخيص البحث</div>
          <div className="text-[10px] text-muted-foreground mt-0.5">
            آخر 100 عملية بحث + مؤشرات ربط البيانات
          </div>
        </Link>
        <Link to="/admin/visitors" className="rounded-2xl border bg-card p-3 hover:bg-muted">
          <div className="text-sm font-bold">👥 متابعة زائري الموقع</div>
          <div className="text-[10px] text-muted-foreground mt-0.5">
            جلسات، منصات، متصفحات، وأكثر عمليات البحث
          </div>
        </Link>
        <Link to="/admin/area-audit" className="rounded-2xl border bg-card p-3 hover:bg-muted">
          <div className="text-sm font-bold">🎯 دقة تعبئة المنطقة</div>
          <div className="text-[10px] text-muted-foreground mt-0.5">
            مقارنة area بإحداثيات OSM وتغذية مرادفات البحث تلقائيًا
          </div>
        </Link>
        <Link to="/admin/route-requests" className="rounded-2xl border bg-card p-3 hover:bg-muted">
          <div className="text-sm font-bold">📥 طلبات الرحلات (اكتب منين لفين)</div>
          <div className="text-[10px] text-muted-foreground mt-0.5">
            مراجعة يدوية للطلبات: دمج المكرر، الربط برحلة، النشر أو الرفض
          </div>
        </Link>
      </section>
    </AdminPageShell>
  );
}
