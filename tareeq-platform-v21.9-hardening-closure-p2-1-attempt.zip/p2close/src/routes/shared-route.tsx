/**
 * Growth Loops — Shared Route receiver page.
 *
 * Route: /shared-route?d=<base64url_payload>&lang=ar|en
 *
 * Foundation-only: renders a minimal, self-contained summary of a shared
 * trip. It does NOT invoke the search engine (per spec: no re-execution
 * changes). If the payload is invalid, missing, or from a newer version,
 * we render a clear fallback — never a crash.
 *
 * No auth required. Nothing sensitive is read from the URL — the payload
 * is validated with Zod before rendering. Query params are treated as
 * untrusted input.
 *
 * QA-only analytics: `shared_route_opened` / `shared_route_failed` are
 * emitted when `?qa_growth_loops=1` is set. No labels or coords are
 * written to analytics — only shape flags.
 */

import { createFileRoute, Link, useSearch } from "@tanstack/react-router";
import { useEffect, useMemo } from "react";

import { decodeShareRouteParams, SHARE_ROUTE_VERSION } from "@/lib/growth/share-route";
import { trackGrowth } from "@/lib/growth/analytics";
import { isGrowthLoopsEnabled } from "@/lib/flags";

type Search = { d?: string; lang?: string };

export const Route = createFileRoute("/shared-route")({
  validateSearch: (raw): Search => {
    const s: Search = {};
    if (typeof raw.d === "string" && raw.d.length > 0 && raw.d.length < 4000) s.d = raw.d;
    if (raw.lang === "ar" || raw.lang === "en") s.lang = raw.lang;
    return s;
  },
  head: () => ({
    meta: [
      { title: "رحلة مشتركة — طريق" },
      { name: "description", content: "افتح تفاصيل رحلة تمت مشاركتها معك على منصة طريق." },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "رحلة مشتركة — طريق" },
      { property: "og:description", content: "افتح تفاصيل رحلة تمت مشاركتها معك على منصة طريق." },
    ],
  }),
  component: SharedRoutePage,
});

function SharedRoutePage() {
  const search = useSearch({ from: Route.id });
  const qaOn = isGrowthLoopsEnabled();

  const decoded = useMemo(() => {
    const p = new URLSearchParams();
    if (search.d) p.set("d", search.d);
    if (search.lang) p.set("lang", search.lang);
    return decodeShareRouteParams(p);
  }, [search.d, search.lang]);

  useEffect(() => {
    if (!qaOn) return;
    if (decoded.ok) {
      trackGrowth("shared_route_opened", {
        version: SHARE_ROUTE_VERSION,
        has_modes: Boolean(decoded.payload.m?.length),
        has_routes: Boolean(decoded.payload.r?.length),
        transfers: decoded.payload.x?.length ?? 0,
        has_duration: typeof decoded.payload.d === "number",
        locale: decoded.locale,
      });
    } else {
      trackGrowth("shared_route_failed", { reason: decoded.reason });
    }
  }, [qaOn, decoded]);

  const locale: "ar" | "en" = decoded.ok ? decoded.locale : search.lang === "en" ? "en" : "ar";
  const dir = locale === "en" ? "ltr" : "rtl";

  if (!decoded.ok) {
    const msg =
      locale === "en"
        ? "This shared trip link is invalid or no longer available."
        : "رابط الرحلة غير صالح أو لم يعد متاحًا.";
    const cta = locale === "en" ? "Open Tareeq" : "افتح طريق";
    return (
      <main dir={dir} className="mx-auto max-w-xl px-4 py-12 text-center">
        <h1 className="text-2xl font-bold text-foreground">
          {locale === "en" ? "Shared trip" : "رحلة مشتركة"}
        </h1>
        <p className="mt-4 text-sm text-muted-foreground">{msg}</p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
          >
            {cta}
          </Link>
        </div>
      </main>
    );
  }

  const p = decoded.payload;
  const strings =
    locale === "en"
      ? {
          title: "Shared trip",
          from: "From",
          to: "To",
          modes: "Modes",
          lines: "Lines",
          transfers: "Transfers",
          duration: "Est. duration",
          minutes: "min",
          openSearch: "Search this route",
          noDuration: "—",
        }
      : {
          title: "رحلة مشتركة",
          from: "من",
          to: "إلى",
          modes: "الوسائل",
          lines: "الخطوط",
          transfers: "التحويلات",
          duration: "المدة التقديرية",
          minutes: "دقيقة",
          openSearch: "ابحث عن هذه الرحلة",
          noDuration: "—",
        };

  return (
    <main dir={dir} lang={locale} className="mx-auto max-w-xl px-4 py-8">
      <h1 className="text-2xl font-bold text-foreground">{strings.title}</h1>

      <section className="mt-6 rounded-xl border border-border bg-card p-4 shadow-sm">
        <dl className="grid grid-cols-1 gap-3 text-sm">
          <Row label={strings.from} value={p.f} />
          <Row label={strings.to} value={p.t} />
          {p.m?.length ? <Row label={strings.modes} value={p.m.join(" · ")} /> : null}
          {p.r?.length ? <Row label={strings.lines} value={p.r.join(" · ")} /> : null}
          <Row label={strings.transfers} value={String(p.x?.length ?? 0)} />
          <Row
            label={strings.duration}
            value={typeof p.d === "number" ? `${p.d} ${strings.minutes}` : strings.noDuration}
          />
        </dl>
      </section>

      <div className="mt-6">
        <Link
          to="/"
          className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
        >
          {strings.openSearch}
        </Link>
      </div>
    </main>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-border/60 pb-2 last:border-b-0 last:pb-0">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="font-medium text-foreground">{value}</dd>
    </div>
  );
}
