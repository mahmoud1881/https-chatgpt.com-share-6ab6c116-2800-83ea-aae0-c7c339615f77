import { supabase } from "../supabase/client";

type SignInOptions = {
  redirect_uri?: string;
  extraParams?: Record<string, string>;
};

type AuthResult = {
  redirected?: boolean;
  error?: Error | null;
};

/**
 * Authentication adapter. Self-hosted deployments use Supabase GoTrue by
 * default; Lovable Cloud can opt in with VITE_AUTH_PROVIDER=lovable.
 */
export const lovable = {
  auth: {
    signInWithOAuth: async (
      provider: "google" | "apple" | "microsoft" | "lovable",
      opts?: SignInOptions,
    ): Promise<AuthResult> => {
      const authProvider = import.meta.env.VITE_AUTH_PROVIDER || "supabase";

      if (authProvider === "lovable") {
        const { createLovableAuth } = await import("@lovable.dev/cloud-auth-js");
        const lovableAuth = createLovableAuth();
        const result = await lovableAuth.signInWithOAuth(provider, {
          redirect_uri: opts?.redirect_uri,
          extraParams: { ...opts?.extraParams },
        });
        if (result.redirected) return result;
        if (result.error) return result;
        try {
          await supabase.auth.setSession(result.tokens);
        } catch (e) {
          return { error: e instanceof Error ? e : new Error(String(e)) };
        }
        return result;
      }

      if (provider === "lovable" || provider === "microsoft") {
        return {
          error: new Error(`OAuth provider ${provider} is not enabled for self-hosted auth`),
        };
      }

      const { data, error } = await supabase.auth.signInWithOAuth({
        provider,
        options: {
          redirectTo: opts?.redirect_uri || window.location.origin,
          queryParams: opts?.extraParams,
        },
      });
      if (error) return { error };
      if (data?.url) {
        window.location.assign(data.url);
        return { redirected: true };
      }
      return { error: new Error("OAuth provider did not return a redirect URL") };
    },
  },
};
