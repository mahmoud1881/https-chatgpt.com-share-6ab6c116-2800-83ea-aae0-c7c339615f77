import { beforeEach, describe, expect, it, vi } from "vitest";

const getUser = vi.fn();
const hasAdminRole = vi.fn();

vi.mock("../client.server", () => ({
  supabaseServerAdmin: { auth: { getUser } },
}));
vi.mock("../../../lib/auth/admin-role", () => ({ hasAdminRole }));

import { verifyAdminSession } from "../verify-admin-session.server";

function request(auth?: string) {
  return new Request("https://example.test/admin", {
    headers: auth ? { Authorization: auth } : undefined,
  });
}

async function expectResponse(promise: Promise<unknown>, status: number) {
  try {
    await promise;
    throw new Error("expected rejection");
  } catch (error) {
    expect(error).toBeInstanceOf(Response);
    expect((error as Response).status).toBe(status);
  }
}

describe("verifyAdminSession", () => {
  beforeEach(() => vi.clearAllMocks());

  it("rejects missing/malformed bearer tokens with 401", async () => {
    await expectResponse(verifyAdminSession(request()), 401);
    await expectResponse(verifyAdminSession(request("Basic abc")), 401);
    expect(getUser).not.toHaveBeenCalled();
  });

  it("rejects invalid credentials with 401", async () => {
    getUser.mockResolvedValue({ data: { user: null }, error: { message: "bad token" } });
    await expectResponse(verifyAdminSession(request("Bearer bad")), 401);
  });

  it("rejects a valid non-admin with 403", async () => {
    getUser.mockResolvedValue({ data: { user: { id: "u1", email: "u@example.com" } }, error: null });
    hasAdminRole.mockResolvedValue(false);
    await expectResponse(verifyAdminSession(request("Bearer token")), 403);
    expect(hasAdminRole).toHaveBeenCalledWith(expect.objectContaining({ userId: "u1" }));
  });

  it("returns the verified admin identity", async () => {
    getUser.mockResolvedValue({ data: { user: { id: "u1", email: "u@example.com" } }, error: null });
    hasAdminRole.mockResolvedValue(true);
    await expect(verifyAdminSession(request("Bearer token"))).resolves.toEqual({
      id: "u1",
      email: "u@example.com",
    });
  });

  it("fails closed when the role RPC errors", async () => {
    getUser.mockResolvedValue({ data: { user: { id: "u1" } }, error: null });
    hasAdminRole.mockRejectedValue(new Error("db down"));
    await expectResponse(verifyAdminSession(request("Bearer token")), 403);
  });
});
