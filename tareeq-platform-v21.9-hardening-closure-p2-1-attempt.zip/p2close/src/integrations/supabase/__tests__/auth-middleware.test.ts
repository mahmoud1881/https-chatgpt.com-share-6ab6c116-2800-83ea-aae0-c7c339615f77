/**
 * Regression tests for requireSupabaseAuth (auth-middleware.ts) — the
 * single gate every authenticated server function/request passes through,
 * including but not limited to admin routes (requireSupabaseAdmin chains
 * on top of this). Before this file, it sat at 2.63% coverage: broader
 * blast radius than any single admin check, since a bug here affects every
 * signed-in user, not just admins.
 *
 * NOTE: auth-middleware.ts is marked "automatically generated. Do not edit
 * it directly." at the top. The only change made to it here was exporting
 * the already-existing `createSupabaseFetch` helper (no logic change) so
 * its Authorization-header-stripping behavior — the part that decides
 * whether a legacy vs. new-format Supabase key gets treated as a bearer
 * token — is directly testable. If this file is regenerated, re-apply that
 * one-line export change or these tests will need updating to test it
 * indirectly instead.
 *
 * We test `requireSupabaseAuth.options.server` directly, same pattern as
 * admin-middleware.test.ts, mocking the two external dependencies that
 * would otherwise require a live HTTP request and a real Supabase project:
 * `getRequest` (TanStack Start's request-scoped accessor) and
 * `createClient` (supabase-js).
 */
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

const getRequestMock = vi.fn();
const getClaimsMock = vi.fn();
const createClientMock = vi.fn();

vi.mock("@tanstack/react-start/server", () => ({
  getRequest: () => getRequestMock(),
}));

vi.mock("@supabase/supabase-js", () => ({
  createClient: (...args: unknown[]) => createClientMock(...args),
}));

import { requireSupabaseAuth, isNewSupabaseApiKey, createSupabaseFetch } from "../auth-middleware";

const VALID_ENV = {
  SUPABASE_URL: "https://example.test",
  SUPABASE_PUBLISHABLE_KEY: "sb_publishable_test123",
};

function headersRequest(entries: Record<string, string>) {
  return { headers: new Headers(entries) };
}

function makeValidJwt() {
  // Header/payload/signature shape only — requireSupabaseAuth only checks
  // there are 3 dot-separated segments before handing the token to
  // supabase-js; it never decodes it itself.
  return "aaa.bbb.ccc";
}

describe("requireSupabaseAuth (integrations/supabase/auth-middleware)", () => {
  const originalEnv = { ...process.env };

  beforeEach(() => {
    process.env.SUPABASE_URL = VALID_ENV.SUPABASE_URL;
    process.env.SUPABASE_PUBLISHABLE_KEY = VALID_ENV.SUPABASE_PUBLISHABLE_KEY;
    getRequestMock.mockReset();
    getClaimsMock.mockReset();
    createClientMock.mockReset();
    createClientMock.mockReturnValue({ auth: { getClaims: getClaimsMock } });
  });

  afterEach(() => {
    process.env = { ...originalEnv };
  });

  it("throws listing every missing env var, without touching the request, when config is absent", async () => {
    delete process.env.SUPABASE_URL;
    delete process.env.SUPABASE_PUBLISHABLE_KEY;
    const next = vi.fn();

    await expect(requireSupabaseAuth.options.server({ next })).rejects.toThrow(
      /Missing Supabase environment variable\(s\): SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY/,
    );
    expect(getRequestMock).not.toHaveBeenCalled();
    expect(next).not.toHaveBeenCalled();
  });

  it("throws when only one of the two required env vars is missing", async () => {
    delete process.env.SUPABASE_URL;
    const next = vi.fn();

    await expect(requireSupabaseAuth.options.server({ next })).rejects.toThrow(
      /Missing Supabase environment variable\(s\): SUPABASE_URL\./,
    );
  });

  it("rejects when the request has no headers at all", async () => {
    getRequestMock.mockReturnValue({});
    const next = vi.fn();

    await expect(requireSupabaseAuth.options.server({ next })).rejects.toThrow(
      /No request headers available/,
    );
  });

  it("rejects when there is no authorization header", async () => {
    getRequestMock.mockReturnValue(headersRequest({}));
    const next = vi.fn();

    await expect(requireSupabaseAuth.options.server({ next })).rejects.toThrow(
      /No authorization header provided/,
    );
  });

  it("rejects a non-Bearer authorization scheme (e.g. Basic auth)", async () => {
    getRequestMock.mockReturnValue(headersRequest({ authorization: "Basic dXNlcjpwYXNz" }));
    const next = vi.fn();

    await expect(requireSupabaseAuth.options.server({ next })).rejects.toThrow(
      /Only Bearer tokens are supported/,
    );
  });

  it("rejects 'Bearer ' with nothing after it", async () => {
    // Use a raw stub instead of the real Headers class: Headers trims
    // trailing whitespace from values (per the Fetch spec), which would
    // silently turn "Bearer " into "Bearer" before the code under test
    // ever runs — masking the exact branch this test targets.
    getRequestMock.mockReturnValue({
      headers: { get: (name: string) => (name === "authorization" ? "Bearer " : null) },
    });
    const next = vi.fn();

    await expect(requireSupabaseAuth.options.server({ next })).rejects.toThrow(/No token provided/);
  });

  it("rejects a token that is not JWT-shaped (not 3 dot-separated segments)", async () => {
    getRequestMock.mockReturnValue(headersRequest({ authorization: "Bearer not-a-jwt" }));
    const next = vi.fn();

    await expect(requireSupabaseAuth.options.server({ next })).rejects.toThrow(
      /Unauthorized: Invalid token/,
    );
    // Must fail on shape before ever calling out to Supabase.
    expect(createClientMock).not.toHaveBeenCalled();
  });

  it("rejects when supabase.auth.getClaims errors", async () => {
    getRequestMock.mockReturnValue(headersRequest({ authorization: `Bearer ${makeValidJwt()}` }));
    getClaimsMock.mockResolvedValue({ data: null, error: { message: "bad signature" } });
    const next = vi.fn();

    await expect(requireSupabaseAuth.options.server({ next })).rejects.toThrow(
      /Unauthorized: Invalid token/,
    );
  });

  it("rejects when getClaims resolves with no claims (no error, but empty data)", async () => {
    getRequestMock.mockReturnValue(headersRequest({ authorization: `Bearer ${makeValidJwt()}` }));
    getClaimsMock.mockResolvedValue({ data: {}, error: null });
    const next = vi.fn();

    await expect(requireSupabaseAuth.options.server({ next })).rejects.toThrow(
      /Unauthorized: Invalid token/,
    );
  });

  it("rejects claims that have no `sub` (user id)", async () => {
    getRequestMock.mockReturnValue(headersRequest({ authorization: `Bearer ${makeValidJwt()}` }));
    getClaimsMock.mockResolvedValue({ data: { claims: { role: "authenticated" } }, error: null });
    const next = vi.fn();

    await expect(requireSupabaseAuth.options.server({ next })).rejects.toThrow(
      /No user ID found in token/,
    );
  });

  it("on success, forwards supabase client, userId, and claims into context", async () => {
    getRequestMock.mockReturnValue(headersRequest({ authorization: `Bearer ${makeValidJwt()}` }));
    const claims = { sub: "user-123", role: "authenticated" };
    getClaimsMock.mockResolvedValue({ data: { claims }, error: null });
    const next = vi.fn().mockReturnValue("handler-ran");

    const result = await requireSupabaseAuth.options.server({ next });

    expect(createClientMock).toHaveBeenCalledWith(
      VALID_ENV.SUPABASE_URL,
      VALID_ENV.SUPABASE_PUBLISHABLE_KEY,
      expect.objectContaining({
        auth: expect.objectContaining({ persistSession: false, autoRefreshToken: false }),
      }),
    );
    expect(next).toHaveBeenCalledWith({
      context: {
        supabase: { auth: { getClaims: getClaimsMock } },
        userId: "user-123",
        claims,
      },
    });
    expect(result).toBe("handler-ran");
  });
});

describe("isNewSupabaseApiKey", () => {
  it("recognizes the new publishable-key format", () => {
    expect(isNewSupabaseApiKey("sb_publishable_abc123")).toBe(true);
  });

  it("recognizes the new secret-key format", () => {
    expect(isNewSupabaseApiKey("sb_secret_abc123")).toBe(true);
  });

  it("rejects a legacy JWT-style anon/service key", () => {
    expect(isNewSupabaseApiKey("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.payload.sig")).toBe(false);
  });

  it("rejects an empty string", () => {
    expect(isNewSupabaseApiKey("")).toBe(false);
  });
});

describe("createSupabaseFetch", () => {
  // This function decides, per outgoing request, whether an Authorization
  // header that happens to equal `Bearer <the project's own API key>` gets
  // stripped. Getting this wrong in either direction is a real security-
  // relevant regression: stripping a *user's* bearer token would silently
  // downgrade every request to anon; failing to strip a stale
  // Authorization:`Bearer <apikey>` for new-format keys breaks supabase-js's
  // own auth flow (which expects apikey-only, no bearer, for opaque keys).
  let fetchMock: ReturnType<typeof vi.fn>;
  const originalFetch = global.fetch;

  beforeEach(() => {
    fetchMock = vi.fn().mockResolvedValue(new Response("ok"));
    global.fetch = fetchMock as unknown as typeof fetch;
  });

  afterEach(() => {
    global.fetch = originalFetch;
  });

  it("strips a redundant Authorization:Bearer<key> header for new-format keys and sets apikey", async () => {
    const wrappedFetch = createSupabaseFetch("sb_publishable_abc123");

    await wrappedFetch("https://example.test/rest/v1/x", {
      headers: { Authorization: "Bearer sb_publishable_abc123" },
    });

    const [, init] = fetchMock.mock.calls[0];
    const sentHeaders = new Headers(init.headers);
    expect(sentHeaders.get("Authorization")).toBeNull();
    expect(sentHeaders.get("apikey")).toBe("sb_publishable_abc123");
  });

  it("does NOT strip Authorization for a legacy JWT-style key, even if it matches", async () => {
    const legacyKey = "eyJhbGciOiJIUzI1NiJ9.payload.sig";
    const wrappedFetch = createSupabaseFetch(legacyKey);

    await wrappedFetch("https://example.test/rest/v1/x", {
      headers: { Authorization: `Bearer ${legacyKey}` },
    });

    const [, init] = fetchMock.mock.calls[0];
    const sentHeaders = new Headers(init.headers);
    // Legacy keys are valid bearer JWTs themselves — stripping here would
    // be a behavior change, not a fix.
    expect(sentHeaders.get("Authorization")).toBe(`Bearer ${legacyKey}`);
    expect(sentHeaders.get("apikey")).toBe(legacyKey);
  });

  it("preserves a genuine user Authorization header (does not strip someone else's bearer token)", async () => {
    const wrappedFetch = createSupabaseFetch("sb_publishable_abc123");

    await wrappedFetch("https://example.test/rest/v1/x", {
      headers: { Authorization: "Bearer some-real-user-jwt.payload.sig" },
    });

    const [, init] = fetchMock.mock.calls[0];
    const sentHeaders = new Headers(init.headers);
    expect(sentHeaders.get("Authorization")).toBe("Bearer some-real-user-jwt.payload.sig");
    expect(sentHeaders.get("apikey")).toBe("sb_publishable_abc123");
  });

  it("always sets apikey even when no init/headers are passed", async () => {
    const wrappedFetch = createSupabaseFetch("sb_publishable_abc123");

    await wrappedFetch("https://example.test/rest/v1/x");

    const [, init] = fetchMock.mock.calls[0];
    const sentHeaders = new Headers(init.headers);
    expect(sentHeaders.get("apikey")).toBe("sb_publishable_abc123");
  });
});
