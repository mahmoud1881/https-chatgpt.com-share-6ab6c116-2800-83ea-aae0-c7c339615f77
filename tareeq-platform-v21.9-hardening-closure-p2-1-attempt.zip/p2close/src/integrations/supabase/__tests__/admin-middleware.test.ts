/**
 * Regression tests for requireSupabaseAdmin — the security gate that every
 * admin-only TanStack server function sits behind. It is the single canonical
 * function-middleware for admin authorization. It was previously
 * completely untested: a bug here silently turns "admin only" into
 * "anyone with a valid session".
 *
 *   $ grep -rl requireSupabaseAdmin src/lib --include='*.functions.ts'
 *
 * We call `.options.server` directly rather than going through the full
 * TanStack Start server-function/HTTP pipeline. `createMiddleware(...)`
 * returns a builder object whose `.options.server` is exactly the async
 * handler passed to `.server(...)` — see node_modules/@tanstack/
 * start-client-core/src/createMiddleware.ts. Calling it directly with a
 * hand-built `{ context, next }` exercises the real role-check branches
 * (the part that matters for security) without needing a live HTTP
 * request, a real Supabase project, or the outer requireSupabaseAuth hop
 * (which is exercised separately and is orthogonal to "is this user an
 * admin").
 */
import { describe, it, expect, vi } from "vitest";
import { requireSupabaseAdmin } from "../admin-middleware";

function mockContext(rpcResult: { data: unknown; error: unknown }) {
  return {
    supabase: { rpc: vi.fn().mockResolvedValue(rpcResult) },
    userId: "user-123",
  };
}

describe("requireSupabaseAdmin (integrations/supabase/admin-middleware)", () => {
  it("calls next() and lets the admin through when has_role returns true", async () => {
    const context = mockContext({ data: true, error: null });
    const next = vi.fn().mockReturnValue("handler-ran");

    const result = await requireSupabaseAdmin.options.server({ context, next });

    expect(context.supabase.rpc).toHaveBeenCalledWith("has_role", {
      _user_id: "user-123",
      _role: "admin",
    });
    expect(next).toHaveBeenCalledWith({ context: { isAdmin: true } });
    expect(result).toBe("handler-ran");
  });

  it("rejects a signed-in non-admin instead of silently letting them through", async () => {
    const context = mockContext({ data: false, error: null });
    const next = vi.fn();

    await expect(requireSupabaseAdmin.options.server({ context, next })).rejects.toThrow(
      /forbidden.*admin role required/i,
    );
    expect(next).not.toHaveBeenCalled();
  });

  it("fails closed (rejects) when the has_role RPC itself errors, rather than defaulting to allow", async () => {
    const context = mockContext({ data: null, error: { message: "db unreachable" } });
    const next = vi.fn();

    await expect(requireSupabaseAdmin.options.server({ context, next })).rejects.toThrow(
      /role check failed: db unreachable/,
    );
    expect(next).not.toHaveBeenCalled();
  });

  it("treats a falsy-but-not-strictly-false has_role result (null/undefined) as non-admin", async () => {
    // Guards against a future refactor accidentally using `isAdmin === false`
    // instead of `!isAdmin`, which would let an RPC returning null through.
    const context = mockContext({ data: null, error: null });
    const next = vi.fn();

    await expect(requireSupabaseAdmin.options.server({ context, next })).rejects.toThrow(
      /forbidden/i,
    );
    expect(next).not.toHaveBeenCalled();
  });
});
