import { supabaseServerAdmin } from "./client.server";
import { hasAdminRole } from "../../lib/auth/admin-role";

export type VerifiedAdminSession = {
  id: string;
  email?: string;
};

function jsonError(status: 401 | 403, error: string): Response {
  return new Response(JSON.stringify({ error }), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

/**
 * Server-only admin verification for raw Request handlers.
 *
 * Security properties:
 * - accepts Bearer access tokens only;
 * - validates the token with Supabase Auth via the server admin client;
 * - checks the canonical has_role(user_id, 'admin') RPC;
 * - fails closed on auth/role errors;
 * - never exposes the service-role key to client code.
 */
export async function verifyAdminSession(req: Request): Promise<VerifiedAdminSession> {
  const authHeader = req.headers.get("authorization");
  const match = authHeader?.match(/^Bearer\s+(.+)$/i);
  const token = match?.[1]?.trim();

  if (!token) {
    throw jsonError(401, "Unauthorized: Missing or malformed token");
  }

  const {
    data: { user },
    error: userError,
  } = await supabaseServerAdmin.auth.getUser(token);

  if (userError || !user) {
    throw jsonError(401, "Unauthorized: Invalid token credentials");
  }

  try {
    const hasRole = await hasAdminRole({
      supabase: supabaseServerAdmin,
      userId: user.id,
    });

    if (!hasRole) {
      throw jsonError(403, "Forbidden: Admin access required");
    }
  } catch (error) {
    if (error instanceof Response) throw error;
    // Do not leak database/RPC internals to callers.
    throw jsonError(403, "Forbidden: Admin access required");
  }

  return { id: user.id, email: user.email ?? undefined };
}
