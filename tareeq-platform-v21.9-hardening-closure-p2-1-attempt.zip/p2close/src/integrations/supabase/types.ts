export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5";
  };
  public: {
    Tables: {
      admin_config: {
        Row: {
          id: number;
          monthly_credit_budget: number;
          notes: string | null;
          updated_at: string;
          use_structured_search: boolean;
        };
        Insert: {
          id?: number;
          monthly_credit_budget?: number;
          notes?: string | null;
          updated_at?: string;
          use_structured_search?: boolean;
        };
        Update: {
          id?: number;
          monthly_credit_budget?: number;
          notes?: string | null;
          updated_at?: string;
          use_structured_search?: boolean;
        };
        Relationships: [];
      };
      ai_cache_shared: {
        Row: {
          cache_key: string;
          created_at: string;
          expires_at: string;
          hits: number;
          model: string | null;
          scope: string;
          value: Json;
        };
        Insert: {
          cache_key: string;
          created_at?: string;
          expires_at: string;
          hits?: number;
          model?: string | null;
          scope: string;
          value: Json;
        };
        Update: {
          cache_key?: string;
          created_at?: string;
          expires_at?: string;
          hits?: number;
          model?: string | null;
          scope?: string;
          value?: Json;
        };
        Relationships: [];
      };
      ai_cache_user: {
        Row: {
          cache_key: string;
          created_at: string;
          expires_at: string;
          hits: number;
          model: string | null;
          scope: string;
          user_id: string;
          value: Json;
        };
        Insert: {
          cache_key: string;
          created_at?: string;
          expires_at: string;
          hits?: number;
          model?: string | null;
          scope: string;
          user_id: string;
          value: Json;
        };
        Update: {
          cache_key?: string;
          created_at?: string;
          expires_at?: string;
          hits?: number;
          model?: string | null;
          scope?: string;
          user_id?: string;
          value?: Json;
        };
        Relationships: [];
      };
      ai_model_pricing: {
        Row: {
          credits_per_m_input: number;
          credits_per_m_output: number;
          model: string;
          updated_at: string;
        };
        Insert: {
          credits_per_m_input?: number;
          credits_per_m_output?: number;
          model: string;
          updated_at?: string;
        };
        Update: {
          credits_per_m_input?: number;
          credits_per_m_output?: number;
          model?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      ai_usage_log: {
        Row: {
          cache_hit: boolean;
          cached_tokens: number;
          completion_tokens: number;
          created_at: string;
          duration_ms: number | null;
          id: string;
          model: string;
          operation: string;
          prompt_tokens: number;
          status: string;
          total_tokens: number;
          user_id: string | null;
        };
        Insert: {
          cache_hit?: boolean;
          cached_tokens?: number;
          completion_tokens?: number;
          created_at?: string;
          duration_ms?: number | null;
          id?: string;
          model: string;
          operation: string;
          prompt_tokens?: number;
          status?: string;
          total_tokens?: number;
          user_id?: string | null;
        };
        Update: {
          cache_hit?: boolean;
          cached_tokens?: number;
          completion_tokens?: number;
          created_at?: string;
          duration_ms?: number | null;
          id?: string;
          model?: string;
          operation?: string;
          prompt_tokens?: number;
          status?: string;
          total_tokens?: number;
          user_id?: string | null;
        };
        Relationships: [];
      };
      alias_suggestions: {
        Row: {
          created_at: string;
          id: string;
          status: string;
          stop_id: string | null;
          suggested_alias: string;
          user_id: string | null;
        };
        Insert: {
          created_at?: string;
          id?: string;
          status?: string;
          stop_id?: string | null;
          suggested_alias: string;
          user_id?: string | null;
        };
        Update: {
          created_at?: string;
          id?: string;
          status?: string;
          stop_id?: string | null;
          suggested_alias?: string;
          user_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "alias_suggestions_stop_id_fkey";
            columns: ["stop_id"];
            isOneToOne: false;
            referencedRelation: "stops";
            referencedColumns: ["id"];
          },
        ];
      };
      api_incidents: {
        Row: {
          at: string;
          created_at: string;
          id: string;
          ip_hash: string | null;
          kind: string;
          message: string | null;
          meta: Json;
          session_id: string | null;
          source: string;
          url: string | null;
          user_agent: string | null;
        };
        Insert: {
          at?: string;
          created_at?: string;
          id?: string;
          ip_hash?: string | null;
          kind: string;
          message?: string | null;
          meta?: Json;
          session_id?: string | null;
          source: string;
          url?: string | null;
          user_agent?: string | null;
        };
        Update: {
          at?: string;
          created_at?: string;
          id?: string;
          ip_hash?: string | null;
          kind?: string;
          message?: string | null;
          meta?: Json;
          session_id?: string | null;
          source?: string;
          url?: string | null;
          user_agent?: string | null;
        };
        Relationships: [];
      };
      community_answers: {
        Row: {
          author_name: string | null;
          body: string;
          country: string | null;
          created_at: string;
          id: string;
          question_id: string;
          user_id: string | null;
        };
        Insert: {
          author_name?: string | null;
          body: string;
          country?: string | null;
          created_at?: string;
          id?: string;
          question_id: string;
          user_id?: string | null;
        };
        Update: {
          author_name?: string | null;
          body?: string;
          country?: string | null;
          created_at?: string;
          id?: string;
          question_id?: string;
          user_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "community_answers_question_id_fkey";
            columns: ["question_id"];
            isOneToOne: false;
            referencedRelation: "community_questions";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "community_answers_question_id_fkey";
            columns: ["question_id"];
            isOneToOne: false;
            referencedRelation: "community_questions_public";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "community_answers_question_id_fkey";
            columns: ["question_id"];
            isOneToOne: false;
            referencedRelation: "my_community_questions";
            referencedColumns: ["id"];
          },
        ];
      };
      community_questions: {
        Row: {
          answers_count: number;
          author_name: string | null;
          body: string | null;
          country: string | null;
          created_at: string;
          id: string;
          title: string;
          user_id: string | null;
        };
        Insert: {
          answers_count?: number;
          author_name?: string | null;
          body?: string | null;
          country?: string | null;
          created_at?: string;
          id?: string;
          title: string;
          user_id?: string | null;
        };
        Update: {
          answers_count?: number;
          author_name?: string | null;
          body?: string | null;
          country?: string | null;
          created_at?: string;
          id?: string;
          title?: string;
          user_id?: string | null;
        };
        Relationships: [];
      };
      community_routes: {
        Row: {
          confirmations: number;
          country: string | null;
          created_at: string;
          duration_min: number | null;
          from_area: string | null;
          id: string;
          price_egp: number | null;
          provenance: Json;
          status: string;
          title: string;
          to_area: string | null;
          user_id: string | null;
        };
        Insert: {
          confirmations?: number;
          country?: string | null;
          created_at?: string;
          duration_min?: number | null;
          from_area?: string | null;
          id?: string;
          price_egp?: number | null;
          provenance?: Json;
          status?: string;
          title: string;
          to_area?: string | null;
          user_id?: string | null;
        };
        Update: {
          confirmations?: number;
          country?: string | null;
          created_at?: string;
          duration_min?: number | null;
          from_area?: string | null;
          id?: string;
          price_egp?: number | null;
          provenance?: Json;
          status?: string;
          title?: string;
          to_area?: string | null;
          user_id?: string | null;
        };
        Relationships: [];
      };
      data_quality_review_items: {
        Row: {
          created_at: string;
          created_by: string | null;
          current_snapshot: Json | null;
          entity_id: string;
          entity_label: string | null;
          entity_type: string;
          id: string;
          issue_type: string;
          proposed_fix: Json | null;
          review_note: string | null;
          reviewed_at: string | null;
          reviewed_by: string | null;
          severity: string;
          source: string | null;
          status: string;
          updated_at: string;
        };
        Insert: {
          created_at?: string;
          created_by?: string | null;
          current_snapshot?: Json | null;
          entity_id: string;
          entity_label?: string | null;
          entity_type: string;
          id?: string;
          issue_type: string;
          proposed_fix?: Json | null;
          review_note?: string | null;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
          severity?: string;
          source?: string | null;
          status?: string;
          updated_at?: string;
        };
        Update: {
          created_at?: string;
          created_by?: string | null;
          current_snapshot?: Json | null;
          entity_id?: string;
          entity_label?: string | null;
          entity_type?: string;
          id?: string;
          issue_type?: string;
          proposed_fix?: Json | null;
          review_note?: string | null;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
          severity?: string;
          source?: string | null;
          status?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      geocode_failures: {
        Row: {
          attempts: number;
          last_query: string | null;
          reason: string | null;
          stop_id: string;
          tried_at: string;
        };
        Insert: {
          attempts?: number;
          last_query?: string | null;
          reason?: string | null;
          stop_id: string;
          tried_at?: string;
        };
        Update: {
          attempts?: number;
          last_query?: string | null;
          reason?: string | null;
          stop_id?: string;
          tried_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "geocode_failures_stop_id_fkey";
            columns: ["stop_id"];
            isOneToOne: true;
            referencedRelation: "stops";
            referencedColumns: ["id"];
          },
        ];
      };
      live_vehicle_pings: {
        Row: {
          country: string | null;
          created_at: string;
          heading: number | null;
          id: string;
          lat: number;
          lng: number;
          location: unknown;
          route_id: string;
          session_id: string;
          speed_kmh: number | null;
          user_id: string | null;
        };
        Insert: {
          country?: string | null;
          created_at?: string;
          heading?: number | null;
          id?: string;
          lat: number;
          lng: number;
          location?: unknown;
          route_id: string;
          session_id: string;
          speed_kmh?: number | null;
          user_id?: string | null;
        };
        Update: {
          country?: string | null;
          created_at?: string;
          heading?: number | null;
          id?: string;
          lat?: number;
          lng?: number;
          location?: unknown;
          route_id?: string;
          session_id?: string;
          speed_kmh?: number | null;
          user_id?: string | null;
        };
        Relationships: [];
      };
      ma_grand_taxi_pings: {
        Row: {
          country: string;
          created_at: string;
          id: string;
          note: string | null;
          reported_at: string;
          reported_by: string | null;
          route_id: string;
          seats_remaining: number | null;
          station_id: string | null;
          total_seats: number | null;
          user_id: string | null;
        };
        Insert: {
          country?: string;
          created_at?: string;
          id?: string;
          note?: string | null;
          reported_at?: string;
          reported_by?: string | null;
          route_id: string;
          seats_remaining?: number | null;
          station_id?: string | null;
          total_seats?: number | null;
          user_id?: string | null;
        };
        Update: {
          country?: string;
          created_at?: string;
          id?: string;
          note?: string | null;
          reported_at?: string;
          reported_by?: string | null;
          route_id?: string;
          seats_remaining?: number | null;
          station_id?: string | null;
          total_seats?: number | null;
          user_id?: string | null;
        };
        Relationships: [];
      };
      ma_tram_pings: {
        Row: {
          country: string;
          created_at: string;
          crowd_level: number | null;
          delay_minutes: number | null;
          id: string;
          line: string;
          note: string | null;
          reporter_id: string | null;
          station_id: string | null;
          user_id: string | null;
        };
        Insert: {
          country?: string;
          created_at?: string;
          crowd_level?: number | null;
          delay_minutes?: number | null;
          id?: string;
          line: string;
          note?: string | null;
          reporter_id?: string | null;
          station_id?: string | null;
          user_id?: string | null;
        };
        Update: {
          country?: string;
          created_at?: string;
          crowd_level?: number | null;
          delay_minutes?: number | null;
          id?: string;
          line?: string;
          note?: string | null;
          reporter_id?: string | null;
          station_id?: string | null;
          user_id?: string | null;
        };
        Relationships: [];
      };
      missing_searches: {
        Row: {
          city: string | null;
          country: string | null;
          created_at: string;
          from_query: string;
          from_stop_id: string | null;
          hits: number;
          id: string;
          status: string;
          to_query: string;
          to_stop_id: string | null;
          updated_at: string;
          user_id: string | null;
        };
        Insert: {
          city?: string | null;
          country?: string | null;
          created_at?: string;
          from_query: string;
          from_stop_id?: string | null;
          hits?: number;
          id?: string;
          status?: string;
          to_query: string;
          to_stop_id?: string | null;
          updated_at?: string;
          user_id?: string | null;
        };
        Update: {
          city?: string | null;
          country?: string | null;
          created_at?: string;
          from_query?: string;
          from_stop_id?: string | null;
          hits?: number;
          id?: string;
          status?: string;
          to_query?: string;
          to_stop_id?: string | null;
          updated_at?: string;
          user_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "missing_searches_from_stop_id_fkey";
            columns: ["from_stop_id"];
            isOneToOne: false;
            referencedRelation: "stops";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "missing_searches_to_stop_id_fkey";
            columns: ["to_stop_id"];
            isOneToOne: false;
            referencedRelation: "stops";
            referencedColumns: ["id"];
          },
        ];
      };
      peer_nodes: {
        Row: {
          created_at: string;
          id: string;
          is_available: boolean;
          last_seen_at: string;
          models: string[];
          peer_id: string;
          region: string | null;
          requests_served: number;
          tier: string;
          user_id: string;
        };
        Insert: {
          created_at?: string;
          id?: string;
          is_available?: boolean;
          last_seen_at?: string;
          models?: string[];
          peer_id: string;
          region?: string | null;
          requests_served?: number;
          tier: string;
          user_id: string;
        };
        Update: {
          created_at?: string;
          id?: string;
          is_available?: boolean;
          last_seen_at?: string;
          models?: string[];
          peer_id?: string;
          region?: string | null;
          requests_served?: number;
          tier?: string;
          user_id?: string;
        };
        Relationships: [];
      };
      profiles: {
        Row: {
          avatar_url: string | null;
          created_at: string;
          display_name: string | null;
          id: string;
          updated_at: string;
        };
        Insert: {
          avatar_url?: string | null;
          created_at?: string;
          display_name?: string | null;
          id: string;
          updated_at?: string;
        };
        Update: {
          avatar_url?: string | null;
          created_at?: string;
          display_name?: string | null;
          id?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      route_corrections: {
        Row: {
          created_at: string;
          from_stop_id: string | null;
          id: string;
          route_id: string | null;
          status: string;
          to_stop_id: string | null;
          user_comment: string | null;
          user_id: string | null;
        };
        Insert: {
          created_at?: string;
          from_stop_id?: string | null;
          id?: string;
          route_id?: string | null;
          status?: string;
          to_stop_id?: string | null;
          user_comment?: string | null;
          user_id?: string | null;
        };
        Update: {
          created_at?: string;
          from_stop_id?: string | null;
          id?: string;
          route_id?: string | null;
          status?: string;
          to_stop_id?: string | null;
          user_comment?: string | null;
          user_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "route_corrections_from_stop_id_fkey";
            columns: ["from_stop_id"];
            isOneToOne: false;
            referencedRelation: "stops";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "route_corrections_route_id_fkey";
            columns: ["route_id"];
            isOneToOne: false;
            referencedRelation: "routes";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "route_corrections_to_stop_id_fkey";
            columns: ["to_stop_id"];
            isOneToOne: false;
            referencedRelation: "stops";
            referencedColumns: ["id"];
          },
        ];
      };
      route_reports: {
        Row: {
          created_at: string;
          id: string;
          kind: string;
          message: string;
          route_code: string | null;
          route_id: string;
          status: string;
          suggested_stop: string | null;
          user_id: string | null;
        };
        Insert: {
          created_at?: string;
          id?: string;
          kind: string;
          message: string;
          route_code?: string | null;
          route_id: string;
          status?: string;
          suggested_stop?: string | null;
          user_id?: string | null;
        };
        Update: {
          created_at?: string;
          id?: string;
          kind?: string;
          message?: string;
          route_code?: string | null;
          route_id?: string;
          status?: string;
          suggested_stop?: string | null;
          user_id?: string | null;
        };
        Relationships: [];
      };
      route_requests: {
        Row: {
          area_hint: string | null;
          created_at: string;
          created_by: string | null;
          details: string | null;
          duplicate_of: string | null;
          from_text: string;
          hit_count: number;
          id: string;
          internal_note: string | null;
          linked_route_id: string | null;
          locale: string;
          normalized_key: string;
          reviewed_at: string | null;
          reviewed_by: string | null;
          source: string;
          status: Database["public"]["Enums"]["route_request_status"];
          to_text: string;
          updated_at: string;
        };
        Insert: {
          area_hint?: string | null;
          created_at?: string;
          created_by?: string | null;
          details?: string | null;
          duplicate_of?: string | null;
          from_text: string;
          hit_count?: number;
          id?: string;
          internal_note?: string | null;
          linked_route_id?: string | null;
          locale?: string;
          normalized_key: string;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
          source?: string;
          status?: Database["public"]["Enums"]["route_request_status"];
          to_text: string;
          updated_at?: string;
        };
        Update: {
          area_hint?: string | null;
          created_at?: string;
          created_by?: string | null;
          details?: string | null;
          duplicate_of?: string | null;
          from_text?: string;
          hit_count?: number;
          id?: string;
          internal_note?: string | null;
          linked_route_id?: string | null;
          locale?: string;
          normalized_key?: string;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
          source?: string;
          status?: Database["public"]["Enums"]["route_request_status"];
          to_text?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "route_requests_duplicate_of_fkey";
            columns: ["duplicate_of"];
            isOneToOne: false;
            referencedRelation: "route_requests";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "route_requests_linked_route_id_fkey";
            columns: ["linked_route_id"];
            isOneToOne: false;
            referencedRelation: "routes";
            referencedColumns: ["id"];
          },
        ];
      };
      route_stops: {
        Row: {
          created_at: string;
          direction: string;
          id: string;
          route_id: string;
          stop_id: string;
          stop_order: number;
        };
        Insert: {
          created_at?: string;
          direction?: string;
          id?: string;
          route_id: string;
          stop_id: string;
          stop_order: number;
        };
        Update: {
          created_at?: string;
          direction?: string;
          id?: string;
          route_id?: string;
          stop_id?: string;
          stop_order?: number;
        };
        Relationships: [
          {
            foreignKeyName: "route_stops_route_id_fkey";
            columns: ["route_id"];
            isOneToOne: false;
            referencedRelation: "routes";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "route_stops_stop_id_fkey";
            columns: ["stop_id"];
            isOneToOne: false;
            referencedRelation: "stops";
            referencedColumns: ["id"];
          },
        ];
      };
      route_stops_full: {
        Row: {
          country: string | null;
          created_at: string;
          id: string;
          lat: number | null;
          lng: number | null;
          route_id: string | null;
          stop_name: string | null;
          stop_order: number | null;
        };
        Insert: {
          country?: string | null;
          created_at?: string;
          id?: string;
          lat?: number | null;
          lng?: number | null;
          route_id?: string | null;
          stop_name?: string | null;
          stop_order?: number | null;
        };
        Update: {
          country?: string | null;
          created_at?: string;
          id?: string;
          lat?: number | null;
          lng?: number | null;
          route_id?: string | null;
          stop_name?: string | null;
          stop_order?: number | null;
        };
        Relationships: [
          {
            foreignKeyName: "route_stops_full_route_id_fkey";
            columns: ["route_id"];
            isOneToOne: false;
            referencedRelation: "transit_routes";
            referencedColumns: ["id"];
          },
        ];
      };
      route_verifications: {
        Row: {
          corroboration_count: number;
          created_at: string;
          created_by: string | null;
          duplicate_key: string;
          expires_at: string;
          id: string;
          locale: string;
          note: string | null;
          proposed_value_json: Json | null;
          review_note: string | null;
          reviewed_at: string | null;
          reviewer_id: string | null;
          route_id: string | null;
          route_reference: string;
          source: string;
          status: Database["public"]["Enums"]["route_verification_status"];
          verification_type: Database["public"]["Enums"]["route_verification_type"];
        };
        Insert: {
          corroboration_count?: number;
          created_at?: string;
          created_by?: string | null;
          duplicate_key: string;
          expires_at?: string;
          id?: string;
          locale?: string;
          note?: string | null;
          proposed_value_json?: Json | null;
          review_note?: string | null;
          reviewed_at?: string | null;
          reviewer_id?: string | null;
          route_id?: string | null;
          route_reference: string;
          source?: string;
          status?: Database["public"]["Enums"]["route_verification_status"];
          verification_type: Database["public"]["Enums"]["route_verification_type"];
        };
        Update: {
          corroboration_count?: number;
          created_at?: string;
          created_by?: string | null;
          duplicate_key?: string;
          expires_at?: string;
          id?: string;
          locale?: string;
          note?: string | null;
          proposed_value_json?: Json | null;
          review_note?: string | null;
          reviewed_at?: string | null;
          reviewer_id?: string | null;
          route_id?: string | null;
          route_reference?: string;
          source?: string;
          status?: Database["public"]["Enums"]["route_verification_status"];
          verification_type?: Database["public"]["Enums"]["route_verification_type"];
        };
        Relationships: [
          {
            foreignKeyName: "route_verifications_route_id_fkey";
            columns: ["route_id"];
            isOneToOne: false;
            referencedRelation: "routes";
            referencedColumns: ["id"];
          },
        ];
      };
      route_verifications_audit: {
        Row: {
          actor_id: string | null;
          created_at: string;
          from_status: Database["public"]["Enums"]["route_verification_status"] | null;
          id: string;
          reason: string | null;
          to_status: Database["public"]["Enums"]["route_verification_status"];
          verification_id: string;
        };
        Insert: {
          actor_id?: string | null;
          created_at?: string;
          from_status?: Database["public"]["Enums"]["route_verification_status"] | null;
          id?: string;
          reason?: string | null;
          to_status: Database["public"]["Enums"]["route_verification_status"];
          verification_id: string;
        };
        Update: {
          actor_id?: string | null;
          created_at?: string;
          from_status?: Database["public"]["Enums"]["route_verification_status"] | null;
          id?: string;
          reason?: string | null;
          to_status?: Database["public"]["Enums"]["route_verification_status"];
          verification_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "route_verifications_audit_verification_id_fkey";
            columns: ["verification_id"];
            isOneToOne: false;
            referencedRelation: "route_verifications";
            referencedColumns: ["id"];
          },
        ];
      };
      route_verifications_rate: {
        Row: {
          bucket_day: string;
          count: number;
          fingerprint: string;
          updated_at: string;
        };
        Insert: {
          bucket_day?: string;
          count?: number;
          fingerprint: string;
          updated_at?: string;
        };
        Update: {
          bucket_day?: string;
          count?: number;
          fingerprint?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      routes: {
        Row: {
          city: string | null;
          country: string;
          created_at: string;
          currency: string | null;
          end_stop_id: string | null;
          estimated_duration: number | null;
          has_intermediate_stops: boolean;
          id: string;
          is_verified: boolean;
          notes: string | null;
          price_max: number | null;
          price_min: number | null;
          provenance: Json;
          route_code: string | null;
          route_name: string;
          source: string | null;
          source_file: string | null;
          start_stop_id: string | null;
          status: string;
          transport_type_id: string | null;
          updated_at: string;
        };
        Insert: {
          city?: string | null;
          country?: string;
          created_at?: string;
          currency?: string | null;
          end_stop_id?: string | null;
          estimated_duration?: number | null;
          has_intermediate_stops?: boolean;
          id?: string;
          is_verified?: boolean;
          notes?: string | null;
          price_max?: number | null;
          price_min?: number | null;
          provenance?: Json;
          route_code?: string | null;
          route_name: string;
          source?: string | null;
          source_file?: string | null;
          start_stop_id?: string | null;
          status?: string;
          transport_type_id?: string | null;
          updated_at?: string;
        };
        Update: {
          city?: string | null;
          country?: string;
          created_at?: string;
          currency?: string | null;
          end_stop_id?: string | null;
          estimated_duration?: number | null;
          has_intermediate_stops?: boolean;
          id?: string;
          is_verified?: boolean;
          notes?: string | null;
          price_max?: number | null;
          price_min?: number | null;
          provenance?: Json;
          route_code?: string | null;
          route_name?: string;
          source?: string | null;
          source_file?: string | null;
          start_stop_id?: string | null;
          status?: string;
          transport_type_id?: string | null;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "routes_end_stop_id_fkey";
            columns: ["end_stop_id"];
            isOneToOne: false;
            referencedRelation: "stops";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "routes_start_stop_id_fkey";
            columns: ["start_stop_id"];
            isOneToOne: false;
            referencedRelation: "stops";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "routes_transport_type_id_fkey";
            columns: ["transport_type_id"];
            isOneToOne: false;
            referencedRelation: "transport_types";
            referencedColumns: ["id"];
          },
        ];
      };
      search_logs: {
        Row: {
          city: string | null;
          country: string | null;
          created_at: string;
          direct_routes_count: number;
          fallback_used: boolean;
          from_query: string | null;
          id: string;
          matched_from_stop_id: string | null;
          matched_to_stop_id: string | null;
          no_result_reason: string | null;
          normalized_from: string | null;
          normalized_to: string | null;
          result_count: number | null;
          result_status: string | null;
          source: string | null;
          to_query: string | null;
          transfer_routes_count: number;
          user_id: string | null;
        };
        Insert: {
          city?: string | null;
          country?: string | null;
          created_at?: string;
          direct_routes_count?: number;
          fallback_used?: boolean;
          from_query?: string | null;
          id?: string;
          matched_from_stop_id?: string | null;
          matched_to_stop_id?: string | null;
          no_result_reason?: string | null;
          normalized_from?: string | null;
          normalized_to?: string | null;
          result_count?: number | null;
          result_status?: string | null;
          source?: string | null;
          to_query?: string | null;
          transfer_routes_count?: number;
          user_id?: string | null;
        };
        Update: {
          city?: string | null;
          country?: string | null;
          created_at?: string;
          direct_routes_count?: number;
          fallback_used?: boolean;
          from_query?: string | null;
          id?: string;
          matched_from_stop_id?: string | null;
          matched_to_stop_id?: string | null;
          no_result_reason?: string | null;
          normalized_from?: string | null;
          normalized_to?: string | null;
          result_count?: number | null;
          result_status?: string | null;
          source?: string | null;
          to_query?: string | null;
          transfer_routes_count?: number;
          user_id?: string | null;
        };
        Relationships: [];
      };
      spatial_ref_sys: {
        Row: {
          auth_name: string | null;
          auth_srid: number | null;
          proj4text: string | null;
          srid: number;
          srtext: string | null;
        };
        Insert: {
          auth_name?: string | null;
          auth_srid?: number | null;
          proj4text?: string | null;
          srid: number;
          srtext?: string | null;
        };
        Update: {
          auth_name?: string | null;
          auth_srid?: number | null;
          proj4text?: string | null;
          srid?: number;
          srtext?: string | null;
        };
        Relationships: [];
      };
      stop_aliases: {
        Row: {
          alias: string;
          created_at: string;
          id: string;
          normalized_alias: string;
          source: string | null;
          stop_id: string;
        };
        Insert: {
          alias: string;
          created_at?: string;
          id?: string;
          normalized_alias: string;
          source?: string | null;
          stop_id: string;
        };
        Update: {
          alias?: string;
          created_at?: string;
          id?: string;
          normalized_alias?: string;
          source?: string | null;
          stop_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "stop_aliases_stop_id_fkey";
            columns: ["stop_id"];
            isOneToOne: false;
            referencedRelation: "stops";
            referencedColumns: ["id"];
          },
        ];
      };
      stops: {
        Row: {
          area: string | null;
          city: string | null;
          country: string;
          created_at: string;
          embedding: string | null;
          embedding_updated_at: string | null;
          id: string;
          is_verified: boolean;
          latitude: number | null;
          location: unknown;
          longitude: number | null;
          name_ar: string;
          name_en: string | null;
          normalized_name: string;
          provenance: Json;
          source: string | null;
          source_file: string | null;
          updated_at: string;
        };
        Insert: {
          area?: string | null;
          city?: string | null;
          country?: string;
          created_at?: string;
          embedding?: string | null;
          embedding_updated_at?: string | null;
          id?: string;
          is_verified?: boolean;
          latitude?: number | null;
          location?: unknown;
          longitude?: number | null;
          name_ar: string;
          name_en?: string | null;
          normalized_name: string;
          provenance?: Json;
          source?: string | null;
          source_file?: string | null;
          updated_at?: string;
        };
        Update: {
          area?: string | null;
          city?: string | null;
          country?: string;
          created_at?: string;
          embedding?: string | null;
          embedding_updated_at?: string | null;
          id?: string;
          is_verified?: boolean;
          latitude?: number | null;
          location?: unknown;
          longitude?: number | null;
          name_ar?: string;
          name_en?: string | null;
          normalized_name?: string;
          provenance?: Json;
          source?: string | null;
          source_file?: string | null;
          updated_at?: string;
        };
        Relationships: [];
      };
      traffic_reports: {
        Row: {
          area: string;
          country: string | null;
          created_at: string;
          expires_at: string | null;
          id: string;
          lat: number | null;
          lat_coarse: number | null;
          lng: number | null;
          lng_coarse: number | null;
          notes: string | null;
          severity: string;
          user_id: string | null;
        };
        Insert: {
          area: string;
          country?: string | null;
          created_at?: string;
          expires_at?: string | null;
          id?: string;
          lat?: number | null;
          lat_coarse?: number | null;
          lng?: number | null;
          lng_coarse?: number | null;
          notes?: string | null;
          severity: string;
          user_id?: string | null;
        };
        Update: {
          area?: string;
          country?: string | null;
          created_at?: string;
          expires_at?: string | null;
          id?: string;
          lat?: number | null;
          lat_coarse?: number | null;
          lng?: number | null;
          lng_coarse?: number | null;
          notes?: string | null;
          severity?: string;
          user_id?: string | null;
        };
        Relationships: [];
      };
      train_line_stations: {
        Row: {
          city: string | null;
          created_at: string;
          id: string;
          is_major: boolean;
          line_id: string;
          sort_order: number;
          station_name: string;
          station_name_en: string | null;
        };
        Insert: {
          city?: string | null;
          created_at?: string;
          id?: string;
          is_major?: boolean;
          line_id: string;
          sort_order: number;
          station_name: string;
          station_name_en?: string | null;
        };
        Update: {
          city?: string | null;
          created_at?: string;
          id?: string;
          is_major?: boolean;
          line_id?: string;
          sort_order?: number;
          station_name?: string;
          station_name_en?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "train_line_stations_line_id_fkey";
            columns: ["line_id"];
            isOneToOne: false;
            referencedRelation: "train_lines";
            referencedColumns: ["id"];
          },
        ];
      };
      train_lines: {
        Row: {
          created_at: string;
          description: string | null;
          from_city: string;
          id: string;
          image_path: string | null;
          name_ar: string;
          name_en: string | null;
          slug: string;
          to_city: string;
          updated_at: string;
        };
        Insert: {
          created_at?: string;
          description?: string | null;
          from_city: string;
          id?: string;
          image_path?: string | null;
          name_ar: string;
          name_en?: string | null;
          slug: string;
          to_city: string;
          updated_at?: string;
        };
        Update: {
          created_at?: string;
          description?: string | null;
          from_city?: string;
          id?: string;
          image_path?: string | null;
          name_ar?: string;
          name_en?: string | null;
          slug?: string;
          to_city?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      train_schedule: {
        Row: {
          arrival_time: string | null;
          created_at: string;
          departure_time: string | null;
          id: string;
          sort_order: number;
          station_name: string;
          train_id: string;
        };
        Insert: {
          arrival_time?: string | null;
          created_at?: string;
          departure_time?: string | null;
          id?: string;
          sort_order: number;
          station_name: string;
          train_id: string;
        };
        Update: {
          arrival_time?: string | null;
          created_at?: string;
          departure_time?: string | null;
          id?: string;
          sort_order?: number;
          station_name?: string;
          train_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "train_schedule_train_id_fkey";
            columns: ["train_id"];
            isOneToOne: false;
            referencedRelation: "trains";
            referencedColumns: ["id"];
          },
        ];
      };
      trains: {
        Row: {
          arrival_time: string | null;
          created_at: string;
          departure_time: string | null;
          direction: string;
          duration_minutes: number | null;
          id: string;
          line_id: string;
          notes: string | null;
          runs_days: string | null;
          stops_count: number | null;
          train_number: string;
          train_type: string;
          updated_at: string;
        };
        Insert: {
          arrival_time?: string | null;
          created_at?: string;
          departure_time?: string | null;
          direction?: string;
          duration_minutes?: number | null;
          id?: string;
          line_id: string;
          notes?: string | null;
          runs_days?: string | null;
          stops_count?: number | null;
          train_number: string;
          train_type: string;
          updated_at?: string;
        };
        Update: {
          arrival_time?: string | null;
          created_at?: string;
          departure_time?: string | null;
          direction?: string;
          duration_minutes?: number | null;
          id?: string;
          line_id?: string;
          notes?: string | null;
          runs_days?: string | null;
          stops_count?: number | null;
          train_number?: string;
          train_type?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "trains_line_id_fkey";
            columns: ["line_id"];
            isOneToOne: false;
            referencedRelation: "train_lines";
            referencedColumns: ["id"];
          },
        ];
      };
      transit_routes: {
        Row: {
          country: string | null;
          created_at: string;
          id: string;
          name: string | null;
          route_code: string | null;
        };
        Insert: {
          country?: string | null;
          created_at?: string;
          id?: string;
          name?: string | null;
          route_code?: string | null;
        };
        Update: {
          country?: string | null;
          created_at?: string;
          id?: string;
          name?: string | null;
          route_code?: string | null;
        };
        Relationships: [];
      };
      transport_types: {
        Row: {
          color: string | null;
          created_at: string;
          icon: string | null;
          id: string;
          name_ar: string;
          name_en: string;
        };
        Insert: {
          color?: string | null;
          created_at?: string;
          icon?: string | null;
          id: string;
          name_ar: string;
          name_en: string;
        };
        Update: {
          color?: string | null;
          created_at?: string;
          icon?: string | null;
          id?: string;
          name_ar?: string;
          name_en?: string;
        };
        Relationships: [];
      };
      user_roles: {
        Row: {
          created_at: string;
          id: string;
          role: Database["public"]["Enums"]["app_role"];
          user_id: string;
        };
        Insert: {
          created_at?: string;
          id?: string;
          role: Database["public"]["Enums"]["app_role"];
          user_id: string;
        };
        Update: {
          created_at?: string;
          id?: string;
          role?: Database["public"]["Enums"]["app_role"];
          user_id?: string;
        };
        Relationships: [];
      };
      user_route_suggestions: {
        Row: {
          boarding_point: string | null;
          city: string | null;
          country: string | null;
          created_at: string;
          drop_point: string | null;
          from_text: string;
          id: string;
          notes: string | null;
          route_name: string | null;
          status: string;
          to_text: string;
          transport_type_id: string | null;
          user_id: string | null;
        };
        Insert: {
          boarding_point?: string | null;
          city?: string | null;
          country?: string | null;
          created_at?: string;
          drop_point?: string | null;
          from_text: string;
          id?: string;
          notes?: string | null;
          route_name?: string | null;
          status?: string;
          to_text: string;
          transport_type_id?: string | null;
          user_id?: string | null;
        };
        Update: {
          boarding_point?: string | null;
          city?: string | null;
          country?: string | null;
          created_at?: string;
          drop_point?: string | null;
          from_text?: string;
          id?: string;
          notes?: string | null;
          route_name?: string | null;
          status?: string;
          to_text?: string;
          transport_type_id?: string | null;
          user_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "user_route_suggestions_transport_type_id_fkey";
            columns: ["transport_type_id"];
            isOneToOne: false;
            referencedRelation: "transport_types";
            referencedColumns: ["id"];
          },
        ];
      };
      user_sessions: {
        Row: {
          ended_at: string | null;
          id: string;
          ip_hash: string | null;
          last_seen_at: string;
          platform: string | null;
          started_at: string;
          user_agent: string | null;
          user_id: string;
        };
        Insert: {
          ended_at?: string | null;
          id?: string;
          ip_hash?: string | null;
          last_seen_at?: string;
          platform?: string | null;
          started_at?: string;
          user_agent?: string | null;
          user_id: string;
        };
        Update: {
          ended_at?: string | null;
          id?: string;
          ip_hash?: string | null;
          last_seen_at?: string;
          platform?: string | null;
          started_at?: string;
          user_agent?: string | null;
          user_id?: string;
        };
        Relationships: [];
      };
      user_stations: {
        Row: {
          country: string | null;
          created_at: string;
          id: string;
          label: string | null;
          station_id: string;
          user_id: string;
        };
        Insert: {
          country?: string | null;
          created_at?: string;
          id?: string;
          label?: string | null;
          station_id: string;
          user_id: string;
        };
        Update: {
          country?: string | null;
          created_at?: string;
          id?: string;
          label?: string | null;
          station_id?: string;
          user_id?: string;
        };
        Relationships: [];
      };
    };
    Views: {
      available_peers: {
        Row: {
          created_at: string | null;
          id: string | null;
          is_available: boolean | null;
          last_seen_at: string | null;
          models: string[] | null;
          peer_id: string | null;
          region: string | null;
          requests_served: number | null;
          tier: string | null;
        };
        Insert: {
          created_at?: string | null;
          id?: string | null;
          is_available?: boolean | null;
          last_seen_at?: string | null;
          models?: string[] | null;
          peer_id?: string | null;
          region?: string | null;
          requests_served?: number | null;
          tier?: string | null;
        };
        Update: {
          created_at?: string | null;
          id?: string | null;
          is_available?: boolean | null;
          last_seen_at?: string | null;
          models?: string[] | null;
          peer_id?: string | null;
          region?: string | null;
          requests_served?: number | null;
          tier?: string | null;
        };
        Relationships: [];
      };
      community_answers_public: {
        Row: {
          author_name: string | null;
          body: string | null;
          country: string | null;
          created_at: string | null;
          id: string | null;
          question_id: string | null;
        };
        Insert: {
          author_name?: string | null;
          body?: string | null;
          country?: string | null;
          created_at?: string | null;
          id?: string | null;
          question_id?: string | null;
        };
        Update: {
          author_name?: string | null;
          body?: string | null;
          country?: string | null;
          created_at?: string | null;
          id?: string | null;
          question_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "community_answers_question_id_fkey";
            columns: ["question_id"];
            isOneToOne: false;
            referencedRelation: "community_questions";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "community_answers_question_id_fkey";
            columns: ["question_id"];
            isOneToOne: false;
            referencedRelation: "community_questions_public";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "community_answers_question_id_fkey";
            columns: ["question_id"];
            isOneToOne: false;
            referencedRelation: "my_community_questions";
            referencedColumns: ["id"];
          },
        ];
      };
      community_questions_public: {
        Row: {
          answers_count: number | null;
          author_name: string | null;
          body: string | null;
          country: string | null;
          created_at: string | null;
          id: string | null;
          title: string | null;
        };
        Insert: {
          answers_count?: number | null;
          author_name?: string | null;
          body?: string | null;
          country?: string | null;
          created_at?: string | null;
          id?: string | null;
          title?: string | null;
        };
        Update: {
          answers_count?: number | null;
          author_name?: string | null;
          body?: string | null;
          country?: string | null;
          created_at?: string | null;
          id?: string | null;
          title?: string | null;
        };
        Relationships: [];
      };
      community_routes_public: {
        Row: {
          confirmations: number | null;
          country: string | null;
          created_at: string | null;
          duration_min: number | null;
          from_area: string | null;
          id: string | null;
          price_egp: number | null;
          status: string | null;
          title: string | null;
          to_area: string | null;
        };
        Insert: {
          confirmations?: number | null;
          country?: string | null;
          created_at?: string | null;
          duration_min?: number | null;
          from_area?: string | null;
          id?: string | null;
          price_egp?: number | null;
          status?: string | null;
          title?: string | null;
          to_area?: string | null;
        };
        Update: {
          confirmations?: number | null;
          country?: string | null;
          created_at?: string | null;
          duration_min?: number | null;
          from_area?: string | null;
          id?: string | null;
          price_egp?: number | null;
          status?: string | null;
          title?: string | null;
          to_area?: string | null;
        };
        Relationships: [];
      };
      geography_columns: {
        Row: {
          coord_dimension: number | null;
          f_geography_column: unknown;
          f_table_catalog: unknown;
          f_table_name: unknown;
          f_table_schema: unknown;
          srid: number | null;
          type: string | null;
        };
        Relationships: [];
      };
      geometry_columns: {
        Row: {
          coord_dimension: number | null;
          f_geometry_column: unknown;
          f_table_catalog: string | null;
          f_table_name: unknown;
          f_table_schema: unknown;
          srid: number | null;
          type: string | null;
        };
        Insert: {
          coord_dimension?: number | null;
          f_geometry_column?: unknown;
          f_table_catalog?: string | null;
          f_table_name?: unknown;
          f_table_schema?: unknown;
          srid?: number | null;
          type?: string | null;
        };
        Update: {
          coord_dimension?: number | null;
          f_geometry_column?: unknown;
          f_table_catalog?: string | null;
          f_table_name?: unknown;
          f_table_schema?: unknown;
          srid?: number | null;
          type?: string | null;
        };
        Relationships: [];
      };
      live_vehicle_pings_public: {
        Row: {
          country: string | null;
          created_at: string | null;
          heading: number | null;
          id: string | null;
          lat: number | null;
          lng: number | null;
          route_id: string | null;
          session_id: string | null;
          speed_kmh: number | null;
        };
        Insert: {
          country?: string | null;
          created_at?: string | null;
          heading?: number | null;
          id?: string | null;
          lat?: number | null;
          lng?: number | null;
          route_id?: string | null;
          session_id?: string | null;
          speed_kmh?: number | null;
        };
        Update: {
          country?: string | null;
          created_at?: string | null;
          heading?: number | null;
          id?: string | null;
          lat?: number | null;
          lng?: number | null;
          route_id?: string | null;
          session_id?: string | null;
          speed_kmh?: number | null;
        };
        Relationships: [];
      };
      ma_grand_taxi_pings_public: {
        Row: {
          country: string | null;
          created_at: string | null;
          id: string | null;
          note: string | null;
          reported_at: string | null;
          route_id: string | null;
          seats_remaining: number | null;
          station_id: string | null;
          total_seats: number | null;
        };
        Insert: {
          country?: string | null;
          created_at?: string | null;
          id?: string | null;
          note?: string | null;
          reported_at?: string | null;
          route_id?: string | null;
          seats_remaining?: number | null;
          station_id?: string | null;
          total_seats?: number | null;
        };
        Update: {
          country?: string | null;
          created_at?: string | null;
          id?: string | null;
          note?: string | null;
          reported_at?: string | null;
          route_id?: string | null;
          seats_remaining?: number | null;
          station_id?: string | null;
          total_seats?: number | null;
        };
        Relationships: [];
      };
      ma_tram_pings_public: {
        Row: {
          country: string | null;
          created_at: string | null;
          crowd_level: number | null;
          delay_minutes: number | null;
          id: string | null;
          line: string | null;
          note: string | null;
          station_id: string | null;
        };
        Insert: {
          country?: string | null;
          created_at?: string | null;
          crowd_level?: number | null;
          delay_minutes?: number | null;
          id?: string | null;
          line?: string | null;
          note?: string | null;
          station_id?: string | null;
        };
        Update: {
          country?: string | null;
          created_at?: string | null;
          crowd_level?: number | null;
          delay_minutes?: number | null;
          id?: string | null;
          line?: string | null;
          note?: string | null;
          station_id?: string | null;
        };
        Relationships: [];
      };
      my_community_answers: {
        Row: {
          author_name: string | null;
          body: string | null;
          country: string | null;
          created_at: string | null;
          id: string | null;
          question_id: string | null;
          user_id: string | null;
        };
        Insert: {
          author_name?: string | null;
          body?: string | null;
          country?: string | null;
          created_at?: string | null;
          id?: string | null;
          question_id?: string | null;
          user_id?: string | null;
        };
        Update: {
          author_name?: string | null;
          body?: string | null;
          country?: string | null;
          created_at?: string | null;
          id?: string | null;
          question_id?: string | null;
          user_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "community_answers_question_id_fkey";
            columns: ["question_id"];
            isOneToOne: false;
            referencedRelation: "community_questions";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "community_answers_question_id_fkey";
            columns: ["question_id"];
            isOneToOne: false;
            referencedRelation: "community_questions_public";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "community_answers_question_id_fkey";
            columns: ["question_id"];
            isOneToOne: false;
            referencedRelation: "my_community_questions";
            referencedColumns: ["id"];
          },
        ];
      };
      my_community_questions: {
        Row: {
          answers_count: number | null;
          author_name: string | null;
          body: string | null;
          country: string | null;
          created_at: string | null;
          id: string | null;
          title: string | null;
          user_id: string | null;
        };
        Insert: {
          answers_count?: number | null;
          author_name?: string | null;
          body?: string | null;
          country?: string | null;
          created_at?: string | null;
          id?: string | null;
          title?: string | null;
          user_id?: string | null;
        };
        Update: {
          answers_count?: number | null;
          author_name?: string | null;
          body?: string | null;
          country?: string | null;
          created_at?: string | null;
          id?: string | null;
          title?: string | null;
          user_id?: string | null;
        };
        Relationships: [];
      };
      my_community_routes: {
        Row: {
          confirmations: number | null;
          country: string | null;
          created_at: string | null;
          duration_min: number | null;
          from_area: string | null;
          id: string | null;
          price_egp: number | null;
          status: string | null;
          title: string | null;
          to_area: string | null;
          user_id: string | null;
        };
        Insert: {
          confirmations?: number | null;
          country?: string | null;
          created_at?: string | null;
          duration_min?: number | null;
          from_area?: string | null;
          id?: string | null;
          price_egp?: number | null;
          status?: string | null;
          title?: string | null;
          to_area?: string | null;
          user_id?: string | null;
        };
        Update: {
          confirmations?: number | null;
          country?: string | null;
          created_at?: string | null;
          duration_min?: number | null;
          from_area?: string | null;
          id?: string | null;
          price_egp?: number | null;
          status?: string | null;
          title?: string | null;
          to_area?: string | null;
          user_id?: string | null;
        };
        Relationships: [];
      };
      traffic_reports_public: {
        Row: {
          area: string | null;
          country: string | null;
          created_at: string | null;
          expires_at: string | null;
          id: string | null;
          lat_coarse: number | null;
          lng_coarse: number | null;
          notes: string | null;
          severity: string | null;
        };
        Insert: {
          area?: string | null;
          country?: string | null;
          created_at?: string | null;
          expires_at?: string | null;
          id?: string | null;
          lat_coarse?: number | null;
          lng_coarse?: number | null;
          notes?: string | null;
          severity?: string | null;
        };
        Update: {
          area?: string | null;
          country?: string | null;
          created_at?: string | null;
          expires_at?: string | null;
          id?: string | null;
          lat_coarse?: number | null;
          lng_coarse?: number | null;
          notes?: string | null;
          severity?: string | null;
        };
        Relationships: [];
      };
    };
    Functions: {
      enforce_rate_limit: {
        Args: {
          p_bucket: string;
          p_identifier: string;
          p_max_count: number;
          p_window: string;
        };
        Returns: undefined;
      };
      submit_route_verification_atomic: {
        Args: {
          p_bucket_day: string;
          p_duplicate_key: string;
          p_fingerprint: string;
          p_locale: string;
          p_note: string | null;
          p_proposed_value_json: Json | null;
          p_rate_limit?: number;
          p_route_id: string | null;
          p_route_reference: string;
          p_source: string;
          p_user_id: string | null;
          p_verification_type: Database["public"]["Enums"]["route_verification_type"];
        };
        Returns: {
          duplicate: boolean;
          id: string;
        }[];
      };
      upsert_route_with_stops_atomic: {
        Args: {
          p_city: string;
          p_country: string;
          p_end_stop_id: string | null;
          p_has_intermediate_stops: boolean;
          p_is_verified: boolean;
          p_notes: string | null;
          p_route_code: string;
          p_route_name: string;
          p_source: string;
          p_source_file: string | null;
          p_start_stop_id: string | null;
          p_status: string;
          p_stop_ids: string[];
          p_transport_type_id: string;
        };
        Returns: {
          action: string;
          route_id: string;
        }[];
      };
      _postgis_deprecate: {
        Args: { newname: string; oldname: string; version: string };
        Returns: undefined;
      };
      _postgis_index_extent: {
        Args: { col: string; tbl: unknown };
        Returns: unknown;
      };
      _postgis_pgsql_version: { Args: never; Returns: string };
      _postgis_scripts_pgsql_version: { Args: never; Returns: string };
      _postgis_selectivity: {
        Args: { att_name: string; geom: unknown; mode?: string; tbl: unknown };
        Returns: number;
      };
      _postgis_stats: {
        Args: { ""?: string; att_name: string; tbl: unknown };
        Returns: string;
      };
      _st_3dintersects: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      _st_contains: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      _st_containsproperly: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      _st_coveredby:
        | { Args: { geog1: unknown; geog2: unknown }; Returns: boolean }
        | { Args: { geom1: unknown; geom2: unknown }; Returns: boolean };
      _st_covers:
        | { Args: { geog1: unknown; geog2: unknown }; Returns: boolean }
        | { Args: { geom1: unknown; geom2: unknown }; Returns: boolean };
      _st_crosses: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      _st_dwithin: {
        Args: {
          geog1: unknown;
          geog2: unknown;
          tolerance: number;
          use_spheroid?: boolean;
        };
        Returns: boolean;
      };
      _st_equals: { Args: { geom1: unknown; geom2: unknown }; Returns: boolean };
      _st_intersects: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      _st_linecrossingdirection: {
        Args: { line1: unknown; line2: unknown };
        Returns: number;
      };
      _st_longestline: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: unknown;
      };
      _st_maxdistance: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: number;
      };
      _st_orderingequals: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      _st_overlaps: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      _st_sortablehash: { Args: { geom: unknown }; Returns: number };
      _st_touches: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      _st_voronoi: {
        Args: {
          clip?: unknown;
          g1: unknown;
          return_polygons?: boolean;
          tolerance?: number;
        };
        Returns: unknown;
      };
      _st_within: { Args: { geom1: unknown; geom2: unknown }; Returns: boolean };
      addauth: { Args: { "": string }; Returns: boolean };
      addgeometrycolumn:
        | {
            Args: {
              catalog_name: string;
              column_name: string;
              new_dim: number;
              new_srid_in: number;
              new_type: string;
              schema_name: string;
              table_name: string;
              use_typmod?: boolean;
            };
            Returns: string;
          }
        | {
            Args: {
              column_name: string;
              new_dim: number;
              new_srid: number;
              new_type: string;
              schema_name: string;
              table_name: string;
              use_typmod?: boolean;
            };
            Returns: string;
          }
        | {
            Args: {
              column_name: string;
              new_dim: number;
              new_srid: number;
              new_type: string;
              table_name: string;
              use_typmod?: boolean;
            };
            Returns: string;
          };
      bulk_update_stop_embeddings: { Args: { _payload: Json }; Returns: number };
      cleanup_old_data: { Args: never; Returns: undefined };
      confirm_community_route: { Args: { route_id: string }; Returns: number };
      disablelongtransactions: { Args: never; Returns: string };
      dropgeometrycolumn:
        | {
            Args: {
              catalog_name: string;
              column_name: string;
              schema_name: string;
              table_name: string;
            };
            Returns: string;
          }
        | {
            Args: {
              column_name: string;
              schema_name: string;
              table_name: string;
            };
            Returns: string;
          }
        | { Args: { column_name: string; table_name: string }; Returns: string };
      dropgeometrytable:
        | {
            Args: {
              catalog_name: string;
              schema_name: string;
              table_name: string;
            };
            Returns: string;
          }
        | { Args: { schema_name: string; table_name: string }; Returns: string }
        | { Args: { table_name: string }; Returns: string };
      enablelongtransactions: { Args: never; Returns: string };
      end_session: { Args: { _session_id: string }; Returns: undefined };
      equals: { Args: { geom1: unknown; geom2: unknown }; Returns: boolean };
      geometry: { Args: { "": string }; Returns: unknown };
      geometry_above: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_below: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_cmp: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: number;
      };
      geometry_contained_3d: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_contains: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_contains_3d: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_distance_box: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: number;
      };
      geometry_distance_centroid: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: number;
      };
      geometry_eq: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_ge: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_gt: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_le: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_left: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_lt: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_overabove: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_overbelow: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_overlaps: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_overlaps_3d: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_overleft: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_overright: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_right: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_same: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_same_3d: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geometry_within: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      geomfromewkt: { Args: { "": string }; Returns: unknown };
      get_admin_stats: { Args: never; Returns: Json };
      get_nearby_stops: {
        Args: {
          max_dist_meters: number;
          max_results?: number;
          user_lat: number;
          user_lng: number;
        };
        Returns: {
          distance_meters: number;
          id: string;
          latitude: number;
          longitude: number;
          name_ar: string;
        }[];
      };
      get_public_flags: { Args: never; Returns: Json };
      get_public_traffic_reports: {
        Args: { p_country?: string; p_limit?: number };
        Returns: {
          area: string;
          country: string;
          created_at: string;
          expires_at: string;
          id: string;
          lat_coarse: number;
          lng_coarse: number;
          notes: string;
          severity: string;
        }[];
      };
      gettransactionid: { Args: never; Returns: unknown };
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"];
          _user_id: string;
        };
        Returns: boolean;
      };
      heartbeat_session: { Args: { _session_id: string }; Returns: undefined };
      log_ai_usage: {
        Args: {
          _cache_hit?: boolean;
          _cached_tokens?: number;
          _completion_tokens?: number;
          _duration_ms?: number;
          _model: string;
          _operation: string;
          _prompt_tokens?: number;
          _status?: string;
        };
        Returns: undefined;
      };
      longtransactionsenabled: { Args: never; Returns: boolean };
      match_stops_semantic: {
        Args: {
          match_count?: number;
          match_country?: string;
          min_similarity?: number;
          query_embedding: string;
        };
        Returns: {
          city: string;
          country: string;
          id: string;
          is_verified: boolean;
          name_ar: string;
          name_en: string;
          similarity: number;
        }[];
      };
      populate_geometry_columns:
        | { Args: { tbl_oid: unknown; use_typmod?: boolean }; Returns: number }
        | { Args: { use_typmod?: boolean }; Returns: string };
      postgis_constraint_dims: {
        Args: { geomcolumn: string; geomschema: string; geomtable: string };
        Returns: number;
      };
      postgis_constraint_srid: {
        Args: { geomcolumn: string; geomschema: string; geomtable: string };
        Returns: number;
      };
      postgis_constraint_type: {
        Args: { geomcolumn: string; geomschema: string; geomtable: string };
        Returns: string;
      };
      postgis_extensions_upgrade: { Args: never; Returns: string };
      postgis_full_version: { Args: never; Returns: string };
      postgis_geos_version: { Args: never; Returns: string };
      postgis_lib_build_date: { Args: never; Returns: string };
      postgis_lib_revision: { Args: never; Returns: string };
      postgis_lib_version: { Args: never; Returns: string };
      postgis_libjson_version: { Args: never; Returns: string };
      postgis_liblwgeom_version: { Args: never; Returns: string };
      postgis_libprotobuf_version: { Args: never; Returns: string };
      postgis_libxml_version: { Args: never; Returns: string };
      postgis_proj_version: { Args: never; Returns: string };
      postgis_scripts_build_date: { Args: never; Returns: string };
      postgis_scripts_installed: { Args: never; Returns: string };
      postgis_scripts_released: { Args: never; Returns: string };
      postgis_svn_version: { Args: never; Returns: string };
      postgis_type_name: {
        Args: {
          coord_dimension: number;
          geomname: string;
          use_new_name?: boolean;
        };
        Returns: string;
      };
      postgis_version: { Args: never; Returns: string };
      postgis_wagyu_version: { Args: never; Returns: string };
      show_limit: { Args: never; Returns: number };
      show_trgm: { Args: { "": string }; Returns: string[] };
      st_3dclosestpoint: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: unknown;
      };
      st_3ddistance: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: number;
      };
      st_3dintersects: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      st_3dlongestline: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: unknown;
      };
      st_3dmakebox: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: unknown;
      };
      st_3dmaxdistance: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: number;
      };
      st_3dshortestline: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: unknown;
      };
      st_addpoint: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: unknown;
      };
      st_angle:
        | { Args: { line1: unknown; line2: unknown }; Returns: number }
        | {
            Args: { pt1: unknown; pt2: unknown; pt3: unknown; pt4?: unknown };
            Returns: number;
          };
      st_area:
        | { Args: { geog: unknown; use_spheroid?: boolean }; Returns: number }
        | { Args: { "": string }; Returns: number };
      st_asencodedpolyline: {
        Args: { geom: unknown; nprecision?: number };
        Returns: string;
      };
      st_asewkt: { Args: { "": string }; Returns: string };
      st_asgeojson:
        | {
            Args: { geog: unknown; maxdecimaldigits?: number; options?: number };
            Returns: string;
          }
        | {
            Args: { geom: unknown; maxdecimaldigits?: number; options?: number };
            Returns: string;
          }
        | {
            Args: {
              geom_column?: string;
              maxdecimaldigits?: number;
              pretty_bool?: boolean;
              r: Record<string, unknown>;
            };
            Returns: string;
          }
        | { Args: { "": string }; Returns: string };
      st_asgml:
        | {
            Args: {
              geog: unknown;
              id?: string;
              maxdecimaldigits?: number;
              nprefix?: string;
              options?: number;
            };
            Returns: string;
          }
        | {
            Args: { geom: unknown; maxdecimaldigits?: number; options?: number };
            Returns: string;
          }
        | { Args: { "": string }; Returns: string }
        | {
            Args: {
              geog: unknown;
              id?: string;
              maxdecimaldigits?: number;
              nprefix?: string;
              options?: number;
              version: number;
            };
            Returns: string;
          }
        | {
            Args: {
              geom: unknown;
              id?: string;
              maxdecimaldigits?: number;
              nprefix?: string;
              options?: number;
              version: number;
            };
            Returns: string;
          };
      st_askml:
        | {
            Args: { geog: unknown; maxdecimaldigits?: number; nprefix?: string };
            Returns: string;
          }
        | {
            Args: { geom: unknown; maxdecimaldigits?: number; nprefix?: string };
            Returns: string;
          }
        | { Args: { "": string }; Returns: string };
      st_aslatlontext: {
        Args: { geom: unknown; tmpl?: string };
        Returns: string;
      };
      st_asmarc21: { Args: { format?: string; geom: unknown }; Returns: string };
      st_asmvtgeom: {
        Args: {
          bounds: unknown;
          buffer?: number;
          clip_geom?: boolean;
          extent?: number;
          geom: unknown;
        };
        Returns: unknown;
      };
      st_assvg:
        | {
            Args: { geog: unknown; maxdecimaldigits?: number; rel?: number };
            Returns: string;
          }
        | {
            Args: { geom: unknown; maxdecimaldigits?: number; rel?: number };
            Returns: string;
          }
        | { Args: { "": string }; Returns: string };
      st_astext: { Args: { "": string }; Returns: string };
      st_astwkb:
        | {
            Args: {
              geom: unknown;
              prec?: number;
              prec_m?: number;
              prec_z?: number;
              with_boxes?: boolean;
              with_sizes?: boolean;
            };
            Returns: string;
          }
        | {
            Args: {
              geom: unknown[];
              ids: number[];
              prec?: number;
              prec_m?: number;
              prec_z?: number;
              with_boxes?: boolean;
              with_sizes?: boolean;
            };
            Returns: string;
          };
      st_asx3d: {
        Args: { geom: unknown; maxdecimaldigits?: number; options?: number };
        Returns: string;
      };
      st_azimuth:
        | { Args: { geog1: unknown; geog2: unknown }; Returns: number }
        | { Args: { geom1: unknown; geom2: unknown }; Returns: number };
      st_boundingdiagonal: {
        Args: { fits?: boolean; geom: unknown };
        Returns: unknown;
      };
      st_buffer:
        | {
            Args: { geom: unknown; options?: string; radius: number };
            Returns: unknown;
          }
        | {
            Args: { geom: unknown; quadsegs: number; radius: number };
            Returns: unknown;
          };
      st_centroid: { Args: { "": string }; Returns: unknown };
      st_clipbybox2d: {
        Args: { box: unknown; geom: unknown };
        Returns: unknown;
      };
      st_closestpoint: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: unknown;
      };
      st_collect: { Args: { geom1: unknown; geom2: unknown }; Returns: unknown };
      st_concavehull: {
        Args: {
          param_allow_holes?: boolean;
          param_geom: unknown;
          param_pctconvex: number;
        };
        Returns: unknown;
      };
      st_contains: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      st_containsproperly: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      st_coorddim: { Args: { geometry: unknown }; Returns: number };
      st_coveredby:
        | { Args: { geog1: unknown; geog2: unknown }; Returns: boolean }
        | { Args: { geom1: unknown; geom2: unknown }; Returns: boolean };
      st_covers:
        | { Args: { geog1: unknown; geog2: unknown }; Returns: boolean }
        | { Args: { geom1: unknown; geom2: unknown }; Returns: boolean };
      st_crosses: { Args: { geom1: unknown; geom2: unknown }; Returns: boolean };
      st_curvetoline: {
        Args: { flags?: number; geom: unknown; tol?: number; toltype?: number };
        Returns: unknown;
      };
      st_delaunaytriangles: {
        Args: { flags?: number; g1: unknown; tolerance?: number };
        Returns: unknown;
      };
      st_difference: {
        Args: { geom1: unknown; geom2: unknown; gridsize?: number };
        Returns: unknown;
      };
      st_disjoint: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      st_distance:
        | {
            Args: { geog1: unknown; geog2: unknown; use_spheroid?: boolean };
            Returns: number;
          }
        | { Args: { geom1: unknown; geom2: unknown }; Returns: number };
      st_distancesphere:
        | { Args: { geom1: unknown; geom2: unknown }; Returns: number }
        | {
            Args: { geom1: unknown; geom2: unknown; radius: number };
            Returns: number;
          };
      st_distancespheroid: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: number;
      };
      st_dwithin: {
        Args: {
          geog1: unknown;
          geog2: unknown;
          tolerance: number;
          use_spheroid?: boolean;
        };
        Returns: boolean;
      };
      st_equals: { Args: { geom1: unknown; geom2: unknown }; Returns: boolean };
      st_expand:
        | { Args: { box: unknown; dx: number; dy: number }; Returns: unknown }
        | {
            Args: { box: unknown; dx: number; dy: number; dz?: number };
            Returns: unknown;
          }
        | {
            Args: {
              dm?: number;
              dx: number;
              dy: number;
              dz?: number;
              geom: unknown;
            };
            Returns: unknown;
          };
      st_force3d: { Args: { geom: unknown; zvalue?: number }; Returns: unknown };
      st_force3dm: {
        Args: { geom: unknown; mvalue?: number };
        Returns: unknown;
      };
      st_force3dz: {
        Args: { geom: unknown; zvalue?: number };
        Returns: unknown;
      };
      st_force4d: {
        Args: { geom: unknown; mvalue?: number; zvalue?: number };
        Returns: unknown;
      };
      st_generatepoints:
        | { Args: { area: unknown; npoints: number }; Returns: unknown }
        | {
            Args: { area: unknown; npoints: number; seed: number };
            Returns: unknown;
          };
      st_geogfromtext: { Args: { "": string }; Returns: unknown };
      st_geographyfromtext: { Args: { "": string }; Returns: unknown };
      st_geohash:
        | { Args: { geog: unknown; maxchars?: number }; Returns: string }
        | { Args: { geom: unknown; maxchars?: number }; Returns: string };
      st_geomcollfromtext: { Args: { "": string }; Returns: unknown };
      st_geometricmedian: {
        Args: {
          fail_if_not_converged?: boolean;
          g: unknown;
          max_iter?: number;
          tolerance?: number;
        };
        Returns: unknown;
      };
      st_geometryfromtext: { Args: { "": string }; Returns: unknown };
      st_geomfromewkt: { Args: { "": string }; Returns: unknown };
      st_geomfromgeojson:
        | { Args: { "": Json }; Returns: unknown }
        | { Args: { "": Json }; Returns: unknown }
        | { Args: { "": string }; Returns: unknown };
      st_geomfromgml: { Args: { "": string }; Returns: unknown };
      st_geomfromkml: { Args: { "": string }; Returns: unknown };
      st_geomfrommarc21: { Args: { marc21xml: string }; Returns: unknown };
      st_geomfromtext: { Args: { "": string }; Returns: unknown };
      st_gmltosql: { Args: { "": string }; Returns: unknown };
      st_hasarc: { Args: { geometry: unknown }; Returns: boolean };
      st_hausdorffdistance: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: number;
      };
      st_hexagon: {
        Args: { cell_i: number; cell_j: number; origin?: unknown; size: number };
        Returns: unknown;
      };
      st_hexagongrid: {
        Args: { bounds: unknown; size: number };
        Returns: Record<string, unknown>[];
      };
      st_interpolatepoint: {
        Args: { line: unknown; point: unknown };
        Returns: number;
      };
      st_intersection: {
        Args: { geom1: unknown; geom2: unknown; gridsize?: number };
        Returns: unknown;
      };
      st_intersects:
        | { Args: { geog1: unknown; geog2: unknown }; Returns: boolean }
        | { Args: { geom1: unknown; geom2: unknown }; Returns: boolean };
      st_isvaliddetail: {
        Args: { flags?: number; geom: unknown };
        Returns: Database["public"]["CompositeTypes"]["valid_detail"];
        SetofOptions: {
          from: "*";
          to: "valid_detail";
          isOneToOne: true;
          isSetofReturn: false;
        };
      };
      st_length:
        | { Args: { geog: unknown; use_spheroid?: boolean }; Returns: number }
        | { Args: { "": string }; Returns: number };
      st_letters: { Args: { font?: Json; letters: string }; Returns: unknown };
      st_linecrossingdirection: {
        Args: { line1: unknown; line2: unknown };
        Returns: number;
      };
      st_linefromencodedpolyline: {
        Args: { nprecision?: number; txtin: string };
        Returns: unknown;
      };
      st_linefromtext: { Args: { "": string }; Returns: unknown };
      st_linelocatepoint: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: number;
      };
      st_linetocurve: { Args: { geometry: unknown }; Returns: unknown };
      st_locatealong: {
        Args: { geometry: unknown; leftrightoffset?: number; measure: number };
        Returns: unknown;
      };
      st_locatebetween: {
        Args: {
          frommeasure: number;
          geometry: unknown;
          leftrightoffset?: number;
          tomeasure: number;
        };
        Returns: unknown;
      };
      st_locatebetweenelevations: {
        Args: { fromelevation: number; geometry: unknown; toelevation: number };
        Returns: unknown;
      };
      st_longestline: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: unknown;
      };
      st_makebox2d: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: unknown;
      };
      st_makeline: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: unknown;
      };
      st_makevalid: {
        Args: { geom: unknown; params: string };
        Returns: unknown;
      };
      st_maxdistance: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: number;
      };
      st_minimumboundingcircle: {
        Args: { inputgeom: unknown; segs_per_quarter?: number };
        Returns: unknown;
      };
      st_mlinefromtext: { Args: { "": string }; Returns: unknown };
      st_mpointfromtext: { Args: { "": string }; Returns: unknown };
      st_mpolyfromtext: { Args: { "": string }; Returns: unknown };
      st_multilinestringfromtext: { Args: { "": string }; Returns: unknown };
      st_multipointfromtext: { Args: { "": string }; Returns: unknown };
      st_multipolygonfromtext: { Args: { "": string }; Returns: unknown };
      st_node: { Args: { g: unknown }; Returns: unknown };
      st_normalize: { Args: { geom: unknown }; Returns: unknown };
      st_offsetcurve: {
        Args: { distance: number; line: unknown; params?: string };
        Returns: unknown;
      };
      st_orderingequals: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      st_overlaps: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: boolean;
      };
      st_perimeter: {
        Args: { geog: unknown; use_spheroid?: boolean };
        Returns: number;
      };
      st_pointfromtext: { Args: { "": string }; Returns: unknown };
      st_pointm: {
        Args: {
          mcoordinate: number;
          srid?: number;
          xcoordinate: number;
          ycoordinate: number;
        };
        Returns: unknown;
      };
      st_pointz: {
        Args: {
          srid?: number;
          xcoordinate: number;
          ycoordinate: number;
          zcoordinate: number;
        };
        Returns: unknown;
      };
      st_pointzm: {
        Args: {
          mcoordinate: number;
          srid?: number;
          xcoordinate: number;
          ycoordinate: number;
          zcoordinate: number;
        };
        Returns: unknown;
      };
      st_polyfromtext: { Args: { "": string }; Returns: unknown };
      st_polygonfromtext: { Args: { "": string }; Returns: unknown };
      st_project: {
        Args: { azimuth: number; distance: number; geog: unknown };
        Returns: unknown;
      };
      st_quantizecoordinates: {
        Args: {
          g: unknown;
          prec_m?: number;
          prec_x: number;
          prec_y?: number;
          prec_z?: number;
        };
        Returns: unknown;
      };
      st_reduceprecision: {
        Args: { geom: unknown; gridsize: number };
        Returns: unknown;
      };
      st_relate: { Args: { geom1: unknown; geom2: unknown }; Returns: string };
      st_removerepeatedpoints: {
        Args: { geom: unknown; tolerance?: number };
        Returns: unknown;
      };
      st_segmentize: {
        Args: { geog: unknown; max_segment_length: number };
        Returns: unknown;
      };
      st_setsrid:
        | { Args: { geog: unknown; srid: number }; Returns: unknown }
        | { Args: { geom: unknown; srid: number }; Returns: unknown };
      st_sharedpaths: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: unknown;
      };
      st_shortestline: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: unknown;
      };
      st_simplifypolygonhull: {
        Args: { geom: unknown; is_outer?: boolean; vertex_fraction: number };
        Returns: unknown;
      };
      st_split: { Args: { geom1: unknown; geom2: unknown }; Returns: unknown };
      st_square: {
        Args: { cell_i: number; cell_j: number; origin?: unknown; size: number };
        Returns: unknown;
      };
      st_squaregrid: {
        Args: { bounds: unknown; size: number };
        Returns: Record<string, unknown>[];
      };
      st_srid:
        { Args: { geog: unknown }; Returns: number } | { Args: { geom: unknown }; Returns: number };
      st_subdivide: {
        Args: { geom: unknown; gridsize?: number; maxvertices?: number };
        Returns: unknown[];
      };
      st_swapordinates: {
        Args: { geom: unknown; ords: unknown };
        Returns: unknown;
      };
      st_symdifference: {
        Args: { geom1: unknown; geom2: unknown; gridsize?: number };
        Returns: unknown;
      };
      st_symmetricdifference: {
        Args: { geom1: unknown; geom2: unknown };
        Returns: unknown;
      };
      st_tileenvelope: {
        Args: {
          bounds?: unknown;
          margin?: number;
          x: number;
          y: number;
          zoom: number;
        };
        Returns: unknown;
      };
      st_touches: { Args: { geom1: unknown; geom2: unknown }; Returns: boolean };
      st_transform:
        | {
            Args: { from_proj: string; geom: unknown; to_proj: string };
            Returns: unknown;
          }
        | {
            Args: { from_proj: string; geom: unknown; to_srid: number };
            Returns: unknown;
          }
        | { Args: { geom: unknown; to_proj: string }; Returns: unknown };
      st_triangulatepolygon: { Args: { g1: unknown }; Returns: unknown };
      st_union:
        | { Args: { geom1: unknown; geom2: unknown }; Returns: unknown }
        | {
            Args: { geom1: unknown; geom2: unknown; gridsize: number };
            Returns: unknown;
          };
      st_voronoilines: {
        Args: { extend_to?: unknown; g1: unknown; tolerance?: number };
        Returns: unknown;
      };
      st_voronoipolygons: {
        Args: { extend_to?: unknown; g1: unknown; tolerance?: number };
        Returns: unknown;
      };
      st_within: { Args: { geom1: unknown; geom2: unknown }; Returns: boolean };
      st_wkbtosql: { Args: { wkb: string }; Returns: unknown };
      st_wkttosql: { Args: { "": string }; Returns: unknown };
      st_wrapx: {
        Args: { geom: unknown; move: number; wrap: number };
        Returns: unknown;
      };
      start_session: {
        Args: { _platform?: string; _user_agent?: string };
        Returns: string;
      };
      unlockrows: { Args: { "": string }; Returns: number };
      updategeometrysrid: {
        Args: {
          catalogn_name: string;
          column_name: string;
          new_srid_in: number;
          schema_name: string;
          table_name: string;
        };
        Returns: string;
      };
    };
    Enums: {
      app_role: "admin" | "moderator" | "user";
      route_request_status: "pending" | "under_review" | "published" | "rejected" | "duplicate";
      route_verification_status:
        "pending" | "corroborated" | "approved" | "rejected" | "duplicate" | "expired";
      route_verification_type:
        | "confirmed"
        | "fare_changed"
        | "pickup_changed"
        | "line_stopped"
        | "better_alternative"
        | "not_tried";
    };
    CompositeTypes: {
      geometry_dump: {
        path: number[] | null;
        geom: unknown;
      };
      valid_detail: {
        valid: boolean | null;
        reason: string | null;
        location: unknown;
      };
    };
  };
};

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">;

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">];

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R;
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] & DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R;
      }
      ? R
      : never
    : never;

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    keyof DefaultSchema["Tables"] | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I;
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I;
      }
      ? I
      : never
    : never;

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    keyof DefaultSchema["Tables"] | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U;
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U;
      }
      ? U
      : never
    : never;

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    keyof DefaultSchema["Enums"] | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never;

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    keyof DefaultSchema["CompositeTypes"] | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never;

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
      route_request_status: ["pending", "under_review", "published", "rejected", "duplicate"],
      route_verification_status: [
        "pending",
        "corroborated",
        "approved",
        "rejected",
        "duplicate",
        "expired",
      ],
      route_verification_type: [
        "confirmed",
        "fare_changed",
        "pickup_changed",
        "line_stopped",
        "better_alternative",
        "not_tried",
      ],
    },
  },
} as const;
