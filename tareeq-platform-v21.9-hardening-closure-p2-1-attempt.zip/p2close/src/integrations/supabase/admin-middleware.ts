// Composite middleware: authenticated user + admin role check.
// Wraps `requireSupabaseAuth` and adds a role verification step via the
// SECURITY DEFINER `has_role()` RPC. Any server function that uses this
// middleware is guaranteed structurally to reject non-admin callers —
// no need to call `assertAdmin(context)` manually in the handler.
//
// Usage:
//   export const doAdminThing = createServerFn({ method: "POST" })
//     .middleware([requireSupabaseAdmin])
//     .handler(async ({ context }) => {
//       // context.supabase, context.userId, context.claims — same as
//       // requireSupabaseAuth, but the caller is proven to be an admin.
//     });
import { createMiddleware } from "@tanstack/react-start";
import { requireSupabaseAuth } from "./auth-middleware";
import { hasAdminRole } from "../../lib/auth/admin-role";

// The role check itself lives in @/lib/auth/admin-role.ts (single source of
// truth) — this file only owns what happens after: throw, or let the
// request through unchanged (note: unlike lib/auth/require-admin.ts, this
// canonical gate also marks the context as admin-verified so every handler
// receives the same contract. This is the only function-middleware allowed
// to perform an admin role decision.
export const requireSupabaseAdmin = createMiddleware({ type: "function" })
  .middleware([requireSupabaseAuth])
  .server(async ({ next, context }) => {
    const isAdmin = await hasAdminRole(context);
    if (!isAdmin) throw new Error("forbidden — admin role required");
    return next({ context: { isAdmin: true as const } });
  });
