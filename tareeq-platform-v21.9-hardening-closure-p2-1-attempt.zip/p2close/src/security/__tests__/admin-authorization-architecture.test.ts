import { describe, expect, it } from "vitest";
import { execFileSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("admin authorization architecture", () => {
  it("passes the repository-wide endpoint/service-role/RLS security audit", () => {
    expect(() =>
      execFileSync(process.execPath, ["scripts/audit-admin-security.mjs"], {
        cwd: resolve("."),
        stdio: "pipe",
      }),
    ).not.toThrow();
  });

  it("keeps the Supabase service-role key inside the canonical server client", () => {
    const audit = readFileSync("scripts/audit-admin-security.mjs", "utf8");
    expect(audit).toContain("direct SUPABASE_SERVICE_ROLE_KEY access outside canonical server client");
    expect(audit).toContain("admin-sensitive endpoint missing requireSupabaseAdmin");
  });
});
