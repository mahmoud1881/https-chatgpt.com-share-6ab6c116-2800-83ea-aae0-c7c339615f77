// Lazy wrapper around /data/governorate-bus-lines.json (~74KB).
export type GovBusLine = {
  governorate: string;
  route_code: string;
  transport_mode: "bus" | "minibus" | "microbus";
  origin_name: string;
  destination_name: string;
  stops: string[];
  name_ar?: string;
};

export let GOV_BUS_LINES: GovBusLine[] = [];

const subscribers = new Set<() => void>();
let loadPromise: Promise<GovBusLine[]> | null = null;
let loaded = false;

export function onGovBusLinesLoaded(cb: () => void): () => void {
  if (loaded) {
    try {
      cb();
    } catch {
      /* noop */
    }
    return () => {};
  }
  subscribers.add(cb);
  return () => subscribers.delete(cb);
}

export function loadGovBusLines(): Promise<GovBusLine[]> {
  if (loaded) return Promise.resolve(GOV_BUS_LINES);
  if (loadPromise) return loadPromise;
  if (typeof fetch === "undefined") return Promise.resolve([]);
  loadPromise = import("@/lib/compact-json")
    .then((m) =>
      m.fetchJsonSmart<GovBusLine>(
        "/data/governorate-bus-lines.json",
        "governorate-bus-lines",
        "1",
      ),
    )
    .then((data) => {
      GOV_BUS_LINES = data ?? [];
      loaded = true;
      subscribers.forEach((cb) => {
        try {
          cb();
        } catch {
          /* noop */
        }
      });
      subscribers.clear();
      return GOV_BUS_LINES;
    })
    .catch((err) => {
      loadPromise = null;
      console.warn("[gov-bus-lines] load failed:", err);
      return [];
    });
  return loadPromise;
}

export function isGovBusLinesLoaded() {
  return loaded;
}
