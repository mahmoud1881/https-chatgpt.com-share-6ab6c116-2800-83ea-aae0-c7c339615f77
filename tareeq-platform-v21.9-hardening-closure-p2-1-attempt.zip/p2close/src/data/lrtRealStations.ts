// ============================================================================
// القطار الكهربائي الخفيف LRT — قطار العاصمة (بيانات حقيقية)
// المصدر: بحث موثق (13 وكيل) — الهيئة القومية للأنفاق (NAT)،
//         وزارة النقل المصرية، شركة RATP Dev Mobility Cairo، OpenStreetMap.
// آخر مراجعة: 2024 — المرحلتان الأولى والثانية (12 محطة تشغيلية).
// ملاحظة: هذا ملف بيانات جديد مستقل ولا يعدّل أو يستبدل أي بيانات قائمة.
// ============================================================================

export type LrtRealArea = { name: string; lat: number; lng: number };

export type LrtRealStation = {
  id: string;
  name: string;
  nameEn: string;
  lat: number;
  lng: number;
  branch: "shared" | "capital" | "10th_ramadan";
  order: number;
  interchange?: string;
  areas: LrtRealArea[];
};

export const LRT_REAL_STATIONS: LrtRealStation[] = [
  {
    id: "adly-mansour",
    name: "عدلي منصور",
    nameEn: "Adly Mansour",
    lat: 30.146389,
    lng: 31.418889,
    branch: "shared",
    order: 1,
    interchange: "الخط الثالث للمترو + السوبر جيت + قطار السويس + BRT",
    areas: [
      { name: "مدينة السلام", lat: 30.132, lng: 31.404 },
      { name: "مدينة النهضة", lat: 30.126, lng: 31.417 },
      { name: "طريق القاهرة–الإسماعيلية الصحراوي", lat: 30.148, lng: 31.44 },
      { name: "معهد التكنولوجيا الصناعية", lat: 30.134, lng: 31.407 },
      { name: "موقف السوبر جيت المركزي", lat: 30.147, lng: 31.42 },
      { name: "الطريق الدائري (تقاطع BRT)", lat: 30.14, lng: 31.435 },
    ],
  },
  {
    id: "el-obour",
    name: "العبور",
    nameEn: "El Obour",
    lat: 30.1542,
    lng: 31.4947,
    branch: "shared",
    order: 2,
    areas: [
      { name: "مدينة العبور", lat: 30.221, lng: 31.481 },
      { name: "المنطقة الصناعية الأولى بالعبور", lat: 30.216, lng: 31.497 },
      { name: "جمعية أحمد عرابي", lat: 30.245, lng: 31.462 },
      { name: "نادي العبور الرياضي", lat: 30.219, lng: 31.474 },
      { name: "جولف سيتي مول", lat: 30.223, lng: 31.472 },
      { name: "سوق العبور المركزي", lat: 30.211, lng: 31.492 },
    ],
  },
  {
    id: "el-mostakbal",
    name: "المستقبل",
    nameEn: "El Mostakbal",
    lat: 30.1585,
    lng: 31.5583,
    branch: "shared",
    order: 3,
    areas: [
      { name: "مدينة المستقبل", lat: 30.121, lng: 31.606 },
      { name: "كمبوند بيتا جاردنز", lat: 30.117, lng: 31.601 },
      { name: "كمبوند بلومفيلدز", lat: 30.101, lng: 31.615 },
      { name: "مدينة الشروق – البوابة الغربية", lat: 30.142, lng: 31.611 },
    ],
  },
  {
    id: "el-shorouk",
    name: "الشروق",
    nameEn: "El Shorouk",
    lat: 30.150921,
    lng: 31.644621,
    branch: "shared",
    order: 4,
    areas: [
      { name: "الجامعة البريطانية في مصر (BUE)", lat: 30.117, lng: 31.643 },
      { name: "أكاديمية الشروق", lat: 30.128, lng: 31.635 },
      { name: "جامعة هليوبوليس", lat: 30.144, lng: 31.639 },
      { name: "مدينتي – البوابة الجنوبية", lat: 30.096, lng: 31.646 },
      { name: "مستشفى الشروق العام", lat: 30.147, lng: 31.636 },
    ],
  },
  {
    id: "new-heliopolis",
    name: "هليوبوليس الجديدة",
    nameEn: "New Heliopolis",
    lat: 30.1455,
    lng: 31.6823,
    branch: "shared",
    order: 5,
    areas: [
      { name: "مدينة هليوبوليس الجديدة", lat: 30.144, lng: 31.68 },
      { name: "كمبوند سوديك إيست (Sodic East)", lat: 30.151, lng: 31.687 },
      { name: "كمبوند سراي (Sarai)", lat: 30.02, lng: 31.638 },
      { name: "مدينتي – البوابة الشمالية", lat: 30.115, lng: 31.641 },
    ],
  },
  {
    id: "badr",
    name: "بدر",
    nameEn: "Badr",
    lat: 30.175055,
    lng: 31.716099,
    branch: "shared",
    order: 6,
    interchange: "محطة تفرّع الخط (اتجاه العاصمة الإدارية / اتجاه العاشر من رمضان)",
    areas: [
      { name: "جامعة بدر بالقاهرة (BUC)", lat: 30.152, lng: 31.727 },
      { name: "الجامعة المصرية الروسية (ERU)", lat: 30.148, lng: 31.741 },
      { name: "المنطقة الصناعية بمدينة بدر", lat: 30.171, lng: 31.712 },
      { name: "سنترال بارك مدينة بدر", lat: 30.164, lng: 31.72 },
      { name: "طريق القاهرة–السويس الصحراوي", lat: 30.169, lng: 31.71 },
    ],
  },
  // فرع العاصمة الإدارية
  {
    id: "el-roubiki",
    name: "الروبيكي",
    nameEn: "El Roubiki",
    lat: 30.166532,
    lng: 31.752453,
    branch: "capital",
    order: 7,
    areas: [
      { name: "مدينة الروبيكي للجلود", lat: 30.166, lng: 31.755 },
      { name: "معامل هيئة سلامة الغذاء", lat: 30.164, lng: 31.749 },
      { name: "مجمعات المخازن الاستراتيجية – طريق السويس", lat: 30.16, lng: 31.762 },
    ],
  },
  {
    id: "capital-gardens",
    name: "حدائق العاصمة",
    nameEn: "Capital Gardens",
    lat: 30.1441,
    lng: 31.8122,
    branch: "capital",
    order: 8,
    areas: [
      { name: "مدينة حدائق العاصمة (سكن كل المصريين)", lat: 30.14, lng: 31.81 },
      { name: "مشروع سكن مصر", lat: 30.138, lng: 31.815 },
      { name: "مشروع جنة", lat: 30.146, lng: 31.808 },
      { name: "مسجد الفتاح العليم", lat: 30.023, lng: 31.647 },
    ],
  },
  {
    id: "capital-airport",
    name: "مطار العاصمة",
    nameEn: "Capital Airport",
    lat: 30.0911,
    lng: 31.815,
    branch: "capital",
    order: 9,
    areas: [
      { name: "مطار العاصمة الدولي", lat: 30.093, lng: 31.816 },
      { name: "المنطقة الإدارية للمطار", lat: 30.089, lng: 31.812 },
      { name: "المنطقة اللوجستية للشحن الجوي", lat: 30.085, lng: 31.82 },
    ],
  },
  {
    id: "arts-culture",
    name: "مدينة الفنون والثقافة",
    nameEn: "Arts & Culture City",
    lat: 30.013727,
    lng: 31.724969,
    branch: "capital",
    order: 10,
    interchange: "ربط مع مونوريل شرق النيل (العاصمة الإدارية)",
    areas: [
      { name: "دار الأوبرا المصرية الجديدة", lat: 30.015, lng: 31.726 },
      { name: "مدينة الفنون والثقافة", lat: 30.014, lng: 31.725 },
      { name: "فندق الماسة كابيتال", lat: 30.017, lng: 31.723 },
      { name: "الحي الحكومي (وزارات)", lat: 30.023, lng: 31.716 },
      { name: "محطة المونوريل", lat: 30.014, lng: 31.724 },
    ],
  },
  // فرع العاشر من رمضان
  {
    id: "industrial-zone",
    name: "المنطقة الصناعية (العاشر)",
    nameEn: "Industrial Zone",
    lat: 30.203961,
    lng: 31.715595,
    branch: "10th_ramadan",
    order: 11,
    areas: [
      { name: "المنطقة الصناعية بمدينة بدر/العاشر", lat: 30.201, lng: 31.717 },
      { name: "مصانع العاشر من رمضان – المدخل الغربي", lat: 30.208, lng: 31.71 },
    ],
  },
  {
    id: "knowledge-city",
    name: "مدينة المعرفة",
    nameEn: "Knowledge City",
    lat: 30.230724,
    lng: 31.691614,
    branch: "10th_ramadan",
    order: 12,
    areas: [
      { name: "مدينة المعرفة – العاشر من رمضان", lat: 30.231, lng: 31.692 },
      { name: "المرحلة الأولى – العاشر من رمضان", lat: 30.234, lng: 31.696 },
    ],
  },
];

export const LRT_META = {
  operator: "RATP Dev Mobility Cairo",
  owner: "الهيئة القومية للأنفاق (NAT)",
  openedAt: "2022-07-03",
  totalKm: 70,
  plannedKm: 105,
  totalStations: LRT_REAL_STATIONS.length,
  maxSpeedKmh: 120,
  commercialSpeedKmh: 85,
  operatingHours: { startFirst: "06:00", lastFromAdly: "22:30", lastFromArts: "23:05" },
  headwayPeak: "10 دقائق",
  headwayOffPeak: "15–20 دقيقة",
  fullTripMinutes: 50,
  rollingStock: {
    manufacturer: "CRRC Qingdao Sifang",
    carsPerTrain: 6,
    capacity: 1300,
    airConditioned: true,
    wifi: true,
    womenCarriage: true,
  },
  payments: [
    "كاش",
    "فيزا / ماستر كارد / ميزة",
    "كارت محفظة قابل للشحن",
    "المحافظ الإلكترونية",
    "الدفع التلامسي Tap & Go",
  ],
  amenities: [
    "مواقف سيارات مجانية",
    "مصاعد وسلالم كهربائية",
    "دورات مياه لذوي الهمم",
    "مسارات بصرية Tactile Paving",
    "شاشات لغة الإشارة",
    "كاميرات مراقبة وأمن 24/7",
  ],
  sources: [
    "الهيئة القومية للأنفاق – nat.gov.eg",
    "Mobility Cairo – mobilitycairo.com",
    "خريطة الشبكة الرسمية 2024 (PDF)",
    "OpenStreetMap",
  ],
};
