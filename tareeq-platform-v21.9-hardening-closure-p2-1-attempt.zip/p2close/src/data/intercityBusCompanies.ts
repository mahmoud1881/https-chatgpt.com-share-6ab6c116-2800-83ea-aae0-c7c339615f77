// Lazy wrapper around /data/intercity-bus-companies.json (~27KB).
import { createLazyJsonResource } from "@/lib/lazy-json-resource";

export type IntercityCompany = {
  id: string;
  name_ar: string;
  name_en: string;
  website?: string;
  hotline?: string;
  hq?: string;
  founded?: string | number;
  fleet?: string;
  classes?: string[];
  governorates: string[];
  terminals: { city: string; name: string }[];
  routes: string[];
  booking?: string[];
  kind: "operator" | "aggregator";
};

const resource = createLazyJsonResource<IntercityCompany>({
  path: "/data/intercity-bus-companies.json",
  cacheKey: "intercity-bus-companies",
  version: "1",
  label: "intercity-companies",
});

/** React hook returning the list, re-rendering when the data hydrates. */
export const useIntercityCompanies = resource.useResource;
export const loadIntercityCompanies = resource.load;
export const intercityCompaniesSnapshot = resource.snapshot;
