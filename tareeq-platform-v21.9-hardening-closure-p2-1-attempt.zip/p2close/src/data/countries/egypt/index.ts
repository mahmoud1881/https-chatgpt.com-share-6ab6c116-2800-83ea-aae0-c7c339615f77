// Egypt namespace — re-exports existing Egyptian datasets.
// Country-isolated views should import from here instead of touching Morocco data.
export * as cairoStations from "@/data/cairoStations";
export * as metroStations from "@/data/metroStations";
export * as governorateBusLines from "@/data/governorateBusLines";
export * as intercityBusCompanies from "@/data/intercityBusCompanies";
export * as microbusLines from "@/data/microbusLines";
export * as governorateStations from "@/data/egGovernorateStations";
export * as informalStops from "@/data/egInformalStops";
export * as capitalTrainStations from "@/data/capitalTrainStations";
export * as trains from "@/data/trains";
