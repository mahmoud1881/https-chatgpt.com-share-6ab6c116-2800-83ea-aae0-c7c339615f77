// Lazy-loaded wrapper around /data/transit-routes.json (served as a public asset).
// The 673 KB payload is fetched at runtime (after first paint) instead of being
// bundled, keeping the main JS chunk small without changing the sync API.

export type TransitRoute = {
  id: string;
  number: string;
  origin: string;
  destination: string;
  path: string;
  stops: string[];
};

export type TransitDataset = {
  source: string;
  totalRoutes: number;
  routes: TransitRoute[];
};

// Mutable shared array. Starts empty; populated once the JSON arrives.
// Consumers should re-read this reference (not snapshot it) for up-to-date data,
// or subscribe via `onTransitRoutesLoaded`.
export let transitRoutes: TransitRoute[] = [];
export let transitDataset: TransitDataset = {
  source: "pending",
  totalRoutes: 0,
  routes: [],
};

const subscribers = new Set<() => void>();
let loadPromise: Promise<TransitRoute[]> | null = null;
let loaded = false;

/** Subscribe to be notified once the dataset is loaded (or immediately if already loaded). */
export function onTransitRoutesLoaded(cb: () => void): () => void {
  if (loaded) {
    try {
      cb();
    } catch {
      /* noop */
    }
    return () => {};
  }
  subscribers.add(cb);
  return () => subscribers.delete(cb);
}

/** Kick off (or reuse) the async fetch. Safe to call repeatedly. */
export function loadTransitRoutes(): Promise<TransitRoute[]> {
  if (loaded) return Promise.resolve(transitRoutes);
  if (loadPromise) return loadPromise;
  if (typeof fetch === "undefined") return Promise.resolve([]);

  loadPromise = fetch("/data/transit-routes.json", { cache: "force-cache" })
    .then((res) => {
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res.json() as Promise<TransitDataset>;
    })
    .then((data) => {
      transitDataset = data;
      transitRoutes = data.routes ?? [];
      loaded = true;
      subscribers.forEach((cb) => {
        try {
          cb();
        } catch {
          /* noop */
        }
      });
      subscribers.clear();
      return transitRoutes;
    })
    .catch((err) => {
      // Reset so callers may retry later; keep empty dataset.
      loadPromise = null;
      console.warn("[transit-routes] load failed:", err);
      return [];
    });

  return loadPromise;
}

export function isTransitRoutesLoaded() {
  return loaded;
}

export function findRouteById(id: string): TransitRoute | undefined {
  return transitRoutes.find((r) => r.id === id);
}

export function searchRoutes(query: string, limit = 50): TransitRoute[] {
  const q = query.trim().toLowerCase();
  if (!q) return transitRoutes.slice(0, limit);
  const out: TransitRoute[] = [];
  for (const r of transitRoutes) {
    if (
      r.number.toLowerCase().includes(q) ||
      r.origin.toLowerCase().includes(q) ||
      r.destination.toLowerCase().includes(q) ||
      r.stops.some((s) => s.toLowerCase().includes(q))
    ) {
      out.push(r);
      if (out.length >= limit) break;
    }
  }
  return out;
}
