// Lazy-loaded wrapper around /data/trains.json (public asset, ~302KB).

export type ServedArea = { name: string; place?: string; km?: number };
export type TrainStation = {
  id: string;
  name: string | null;
  city: string | null;
  lat: number | null;
  lng: number | null;
  address: string | null;
  confirmations_count: number;
  served_areas?: ServedArea[];
};
export type TrainRoute = {
  id: string;
  from_station_id: string | null;
  to_station_id: string | null;
  schedule_text: string | null;
  duration_min: number | null;
  operator: string | null;
  notes: string | null;
  confirmations_count: number;
};

export let TRAIN_STATIONS: TrainStation[] = [];
export let TRAIN_ROUTES: TrainRoute[] = [];

const subscribers = new Set<() => void>();
let loadPromise: Promise<{ stations: TrainStation[]; routes: TrainRoute[] }> | null = null;
let loaded = false;

export function onTrainsLoaded(cb: () => void): () => void {
  if (loaded) {
    try {
      cb();
    } catch {
      /* noop */
    }
    return () => {};
  }
  subscribers.add(cb);
  return () => subscribers.delete(cb);
}

export function loadTrains() {
  if (loaded) return Promise.resolve({ stations: TRAIN_STATIONS, routes: TRAIN_ROUTES });
  if (loadPromise) return loadPromise;
  if (typeof fetch === "undefined") return Promise.resolve({ stations: [], routes: [] });

  loadPromise = fetch("/data/trains.json", { cache: "force-cache" })
    .then((res) => {
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res.json() as Promise<{ stations: TrainStation[]; routes: TrainRoute[] }>;
    })
    .then((data) => {
      TRAIN_STATIONS = data?.stations ?? [];
      TRAIN_ROUTES = data?.routes ?? [];
      loaded = true;
      subscribers.forEach((cb) => {
        try {
          cb();
        } catch {
          /* noop */
        }
      });
      subscribers.clear();
      return { stations: TRAIN_STATIONS, routes: TRAIN_ROUTES };
    })
    .catch((err) => {
      loadPromise = null;
      console.warn("[trains] load failed:", err);
      return { stations: [], routes: [] };
    });

  return loadPromise;
}

export function isTrainsLoaded() {
  return loaded;
}
