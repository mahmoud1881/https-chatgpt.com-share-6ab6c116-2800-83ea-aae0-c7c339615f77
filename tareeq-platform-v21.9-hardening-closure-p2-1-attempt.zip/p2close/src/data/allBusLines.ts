// Aggregates every bus/minibus/microbus line dataset the project ships and
// classifies each entry into two regional groups: Greater Cairo (القاهرة الكبرى)
// and Alexandria (الإسكندرية). Everything else is bucketed as "other".
//
// The heavy `PDF_BUS_LINES` literal (~128KB) is loaded lazily to keep it out
// of the initial client bundle. All non-PDF datasets are wired in eagerly since
// they are already lightweight or lazy-hydrated by their own loaders.

import { CAIRO_BUS_LINES, loadCairoBusLines, onCairoBusLinesLoaded } from "./cairoBusLines";
import {
  CAIRO_MINIBUS_LINES,
  loadCairoMinibusLines,
  onCairoMinibusLinesLoaded,
} from "./cairoMinibusLines";
import { GOV_BUS_LINES, loadGovBusLines, onGovBusLinesLoaded } from "./governorateBusLines";
import { MICROBUS_LINES, loadMicrobusLines, onMicrobusLinesLoaded } from "./microbusLines";
import {
  AGENT_RESEARCH_LINES,
  loadAgentResearchLines,
  onAgentResearchLinesLoaded,
} from "./agentResearchLines";
import { extraBusRoutes, isExtraOwnedCode } from "./bus-stations-extra";

export type BusRegion = "cairo" | "alex" | "other";

export type AggregatedBusLine = {
  code: string;
  route: string;
  from?: string;
  to?: string;
  stops?: string[];
  governorate?: string;
  region: BusRegion;
  source:
    | "cta-pdf"
    | "cairo-bus"
    | "cairo-minibus"
    | "governorate-bus"
    | "microbus"
    | "extra"
    | "agent-research";
  operator?: string;
  mode?: string;
};

// Greater Cairo = القاهرة + الجيزة + القليوبية (per CAPMAS definition).
const CAIRO_GOVERNORATES = new Set(["القاهرة", "الجيزة", "القليوبية"]);
const ALEX_GOVERNORATES = new Set(["الإسكندرية", "الاسكندرية"]);

function classify(gov?: string): BusRegion {
  if (!gov) return "other";
  if (CAIRO_GOVERNORATES.has(gov)) return "cairo";
  if (ALEX_GOVERNORATES.has(gov)) return "alex";
  return "other";
}

function normalizeKey(code: string, route: string): string {
  return `${code}::${route.replace(/\s+/g, " ").trim()}`.toLowerCase();
}

// Cached slice from the (heavy) PDF module. Populated on first async load.
type PdfEntry = { code: string; route: string; from?: string; to?: string; stops?: string[] };
let _pdfBusLines: readonly PdfEntry[] | null = null;

async function loadPdfBusLines(): Promise<readonly PdfEntry[]> {
  if (_pdfBusLines) return _pdfBusLines;
  const mod = await import("./pdfBusLines");
  _pdfBusLines = await mod.loadPdfBusLines();
  return _pdfBusLines;
}

function buildFromDatasets(pdfLines: readonly PdfEntry[]): AggregatedBusLine[] {
  const out: AggregatedBusLine[] = [];
  const seen = new Set<string>();

  const push = (entry: AggregatedBusLine) => {
    // Any code owned by bus-stations-extra.json is the single source of
    // truth: skip every other dataset's entry for that code.
    if (entry.source !== "extra" && isExtraOwnedCode(entry.code)) return;
    const key = normalizeKey(entry.code, entry.route);
    if (seen.has(key)) return;
    seen.add(key);
    out.push(entry);
  };

  // 0) bus-stations-extra.json — authoritative, wins over everything else
  for (const l of extraBusRoutes) {
    push({
      code: l.route_code,
      route: (l.stops ?? []).join(" – ") || `${l.origin_name} – ${l.destination_name}`,
      from: l.origin_name,
      to: l.destination_name,
      stops: l.stops ?? [l.origin_name, l.destination_name],
      region: "cairo",
      source: "extra",
    });
  }

  // 1) CTA official PDF — all Greater Cairo
  for (const l of pdfLines) {
    push({
      code: l.code,
      route: l.route,
      from: l.from,
      to: l.to,
      stops: l.stops,
      region: "cairo",
      source: "cta-pdf",
    });
  }

  // 2) Cairo bus lines
  for (const l of CAIRO_BUS_LINES) {
    const stops = l.route
      .split(/\s*[–—−-]\s*/)
      .map((s) => s.trim())
      .filter(Boolean);
    push({
      code: l.line,
      route: l.route,
      from: l.from,
      to: l.to,
      stops,
      region: "cairo",
      source: "cairo-bus",
    });
  }

  // 3) Cairo minibus lines
  for (const l of CAIRO_MINIBUS_LINES) {
    const stops = l.route
      .split(/\s*[–—−,،-]\s*/)
      .map((s) => s.trim())
      .filter(Boolean);
    push({
      code: l.line,
      route: l.route,
      from: l.from,
      to: l.to,
      stops,
      region: "cairo",
      source: "cairo-minibus",
    });
  }

  // 4) Governorate bus lines
  for (const l of GOV_BUS_LINES) {
    const region = classify(l.governorate);
    if (region === "other") continue;
    push({
      code: l.route_code,
      route: (l.stops || []).join(" – ") || `${l.origin_name} – ${l.destination_name}`,
      from: l.origin_name,
      to: l.destination_name,
      stops: l.stops || [l.origin_name, l.destination_name],
      governorate: l.governorate,
      region,
      source: "governorate-bus",
    });
  }

  // 5) Microbus lines
  for (const l of MICROBUS_LINES) {
    const region = classify(l.governorate);
    if (region === "other") continue;
    const stops = [l.origin, ...(l.via || []), l.destination].filter(Boolean);
    push({
      code: "—",
      route: stops.join(" – "),
      from: l.origin,
      to: l.destination,
      stops,
      governorate: l.governorate,
      region,
      source: "microbus",
    });
  }

  // 6) Agent research lines (bus/minibus/microbus across every Egyptian
  // governorate, discovered by the 125 research agents).
  for (const l of AGENT_RESEARCH_LINES) {
    const region = classify(l.governorate);
    const stops = l.stops && l.stops.length ? l.stops : [l.origin, l.destination].filter(Boolean);
    push({
      code: l.code || "—",
      route: stops.join(" – ") || `${l.origin} – ${l.destination}`,
      from: l.origin,
      to: l.destination,
      stops,
      governorate: l.governorate,
      region,
      source: "agent-research",
      operator: l.operator,
      mode: l.mode,
    });
  }

  return out;
}

// Memoize the built aggregation by the identity of every input array. As long
// as none of the source datasets has been reassigned since the last call, we
// return the cached array — avoiding a full rescan of thousands of entries
// (and dozens of regex splits) on every re-render / load callback tick.
let _cache: { out: AggregatedBusLine[]; keys: readonly unknown[] } | null = null;

function buildCached(pdfLines: readonly PdfEntry[]): AggregatedBusLine[] {
  const keys = [
    pdfLines,
    extraBusRoutes,
    CAIRO_BUS_LINES,
    CAIRO_MINIBUS_LINES,
    GOV_BUS_LINES,
    MICROBUS_LINES,
    AGENT_RESEARCH_LINES,
  ] as const;
  if (_cache && _cache.keys.every((k, i) => k === keys[i])) return _cache.out;
  const out = buildFromDatasets(pdfLines);
  _cache = { out, keys };
  return out;
}

/**
 * Synchronous getter: returns whatever is currently loaded. If the PDF slice
 * hasn't been hydrated yet, it is skipped — callers that need the full dataset
 * should prefer `loadAllBusLines()`.
 */
export function getAllBusLines(): AggregatedBusLine[] {
  return buildCached(_pdfBusLines ?? []);
}

export async function loadAllBusLines(): Promise<AggregatedBusLine[]> {
  const [pdfLines] = await Promise.all([
    loadPdfBusLines(),
    Promise.allSettled([
      loadCairoBusLines(),
      loadCairoMinibusLines(),
      loadGovBusLines(),
      loadMicrobusLines(),
      loadAgentResearchLines(),
    ]),
  ]);
  return buildCached(pdfLines);
}

export function onAllBusLinesLoaded(cb: () => void): () => void {
  const unsub = [
    onCairoBusLinesLoaded(cb),
    onCairoMinibusLinesLoaded(cb),
    onGovBusLinesLoaded(cb),
    onMicrobusLinesLoaded(cb),
    onAgentResearchLinesLoaded(cb),
  ];
  return () => unsub.forEach((u) => u());
}
