// Lazy wrapper around /data/microbus-lines.json (~48KB).
export type MicrobusLine = {
  governorate: string;
  origin: string;
  destination: string;
  via?: string[];
};

export let MICROBUS_LINES: MicrobusLine[] = [];

const subscribers = new Set<() => void>();
let loadPromise: Promise<MicrobusLine[]> | null = null;
let loaded = false;

export function onMicrobusLinesLoaded(cb: () => void): () => void {
  if (loaded) {
    try {
      cb();
    } catch {
      /* noop */
    }
    return () => {};
  }
  subscribers.add(cb);
  return () => subscribers.delete(cb);
}

export function loadMicrobusLines(): Promise<MicrobusLine[]> {
  if (loaded) return Promise.resolve(MICROBUS_LINES);
  if (loadPromise) return loadPromise;
  if (typeof fetch === "undefined") return Promise.resolve([]);
  loadPromise = import("@/lib/compact-json")
    .then((m) => m.fetchJsonSmart<MicrobusLine>("/data/microbus-lines.json", "microbus-lines", "1"))
    .then((data) => {
      MICROBUS_LINES = data ?? [];
      loaded = true;
      subscribers.forEach((cb) => {
        try {
          cb();
        } catch {
          /* noop */
        }
      });
      subscribers.clear();
      return MICROBUS_LINES;
    })
    .catch((err) => {
      loadPromise = null;
      console.warn("[microbus-lines] load failed:", err);
      return [];
    });
  return loadPromise;
}

export function isMicrobusLinesLoaded() {
  return loaded;
}
