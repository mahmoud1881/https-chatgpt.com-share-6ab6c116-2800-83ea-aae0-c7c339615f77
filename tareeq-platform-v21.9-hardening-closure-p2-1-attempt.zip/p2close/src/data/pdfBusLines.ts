// Lazy wrapper around /data/pdf-bus-lines.json (~106KB).
// Previously an inline TS literal (~3600 lines).
export interface PdfBusLine {
  code: string;
  route: string;
  stops: string[];
  from: string;
  to: string;
}

export let PDF_BUS_LINES: PdfBusLine[] = [];

const subscribers = new Set<() => void>();
let loadPromise: Promise<PdfBusLine[]> | null = null;
let loaded = false;

export function onPdfBusLinesLoaded(cb: () => void): () => void {
  if (loaded) {
    try {
      cb();
    } catch {
      /* noop */
    }
    return () => {};
  }
  subscribers.add(cb);
  return () => subscribers.delete(cb);
}

export function loadPdfBusLines(): Promise<PdfBusLine[]> {
  if (loaded) return Promise.resolve(PDF_BUS_LINES);
  if (loadPromise) return loadPromise;
  if (typeof fetch === "undefined") return Promise.resolve([]);
  loadPromise = import("@/lib/compact-json")
    .then((m) => m.fetchJsonSmart<PdfBusLine>("/data/pdf-bus-lines.json", "pdf-bus-lines", "1"))
    .then((data) => {
      PDF_BUS_LINES = data ?? [];
      loaded = true;
      subscribers.forEach((cb) => {
        try {
          cb();
        } catch {
          /* noop */
        }
      });
      subscribers.clear();
      return PDF_BUS_LINES;
    })
    .catch((err) => {
      loadPromise = null;
      console.warn("[pdf-bus-lines] load failed:", err);
      return [];
    });
  return loadPromise;
}

export function isPdfBusLinesLoaded() {
  return loaded;
}
