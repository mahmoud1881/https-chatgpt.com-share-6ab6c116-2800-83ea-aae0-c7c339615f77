// Lazy wrapper around /data/cairo-stations.json (~30KB).
export type CairoStationMode =
  "أتوبيس" | "ميني باص" | "ميكروباص" | "أقاليم" | "brt" | "metro" | "lrt" | "rail";
export type CairoStationKind = "transport_hub" | "stop_cluster" | "brt_station" | "simple_stop";
export type CairoStationPriority = "high" | "medium" | "normal";

export type CairoStation = {
  gov: string;
  name: string;
  kind: CairoStationKind;
  kind_ar: string;
  area: string;
  modes: CairoStationMode[];
  priority: CairoStationPriority;
  lat?: number | null;
  lng?: number | null;
  maps_url?: string;
  served_areas?: string[];
};

export let CAIRO_STATIONS: CairoStation[] = [];

const subscribers = new Set<() => void>();
let loadPromise: Promise<CairoStation[]> | null = null;
let loaded = false;

export function onCairoStationsLoaded(cb: () => void): () => void {
  if (loaded) {
    try {
      cb();
    } catch {
      /* noop */
    }
    return () => {};
  }
  subscribers.add(cb);
  return () => subscribers.delete(cb);
}

export function loadCairoStations(): Promise<CairoStation[]> {
  if (loaded) return Promise.resolve(CAIRO_STATIONS);
  if (loadPromise) return loadPromise;
  if (typeof fetch === "undefined") return Promise.resolve([]);
  loadPromise = import("@/lib/compact-json")
    .then((m) => m.fetchJsonSmart<CairoStation>("/data/cairo-stations.json", "cairo_stations", "1"))
    .then((data) => {
      CAIRO_STATIONS = data ?? [];
      loaded = true;
      subscribers.forEach((cb) => {
        try {
          cb();
        } catch {
          /* noop */
        }
      });
      subscribers.clear();
      return CAIRO_STATIONS;
    })
    .catch((err) => {
      loadPromise = null;
      console.warn("[cairo-stations] load failed:", err);
      return [];
    });
  return loadPromise;
}

export function isCairoStationsLoaded() {
  return loaded;
}
