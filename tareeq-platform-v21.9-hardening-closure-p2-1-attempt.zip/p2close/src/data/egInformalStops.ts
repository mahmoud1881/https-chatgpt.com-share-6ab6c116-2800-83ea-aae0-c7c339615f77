// Lazy wrapper around /data/eg-informal-stops.json — informal (عشوائية)
// microbus/tuktuk gathering points across all 27 Egyptian governorates.
// Compiled by 27 parallel research agents from Google Maps, OSM, Facebook
// groups, Arabic news, and local forums.

export type EgInformalStop = {
  name_ar: string;
  name_en?: string;
  governorate: string;
  city: string;
  type: string; // microbus | tuktuk | microbus/tuktuk | suzuki | service
  lat: number;
  lng: number;
  description?: string;
  served_areas?: string[];
  source_url?: string;
};

export let EG_INFORMAL_STOPS: EgInformalStop[] = [];

const subscribers = new Set<() => void>();
let loadPromise: Promise<EgInformalStop[]> | null = null;
let loaded = false;

export function onEgInformalStopsLoaded(cb: () => void): () => void {
  if (loaded) {
    try {
      cb();
    } catch {
      /* noop */
    }
    return () => {};
  }
  subscribers.add(cb);
  return () => subscribers.delete(cb);
}

export function loadEgInformalStops(): Promise<EgInformalStop[]> {
  if (loaded) return Promise.resolve(EG_INFORMAL_STOPS);
  if (loadPromise) return loadPromise;
  if (typeof fetch === "undefined") return Promise.resolve([]);
  loadPromise = import("@/lib/compact-json")
    .then((m) =>
      m.fetchJsonSmart<EgInformalStop>("/data/eg-informal-stops.json", "eg-informal-stops", "1"),
    )
    .then((data) => {
      EG_INFORMAL_STOPS = Array.isArray(data) ? data : [];
      loaded = true;
      subscribers.forEach((cb) => {
        try {
          cb();
        } catch {
          /* noop */
        }
      });
      subscribers.clear();
      return EG_INFORMAL_STOPS;
    })
    .catch((err) => {
      loadPromise = null;
      console.warn("[eg-informal-stops] load failed:", err);
      return [];
    });
  return loadPromise;
}

export function isEgInformalStopsLoaded() {
  return loaded;
}

export function getInformalStopsByGovernorate(gov: string): EgInformalStop[] {
  return EG_INFORMAL_STOPS.filter((s) => s.governorate === gov);
}
