// Lazy-loaded wrapper around /data/cairo-minibus-lines.json (public asset, ~146KB).

export type CairoMinibusLine = {
  line: string;
  num: number;
  route: string;
  from: string;
  to: string;
  kind: string;
};

export let CAIRO_MINIBUS_LINES: CairoMinibusLine[] = [];

const subscribers = new Set<() => void>();
let loadPromise: Promise<CairoMinibusLine[]> | null = null;
let loaded = false;

export function onCairoMinibusLinesLoaded(cb: () => void): () => void {
  if (loaded) {
    try {
      cb();
    } catch {
      /* noop */
    }
    return () => {};
  }
  subscribers.add(cb);
  return () => subscribers.delete(cb);
}

export function loadCairoMinibusLines(): Promise<CairoMinibusLine[]> {
  if (loaded) return Promise.resolve(CAIRO_MINIBUS_LINES);
  if (loadPromise) return loadPromise;
  if (typeof fetch === "undefined") return Promise.resolve([]);

  loadPromise = import("@/lib/compact-json")
    .then((m) =>
      m.fetchJsonSmart<CairoMinibusLine>(
        "/data/cairo-minibus-lines.json",
        "cairo-minibus-lines",
        "1",
      ),
    )
    .then((rows) => {
      CAIRO_MINIBUS_LINES = rows ?? [];
      loaded = true;
      subscribers.forEach((cb) => {
        try {
          cb();
        } catch {
          /* noop */
        }
      });
      subscribers.clear();
      return CAIRO_MINIBUS_LINES;
    })
    .catch((err) => {
      loadPromise = null;
      console.warn("[cairo-minibus-lines] load failed:", err);
      return [];
    });

  return loadPromise;
}

export function isCairoMinibusLinesLoaded() {
  return loaded;
}
