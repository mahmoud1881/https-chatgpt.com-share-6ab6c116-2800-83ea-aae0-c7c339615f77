// Lazy wrapper around /data/eg-governorate-stations.json — bus/minibus/microbus
// terminals across 24 Egyptian governorates (excluding Greater Cairo).
// Compiled from Google Maps, OpenStreetMap, Wikipedia, and government sources
// by parallel research agents (see .lovable/plan.md).

export type EgStationType = "bus" | "minibus" | "microbus" | "mixed" | "ferry" | "train";

export type EgGovStation = {
  name_ar: string;
  name_en?: string | null;
  governorate: string;
  city: string;
  type: EgStationType;
  lat?: number | null;
  lng?: number | null;
  served_areas?: string[];
  source?: string;
};

export let EG_GOV_STATIONS: EgGovStation[] = [];

const subscribers = new Set<() => void>();
let loadPromise: Promise<EgGovStation[]> | null = null;
let loaded = false;

export function onEgGovStationsLoaded(cb: () => void): () => void {
  if (loaded) {
    try {
      cb();
    } catch {
      /* noop */
    }
    return () => {};
  }
  subscribers.add(cb);
  return () => subscribers.delete(cb);
}

export function loadEgGovStations(): Promise<EgGovStation[]> {
  if (loaded) return Promise.resolve(EG_GOV_STATIONS);
  if (loadPromise) return loadPromise;
  if (typeof fetch === "undefined") return Promise.resolve([]);
  loadPromise = import("@/lib/compact-json")
    .then((m) =>
      m.fetchJsonSmart<EgGovStation>("/data/eg-governorate-stations.json", "eg-gov-stations", "1"),
    )
    .then((data) => {
      EG_GOV_STATIONS = Array.isArray(data) ? data : [];
      loaded = true;
      subscribers.forEach((cb) => {
        try {
          cb();
        } catch {
          /* noop */
        }
      });
      subscribers.clear();
      return EG_GOV_STATIONS;
    })
    .catch((err) => {
      loadPromise = null;
      console.warn("[eg-gov-stations] load failed:", err);
      return [];
    });
  return loadPromise;
}

export function isEgGovStationsLoaded() {
  return loaded;
}

export function getStationsByGovernorate(gov: string): EgGovStation[] {
  return EG_GOV_STATIONS.filter((s) => s.governorate === gov);
}

export function listEgGovernorates(): string[] {
  const set = new Set<string>();
  for (const s of EG_GOV_STATIONS) set.add(s.governorate);
  return Array.from(set).sort();
}
