// Programmatic SEO: curated + auto-generated trip pairs.
// Cross-product of EG_CITIES and MA_CITIES yields thousands of /trip pages.

import { EG_CITIES, MA_CITIES, findCity, haversineKm, type City } from "./cityCatalog";

export type TripPair = {
  fromSlug: string;
  toSlug: string;
  fromAr: string;
  toAr: string;
  fromFr?: string;
  toFr?: string;
  country: "eg" | "ma";
  modes: string[];
  distanceKm?: number;
  approxMinutes?: number;
  curated?: boolean;
};

const CURATED: TripPair[] = [
  {
    country: "eg",
    fromSlug: "cairo",
    toSlug: "alexandria",
    fromAr: "القاهرة",
    toAr: "الإسكندرية",
    modes: ["قطار", "أتوبيس", "ميكروباص"],
    distanceKm: 220,
    approxMinutes: 150,
    curated: true,
  },
  {
    country: "eg",
    fromSlug: "cairo",
    toSlug: "luxor",
    fromAr: "القاهرة",
    toAr: "الأقصر",
    modes: ["قطار", "أتوبيس", "طيران"],
    distanceKm: 670,
    approxMinutes: 600,
    curated: true,
  },
  {
    country: "eg",
    fromSlug: "cairo",
    toSlug: "aswan",
    fromAr: "القاهرة",
    toAr: "أسوان",
    modes: ["قطار", "أتوبيس"],
    distanceKm: 880,
    approxMinutes: 780,
    curated: true,
  },
  {
    country: "eg",
    fromSlug: "cairo",
    toSlug: "hurghada",
    fromAr: "القاهرة",
    toAr: "الغردقة",
    modes: ["أتوبيس", "طيران"],
    distanceKm: 460,
    approxMinutes: 360,
    curated: true,
  },
  {
    country: "eg",
    fromSlug: "cairo",
    toSlug: "sharm-el-sheikh",
    fromAr: "القاهرة",
    toAr: "شرم الشيخ",
    modes: ["أتوبيس", "طيران"],
    distanceKm: 510,
    approxMinutes: 420,
    curated: true,
  },
  {
    country: "eg",
    fromSlug: "cairo",
    toSlug: "new-administrative-capital",
    fromAr: "القاهرة",
    toAr: "العاصمة الإدارية",
    modes: ["قطار العاصمة LRT", "أتوبيس"],
    distanceKm: 60,
    approxMinutes: 75,
    curated: true,
  },
  {
    country: "ma",
    fromSlug: "casablanca",
    toSlug: "rabat",
    fromAr: "الدار البيضاء",
    toAr: "الرباط",
    fromFr: "Casablanca",
    toFr: "Rabat",
    modes: ["ONCF البراق", "حافلة CTM", "طاكسي كبير"],
    distanceKm: 87,
    approxMinutes: 50,
    curated: true,
  },
  {
    country: "ma",
    fromSlug: "casablanca",
    toSlug: "marrakech",
    fromAr: "الدار البيضاء",
    toAr: "مراكش",
    fromFr: "Casablanca",
    toFr: "Marrakech",
    modes: ["ONCF", "CTM", "Supratours"],
    distanceKm: 240,
    approxMinutes: 180,
    curated: true,
  },
  {
    country: "ma",
    fromSlug: "casablanca",
    toSlug: "tangier",
    fromAr: "الدار البيضاء",
    toAr: "طنجة",
    fromFr: "Casablanca",
    toFr: "Tanger",
    modes: ["البراق TGV", "CTM"],
    distanceKm: 340,
    approxMinutes: 130,
    curated: true,
  },
  {
    country: "ma",
    fromSlug: "marrakech",
    toSlug: "agadir",
    fromAr: "مراكش",
    toAr: "أكادير",
    fromFr: "Marrakech",
    toFr: "Agadir",
    modes: ["CTM", "Supratours"],
    distanceKm: 250,
    approxMinutes: 180,
    curated: true,
  },
];

const CURATED_KEY = new Map(CURATED.map((p) => [`${p.fromSlug}->${p.toSlug}`, p]));

function autoPair(f: City, t: City): TripPair {
  const km = Math.round(haversineKm(f, t));
  const minutes = Math.max(30, Math.round((km / 70) * 60));
  const modes: string[] = [];
  if (f.rail && t.rail) modes.push(f.country === "ma" ? "ONCF" : "قطار السكة الحديد");
  modes.push(f.country === "ma" ? "حافلة CTM/Supratours" : "أتوبيس");
  modes.push(f.country === "ma" ? "طاكسي كبير مشترك" : "ميكروباص");
  return {
    country: f.country,
    fromSlug: f.slug,
    toSlug: t.slug,
    fromAr: f.ar,
    toAr: t.ar,
    fromFr: f.fr,
    toFr: t.fr,
    modes,
    distanceKm: km,
    approxMinutes: minutes,
  };
}

export function getPair(from: string, to: string): TripPair | undefined {
  const curated = CURATED_KEY.get(`${from}->${to}`);
  if (curated) return curated;
  const f = findCity(from);
  const t = findCity(to);
  if (!f || !t || f.country !== t.country || f.slug === t.slug) return undefined;
  return autoPair(f, t);
}

export const POPULAR_PAIRS: TripPair[] = CURATED;

export function getAllTripPaths(): string[] {
  const out: string[] = [];
  for (const list of [EG_CITIES, MA_CITIES]) {
    for (const a of list) {
      for (const b of list) {
        if (a.slug !== b.slug) out.push(`/trip/${a.slug}/${b.slug}`);
      }
    }
  }
  return out;
}

export function getTripPathsByCountry(country: "eg" | "ma"): string[] {
  const list = country === "eg" ? EG_CITIES : MA_CITIES;
  const out: string[] = [];
  for (const a of list)
    for (const b of list) if (a.slug !== b.slug) out.push(`/trip/${a.slug}/${b.slug}`);
  return out;
}
