// Static fallback: bus routes parsed from the manual upload that were NOT
// already present in the `transit_routes` DB at the time of import. These
// rows render in /bus-stations alongside the DB results, deduped by
// (route_code, origin_name, destination_name).
import data from "./bus-stations-extra.json";

export type ExtraBusRoute = {
  id: string;
  route_code: string;
  transport_mode: "bus";
  origin_name: string;
  destination_name: string;
  name_ar: string | null;
  stops: string[];
  stop_coords?: Array<[number, number] | null>;
};

export const extraBusRoutes = data as ExtraBusRoute[];

function normCode(s: string | null | undefined) {
  return (s ?? "").replace(/\s+/g, " ").trim().toLowerCase();
}

/**
 * Set of route codes fully authored inside `bus-stations-extra.json`.
 * Any other dataset (PDF, cairo-bus-lines, DB) MUST be filtered out for
 * these codes so the authoritative version here wins across the app.
 */
export const extraOwnedRouteCodes: Set<string> = new Set(
  extraBusRoutes.map((r) => normCode(r.route_code)).filter(Boolean),
);

export function isExtraOwnedCode(code: string | null | undefined): boolean {
  return extraOwnedRouteCodes.has(normCode(code));
}

export function extraKey(r: {
  route_code: string | null;
  origin_name: string | null;
  destination_name: string | null;
}) {
  return `${(r.route_code ?? "").trim()}|${(r.origin_name ?? "").trim()}|${(r.destination_name ?? "").trim()}`;
}
