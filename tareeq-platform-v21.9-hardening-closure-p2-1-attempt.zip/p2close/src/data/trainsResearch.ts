// Comprehensive Egyptian railway research data compiled from 37 parallel research agents
// Sources: ENR (enr.gov.eg), Wikipedia AR/EN, OpenStreetMap, NAT, RATP Dev, Alstom, Siemens,
// Talgo, Abela Trains, MoT Egypt, Al-Masry Al-Youm, Al-Ahram, Youm7, Al-Shorouk, Raseef22.

export type LineStation = { name: string; gov?: string; lat?: number; lng?: number };
export type RailLine = {
  id: string;
  name: string;
  category:
    | "intercity"
    | "delta"
    | "upper"
    | "branch"
    | "sinai"
    | "lrt"
    | "monorail"
    | "hsr"
    | "metro"
    | "tram";
  status: "operational" | "partial" | "under_construction" | "planned" | "suspended";
  lengthKm?: number;
  durationText?: string;
  operator?: string;
  description?: string;
  stations: LineStation[];
  trainTypes?: string[];
  scheduleNotes?: string;
};

// Lazy-loaded from /data/rail-lines.json (~42KB).
import { createLazyJsonResource } from "@/lib/lazy-json-resource";

const railLinesResource = createLazyJsonResource<RailLine>({
  path: "/data/rail-lines.json",
  cacheKey: "rail-lines",
  version: "1",
  label: "rail-lines",
});

/** React hook returning the list, re-rendering when the data hydrates. */
export const useRailLines = railLinesResource.useResource;
/** Imperative loader — awaits the fetch and returns the array. */
export const loadRailLines = railLinesResource.load;
/** Sync snapshot (empty before hydration). */
export const railLinesSnapshot = railLinesResource.snapshot;

// ============= Train categories / classes =============
export type TrainClass = {
  name: string;
  arName: string;
  description: string;
  topSpeedKmh?: number;
  builder?: string;
  routes: string[];
  amenities: string[];
};

export const TRAIN_CLASSES: TrainClass[] = [
  {
    name: "Talgo",
    arName: "تالجو (Talgo) – إسباني فاخر",
    description:
      "أحدث وأسرع قطارات السكة الحديد. صفقة 7 قطارات إسبانية (6 متعاقد + 1 هدية). كل طقم 15 عربة + جرار PowerHaul أمريكي + عربة قوى + 5 درجة أولى + 8 درجة ثانية + بوفيه. السعة ~490 راكب. أُطلق ديسمبر 2022 (الإسكندرية) وفبراير 2023 (أسوان).",
    topSpeedKmh: 160,
    builder: "Talgo (إسبانيا)",
    routes: [
      "القاهرة – الإسكندرية (2025/2023/2027 و2022/2024/2026)",
      "القاهرة – أسوان (2030/2031)",
    ],
    amenities: ["مقاعد جلدية", "Wi-Fi", "شاشات", "بوفيه", "مخارج كهرباء"],
  },
  {
    name: "VIP",
    arName: "VIP / Top VIP / VIP Premium (خدمة خاصة)",
    description:
      "البديل الأفخم بعد تالجو. Top VIP عربة فاخرة جداً بمقاعد جلدية وشاشات خلف كل مقعد. VIP Premium (2025/2026) مدمجة نوم وجلوس فاخر.",
    routes: [
      "القاهرة – أسوان (980/981/2006/2007/2010–2015/996)",
      "القاهرة – الإسكندرية (934/935/905/917/921/927)",
    ],
    amenities: ["مقاعد دوارة (أولى)", "بوفيه", "Wi-Fi (متذبذب)", "مخارج كهرباء", "صيدلية طوارئ"],
  },
  {
    name: "Russian-Hungarian",
    arName: "روسي / مجري مطور (TMH)",
    description:
      "الصفقة الأضخم في تاريخ ENR (1.1 مليار يورو) – تحالف Transmashholding الروسي-المجري. 1300 عربة (ارتفعت لـ 1350): 500 تهوية ديناميكية + 500 ثالثة مكيفة + 180 ثانية مكيفة + 90 أولى مكيفة + 30 بوفيه. الصناعة في تفير الروسية ودوناكيسي المجرية. الجرارات بالغالب GE ES30ACi و Wabtec Progress Rail الأمريكية.",
    builder: "Transmashholding (روسيا/المجر)",
    routes: [
      "معظم الخطوط الرئيسية: أسوان 1004/1006/1008/1010/1012/1014",
      "إسكندرية 1130/1131",
      "بورسعيد/المنصورة 941/942",
    ],
    amenities: ["تكييف", "إضاءة LED", "حمامات حديثة", "مأخذ شحن"],
  },
  {
    name: "Sleeper",
    arName: "قطار النوم (Abela / Watania)",
    description:
      "خدمة فاخرة بكبائن خاصة مفردة/مزدوجة تشمل العشاء والإفطار. تشغيل أبيلا مصر (مجموعة أوراسكوم) – ساويرس. الأجانب يدفعون بالدولار/اليورو.",
    routes: ["القاهرة – الأقصر – أسوان (82/86/1086/1087)", "الإسكندرية – أسوان (موسمياً)"],
    amenities: ["كابينة خاصة", "حوض غسل", "وجبة عشاء وإفطار", "خدمة مضيف"],
  },
  {
    name: "Improved",
    arName: "تحيا مصر / محسن",
    description:
      "قطارات اقتصادية (تهوية ديناميكية) – درجة ثالثة محسنة، الأنسب للمسافات القصيرة والمتوسطة.",
    routes: ["جميع الخطوط بما فيها الدلتا والصعيد والقناة"],
    amenities: ["تهوية", "مقاعد مطورة"],
  },
];

// ============= Major terminal stations details =============
export type TerminalStation = {
  id: string;
  name: string;
  city: string;
  lat: number;
  lng: number;
  platforms: number;
  opened: string;
  history: string;
  facilities: string[];
  connections: string[];
};

export const TERMINAL_STATIONS: TerminalStation[] = [
  {
    id: "ramses",
    name: "محطة مصر (رمسيس)",
    city: "القاهرة",
    lat: 30.0625,
    lng: 31.2497,
    platforms: 11,
    opened: "1856 (أُعيد البناء 1892)",
    history:
      "أول محطة سكة حديد في أفريقيا والشرق الأوسط. صُممت بالطراز الإسلامي الحديث/النيو-مملوكي. كانت تُعرف بـ'باب الحديد' ثم سُميت رمسيس عام 1955.",
    facilities: ["مكتب بريد", "صراف آلي", "قاعات انتظار درجة أولى", "مطاعم", "صيدلية", "مكاتب حجز"],
    connections: ["مترو الشهداء (خط 1 و2)", "موقف أتوبيسات ميدان رمسيس", "ميكروباصات"],
  },
  {
    id: "sidi-gaber",
    name: "محطة سيدي جابر",
    city: "الإسكندرية",
    lat: 31.2189,
    lng: 29.9425,
    platforms: 8,
    opened: "خمسينيات القرن 19، تطوير شامل 2012",
    history:
      "محطة تجارية حديثة فوقها مول تجاري متكامل بكافيهات ومطاعم عالمية. شهدت تطويراً ضخماً عام 2012.",
    facilities: ["مول تجاري", "كافيهات", "مطاعم", "سلالم كهربائية", "مكاتب حجز"],
    connections: ["ترام سيدي جابر", "أتوبيسات النقل العام", "تاكسي"],
  },
  {
    id: "alex-main",
    name: "محطة مصر (الإسكندرية)",
    city: "الإسكندرية",
    lat: 31.1925,
    lng: 29.9089,
    platforms: 8,
    opened: "1856 – المبنى الحالي صممه لويجي أفوسكاني ~1920",
    history:
      "تحفة معمارية أثرية من تصميم المعماري الإيطالي لويجي أفوسكاني في عهد الملك فؤاد الأول. خضعت لتطوير شامل عام 2022.",
    facilities: ["صالات انتظار VIP", "مكاتب استعلامات", "كافيتريات", "موقف سيارات واسع"],
    connections: ["ترام الإسكندرية", "أتوبيسات النقل العام", "منطقة المنشية"],
  },
  {
    id: "bashteel",
    name: "محطة قطارات صعيد مصر (بشتيل)",
    city: "الجيزة",
    lat: 30.05,
    lng: 31.15,
    platforms: 6,
    opened: "افتُتحت رسمياً 2022",
    history: "محطة محورية جديدة لقطارات الصعيد لتخفيف العبء عن محطة رمسيس.",
    facilities: ["صالات حديثة", "خدمات إلكترونية", "كافيتريات", "مواقف"],
    connections: ["أتوبيسات NAT", "تاكسي"],
  },
  {
    id: "adly-mansour",
    name: "محطة عدلي منصور التبادلية",
    city: "القاهرة",
    lat: 30.1464,
    lng: 31.4189,
    platforms: 6,
    opened: "2022 (LRT)",
    history:
      "أضخم محطة تبادلية في الشرق الأوسط – نقطة التقاء مترو خط 3 + LRT العاصمة + سكة حديد السويس + BRT + سوبر جيت.",
    facilities: ["Park & Ride", "ATM", "أكشاك", "تسهيلات ذوي الهمم", "مصاعد"],
    connections: ["مترو خط 3", "LRT قطار العاصمة", "قطار السويس", "BRT الدائري", "سوبر جيت"],
  },
];

// ============= Booking, discounts, signals =============
export const BOOKING_METHODS = [
  {
    name: "الموقع الرسمي ENR",
    url: "https://obs.enr.gov.eg",
    notes: "بوابة الحجز الإلكتروني. تتطلب حساب برقم الهاتف والبريد. دفع بفيزا/ماستركارد.",
  },
  {
    name: "تطبيق ENR",
    url: "https://play.google.com/store/apps/details?id=enr.transit.maf",
    notes: "تطبيق Egyptian National Railways على Google Play و App Store. حجز، استعلام، رد تذاكر.",
  },
  {
    name: "قطارات النوم Abela",
    url: "https://abelatrains.com",
    notes: "موقع منفصل لحجز كبائن النوم – أبيلا مصر. خط ساخن 16086.",
  },
  {
    name: "منافذ فوري وأمان",
    url: "https://www.fawry.com",
    notes: "حجز فوري من أي ماكينة فوري/أمان مع رسوم خدمة 5–10 ج.",
  },
  { name: "ماكينات TVM", url: "", notes: "ماكينات الحجز الذاتي في رمسيس وسيدي جابر." },
  { name: "مكاتب البريد المصري", url: "", notes: "خدمة حجز التذاكر من مكاتب البريد." },
];

export const DISCOUNTS = [
  {
    group: "الطلبة (اشتراك)",
    value: "حتى 98%",
    notes: "في تحيا مصر، 97% في التهوية، 90% في ثالثة مكيفة. مدة 9 شهور، أقصى مسافة 400 كم.",
  },
  {
    group: "كبار السن +70 سنة",
    value: "100% مجاناً",
    notes: "في قطارات تحيا مصر بموجب بطاقة الرقم القومي.",
  },
  { group: "أصحاب المعاشات +60", value: "50%", notes: "على جميع أنواع القطارات." },
  { group: "المجندون (الجيش)", value: "100% مجاناً", notes: "في تحيا مصر/تهوية، 50% في المكيف." },
  {
    group: "الشرطة",
    value: "100% مجاناً",
    notes: "في تحيا مصر/تهوية، 50% في المكيف بموجب الكارنيه.",
  },
  { group: "ذوو الهمم + المرافق", value: "50%", notes: "على كل الأنواع بما فيها تالجو." },
  { group: "مرضى السرطان", value: "100% مجاناً", notes: "ذهاب وعودة في نفس اليوم بكارت ذكي." },
  {
    group: "الصحفيون والأطفال 4–10",
    value: "50%",
    notes: "على القطارات العادية، مع دفع فرق التكييف.",
  },
  { group: "العاملون بالقطاع العام", value: "70%", notes: "اشتراكات تحيا مصر." },
];

export const REFUND_POLICY = [
  { window: "قبل 48 ساعة", penalty: "خصم 25% (أو رسوم إدارية بسيطة)" },
  { window: "24 – 48 ساعة", penalty: "خصم 25–50%" },
  { window: "أقل من 24 ساعة", penalty: "خصم 50%" },
  { window: "بعد تحرك القطار", penalty: "لا يجوز الاسترداد" },
  { window: "إلغاء من ENR / تعطل القطار", penalty: "رد كامل القيمة" },
];

export const SIGNALING = {
  systems: [
    "ETCS Level 1 (Thales) على خطوط القاهرة–الإسكندرية وأسيوط–نجع حمادي",
    "EIS Electronic Interlocking بدلاً من الميكانيكي",
    "CTC Centralized Traffic Control لإدارة الحركة من مراكز موحدة",
    "Alstom على خط بني سويف–أسيوط",
    "Siemens على خطوط القطار السريع",
  ],
  recommendations: [
    "تفعيل ATC/ETCS لضمان الفرملة الجبرية",
    "استكمال تحويل الأبراج اليدوية لإلكترونية",
    "تكثيف تدريب السائقين بمعهد وردان",
    "حظر القيادة دون أجهزة ATC مفعلة",
  ],
};

export const NETWORK_STATS = {
  totalKm: "10,000 كم (يستهدف 13,100 كم بحلول 2030)",
  totalStations: "705 محطة (22 رئيسية + 59 مركزية + 60 متوسطة + 564 صغيرة)",
  locomotives: "989 جراراً (من 810 عام 2014)",
  carriages: "1350+ عربة روسية جديدة + 7 قطارات تالجو + أسطول تقليدي",
  dailyPassengers: "1.2 – 1.5 مليون راكب يومياً (يستهدف 2 مليون بحلول 2030)",
  dailyTrains: "~1000 رحلة يومياً",
  freight: "8 ملايين طن سنوياً (يستهدف 13 مليون)",
  developmentCost: "~225 مليار ج.م خلال 2014–2024",
  upgradedCrossings: "670+ من إجمالي 1120 مزلقاناً",
};
