// Lazy-loaded wrapper around /data/cairo-bus-lines.json (public asset).
// The ~355 KB payload is fetched at runtime (after first paint) instead of
// being bundled, keeping the main JS chunk small. The exported array is
// mutable and gets populated once the fetch resolves; consumers should
// re-read the reference or subscribe via `onCairoBusLinesLoaded`.

export type CairoBusLine = {
  line: string;
  num: number;
  route: string;
  from: string;
  to: string;
  kind: string;
};

export let CAIRO_BUS_LINES: CairoBusLine[] = [];

const subscribers = new Set<() => void>();
let loadPromise: Promise<CairoBusLine[]> | null = null;
let loaded = false;

export function onCairoBusLinesLoaded(cb: () => void): () => void {
  if (loaded) {
    try {
      cb();
    } catch {
      /* noop */
    }
    return () => {};
  }
  subscribers.add(cb);
  return () => subscribers.delete(cb);
}

export function loadCairoBusLines(): Promise<CairoBusLine[]> {
  if (loaded) return Promise.resolve(CAIRO_BUS_LINES);
  if (loadPromise) return loadPromise;
  if (typeof fetch === "undefined") return Promise.resolve([]);

  loadPromise = import("@/lib/compact-json")
    .then((m) =>
      m.fetchJsonSmart<CairoBusLine>("/data/cairo-bus-lines.json", "cairo-bus-lines", "1"),
    )
    .then((rows) => {
      CAIRO_BUS_LINES = rows ?? [];
      loaded = true;
      subscribers.forEach((cb) => {
        try {
          cb();
        } catch {
          /* noop */
        }
      });
      subscribers.clear();
      return CAIRO_BUS_LINES;
    })
    .catch((err) => {
      loadPromise = null;
      console.warn("[cairo-bus-lines] load failed:", err);
      return [];
    });

  return loadPromise;
}

export function isCairoBusLinesLoaded() {
  return loaded;
}
