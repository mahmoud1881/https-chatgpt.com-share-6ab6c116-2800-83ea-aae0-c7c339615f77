// Lazy wrapper around /data/egypt-stations.json (served as a public asset).
// The TypeScript array previously bundled here (~26KB) is now fetched at
// runtime, keeping the main JS chunk small. Consumers read EGYPT_STATIONS
// as a mutable export (re-read it, don't snapshot) or subscribe via
// onEgyptStationsLoaded.

export type EgyptStationType =
  | "transport_hub"
  | "stop_cluster"
  | "intercity_terminal"
  | "rail_station"
  | "port_terminal"
  | "simple_stop";

export type EgyptStationMode =
  "أتوبيس" | "ميني باص" | "ميكروباص" | "أقاليم" | "سكة حديد" | "نقل نهري" | "بحري";

export type EgyptStation = {
  governorate: string;
  name: string;
  type: EgyptStationType;
  area: string;
  modes: EgyptStationMode[];
  priority: "P0" | "P1" | "P2";
  lat?: number | null;
  lng?: number | null;
  maps_url?: string;
  served_areas?: string[];
};

export let EGYPT_STATIONS: EgyptStation[] = [];

const subscribers = new Set<() => void>();
let loadPromise: Promise<EgyptStation[]> | null = null;
let loaded = false;

export function onEgyptStationsLoaded(cb: () => void): () => void {
  if (loaded) {
    try {
      cb();
    } catch {
      /* noop */
    }
    return () => {};
  }
  subscribers.add(cb);
  return () => subscribers.delete(cb);
}

export function loadEgyptStations(): Promise<EgyptStation[]> {
  if (loaded) return Promise.resolve(EGYPT_STATIONS);
  if (loadPromise) return loadPromise;
  if (typeof fetch === "undefined") return Promise.resolve([]);
  loadPromise = import("@/lib/compact-json")
    .then((m) => m.fetchJsonSmart<EgyptStation>("/data/egypt-stations.json", "egypt_stations", "1"))
    .then((data) => {
      EGYPT_STATIONS = data ?? [];
      loaded = true;
      subscribers.forEach((cb) => {
        try {
          cb();
        } catch {
          /* noop */
        }
      });
      subscribers.clear();
      return EGYPT_STATIONS;
    })
    .catch((err) => {
      loadPromise = null;
      console.warn("[egypt-stations] load failed:", err);
      return [];
    });
  return loadPromise;
}

export function isEgyptStationsLoaded() {
  return loaded;
}
