// Lazy loader for /data/agent-lines.json — bus/minibus/microbus routes
// discovered by the 125 research agents across all Egyptian governorates.

export type AgentResearchLine = {
  governorate: string;
  mode: "bus" | "minibus" | "microbus" | string;
  code: string;
  origin: string;
  destination: string;
  stops?: string[];
  operator?: string;
  source?: string;
};

export let AGENT_RESEARCH_LINES: AgentResearchLine[] = [];

const subscribers = new Set<() => void>();
let loadPromise: Promise<AgentResearchLine[]> | null = null;
let loaded = false;

export function onAgentResearchLinesLoaded(cb: () => void): () => void {
  if (loaded) {
    try {
      cb();
    } catch {
      /* noop */
    }
    return () => {};
  }
  subscribers.add(cb);
  return () => subscribers.delete(cb);
}

export function loadAgentResearchLines(): Promise<AgentResearchLine[]> {
  if (loaded) return Promise.resolve(AGENT_RESEARCH_LINES);
  if (loadPromise) return loadPromise;
  if (typeof fetch === "undefined") return Promise.resolve([]);
  loadPromise = fetch("/data/agent-lines.json", { cache: "force-cache" })
    .then((r) => (r.ok ? r.json() : []))
    .then((data: AgentResearchLine[]) => {
      AGENT_RESEARCH_LINES = Array.isArray(data) ? data : [];
      loaded = true;
      subscribers.forEach((cb) => {
        try {
          cb();
        } catch {
          /* noop */
        }
      });
      subscribers.clear();
      return AGENT_RESEARCH_LINES;
    })
    .catch((err) => {
      loadPromise = null;
      console.warn("[agent-research-lines] load failed:", err);
      return [];
    });
  return loadPromise;
}

export function isAgentResearchLinesLoaded() {
  return loaded;
}
