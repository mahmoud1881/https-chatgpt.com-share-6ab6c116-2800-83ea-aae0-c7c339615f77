// Lazy-loaded wrapper around /data/metro-stations.json (public asset, ~80KB).
// The dataset is fetched at runtime instead of being bundled into the main JS chunk.

export type NearbyStop = { name: string; km: number; lat: number; lng: number };

export type MetroStation = {
  id: string;
  line: "1" | "2" | "3" | "3a" | "3b";
  seq: number;
  name: string;
  name_en?: string;
  governorate: string;
  lat: number | null;
  lng: number | null;
  description: string;
  areas?: string[];
  aliases?: string[];
  is_interchange?: boolean;
  interchange_lines?: string[];
  nearby: NearbyStop[];
};

export let METRO_STATIONS: MetroStation[] = [];

const subscribers = new Set<() => void>();
let loadPromise: Promise<MetroStation[]> | null = null;
let loaded = false;

export function onMetroStationsLoaded(cb: () => void): () => void {
  if (loaded) {
    try {
      cb();
    } catch {
      /* noop */
    }
    return () => {};
  }
  subscribers.add(cb);
  return () => subscribers.delete(cb);
}

export function loadMetroStations(): Promise<MetroStation[]> {
  if (loaded) return Promise.resolve(METRO_STATIONS);
  if (loadPromise) return loadPromise;
  if (typeof fetch === "undefined") return Promise.resolve([]);

  loadPromise = import("@/lib/compact-json")
    .then((m) => m.fetchJsonSmart<MetroStation>("/data/metro-stations.json", "metro-stations", "1"))
    .then((rows) => {
      METRO_STATIONS = Array.isArray(rows) ? rows : [];
      loaded = true;
      subscribers.forEach((cb) => {
        try {
          cb();
        } catch {
          /* noop */
        }
      });
      subscribers.clear();
      return METRO_STATIONS;
    })
    .catch((err) => {
      loadPromise = null;
      console.warn("[metro-stations] load failed:", err);
      return [];
    });

  return loadPromise;
}

export function isMetroStationsLoaded() {
  return loaded;
}
