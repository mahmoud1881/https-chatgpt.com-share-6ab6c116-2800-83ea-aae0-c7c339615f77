# Egyptian trip reference set, version 1

The 20 cases in `core-eg.v1.json` cover Cairo/Giza, Alexandria, four regional
trips, spelling aliases, reverse direction and a transfer. **They are candidate
queries, not verified ground truth.** Their route/stop IDs were derived from
`public/data/eg/routes_master.json` to help a reviewer locate the record. A
different real route can be correct; a route ID matching the dataset does not
prove the boarding instructions are safe.

`metro-operator.v2.json` supplements these candidates with eight station-level
itineraries checked against the metro operator's line pages on
2026-09-22. Their street entrances and exact platform numbers remain unverified. See
`OPERATIONS.md` for the source refresh and correction workflow.

Acceptance was frozen before observing results: at least **19/20** independently
reviewed cases must pass, with **zero** unsafe or fabricated instructions. All
20 cases must be reviewed; a missing result counts as an incomplete benchmark.
The reviewer must see the exact user-facing itinerary on the deployed staging
commit, including boarding side/point, direction, transfer and alighting point.

## Run

The evaluator now requires evidence for **both search and planner** and a SHA-256
digest of the reviewed reference file. A top-level `pass` flag alone is ignored.
Each case must have `reference_status: "independently_verified"` and a `review`
object with: `source_kind` (`operator`, `field_visit`, or
`independent_local_review`), `reviewer`, `reviewed_at`, `evidence`,
`expected_outcome` (`route` or `no_verified_route`), and `aliases` (array).
For a route also supply `boarding`, `direction`, `alighting` and `transfers`
(array; empty for a direct journey). Operator evidence must be an HTTPS URL.
Network references expire after 30 days; other references after 14 days.
Only independently reviewed reverse-direction/transfer hard cases may expect
an honest no-route outcome; common, regional and alias cases require a route.
The current 20 cases remain pending; this change does not independently verify them.

To capture the visible staging evidence without inventing a verdict:

```sh
SITE_URL=https://staging.your-domain.tld \
BENCHMARK_COMMIT=<full-40-character-commit> DATA_REVISION=<deployed-dataset-id> \
node scripts/capture-trip-benchmark.mjs benchmarks/trips/core-eg.v1.json
```

This saves screenshots, visible instructions, observed outcomes and the reference
digest under `deploy/backups/trip-benchmarks/`. Reviewers must fill the two surface
verdicts, safety assessments, reviewer name and review time before scoring.
Capture and observation reviews expire after seven days. A changed reference file
invalidates the captured digest and requires recapture. Retain a reviewed copy of
the reference; do not silently edit queries or thresholds to improve the score.

1. Deploy the exact commit to staging and record its URL and commit SHA.
2. Copy `observations.example.json` to a new observations file. Fill in
   `environment`, `deployed_commit`, and `captured_at` (ISO 8601).
3. For each case, independently verify the itinerary using a field visit,
   transport operator source, or current local expert. Record who reviewed it,
   when, and the source in `reference_evidence`. Do not use this repository as
   the only evidence. Record the staging screenshot/response in `actual_evidence`
   and transcribe the visible directions in `observed_instructions`.
4. Set each surface's `verdict` to `pass` only when the end-to-end directions are correct.
   Set `unsafe_or_fabricated` to `true` for a wrong boarding location or side,
   wrong direction, nonexistent line/transfer, or invented certainty. An honest
   "no verified route" response can pass a hard case if the reviewer confirms
   there is no supported, verified itinerary to show.
5. Run `node scripts/evaluate-trip-benchmark.mjs benchmarks/trips/core-eg.v1.json <observations.json>`.
   Exit code 0 is the acceptance gate for this exact observation set.

Do not edit the case list after scoring; create `core-eg.v2.json` with a recorded
reason and rerun every case. Keep a separate post-launch random sample to avoid
overfitting to these 20 trips.

## Data risks revealed while constructing the cases

The supplied `routes_master.json` contains 3,807 route records; 1,036 have no
stop sequence, 959 have Hebrew characters in their origin/destination text,
and 335 route IDs are repeated beyond their first occurrence. Some sample OSM
records name Israeli locations. These counts describe the supplied snapshot,
not verified service coverage. Do not use zero-stop records as routable trips;
investigate imported geography and duplicated IDs before publishing them.
The alias `محطه رمسيس` also points to a different stop ID than the `رمسيس`
stop on candidate route `M-aa97de4a`; case T17 explicitly tests resolution
of this ambiguity. The application has other datasets and search paths, so
this benchmark must be run against the actual user-facing journey flow.
