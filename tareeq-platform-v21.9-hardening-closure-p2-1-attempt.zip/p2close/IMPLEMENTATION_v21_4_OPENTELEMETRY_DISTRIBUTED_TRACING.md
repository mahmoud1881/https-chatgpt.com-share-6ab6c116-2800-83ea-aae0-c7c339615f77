# v21.4 — OpenTelemetry Distributed Tracing & Production Telemetry Backend

Implemented a server-side W3C Trace Context pipeline with request root spans, AsyncLocalStorage context propagation, traced outgoing `fetch` calls (therefore including the server-side Supabase clients), OTLP/HTTP JSON export, configurable sampling, and sensitive attribute redaction.

## Runtime contract
- Incoming `traceparent` is continued when valid; otherwise a 128-bit trace ID is generated.
- `DEPLOYMENT_ID` and `CORRELATION_ID` are attached to spans and propagated on outbound requests.
- Global server `fetch` is installed once as `tracedFetch`, so Supabase and external HTTP calls inherit the active trace.
- OTLP exports bypass the instrumented fetch to prevent exporter recursion.
- Authorization/cookie/token/secret/password/email/phone-like attributes are redacted before export.
- Sampling is controlled by `OTEL_TRACES_SAMPLER_ARG` (default 0.10).
- Incident bundles collect real 32-hex trace IDs observed in stage telemetry/logs.

## Release gate
`security:telemetry:otel` statically proves the required propagation/export/redaction/sampling/incident-linkage wiring and is part of `release:gate`.

A live production certification still requires a reachable OTLP collector/backend and real deployment traffic; the static gate does not claim backend ingestion success.
