import { defineConfig } from "vitest/config";
import tsconfigPaths from "vite-tsconfig-paths";
import react from "@vitejs/plugin-react";

// Vitest configuration is separate from vite.config.ts because the Lovable
// TanStack preset re-uses that file for the app build and Nitro doesn't
// understand a `test` block. Component tests need a DOM implementation
// (jsdom) plus the shared setup file that registers jest-dom matchers and
// mocks like matchMedia — without them React Testing Library throws
// "document is not defined".
export default defineConfig({
  plugins: [react(), tsconfigPaths()],
  test: {
    environment: "jsdom",
    globals: false,
    setupFiles: ["./src/test/setup.ts"],
    css: false,
    include: ["src/**/*.{test,spec}.{ts,tsx}"],
    exclude: ["node_modules/**", "dist/**", ".output/**", "deploy/**"],
  },
});
