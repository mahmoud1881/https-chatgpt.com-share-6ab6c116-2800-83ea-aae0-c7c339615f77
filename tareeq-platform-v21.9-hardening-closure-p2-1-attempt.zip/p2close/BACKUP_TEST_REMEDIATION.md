# Backup regression remediation

The three backup snapshot tests previously timed out because their fake Docker process did not answer the recovery-point query or support the added schema/content fingerprint calls.

Changes:
- Added a strict Docker/psql protocol fixture covering the interactive snapshot holder, recovery timestamp, snapshot-imported schema/content reads, dump, roles and commit.
- The fixture rejects unknown queries, invalid SQL snapshot literals and reads/dumps after the snapshot holder closes.
- Corrected the production schema-import SQL: Bash `%q` quoting is not SQL quoting. The already validated snapshot identifier is now passed as a quoted SQL string using `%s`.
- Resolved the destination and script directory before changing to `deploy/`, so calling the helper from the repository root or another directory does not break Compose or helper paths.
- Added checks for emitted recovery references, snapshot lifetime/order, arbitrary caller directory, schema failure and content failure. Retained role-change and dump-error rejection. No timeout increase or skipped tests.

Verification:
- `bash -n deploy/scripts/backup-database.sh`: passed.
- `node --test deploy/scripts/critical-deployment.test.mjs`: 12 passed.
- `node --test deploy/scripts/*.test.mjs scripts/*test.mjs`: 182 passed, zero failed/skipped.

These are local regression tests with simulated Docker/PostgreSQL IO. They do not prove a real backup or restoration, and do not establish full application build, CI, staging or production readiness. The other recovery timing, isolation and release-readiness findings remain separate work.
