# v21.9 Production Execution Bundle & Preflight

Adds a fail-closed preflight before production certification. It verifies required CLI tooling, required runtime configuration without printing secret values, staging/production PostgreSQL connectivity, stable/candidate endpoints, Tempo/Prometheus readiness, telemetry probe reachability, signing/backup file presence, and immutable registry image digest identity.

## Commands

- `npm run production:preflight` — writes `artifacts/production-preflight.json`; exits non-zero on any missing/unreachable dependency.
- `npm run production:certify:e2e` — preflight → existing v21.9 full runtime certification → detached signature verification. It stops at the first failure.

`.env.production.example` is a names-only/template file. Real credentials must be injected by CI/secret storage and must never be committed.

A successful static validation does not mean production is certified. Only a successful live `production:certify:e2e` run may do so.
