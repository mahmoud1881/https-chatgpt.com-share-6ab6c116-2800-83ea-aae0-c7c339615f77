# v21.3 — Automated Observability & Incident Correlation Gate

Implemented on top of v21.2.

- A deployment-scoped `DEPLOYMENT_ID` and `CORRELATION_ID` are generated once and propagated through every progressive stage.
- Every candidate/stable synthetic probe carries `x-deployment-id`, `x-correlation-id`, and a per-probe `x-trace-id`.
- Stage evidence unifies active-probe metrics, container readiness, correlated synthetic traces, and candidate database/application signals.
- Candidate anomalies are evaluated against the stable baseline (error delta and p95/p99 ratios) as well as absolute SLOs and burn rate.
- Every `hold` or `abort` creates an immutable-style JSON incident evidence bundle under `artifacts/incidents/<deploymentId>/` with timeline, SLO evidence, candidate/stable logs, and classified application/database/external-service degradation deltas.
- The release gate contains a v21.3 static wiring check and fails if correlation or incident generation is removed.

Runtime observability remains fail-closed with respect to the existing production deployment prerequisites; a real production PASS still requires the Docker/Caddy deployment environment and live traffic.
