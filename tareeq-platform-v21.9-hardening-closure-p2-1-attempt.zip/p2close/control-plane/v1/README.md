# control-plane/v1 — Frozen Core Contract

This directory defines the stable extension boundary for the Platform Management Control System.

Constitution: no P4; core truth is derived; evidence/history are immutable; CLOSED is computed; VERIFIED_PASS requires independent verification; overrides never close defects; recurrences create new incidents; extensions use declared capabilities only.

Extension types: Policy, SignalProvider, EvidenceProvider, Verifier, RemediationAdapter, DeploymentAdapter.

Extensions may emit observations/proposals through the SDK. They may not write VERIFIED_PASS/CLOSED, delete incidents, mutate historical evidence, or rewrite audit history.

Registration requires schema/manifest validation, API compatibility, capability/permission validation, isolation, timeout/resource limits, evidence requirements, failure semantics, and the Control Plane non-regression gate.
