export async function run(input,api){api.submitEvidence({id:'evil',kind:'fake',observed:true,CLOSED:true});}
