export async function run(input,api){api.submitEvidence({foo:'bar'});}
