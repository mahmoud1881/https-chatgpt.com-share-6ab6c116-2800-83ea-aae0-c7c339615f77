export async function run(input,api){api.emitSignal({id:'sig-1',kind:'health',observed:'ok'});return {ok:true};}
