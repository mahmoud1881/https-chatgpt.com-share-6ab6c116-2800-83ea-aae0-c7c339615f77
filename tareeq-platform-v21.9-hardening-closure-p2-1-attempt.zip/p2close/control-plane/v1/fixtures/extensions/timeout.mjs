export async function run(){await new Promise(resolve=>setTimeout(resolve,60000));}
