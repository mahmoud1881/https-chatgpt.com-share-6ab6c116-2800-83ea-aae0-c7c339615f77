# v20.4 — Admin Authentication Unification

## Security invariant
Every TanStack server function that is admin-only must use exactly one canonical gate:
`src/integrations/supabase/admin-middleware.ts` → `requireSupabaseAdmin`.

The gate chains `requireSupabaseAuth`, verifies the canonical `hasAdminRole()` / `has_role` decision, fails closed, and adds `context.isAdmin === true`.

## Changes
- Removed the duplicate `src/lib/auth/require-admin.ts` middleware.
- Migrated OSM admin functions to the canonical gate.
- Migrated route-request moderation from `requireSupabaseAuth + assertAdmin()` to the canonical gate.
- Migrated route-verification moderation from `requireSupabaseAuth + assertAdmin()` to the canonical gate.
- Put `verifyAdminAccess` itself behind the canonical gate.
- Kept `verifyAdminSession(Request)` for raw Request handlers; it shares the same canonical `hasAdminRole()` decision and is not a second TanStack middleware.
- UI-only role checks (for display/navigation) are not security boundaries; server gates and RLS remain authoritative.
