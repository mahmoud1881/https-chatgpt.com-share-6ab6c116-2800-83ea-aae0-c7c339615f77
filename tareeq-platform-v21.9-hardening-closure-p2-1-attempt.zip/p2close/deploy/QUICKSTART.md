# Quickstart (5 minutes)

```bash
cd deploy
cp .env.example .env            # أو شغّل bootstrap.sh للتوليد التلقائي
./scripts/bootstrap.sh
./scripts/deploy.sh
```

افتح `https://<APP_DOMAIN>` من المتصفح. شُكراً.

لـ staging والتحقق من البريد وOAuth واستعادة نسخة خارجية على بيئة منفصلة،
اتبع [STAGING_RUNBOOK.md](STAGING_RUNBOOK.md). لا تعتبر مجرد فتح الصفحة إثباتًا
لجاهزية قاعدة البيانات أو خدمات المصادقة أو التعافي.
