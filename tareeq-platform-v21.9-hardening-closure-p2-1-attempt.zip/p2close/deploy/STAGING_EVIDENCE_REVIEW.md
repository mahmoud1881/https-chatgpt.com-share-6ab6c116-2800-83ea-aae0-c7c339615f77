# مراجعة دليل البريد وOAuth

لم تعد أوقات الوصول والعودة وحدها كافية لاجتياز staging-services. يلزم مرفقان منفصلان ومراجعة معتمدة موقعة Ed25519. لا ترسل بريد الاختبار أو المفاتيح أو الرموز إلى المحادثة أو المستودع.

1. شغّل تجربة staging الأولى واحفظ probeId وcontext من `backups/staging-probe.json`. التقط وصول رسالة الاسترداد في صندوق المستلم الفعلي، ثم اكتمال OAuth والعودة إلى التطبيق بحساب مسجل الدخول. صفحة موفّر OAuth أو استجابة قبول SMTP وحدها غير كافيتين.
2. احفظ الدليل في مجلد خاص خارج المشروع بصلاحيات مقيدة. يُقبل PNG/JPG/PDF/EML/JSON بحد 20 MiB لكل ملف. احجب كلمات المرور ورموز الجلسة وOAuth codes وروابط الاسترداد الفعالة قبل حساب البصمات؛ احتفظ بسياق كافٍ للربط بالتجربة والحساب المستهدف والوقت والموفّر. يحفظ المراجع الأصل الحساس وفق سياسة الوصول الداخلية عند الحاجة.
3. أنشئ manifest.json بالشكل الآتي مستخدمًا القيم الفعلية. الأوقات يجب أن تطابق متغيرات التجربة، والمراجعة بعد المشاهدتين، وجميعها ضمن ساعة بداية التجربة. احسب sha256 بوسيلة مثل `sha256sum mailbox.png oauth.png`.

```json
{
  "schemaVersion": 1,
  "probeId": "COPY_CURRENT_PROBE_ID",
  "context": "COPY_CURRENT_CONTEXT_HASH",
  "releaseCommit": "FULL_SOURCE_SHA",
  "collector": "operator-id",
  "review": {
    "reviewer": "independent-reviewer-id",
    "decision": "approved",
    "reviewedAt": "ACTUAL_REVIEW_TIME"
  },
  "artifacts": [
    {"kind":"mailbox","file":"mailbox.png","sha256":"ACTUAL_SHA256","observedAt":"ACTUAL_EMAIL_TIME"},
    {"kind":"oauth","file":"oauth.png","sha256":"ACTUAL_SHA256","observedAt":"ACTUAL_CALLBACK_TIME"}
  ]
}
```

4. يراجع شخص مختلف الدليلين والسياق والتواريخ ونجاح الجلسة بعد العودة. يعتمد الهوية وتاريخ المراجعة والقرار داخل manifest ثم يوقّع بايتاته النهائية على جهازه:

```bash
node deploy/scripts/sign-staging-review.mjs /secure/evidence/manifest.json /secure/reviewer-private.pem
```

يمكن إنشاء زوج مفاتيح مرة واحدة على جهاز المراجع:

```bash
umask 077
openssl genpkey -algorithm ED25519 -out reviewer-private.pem
openssl pkey -in reviewer-private.pem -pubout -out reviewer-public.pem
```

يُسلّم المفتاح العام إلى مسؤول النشر بقناة مستقلة موثوقة ويُثبت في إعداداته. لا يُعتمد مفتاح عام قادم داخل حزمة الدليل نفسها. يبقى المفتاح الخاص لدى المراجع. ملف `manifest.json.sig` توقيع ثنائي؛ أي تعديل للـmanifest بعد التوقيع يتطلب مراجعة وتوقيعًا جديدين.

5. ضع manifest والتوقيع والمرفقين في مجلد واحد على مضيف التحقق، وصدّر:

```bash
export STAGING_EVIDENCE_MANIFEST=/secure/evidence/manifest.json
export STAGING_REVIEW_PUBLIC_KEY_FILE=/etc/platform/reviewer-public.pem
export STAGING_REVIEWER_ID=independent-reviewer-id
# احتفظ بمتغيرات STAGING_PROBE_ID وأوقات المشاهدة الفعلية من التجربة الحالية
./scripts/staging-verify.sh
```

يرفض الفحص الدليل المفقود أو المعدّل، وتوقيعًا بمفتاح آخر، وتكرار المرفق نفسه للدليلين، والمراجعة الذاتية الاسمية، والمسارات الخارجة عن المجلد والروابط الرمزية للمرفقات. يُحفظ إيصال بصمات ومعلومات المراجعة في `backups/staging-reviewed-evidence.json` دون نسخ المرفقات أو محتواها. الإيصال يخص مراجعة البريد وOAuth؛ ليس شهادة نجاح جميع خدمات staging.

التوقيع يثبت امتلاك مفتاح المراجع وسلامة الملفات، ولا يثبت تلقائيًا صدق الصورة أو محتوى البريد. اختلاف الاسمين لا يثبت اختلاف الشخصين وحده؛ يلزم فصل صلاحيات المفتاح وإعدادات الثقة. من يستطيع تعديل المفتاح العام الموثوق يستطيع تغيير المراجع المقبول. يجب الاحتفاظ بالدليل الموقع خارج المضيف وفق سياسة وصول واحتفاظ مناسبة.

التحقق المحلي: 11 اختبارًا ناجحًا لأدلة staging والمرفقات الموقعة، وESLint ناجح. لم تُرسل رسائل بريد ولم تُنفّذ جلسة OAuth حقيقية ضمن هذا التعديل؛ الأدلة الفعلية ما زالت مطلوبة.
