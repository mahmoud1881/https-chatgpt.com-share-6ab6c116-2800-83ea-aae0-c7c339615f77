import {freshPromotionGate} from './promotion-policy.mjs';
import {inspectCandidate} from './runtime-image-binding.mjs';
// Run from deploy/. Never migrates or restores the database.
import { readFileSync, writeFileSync, renameSync, mkdirSync, rmdirSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";
import { fingerprint, assertStateBoundGate } from "./rollout-evidence.mjs";
import { rehearsalBootstrap } from "./promotion-load.mjs";

export function trafficConfig(percent) {
  if (![0, 1, 5, 25, 50, 100].includes(percent)) throw Error("Unsupported percentage");
  if (percent === 0) return "reverse_proxy app:{$APP_PORT}\n";
  if (percent === 100) return "reverse_proxy candidate:{$APP_PORT}\n";
  return `reverse_proxy app:{$APP_PORT} candidate:{$APP_PORT} {
  lb_policy cookie tareeq_rollout {$ROLLOUT_COOKIE_SECRET} {
    fallback weighted_round_robin ${100 - percent} ${percent}
  }
}\n`;
}
function docker(...args) {
  if(args[0]==="compose"&&!args.includes("-f"))args=["compose","-p","platform","-f","docker-compose.yml",...args.slice(1)];
  const r = spawnSync("docker", args, { encoding: "utf8", timeout: 30000 });
  if (r.status !== 0 || r.error) throw Error("Docker validation/reload failed; inspect proxy logs");
  return r.stdout.trim();
}
export function validateGate(gate, percent, image, now = Date.now()) {
  const age = now - Date.parse(gate.checkedAt);
  if (
    gate.passed !== true ||
    gate.targetPercent !== percent ||
    gate.candidateImage !== image ||
    !Number.isFinite(age) ||
    age < 0 ||
    age > 3600000
  )
    throw Error("Missing, stale or mismatched rollout gate");
}
function main() {
  if(!/^(0|1|5|25|50|100)$/.test(process.argv[2]||''))throw Error('Invalid rollout percentage');
  const percent = Number(process.argv[2]);
  const content = trafficConfig(percent);
  const stableId = docker("compose", "ps", "-q", "app");
  if (!stableId) throw Error("Retained stable application is missing");
  const stableImage = docker("inspect", "-f", "{{.Image}}", stableId);
  const candidateId = docker("compose", "--profile", "canary", "ps", "-q", "candidate");
  const candidateImage = candidateId ? docker("inspect", "-f", "{{.Image}}", candidateId) : null;
  if (percent > 0) {
    inspectCandidate(process.env,args=>{const fixed=args.map(x=>x==='deploy/docker-compose.yml'?'docker-compose.yml':x==='deploy'?'.':x);return docker(...fixed)});
    freshPromotionGate(percent);
    const id = docker("compose", "--profile", "canary", "ps", "-q", "candidate");
    if (!id || docker("inspect", "-f", "{{.State.Health.Status}}", id) !== "healthy")
      throw Error("Candidate must be running and healthy");
    const image = docker("inspect", "-f", "{{.Image}}", id);
    const candidateApi = docker(
      "compose",
      "--profile",
      "canary",
      "exec",
      "-T",
      "candidate",
      "cat",
      "/app/.built-with-api-url",
    );
    const stableApi = docker("compose", "exec", "-T", "app", "cat", "/app/.built-with-api-url");
    if (!candidateApi || candidateApi !== stableApi)
      throw Error("Candidate and stable images use different API URLs");
    const gate = JSON.parse(readFileSync("backups/rollout/latest-gate.json", "utf8"));
    validateGate(gate, percent, image);
    if (gate.checks?.rehearsalBootstrap) {
      if (
        !rehearsalBootstrap(percent, process.env) ||
        new URL(process.env.SITE_URL).origin !== gate.checks.bootstrapSite
      )
        throw Error("Staging rehearsal gate cannot be used on another target");
    }
    assertStateBoundGate(
      gate,
      JSON.parse(readFileSync("backups/rollout/traffic-state.json", "utf8")),
      stableImage,
      image,
      readFileSync("caddy/rollout.caddy", "utf8"),
    );
    const ledger = docker(
      "compose",
      "exec",
      "-T",
      "db",
      "psql",
      "-X",
      "-U",
      "postgres",
      "-d",
      "postgres",
      "-v",
      "ON_ERROR_STOP=1",
      "-tAc",
      "SELECT string_agg(filename,',' ORDER BY filename) FROM platform_meta.applied_migrations",
    );
    if (!ledger || gate.migrationFingerprint !== fingerprint(ledger))
      throw Error("Migrations changed since gate review");
    const secret = docker(
      "compose",
      "exec",
      "-T",
      "proxy",
      "sh",
      "-c",
      "test ${#ROLLOUT_COOKIE_SECRET} -ge 32 && echo configured",
    );
    if (secret !== "configured")
      throw Error("Configure ROLLOUT_COOKIE_SECRET and recreate proxy first");
  }
  const file = "caddy/rollout.caddy";
  const previous = readFileSync(file, "utf8");
  mkdirSync("backups/rollout", { recursive: true, mode: 0o700 });
  writeFileSync("backups/rollout/previous-routing.caddy", previous, { mode: 0o600 });
  writeFileSync(`${file}.next`, content);
  renameSync(`${file}.next`, file);
  try {
    docker(
      "compose",
      "exec",
      "-T",
      "proxy",
      "caddy",
      "validate",
      "--config",
      "/etc/caddy/Caddyfile",
      "--adapter",
      "caddyfile",
    );
    docker(
      "compose",
      "exec",
      "-T",
      "proxy",
      "caddy",
      "reload",
      "--config",
      "/etc/caddy/Caddyfile",
      "--adapter",
      "caddyfile",
    );
  } catch (e) {
    writeFileSync(`${file}.next`, previous);
    renameSync(`${file}.next`, file);
    // A failed reload normally leaves the active config unchanged. Explicitly restore it.
    docker(
      "compose",
      "exec",
      "-T",
      "proxy",
      "caddy",
      "reload",
      "--config",
      "/etc/caddy/Caddyfile",
      "--adapter",
      "caddyfile",
    );
    throw e;
  }
  const stateFile = "backups/rollout/traffic-state.json";
  writeFileSync(
    `${stateFile}.next`,
    JSON.stringify({
      percent,
      changedAt: new Date().toISOString(),
      stableImage,
      candidateImage,
      routingFingerprint: fingerprint(content),
    }),
    { mode: 0o600 },
  );
  renameSync(`${stateFile}.next`, stateFile);
  console.log(
    `Routing changed: ${percent}% candidate for new assignments; 0/100 selects one upstream exclusively.`,
  );
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  let locked = false;
  const lock = "backups/rollout/.traffic-lock";
  try {
    mkdirSync("backups/rollout", { recursive: true, mode: 0o700 });
    mkdirSync(lock);
    locked = true;
    main();
  } catch (e) {
    console.error(e.message);
    process.exitCode = 1;
  } finally {
    if (locked) rmdirSync(lock);
  }
}
