import { mkdtempSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import { trafficConfig } from "./rollout-traffic.mjs";
const dir = mkdtempSync(join(tmpdir(), "tareeq-caddy-"));
try {
  for (const percent of [0, 1, 5, 25, 50, 100]) {
    writeFileSync(join(dir, "Caddyfile"), `:80 {\n${trafficConfig(percent)}\n}\n`);
    const r = spawnSync(
      "docker",
      [
        "run",
        "--rm",
        "-e",
        "APP_PORT=3000",
        "-e",
        "ROLLOUT_COOKIE_SECRET=ci-only-not-a-production-secret",
        "-v",
        `${dir}:/etc/caddy:ro`,
        "caddy:2.8-alpine",
        "caddy",
        "adapt",
        "--config",
        "/etc/caddy/Caddyfile",
        "--adapter",
        "caddyfile",
      ],
      { encoding: "utf8", timeout: 120000 },
    );
    if (r.status !== 0 || r.error) {
      console.error(r.stderr || r.error?.message);
      throw Error(`Caddy ${percent}% config failed`);
    }
    console.log(`Caddy 2.8 config ${percent}%: PASS`);
  }
} finally {
  rmSync(dir, { recursive: true, force: true });
}
