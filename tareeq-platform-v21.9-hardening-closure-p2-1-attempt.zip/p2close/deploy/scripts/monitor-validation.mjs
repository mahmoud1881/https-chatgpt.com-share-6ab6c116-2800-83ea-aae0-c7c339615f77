export function requireCounters(values, maximumIndex = -1) {
  if (
    !values.length ||
    values.some((value) => !Number.isFinite(value) || value < 0) ||
    (maximumIndex >= 0 && values[maximumIndex] <= 0)
  )
    throw new Error("Invalid monitoring counters");
}
export function parsePostgresCounters(line) {
  if (!/^\d+\|\d+\|\d+\|\d+\|\d+$/.test(line)) throw new Error("Invalid PG counters");
  const values = line.split("|").map(Number);
  requireCounters(values, 1);
  if (values.some((value) => !Number.isSafeInteger(value))) throw new Error("Invalid PG counters");
  return values;
}
export function incidentState(alerts, previous, now, fingerprint) {
  const key = fingerprint([...new Set(alerts)].sort());
  const gap = now - Date.parse(previous.at);
  const same = Number.isFinite(gap) && gap > 0 && gap <= 300000 && previous.incidentKey === key;
  const prior =
    Number.isSafeInteger(previous.consecutive) && previous.consecutive >= 0
      ? previous.consecutive
      : 0;
  return {
    incidentKey: key,
    consecutive: alerts.length ? (same ? prior + 1 : 1) : 0,
    notified: alerts.length > 0 && same && previous.notified === true,
  };
}
