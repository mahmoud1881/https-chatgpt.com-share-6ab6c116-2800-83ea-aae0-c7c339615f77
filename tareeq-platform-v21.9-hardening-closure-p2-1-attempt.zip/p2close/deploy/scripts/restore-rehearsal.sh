#!/usr/bin/env bash
# Rehearse an offsite restore in a disposable Compose project and time the RTO.
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
cd "$root/deploy"
umask 077
id="${1:-}"
[[ "$id" =~ ^[0-9]{8}T[0-9]{6}Z-[a-f0-9]{6}$ ]] || {
  echo 'Usage: restore-rehearsal.sh <offsite-backup-id>' >&2; exit 2;
}
: "${BACKUP_SSH_TARGET:?Missing BACKUP_SSH_TARGET}"
: "${BACKUP_REMOTE_DIR:?Missing BACKUP_REMOTE_DIR}"
: "${AGE_IDENTITY_FILE:?Missing AGE_IDENTITY_FILE (private key path)}"
: "${RESTORE_TEST_EMAIL:?Missing confirmed account in the backed-up database}"
: "${RESTORE_TEST_PASSWORD:?Missing password for restored account probe}"
: "${RTO_TARGET_SECONDS:=3600}"
[[ "$RTO_TARGET_SECONDS" =~ ^[1-9][0-9]*$ ]] || { echo 'RTO_TARGET_SECONDS must be positive' >&2; exit 2; }
[[ -r "$AGE_IDENTITY_FILE" ]] || { echo 'Age identity not readable' >&2; exit 2; }
[[ "$BACKUP_SSH_TARGET" =~ ^[a-zA-Z0-9_-]+@[a-zA-Z0-9._-]+$ ]] || exit 2
[[ "$BACKUP_REMOTE_DIR" =~ ^/[a-zA-Z0-9._/-]+$ && "$BACKUP_REMOTE_DIR" != *..* ]] || exit 2
for binary in docker age ssh scp sha256sum tar openssl comm node; do command -v "$binary" >/dev/null || exit 2; done
docker compose version >/dev/null

mkdir -p backups/rehearsals
tmp=$(mktemp -d "${TMPDIR:-/tmp}/tareeq-rehearsal.XXXXXXXX")
project="tareeqdr$(date -u +%s)$(openssl rand -hex 2)"
compose=(env -u RELEASE_COMMIT docker compose -p "$project" --env-file "$tmp/work/deploy/.env" --project-directory "$tmp/work/deploy" -f "$tmp/work/deploy/docker-compose.yml")
start=$(date +%s)
status=failed
completed=""
backup_sha256=""
restored_release=""
resources_started=no
cleanup() {
  local exit_code=$?
  [[ "$exit_code" == 0 ]] || status=failed
  if [[ "$resources_started" == yes ]]; then
    if "${compose[@]}" down -v --remove-orphans >/dev/null 2>&1; then
      completed+=",cleanup"
    else
      status=cleanup_failed
    fi
  fi
  local elapsed=$(( $(date +%s) - start ))
  if (( elapsed > RTO_TARGET_SECONDS )); then status=rto_exceeded; fi
  node "$root/deploy/scripts/restore-evidence.mjs" "backups/rehearsals/$id.json" \
    "$id" "$status" "$start" "$RTO_TARGET_SECONDS" "$backup_sha256" "$restored_release" "$project" "$completed"
  rm -rf -- "$tmp"
  [[ "$status" == passed ]] || exit 1
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
if docker volume inspect "${project}_db_data" >/dev/null 2>&1; then
  echo 'Isolated volume already exists' >&2; exit 1
fi
remote="$BACKUP_REMOTE_DIR/$id"
scp -q -o BatchMode=yes -o StrictHostKeyChecking=yes \
  "$BACKUP_SSH_TARGET:$remote/backup.tar.age" \
  "$BACKUP_SSH_TARGET:$remote/SHA256SUMS.encrypted" "$tmp/"
(cd "$tmp" && sha256sum -c SHA256SUMS.encrypted)
backup_sha256=$(sha256sum "$tmp/backup.tar.age" | cut -d ' ' -f 1)
completed+=",downloadChecksum"
age -d -i "$AGE_IDENTITY_FILE" -o "$tmp/backup.tar.gz" "$tmp/backup.tar.age"
mkdir -p "$tmp/extracted"
tar -xzf "$tmp/backup.tar.gz" -C "$tmp/extracted" \
  db.dump db-roles.sql db-role-names.txt deploy-config.tar.gz source-tree.tar.gz db-metrics.txt SHA256SUMS
(cd "$tmp/extracted" && sha256sum -c SHA256SUMS)
completed+=",archiveChecksum"
[[ -s "$tmp/extracted/db.dump" && -s "$tmp/extracted/db-roles.sql" ]] || exit 1

# Restore the exact source/config as well as PostgreSQL, without exposing
# public ports. The restored source supplies Compose's application build context.
mkdir -p "$tmp/work"
tar -xzf "$tmp/extracted/source-tree.tar.gz" -C "$tmp/work"
tar -xzf "$tmp/extracted/deploy-config.tar.gz" -C "$tmp/work/deploy"
[[ -s "$tmp/work/deploy/.env" ]] || { echo 'Archived config lacks .env' >&2; exit 1; }

echo "▶ Starting isolated PostgreSQL project: $project"
resources_started=yes
"${compose[@]}" up -d db
for i in $(seq 1 45); do
  if "${compose[@]}" exec -T db pg_isready -U postgres -d postgres >/dev/null 2>&1; then break; fi
  sleep 2
done
"${compose[@]}" exec -T db pg_isready -U postgres -d postgres >/dev/null
# Supabase's image already defines standard roles; duplicate CREATE ROLE
# statements are expected. The following dump restore and checks are strict.
bash "$root/deploy/scripts/prepare-roles.sh" "$tmp/extracted/db-roles.sql" "$tmp/extracted/db-role-names.txt" > "$tmp/roles-strict.sql"
"${compose[@]}" exec -T db psql -X -U postgres -d postgres -v ON_ERROR_STOP=1 \
  < "$tmp/roles-strict.sql" > "$tmp/roles.log" 2>&1
"${compose[@]}" exec -T db pg_restore -U postgres -d postgres \
  --clean --if-exists --exit-on-error < "$tmp/extracted/db.dump"
completed+=",databaseRestore"
actual=$("${compose[@]}" exec -T db psql -U postgres -d postgres -v ON_ERROR_STOP=1 -tAc \
  'SELECT (SELECT count(*) FROM auth.users), (SELECT count(*) FROM public.routes), (SELECT count(*) FROM public.community_routes)')
expected=$(cat "$tmp/extracted/db-metrics.txt")
[[ "$actual" == "$expected" ]] || { echo "Restore row counts differ ($actual vs $expected)" >&2; exit 1; }
completed+=",rowCounts"
"${compose[@]}" exec -T db psql -U postgres -d postgres -v ON_ERROR_STOP=1 -tAc \
  "SELECT rolname FROM pg_roles WHERE rolname NOT LIKE 'pg_%' ORDER BY rolname COLLATE \"C\"" > "$tmp/restored-role-names.txt"
missing=$(LC_ALL=C comm -23 "$tmp/extracted/db-role-names.txt" "$tmp/restored-role-names.txt")
[[ -z "$missing" ]] || { echo "Restore missing database roles: $missing" >&2; exit 1; }
schema_ok=$("${compose[@]}" exec -T db psql -X -U postgres -d postgres -v ON_ERROR_STOP=1 -tAc \
  "SELECT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='authenticator') AND to_regclass('auth.users') IS NOT NULL")
[[ "$schema_ok" == t ]] || { echo 'Restored schema/role check failed' >&2; exit 1; }
completed+=",roles"

# Recreate critical services against the restored database, then exercise
# application HTTP, Auth, REST and a genuine Realtime channel.
"${compose[@]}" up -d --build auth rest realtime meta kong app
restored_release=$("${compose[@]}" exec -T app cat /app/.release-commit | tr -d '\r\n')
[[ "$restored_release" =~ ^[a-fA-F0-9]{40}$ ]] || { echo 'Restored image has no valid release stamp' >&2; exit 1; }
archived_release=$(sed -n 's/^RELEASE_COMMIT=//p' "$tmp/work/deploy/.env" | tail -n 1)
[[ "$restored_release" == "$archived_release" ]] || { echo 'Restored image differs from archived release' >&2; exit 1; }
for i in $(seq 1 60); do
  if "${compose[@]}" exec -T app node -e \
    'Promise.all([fetch("http://127.0.0.1:3000/"),fetch("http://kong:8000/auth/v1/health",{headers:{apikey:process.env.VITE_SUPABASE_PUBLISHABLE_KEY}}),fetch("http://kong:8000/rest/v1/routes?select=id&limit=1",{headers:{apikey:process.env.VITE_SUPABASE_PUBLISHABLE_KEY}})]).then(x=>process.exit(x.every(r=>r.ok)?0:1)).catch(()=>process.exit(1))' \
    >/dev/null 2>&1; then break; fi
  sleep 3
done
"${compose[@]}" exec -T app node -e \
  'Promise.all([fetch("http://127.0.0.1:3000/"),fetch("http://kong:8000/auth/v1/health",{headers:{apikey:process.env.VITE_SUPABASE_PUBLISHABLE_KEY}}),fetch("http://kong:8000/rest/v1/routes?select=id&limit=1",{headers:{apikey:process.env.VITE_SUPABASE_PUBLISHABLE_KEY}})]).then(x=>process.exit(x.every(r=>r.ok)?0:1)).catch(()=>process.exit(1))' \
  >/dev/null
completed+=",services"
"${compose[@]}" exec -T -e RESTORE_TEST_EMAIL -e RESTORE_TEST_PASSWORD app node -e \
  'fetch("http://kong:8000/auth/v1/token?grant_type=password",{method:"POST",headers:{apikey:process.env.VITE_SUPABASE_PUBLISHABLE_KEY,"content-type":"application/json"},body:JSON.stringify({email:process.env.RESTORE_TEST_EMAIL,password:process.env.RESTORE_TEST_PASSWORD})}).then(async r=>{let j=await r.json();process.exit(r.ok&&j.access_token&&j.user?.id?0:1)}).catch(()=>process.exit(1))' \
  >/dev/null
completed+=",auth"
"${compose[@]}" exec -T app node - ws://kong:8000/realtime/v1/websocket \
  < "$root/deploy/scripts/probe-realtime.mjs"
completed+=",realtime"
elapsed=$(( $(date +%s) - start ))
if (( elapsed > RTO_TARGET_SECONDS )); then
  echo "❌ Restore exceeded preselected RTO ($elapsed > $RTO_TARGET_SECONDS seconds)" >&2
  exit 1
fi
status=passed
echo "Restore checks completed: $actual rows; elapsed $elapsed seconds. Final status follows isolated-resource cleanup in the JSON report."
