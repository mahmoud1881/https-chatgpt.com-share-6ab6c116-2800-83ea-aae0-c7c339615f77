export const scenarios = ["search", "planner", "write"];
export const loadLimits = {
  errorRate: 0.01,
  searchP95: 3000,
  plannerP95: 3000,
  writeP95: 2000,
  minimumSamples: 100,
};
export function summarizeLoad(records, users, rounds, limits = loadLimits) {
  const expected = users * rounds;
  const summary = { users, rounds, operations: records.length, scenarios: {} };
  for (const name of scenarios) {
    const rows = records.filter((row) => row.scenario === name);
    const valid = rows.every(
      (row) => typeof row.ok === "boolean" && Number.isFinite(row.ms) && row.ms >= 0,
    );
    const durations = rows.map((row) => row.ms).sort((a, b) => a - b);
    const errors = rows.filter((row) => row.ok !== true).length;
    const p95Ms =
      valid && durations.length ? durations[Math.ceil(durations.length * 0.95) - 1] : null;
    const errorRate = rows.length ? errors / rows.length : null;
    summary.scenarios[name] = {
      total: rows.length,
      errors,
      errorRate,
      p95Ms,
      passed:
        valid &&
        rows.length === expected &&
        rows.length >= limits.minimumSamples &&
        errorRate <= limits.errorRate &&
        p95Ms !== null &&
        p95Ms <= limits[`${name}P95`],
    };
  }
  summary.errorRate = records.length
    ? records.filter((row) => row.ok !== true).length / records.length
    : null;
  summary.passed =
    records.length === expected * scenarios.length &&
    Object.values(summary.scenarios).every((row) => row.passed);
  // Error text from browsers may contain URLs and credentials; retain counts only.
  return summary;
}

export function assertWrittenRoute(rows, expected) {
  if (
    !Array.isArray(rows) ||
    rows.length !== 1 ||
    !["id", "user_id", "title", "status", "confirmations"].every(
      (key) => rows[0]?.[key] === expected[key],
    )
  )
    throw new Error("Public write readback mismatch");
}
