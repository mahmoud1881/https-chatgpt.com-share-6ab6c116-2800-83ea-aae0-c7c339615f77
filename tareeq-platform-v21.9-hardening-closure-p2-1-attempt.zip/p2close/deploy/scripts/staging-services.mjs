// Run on the staging host after Compose is healthy. Never logs tokens or passwords.
import { lookup } from "node:dns/promises";
import { connect } from "node:tls";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { randomUUID } from "node:crypto";
import { stagingContext, assertStagingProof, assertStagingRelease } from "./staging-evidence.mjs";
import { validateStagingReview } from "./staging-review.mjs";

const env = process.env;
function required(name) {
  const value = env[name];
  if (!value) throw new Error(`Missing ${name}`);
  return value;
}
async function check(name, action) {
  await action();
  console.log(`✅ ${name}`);
}
function assert(ok, message) {
  if (!ok) throw new Error(message);
}
async function request(url, options = {}) {
  const response = await fetch(url, { signal: AbortSignal.timeout(12000), ...options });
  assert(response.ok, `${new URL(url).pathname}: HTTP ${response.status}`);
  return response;
}
const proofFile = "backups/staging-probe.json";
async function main() {
  const context = stagingContext(env);
  const site = new URL(required("SITE_URL"));
  const api = new URL(required("SUPABASE_PUBLIC_URL"));
  const studio = new URL(`https://${required("STUDIO_DOMAIN")}`);
  const expectedIp = required("STAGING_EXPECTED_IPV4");
  const anon = required("VITE_SUPABASE_PUBLISHABLE_KEY");
  const email = required("STAGING_TEST_EMAIL");
  const password = required("STAGING_TEST_PASSWORD");
  const provider = required("STAGING_OAUTH_PROVIDER");
  const providerHost = required("STAGING_OAUTH_EXPECTED_HOST");
  assert(
    [site, api, studio].every((u) => u.protocol === "https:"),
    "HTTPS required for all staging domains",
  );
  assert(env.AUTH_AUTOCONFIRM === "false", "Disable email autoconfirm to exercise actual delivery");
  for (const name of ["SMTP_HOST", "SMTP_USER", "SMTP_PASS", "SMTP_ADMIN_EMAIL"]) required(name);

  for (const u of [site, api, studio]) {
    await check(`DNS ${u.hostname}`, async () => {
      const ips = await lookup(u.hostname, { all: true });
      assert(
        ips.some((ip) => ip.family === 4 && ip.address === expectedIp),
        `${u.hostname} does not resolve to staging IP`,
      );
    });
    await check(
      `TLS ${u.hostname}`,
      () =>
        new Promise((resolve, reject) => {
          const socket = connect({
            host: u.hostname,
            port: 443,
            servername: u.hostname,
            rejectUnauthorized: true,
          });
          socket.setTimeout(12000, () => {
            socket.destroy();
            reject(new Error("TLS timeout"));
          });
          socket.once("error", reject);
          socket.once("secureConnect", () => {
            const cert = socket.getPeerCertificate();
            socket.end();
            const days = (Date.parse(cert.valid_to) - Date.now()) / 86400000;
            days >= 14
              ? resolve()
              : reject(new Error(`TLS certificate expires in ${days.toFixed(1)} days`));
          });
        }),
    );
  }
  await check("public application", async () => {
    const response = await request(site);
    assertStagingRelease(response, env.RELEASE_COMMIT);
  });
  const headers = { apikey: anon };
  await check("public Auth health", async () => {
    await request(new URL("/auth/v1/health", api), { headers });
  });
  await check("public REST route query", async () => {
    const response = await request(new URL("/rest/v1/routes?select=id&limit=1", api), { headers });
    assert(Array.isArray(await response.json()), "REST returned no JSON array");
  });
  const settings = await (await request(new URL("/auth/v1/settings", api), { headers })).json();
  assert(settings.external?.email === true, "Email login is disabled");
  assert(settings.external?.[provider] === true, `OAuth provider ${provider} is disabled`);
  console.log("✅ Auth provider settings");
  await check("password login and /user", async () => {
    const response = await request(new URL("/auth/v1/token?grant_type=password", api), {
      method: "POST",
      headers: { ...headers, "content-type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const token = (await response.json()).access_token;
    assert(typeof token === "string" && token.length > 50, "No access token");
    const user = await (
      await request(new URL("/auth/v1/user", api), {
        headers: { ...headers, Authorization: `Bearer ${token}` },
      })
    ).json();
    assert(
      user.id && user.email?.toLowerCase() === email.toLowerCase(),
      "Authenticated user mismatch",
    );
  });
  const confirming = Boolean(
    env.STAGING_PROBE_ID || env.STAGING_EMAIL_RECEIVED_AT || env.STAGING_OAUTH_CALLBACK_AT,
  );
  let proof;
  if (confirming) {
    proof = JSON.parse(readFileSync(proofFile, "utf8"));
    assertStagingProof(proof, env);
  }
  if (!confirming) {
    mkdirSync("backups", { recursive: true, mode: 0o700 });
    const started = new Date().toISOString();
    proof = { schemaVersion: 1, id: randomUUID(), startedAt: started, context };
    writeFileSync(proofFile, JSON.stringify(proof) + "\n", { mode: 0o600 });
    await check("SMTP recovery request accepted", async () => {
      await request(new URL("/auth/v1/recover", api), {
        method: "POST",
        headers: { ...headers, "content-type": "application/json" },
        body: JSON.stringify({ email, redirect_to: site.href }),
      });
    });
    console.log(
      `Record mailbox delivery and OAuth callback AFTER ${started}, then rerun with STAGING_PROBE_ID=${proof.id}.`,
    );
  }
  await check("OAuth provider redirect", async () => {
    const url = new URL("/auth/v1/authorize", api);
    url.searchParams.set("provider", provider);
    url.searchParams.set("redirect_to", site.href);
    const response = await fetch(url, { redirect: "manual", signal: AbortSignal.timeout(12000) });
    assert([302, 303, 307].includes(response.status), `OAuth returned HTTP ${response.status}`);
    const target = new URL(response.headers.get("location"));
    assert(
      target.hostname === providerHost,
      `OAuth redirected to unexpected host ${target.hostname}`,
    );
  });
  // These two require observations in a real mailbox/browser; API acceptance is insufficient.
  assertStagingProof(proof, env);
  const review = validateStagingReview(required("STAGING_EVIDENCE_MANIFEST"), proof, env);
  writeFileSync("backups/staging-reviewed-evidence.json", JSON.stringify(review, null, 2) + "\n", {
    mode: 0o600,
  });
  console.log(
    "✅ Mailbox and OAuth attachments match the independently signed review for this probe",
  );
}
main().catch((error) => {
  console.error(`❌ Staging services: ${error.message}`);
  process.exitCode = 1;
});
