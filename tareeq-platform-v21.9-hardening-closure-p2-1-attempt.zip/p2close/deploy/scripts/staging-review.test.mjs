import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, writeFileSync, rmSync, unlinkSync, symlinkSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { generateKeyPairSync, createHash, sign } from "node:crypto";
import { stagingContext } from "./staging-evidence.mjs";
import { validateStagingReview } from "./staging-review.mjs";
const now = Date.parse("2026-09-24T12:00:00Z");
function scenario(run) {
  const dir = mkdtempSync(join(tmpdir(), "staging-review-"));
  const { publicKey, privateKey } = generateKeyPairSync("ed25519");
  const env = {
    RELEASE_COMMIT: "a".repeat(40),
    SITE_URL: "https://staging.example.com",
    SUPABASE_PUBLIC_URL: "https://api.example.com",
    STUDIO_DOMAIN: "studio.example.com",
    STAGING_EXPECTED_IPV4: "192.0.2.1",
    STAGING_TEST_EMAIL: "test@example.com",
    STAGING_OAUTH_PROVIDER: "google",
    STAGING_OAUTH_EXPECTED_HOST: "accounts.google.com",
    STAGING_PROBE_ID: "probe",
    STAGING_EMAIL_RECEIVED_AT: "2026-09-24T11:55:00Z",
    STAGING_OAUTH_CALLBACK_AT: "2026-09-24T11:56:00Z",
    STAGING_REVIEWER_ID: "reviewer",
    STAGING_REVIEW_PUBLIC_KEY_FILE: join(dir, "public.pem"),
  };
  writeFileSync(
    env.STAGING_REVIEW_PUBLIC_KEY_FILE,
    publicKey.export({ type: "spki", format: "pem" }),
  );
  const proof = { id: "probe", context: stagingContext(env), startedAt: "2026-09-24T11:50:00Z" };
  const artifacts = ["mailbox", "oauth"].map((kind, i) => {
    const body = JSON.stringify({ fixture: kind });
    writeFileSync(join(dir, `${kind}.json`), body);
    return {
      kind,
      file: `${kind}.json`,
      sha256: createHash("sha256").update(body).digest("hex"),
      observedAt: i ? env.STAGING_OAUTH_CALLBACK_AT : env.STAGING_EMAIL_RECEIVED_AT,
    };
  });
  const manifest = {
    schemaVersion: 1,
    probeId: proof.id,
    context: proof.context,
    releaseCommit: env.RELEASE_COMMIT,
    collector: "operator",
    review: { reviewer: "reviewer", decision: "approved", reviewedAt: "2026-09-24T11:58:00Z" },
    artifacts,
  };
  const file = join(dir, "manifest.json");
  const save = (key = privateKey) => {
    const bytes = Buffer.from(JSON.stringify(manifest));
    writeFileSync(file, bytes);
    writeFileSync(`${file}.sig`, sign(null, bytes, key));
  };
  try {
    save();
    run({
      dir,
      env,
      proof,
      manifest,
      save,
      file,
      check: () => validateStagingReview(file, proof, env, now),
    });
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}
test("signed independently reviewed attachments produce a hash-only receipt", () =>
  scenario(({ check }) => {
    const result = check();
    assert.equal(result.artifacts.length, 2);
    assert.equal(result.reviewer, "reviewer");
    assert.ok(!JSON.stringify(result).includes("test@example.com"));
  }));
test("timestamps alone and missing attachments fail", () =>
  scenario(({ dir, check }) => {
    unlinkSync(join(dir, "mailbox.json"));
    assert.throws(check);
  }));
test("changed attachments and tampered manifests fail", () =>
  scenario(({ dir, file, check }) => {
    writeFileSync(join(dir, "oauth.json"), "changed");
    assert.throws(check);
    writeFileSync(file, "{}");
    assert.throws(check);
  }));
test("untrusted signature fails", () =>
  scenario(({ save, check }) => {
    save(generateKeyPairSync("ed25519").privateKey);
    assert.throws(check);
  }));
test("self-review, rejected reviews and wrong release or run fail", () => {
  for (const mutate of [
    (m) => (m.collector = "reviewer"),
    (m) => (m.review.decision = "rejected"),
    (m) => (m.releaseCommit = "b".repeat(40)),
    (m) => (m.probeId = "old"),
    (m) => (m.review.reviewedAt = "2026-09-24T11:54:00Z"),
  ])
    scenario(({ manifest, save, check }) => {
      mutate(manifest);
      save();
      assert.throws(check);
    });
});
test("path traversal and symlink evidence fail", () => {
  scenario(({ manifest, save, check }) => {
    manifest.artifacts[0].file = "../mailbox.json";
    save();
    assert.throws(check);
  });
  scenario(({ dir, check }) => {
    unlinkSync(join(dir, "mailbox.json"));
    symlinkSync(join(dir, "oauth.json"), join(dir, "mailbox.json"));
    assert.throws(check);
  });
});
