import { BINDING_PHASES } from "./runtime-image-binding.mjs";
import test from "node:test";
import assert from "node:assert/strict";
import { generateKeyPairSync, sign, randomUUID } from "node:crypto";
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, rmSync, symlinkSync } from "node:fs";
import { tmpdir } from "node:os";
import { resolve, dirname } from "node:path";
import { spawnSync } from "node:child_process";
import {
  FORMAT,
  GATES,
  EVIDENCE,
  sha,
  canonical,
  verifyCertificate,
  loadTrust,
  MAX_AGE_MS,
  MAX_CERT_DURATION_MS,
} from "./certification-policy.mjs";
const pair = generateKeyPairSync("ed25519"),
  other = generateKeyPairSync("ed25519");
function fixture(fn) {
  const root = mkdtempSync(resolve(tmpdir(), "cert-test-"));
  const now = Date.now(),
    start = new Date(now - 10000).toISOString(),
    end = new Date(now - 1000).toISOString();
  const commit = "a".repeat(40),
    digest = "sha256:" + "b".repeat(64),
    fingerprint = "c".repeat(64);
  const trust = { key: pair.publicKey, keyId: "release-2026", commit, digest };
  const cert = {
    format: FORMAT,
    runId: randomUUID(),
    status: "PRODUCTION CERTIFIED",
    startedAt: start,
    completedAt: end,
    passed: true,
    release: { gitCommit: commit, imageDigest: digest, schemaFingerprint: fingerprint },
    runtimeGates: GATES.map((name) => ({
      name,
      startedAt: start,
      completedAt: start,
      exitCode: 0,
      passed: true,
    })),
    evidence: {},
    signature: {
      algorithm: "Ed25519",
      keyId: trust.keyId,
      publicKeySha256: sha(pair.publicKey.export({ type: "spki", format: "der" })),
      detachedSignature: "artifacts/production-certification.sig",
    },
  };
  const docs = Object.fromEntries(
    Object.entries(EVIDENCE).map(([label, [, format]]) => [
      label,
      { ...(format ? { format } : {}), completedAt: end },
    ]),
  );
  Object.assign(docs.sbomSpdx, {
    spdxVersion: "SPDX-2.3",
    packages: [{ name: "app" }],
    creationInfo: { created: end },
  });
  Object.assign(docs.sbomCycloneDx, {
    bomFormat: "CycloneDX",
    components: [{ name: "app" }],
    metadata: { timestamp: end },
  });
  Object.assign(docs.provenance, {
    _type: "https://in-toto.io/Statement/v1",
    predicateType: "https://slsa.dev/provenance/v1",
    subject: [{ digest: { sha256: digest.slice(7) } }],
    predicate: {
      buildDefinition: { externalParameters: { gitCommit: commit }, resolvedDependencies: [] },
      runDetails: { metadata: { finishedOn: end } },
    },
  });
  Object.assign(docs.schemaDrift, {
    expectedSchemaSha256: fingerprint,
    expectedMigrationCount: 1,
    targets: Object.fromEntries(
      ["staging", "production"].map((t) => [
        t,
        { matches: true, schemaSha256: fingerprint, migrationCount: 1 },
      ]),
    ),
  });
  docs.migrationManifest = {
    format: EVIDENCE.migrationManifest[1],
    migrations: { "001.sql": "d".repeat(64) },
  };
  Object.assign(docs.migrationSafety, { pendingCount: 0, pending: [] });
  Object.assign(docs.productionMigration, {
    trafficCutoverAllowed: true,
    postDeployMigrationCount: 1,
  });
  Object.assign(docs.zeroDowntime, {
    status: "passed",
    trafficCutoverAllowed: true,
    databaseRollbackAttempted: false,
    recoveryMode: "roll-forward-only",
    phases: [
      "expand",
      "dual-release-schema-compatibility",
      "deploy-green-and-probe",
      "progressive-delivery",
      "full-cutover",
      "post-deploy-schema-fingerprint",
    ].map((phase) => ({ phase, status: "passed" })),
  });
  Object.assign(docs.progressiveDelivery, {
    status: "passed",
    stages: [1, 5, 25, 50, 100],
    decisions: [1, 5, 25, 50, 100].map((percent) => ({
      percent,
      decision: percent === 100 ? "complete" : "promote",
      slo: { passed: true },
    })),
  });
  Object.assign(docs.telemetry, {
    passed: true,
    checks: Object.fromEntries(
      [
        "tempoReady",
        "prometheusReady",
        "syntheticRequest",
        "traceRetrievable",
        "appSpanMetrics",
        "databaseMetrics",
      ].map((c) => [c, true]),
    ),
  });
  Object.assign(docs.runtimeChaos, {
    passed: true,
    telemetryCertification: { passed: true },
    scenarios: ["5xx", "latency", "db-outage", "external-failure"].map((mode) => ({
      mode,
      passed: true,
      detected: true,
      incident: true,
      stableRestored: true,
    })),
  });
  Object.assign(docs.disasterRecovery, {
    passed: true,
    checks: Object.fromEntries(
      [
        "backupIntegrity",
        "rpo",
        "cleanDatabaseStarted",
        "databaseRestore",
        "dataIntegrity",
        "schemaIntegrity",
        "servicesRestarted",
        "telemetryRecovered",
        "trafficRestored",
        "rto",
        "isolationVerified",
      ].map((c) => [c, true]),
    ),
    cleanup: { attempted: true, errors: [] },
  });
  Object.assign(docs.supplyChain, {
    passed: true,
    gitCommit: commit,
    image: { ref: "registry.example/tareeq", expectedDigest: digest, publishedDigest: digest },
    checks: [
      "git-commit-identity",
      "published-image-digest",
      "sbom-spdx",
      "sbom-cyclonedx",
      "dependency-vulnerability-scan",
      "secret-scan",
      "oci-image-sign",
      "oci-image-signature-verify",
      "oci-provenance-attest",
      "oci-provenance-verify",
    ].map((name) => ({ name, passed: true, exitCode: 0 })),
    artifacts: {},
  });
  Object.assign(docs.imageBinding, {
    passed: true,
    runId: cert.runId,
    gitCommit: commit,
    completedAt: start,
    samples: BINDING_PHASES.map((phase) => ({
      phase,
      immutableRef: `registry.example/tareeq@${digest}`,
      imageId: "sha256:" + "1".repeat(64),
      containerId: "2".repeat(64),
      observedAt: start,
    })),
  });
  docs.zeroDowntime.newRelease = `registry.example/tareeq@${digest}`;
  function save(label) {
    const path = EVIDENCE[label][0],
      d = docs[label],
      raw = JSON.stringify(d);
    mkdirSync(dirname(resolve(root, path)), { recursive: true });
    writeFileSync(resolve(root, path), raw);
    cert.evidence[label] = {
      path,
      sha256: sha(raw),
      format: d.format ?? null,
      completedAt:
        label === "migrationManifest"
          ? null
          : label === "sbomSpdx"
            ? d.creationInfo.created
            : label === "sbomCycloneDx"
              ? d.metadata.timestamp
              : label === "provenance"
                ? d.predicate.runDetails.metadata.finishedOn
                : d.completedAt,
    };
  }
  for (const label of ["sbomSpdx", "sbomCycloneDx"]) save(label);
  docs.provenance.predicate.buildDefinition.resolvedDependencies = [
    ["sbom:spdx", "sbomSpdx"],
    ["sbom:cyclonedx", "sbomCycloneDx"],
  ].map(([uri, label]) => ({ uri, digest: { sha256: cert.evidence[label].sha256 } }));
  save("provenance");
  for (const label of ["sbomSpdx", "sbomCycloneDx", "provenance"])
    docs.supplyChain.artifacts[label] = { sha256: cert.evidence[label].sha256 };
  for (const label of Object.keys(docs)) save(label);
  for (const [label, field] of [
    ["sbomSpdx", "sbomSpdxSha256"],
    ["sbomCycloneDx", "sbomCycloneDxSha256"],
    ["provenance", "provenanceSha256"],
    ["migrationManifest", "migrationManifestSha256"],
  ])
    cert.release[field] = cert.evidence[label].sha256;
  const signature = () =>
    sign(null, Buffer.from(canonical(cert)), pair.privateKey).toString("base64");
  const check = () => verifyCertificate({ cert, signature: signature(), root, trust, now });
  try {
    fn({ root, cert, docs, trust, now, save, check, signature });
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
}
test("complete fresh certificate with independent trust is accepted", () =>
  fixture((f) => assert.equal(f.check().passed, true)));
const bad = (name, mutate, pattern) =>
  test(name, () =>
    fixture((f) => {
      mutate(f);
      assert.throws(f.check, pattern);
    }),
  );
bad(
  "missing evidence cannot be signed into acceptance",
  (f) => delete f.cert.evidence.telemetry,
  /schema/,
);
bad("empty gate list rejected", (f) => (f.cert.runtimeGates = []), /gates/);
bad("unknown schema rejected", (f) => (f.cert.format = "old-v1"), /unsupported/);
bad("unknown certificate field rejected", (f) => (f.cert.extra = true), /schema/);
bad(
  "wrong expected release rejected",
  (f) => (f.trust.digest = "sha256:" + "f".repeat(64)),
  /release/,
);
bad(
  "expired certificate rejected",
  (f) => {
    f.cert.completedAt = new Date(f.now - MAX_AGE_MS - 1).toISOString();
    f.cert.startedAt = new Date(f.now - MAX_AGE_MS - 10001).toISOString();
  },
  /expired/,
);

bad(
  "overlong certification rejected",
  (f) => {
    f.cert.startedAt = new Date(f.now - MAX_CERT_DURATION_MS - 2000).toISOString();
    f.cert.runtimeGates.forEach((g) => { g.startedAt = f.cert.startedAt; g.completedAt = f.cert.startedAt; });
  },
  /overlong/,
);
bad(
  "future certificate rejected",
  (f) => (f.cert.completedAt = new Date(f.now + 120000).toISOString()),
  /future/,
);
bad("invalid timestamp rejected", (f) => (f.cert.startedAt = "today"), /timestamp/);
bad("reordered gate rejected", (f) => f.cert.runtimeGates.reverse(), /gate/);
bad("failed gate rejected", (f) => (f.cert.runtimeGates[0].exitCode = 1), /gate/);
bad(
  "tampered bytes rejected",
  (f) => writeFileSync(resolve(f.root, EVIDENCE.telemetry[0]), "{}"),
  /hash/,
);
bad("missing file rejected", (f) => rmSync(resolve(f.root, EVIDENCE.telemetry[0])), /ENOENT/);
bad("path traversal rejected", (f) => (f.cert.evidence.telemetry.path = "../outside.json"), /path/);
bad(
  "symlink evidence rejected",
  (f) => {
    const p = resolve(f.root, EVIDENCE.telemetry[0]);
    rmSync(p);
    symlinkSync(resolve(f.root, EVIDENCE.runtimeChaos[0]), p);
  },
  /symlink/,
);
bad(
  "stale evidence rejected even after rehash and signing",
  (f) => {
    f.docs.telemetry.completedAt = new Date(f.now - 120000).toISOString();
    f.save("telemetry");
  },
  /window/,
);
bad(
  "future evidence rejected even after rehash and signing",
  (f) => {
    f.docs.telemetry.completedAt = new Date(f.now + 120000).toISOString();
    f.save("telemetry");
  },
  /window/,
);
bad(
  "missing telemetry checks rejected",
  (f) => {
    f.docs.telemetry.checks = {};
    f.save("telemetry");
  },
  /telemetry/,
);
bad(
  "zero canary decisions rejected",
  (f) => {
    f.docs.progressiveDelivery.decisions = [];
    f.save("progressiveDelivery");
  },
  /stage/,
);
bad(
  "missing chaos scenario rejected",
  (f) => {
    f.docs.runtimeChaos.scenarios.pop();
    f.save("runtimeChaos");
  },
  /chaos/,
);
bad(
  "database-only DR cannot certify production",
  (f) => {
    f.docs.disasterRecovery.scope = "isolated-database";
    f.save("disasterRecovery");
  },
  /full disaster/,
);
bad(
  "skipped telemetry in DR rejected",
  (f) => {
    f.docs.disasterRecovery.checks.telemetryRecovered = "skipped";
    f.save("disasterRecovery");
  },
  /recovery/,
);
bad(
  "cleanup errors rejected",
  (f) => {
    f.docs.disasterRecovery.cleanup.errors = ["failed"];
    f.save("disasterRecovery");
  },
  /cleanup/,
);
bad(
  "wrong schema target rejected",
  (f) => {
    f.docs.schemaDrift.targets.production.schemaSha256 = "e".repeat(64);
    f.save("schemaDrift");
  },
  /schema/,
);
bad("wrong signing key rejected", (f) => (f.trust.key = other.publicKey), /untrusted/);
test("certificate modification invalidates signature", () =>
  fixture((f) => {
    const signature = f.signature();
    f.cert.runId = randomUUID();
    assert.throws(() => verifyCertificate({ ...f, signature }), /signature/);
  }));
test("self-signed empty certificate cannot establish its own trust", () =>
  fixture((f) => {
    const cert = {
      status: "PRODUCTION CERTIFIED",
      passed: true,
      signature: {
        keyId: f.trust.keyId,
        publicKeySha256: sha(other.publicKey.export({ type: "spki", format: "der" })),
      },
    };
    const signature = sign(null, Buffer.from(canonical(cert)), other.privateKey).toString("base64");
    assert.throws(() => verifyCertificate({ ...f, cert, signature }), /untrusted/);
  }));
test("no configured trust and bundled keys are rejected", () =>
  fixture((f) => {
    assert.throws(() => loadTrust(f.root, {}), /independent/);
    const p = resolve(f.root, "bundled.pem");
    writeFileSync(p, pair.publicKey.export({ type: "spki", format: "pem" }));
    assert.throws(
      () =>
        loadTrust(f.root, { RELEASE_TRUSTED_PUBLIC_KEY_FILE: p, RELEASE_TRUSTED_KEY_ID: "key" }),
      /outside/,
    );
  }));
test("CLI never falls back to bundled key", () =>
  fixture((f) => {
    const result = spawnSync(
      process.execPath,
      [resolve("deploy/scripts/verify-production-certification.mjs")],
      { env: { CERTIFICATION_BUNDLE_ROOT: f.root }, encoding: "utf8" },
    );
    assert.equal(result.status, 1);
    assert.match(result.stderr, /independent trusted/);
  }));
test("CLI accepts valid bundle only with externally configured key and release", () =>
  fixture((f) => {
    const external = mkdtempSync(resolve(tmpdir(), "trusted-key-"));
    try {
      const key = resolve(external, "release.pem");
      writeFileSync(key, pair.publicKey.export({ type: "spki", format: "pem" }));
      writeFileSync(
        resolve(f.root, "artifacts/production-certification.json"),
        JSON.stringify(f.cert),
      );
      writeFileSync(resolve(f.root, "artifacts/production-certification.sig"), f.signature());
      const result = spawnSync(
        process.execPath,
        [resolve("deploy/scripts/verify-production-certification.mjs")],
        {
          env: {
            CERTIFICATION_BUNDLE_ROOT: f.root,
            RELEASE_TRUSTED_PUBLIC_KEY_FILE: key,
            RELEASE_TRUSTED_KEY_ID: f.trust.keyId,
            RELEASE_COMMIT: f.trust.commit,
            RELEASE_IMAGE_DIGEST: f.trust.digest,
          },
          encoding: "utf8",
        },
      );
      assert.equal(result.status, 0, result.stderr);
      assert.match(result.stdout, /verified/);
    } finally {
      rmSync(external, { recursive: true, force: true });
    }
  }));
test("legacy public-key CLI argument is explicitly rejected", () => {
  const result = spawnSync(
    process.execPath,
    [
      resolve("deploy/scripts/verify-production-certification.mjs"),
      "manifest",
      "signature",
      "bundled-key",
    ],
    { encoding: "utf8" },
  );
  assert.equal(result.status, 1);
  assert.match(result.stderr, /no longer accepted/);
});

bad(
  "missing live image checkpoints rejected",
  (f) => {
    f.docs.imageBinding.samples.pop();
    f.save("imageBinding");
  },
  /checkpoints/,
);
bad(
  "container swapped during tests rejected",
  (f) => {
    f.docs.imageBinding.samples[1].containerId = "3".repeat(64);
    f.save("imageBinding");
  },
  /changed/,
);
bad(
  "image report from a different run rejected",
  (f) => {
    f.docs.imageBinding.runId = randomUUID();
    f.save("imageBinding");
  },
  /run mismatch/,
);
bad(
  "deployment tag cannot substitute for immutable release",
  (f) => {
    f.docs.zeroDowntime.newRelease = "app:latest";
    f.save("zeroDowntime");
  },
  /deployment release/,
);
