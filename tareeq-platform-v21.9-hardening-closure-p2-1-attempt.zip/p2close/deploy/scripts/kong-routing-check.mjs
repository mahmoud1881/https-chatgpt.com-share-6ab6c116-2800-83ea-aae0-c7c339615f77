// Real Kong 2.8.1 integration with a disposable echo upstream. No real secrets.
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { resolve } from "node:path";
const root = resolve(import.meta.dirname, "../..");
const id = `tareeq-kong-test-${process.pid}-${Date.now()}`;
const gateway = `${id}-gateway`,
  upstream = `${id}-upstream`;
const docker = (...args) =>
  execFileSync("docker", args, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }).trim();
try {
  docker("network", "create", id);
  docker(
    "run",
    "-d",
    "--name",
    upstream,
    "--network",
    id,
    "--network-alias",
    "auth",
    "-v",
    `${root}/deploy/scripts/kong-test-upstream.py:/echo.py:ro`,
    "python:3.12-alpine",
    "python",
    "/echo.py",
  );
  docker(
    "run",
    "-d",
    "--name",
    gateway,
    "--network",
    id,
    "-p",
    "127.0.0.1::8000",
    "-e",
    "KONG_DATABASE=off",
    "-e",
    "KONG_DECLARATIVE_CONFIG=/tmp/kong-rendered.yml",
    "-e",
    "KONG_PLUGINS=request-transformer,cors,key-auth,acl,basic-auth",
    "-e",
    "SUPABASE_ANON_KEY=anon.payload.signature",
    "-e",
    "SUPABASE_SERVICE_KEY=service.payload.signature",
    "-v",
    `${root}/deploy/supabase/kong.yml:/var/lib/kong/kong.template.yml:ro`,
    "-v",
    `${root}/deploy/supabase/kong-entrypoint.sh:/render.sh:ro`,
    "--entrypoint",
    "/bin/sh",
    "kong:2.8.1",
    "/render.sh",
  );
  const address = docker("port", gateway, "8000/tcp");
  const base = `http://${address}`;
  let ready = false;
  for (let i = 0; i < 40; i++) {
    try {
      const r = await fetch(`${base}/auth/v1/health`, { signal: AbortSignal.timeout(1500) });
      if (r.status === 401) {
        ready = true;
        break;
      }
    } catch {}
    await new Promise((r) => setTimeout(r, 1000));
  }
  assert.ok(ready, "Kong did not become ready");
  for (const endpoint of [
    "verify?token=test&type=signup",
    "callback?code=test",
    "authorize?provider=google",
    ".well-known/jwks.json",
  ]) {
    const response = await fetch(`${base}/auth/v1/${endpoint}`, {
      signal: AbortSignal.timeout(5000),
    });
    assert.equal(response.status, 200, `public ${endpoint} must not require apikey`);
    assert.equal(
      (await response.json()).path,
      `/${endpoint}`,
      "upstream path and query must survive",
    );
  }
  for (const endpoint of ["health", "token", "user", "admin/users"]) {
    const response = await fetch(`${base}/auth/v1/${endpoint}`, {
      signal: AbortSignal.timeout(5000),
    });
    assert.equal(response.status, 401, `protected ${endpoint}`);
  }
  for (const key of ["anon.payload.signature", "service.payload.signature"]) {
    const response = await fetch(`${base}/auth/v1/health`, {
      headers: { apikey: key },
      signal: AbortSignal.timeout(5000),
    });
    assert.equal(response.status, 200, "rendered key accepted");
    assert.equal((await response.json()).path, "/health");
  }
  const rejected = await fetch(`${base}/auth/v1/health`, {
    headers: { apikey: "incorrect" },
    signal: AbortSignal.timeout(5000),
  });
  assert.equal(rejected.status, 401);
  console.log("Kong routing, public OAuth endpoints and key substitution passed");
} catch (error) {
  try {
    console.error(docker("logs", gateway));
  } catch {}
  throw error;
} finally {
  for (const name of [gateway, upstream]) {
    try {
      docker("rm", "-f", name);
    } catch {}
  }
  try {
    docker("network", "rm", id);
  } catch {}
}
