#!/usr/bin/env bash
# Run after bootstrap.sh + deploy.sh on a newly provisioned staging host.
set -euo pipefail
cd "$(dirname "$0")/.."
[[ -f .env ]] || { echo '❌ Missing deploy/.env' >&2; exit 1; }
# shellcheck disable=SC1091
set -a; . ./.env; set +a
: "${SITE_URL:?Missing SITE_URL}"
: "${SUPABASE_PUBLIC_URL:?Missing SUPABASE_PUBLIC_URL}"
: "${VITE_SUPABASE_PUBLISHABLE_KEY:?Missing anon key}"
[[ "$SITE_URL" == https://* && "$SUPABASE_PUBLIC_URL" == https://* ]] || {
  echo '❌ Staging endpoints must use HTTPS.' >&2; exit 1;
}

./scripts/health.sh
curl --fail --silent --show-error --max-time 15 -o /dev/null "$SITE_URL/"
curl --fail --silent --show-error --max-time 15 -o /dev/null \
  -H "apikey: $VITE_SUPABASE_PUBLISHABLE_KEY" "$SUPABASE_PUBLIC_URL/auth/v1/health"
curl --fail --silent --show-error --max-time 15 -o /dev/null \
  -H "apikey: $VITE_SUPABASE_PUBLISHABLE_KEY" "$SUPABASE_PUBLIC_URL/rest/v1/"
node ./scripts/staging-services.mjs
node ./scripts/probe-realtime.mjs "${SUPABASE_PUBLIC_URL/https:/wss:}/realtime/v1/websocket"
echo '✅ Staging services, DNS/TLS, Auth, REST and Realtime passed; mailbox and OAuth completion evidence recorded.'
