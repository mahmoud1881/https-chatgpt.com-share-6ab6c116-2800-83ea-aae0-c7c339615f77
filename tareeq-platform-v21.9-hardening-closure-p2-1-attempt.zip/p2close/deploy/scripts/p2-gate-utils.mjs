import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
export const root=process.cwd(); export const artifacts=resolve(root,'artifacts'); mkdirSync(artifacts,{recursive:true});
export function readJson(p){try{return JSON.parse(readFileSync(resolve(root,p),'utf8'))}catch{return null}}
export function accepted(p){const x=readJson(p); return !!x && (x.accepted===true || x.passed===true || x.status==='PASS' || x.status==='passed')}
export function save(name,obj){writeFileSync(resolve(artifacts,name),JSON.stringify(obj,null,2)+'\n',{mode:0o600})}
export function run(name,cmd,args=[],timeout=1800000){const startedAt=new Date().toISOString();const r=spawnSync(cmd,args,{cwd:root,env:process.env,encoding:'utf8',timeout});return {name,executed:true,passed:!r.error&&r.status===0,exitCode:r.status,startedAt,completedAt:new Date().toISOString(),stdout:(r.stdout||'').slice(-12000),stderr:(r.stderr||'').slice(-12000),error:r.error?.message||null}}
export function blocked(stage,out,prereqs){const missing=Object.entries(prereqs).filter(([,p])=>!accepted(p)).map(([k])=>k); if(!missing.length)return null; const report={format:`tareeq-${stage.toLowerCase()}-v1`,stage,status:'BLOCKED_BY_PREREQUISITE',accepted:false,generatedAt:new Date().toISOString(),prerequisites:Object.fromEntries(Object.entries(prereqs).map(([k,p])=>[k,{path:p,accepted:accepted(p)}])),blockedBy:missing};save(out,report);return report}
