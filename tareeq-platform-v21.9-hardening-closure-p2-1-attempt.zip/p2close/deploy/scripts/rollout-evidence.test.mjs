import test from "node:test";
import assert from "node:assert/strict";
import {
  fingerprint,
  assertStateBoundGate,
  currentSamples,
  requireFunctionalRollback,
} from "./rollout-evidence.mjs";
const now = Date.parse("2026-09-23T12:00:00Z");
function setup() {
  const routing = "test-routing";
  const state = {
    percent: 1,
    changedAt: new Date(now - 86400000).toISOString(),
    stableImage: "stable-a",
    candidateImage: "candidate-a",
    routingFingerprint: fingerprint(routing),
  };
  const gate = {
    checkedAt: new Date(now).toISOString(),
    previousPercent: 1,
    targetPercent: 5,
    stableImage: "stable-a",
    stateFingerprint: fingerprint(state),
  };
  return { state, gate, routing };
}
test("promotion accepts only the exact evaluated state and image pair", () => {
  const { state, gate, routing } = setup();
  assert.doesNotThrow(() =>
    assertStateBoundGate(gate, state, "stable-a", "candidate-a", routing, now),
  );
  assert.throws(() => assertStateBoundGate(gate, state, "stable-b", "candidate-a", routing, now));
  assert.throws(() => assertStateBoundGate(gate, state, "stable-a", "candidate-b", routing, now));
  assert.throws(() =>
    assertStateBoundGate(gate, state, "stable-a", "candidate-a", "changed-routing", now),
  );
});
test("previously passing gate cannot skip stages or be replayed after rollback", () => {
  const { state, gate, routing } = setup();
  assert.throws(() =>
    assertStateBoundGate(
      { ...gate, targetPercent: 25 },
      state,
      "stable-a",
      "candidate-a",
      routing,
      now,
    ),
  );
  assert.throws(() =>
    assertStateBoundGate(
      gate,
      { ...state, percent: 0, changedAt: new Date(now).toISOString() },
      "stable-a",
      "candidate-a",
      routing,
      now,
    ),
  );
});
test("monitoring removes duplicate, overlapping, stale and wrong-image windows", () => {
  const { state } = setup();
  const sample = (start, end, overrides = {}) => ({
    stateFingerprint: fingerprint(state),
    candidateImage: "candidate-a",
    windowStart: new Date(now - start).toISOString(),
    at: new Date(now - end).toISOString(),
    ...overrides,
  });
  const a = sample(360000, 240000),
    b = sample(240000, 120000);
  const selected = currentSamples(
    [
      a,
      a,
      sample(300000, 180000),
      b,
      sample(120000, 0, { candidateImage: "other" }),
      sample(7200000, 7080000),
    ],
    state,
    "candidate-a",
    now,
  );
  assert.deepEqual(selected, [a, b]);
});
test("monitoring from an earlier state or future timestamps cannot count", () => {
  const { state } = setup();
  assert.deepEqual(
    currentSamples(
      [
        {
          stateFingerprint: "old",
          candidateImage: "candidate-a",
          windowStart: new Date(now - 1000).toISOString(),
          at: new Date(now).toISOString(),
        },
        {
          stateFingerprint: fingerprint(state),
          candidateImage: "candidate-a",
          windowStart: new Date(now).toISOString(),
          at: new Date(now + 1000).toISOString(),
        },
      ],
      state,
      "candidate-a",
      now,
    ),
    [],
  );
});
test("HTTP-only rollback report cannot authorize expansion", () => {
  const report = {
    passed: true,
    startedAt: new Date(now).toISOString(),
    stableImage: "stable-a",
    candidateImage: "candidate-a",
    migrationFingerprint: "ledger",
    elapsedSeconds: 0,
    rtoTargetSeconds: 300,
  };
  assert.throws(() => requireFunctionalRollback(report, "stable-a", "candidate-a", "ledger", now));
  report.functionalChecks = {
    search: true,
    planner: true,
    auth: true,
    writeReadback: true,
    cleanup: true,
  };
  assert.doesNotThrow(() =>
    requireFunctionalRollback(report, "stable-a", "candidate-a", "ledger", now),
  );
  assert.throws(() =>
    requireFunctionalRollback(report, "stable-a", "candidate-a", "new-ledger", now),
  );
  assert.throws(() =>
    requireFunctionalRollback(report, "other-stable", "candidate-a", "ledger", now),
  );
  assert.throws(() =>
    requireFunctionalRollback(
      { ...report, functionalChecks: { ...report.functionalChecks, cleanup: false } },
      "stable-a",
      "candidate-a",
      "ledger",
      now,
    ),
  );
});
