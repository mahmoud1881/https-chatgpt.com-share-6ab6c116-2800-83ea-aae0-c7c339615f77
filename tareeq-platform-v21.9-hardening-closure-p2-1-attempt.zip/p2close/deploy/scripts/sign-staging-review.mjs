// Run on the reviewer's machine after inspecting the evidence, never on the staging host.
import { readFileSync, writeFileSync } from "node:fs";
import { createPrivateKey, sign } from "node:crypto";
const [manifest, privateKey] = process.argv.slice(2);
if (!manifest || !privateKey)
  throw Error("Usage: node sign-staging-review.mjs <manifest.json> <reviewer-private-key.pem>");
const key = createPrivateKey(readFileSync(privateKey));
if (key.asymmetricKeyType !== "ed25519") throw Error("Ed25519 reviewer key required");
writeFileSync(`${manifest}.sig`, sign(null, readFileSync(manifest), key), { mode: 0o600 });
console.log("Review signature written; private key was not copied or logged.");
