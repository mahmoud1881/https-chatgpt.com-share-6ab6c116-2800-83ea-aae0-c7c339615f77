import { spawnSync } from "node:child_process";
import { existsSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
export const BINDING_PHASES = [
  "before-deployment-tests",
  "after-deployment-tests",
  "before-telemetry-end-to-end",
  "after-telemetry-end-to-end",
  "before-runtime-chaos-recovery",
  "after-runtime-chaos-recovery",
  "before-stateful-disaster-recovery",
  "after-stateful-disaster-recovery",
  "before-signing",
];
export const COMPOSE_ARGS = [
  "compose",
  "--project-directory",
  "deploy",
  "-p",
  "platform",
  "-f",
  "deploy/docker-compose.yml",
  "--profile",
  "canary",
];
export function immutableRelease(env = process.env) {
  const ref = env.RELEASE_IMAGE_REF,
    digest = env.RELEASE_IMAGE_DIGEST;
  if (
    typeof ref !== "string" ||
    !/^([a-z0-9]+(?:[._-][a-z0-9]+)*(?::[0-9]+)?\/)[a-z0-9._/-]+$/.test(ref) ||
    ref.includes("..") ||
    ref.endsWith("/")
  )
    throw Error("RELEASE_IMAGE_REF must be an untagged registry/repository");
  if (!/^sha256:[a-f0-9]{64}$/.test(digest || "")) throw Error("immutable SHA256 digest required");
  const immutable = `${ref}@${digest}`;
  for (const name of ["NEW_RELEASE", "CANDIDATE_APP_IMAGE"])
    if (env[name] && env[name] !== immutable)
      throw Error(`${name} differs from certified immutable image`);
  return immutable;
}
export function docker(args) {
  const r = spawnSync("docker", args, { encoding: "utf8", timeout: 120000 });
  if (r.error || r.status !== 0)
    throw Error(`Docker identity command failed: ${r.error?.message || r.stderr || r.status}`);
  return r.stdout.trim();
}
export function inspectCandidate(env = process.env, run = docker) {
  const ref = immutableRelease(env);
  const ids = run([...COMPOSE_ARGS, "ps", "-q", "candidate"])
    .split(/\s+/)
    .filter(Boolean);
  if (ids.length !== 1) throw Error("expected exactly one candidate container");
  const images = JSON.parse(run(["image", "inspect", ref]));
  const containers = JSON.parse(run(["container", "inspect", ids[0]]));
  if (images.length !== 1 || containers.length !== 1) throw Error("ambiguous Docker identity");
  const image = images[0],
    c = containers[0];
  if (!/^sha256:[a-f0-9]{64}$/.test(image.Id || "") || !image.RepoDigests?.includes(ref))
    throw Error("local image is not bound to certified repository digest");
  if (c.Config?.Image !== ref || c.Image !== image.Id)
    throw Error("actual container image differs from certified image");
  if (
    !c.State?.Running ||
    c.Config?.Labels?.["com.docker.compose.project"] !== "platform" ||
    c.Config?.Labels?.["com.docker.compose.service"] !== "candidate"
  )
    throw Error("candidate runtime identity or state mismatch");
  if (!/^[a-f0-9]{64}$/.test(c.Id || "") || c.Id !== ids[0]) throw Error("invalid container ID");
  if (c.Mounts?.length) throw Error("candidate filesystem mounts can override certified image");
  return {
    immutableRef: ref,
    imageId: image.Id,
    containerId: c.Id,
    observedAt: new Date().toISOString(),
  };
}
export function checkpoint(
  phase,
  {
    env = process.env,
    run = docker,
    path = "artifacts/runtime-image-binding.json",
    reset = false,
  } = {},
) {
  if (!BINDING_PHASES.includes(phase)) throw Error("unknown identity checkpoint");
  const sample = { phase, ...inspectCandidate(env, run) };
  let report =
    !reset && existsSync(path)
      ? JSON.parse(readFileSync(path, "utf8"))
      : {
          format: "tareeq-runtime-image-binding-v1",
          runId: env.CERTIFICATION_RUN_ID,
          gitCommit: env.RELEASE_COMMIT,
          samples: [],
          passed: false,
        };
  if (
    !report.runId ||
    report.runId !== env.CERTIFICATION_RUN_ID ||
    report.gitCommit !== env.RELEASE_COMMIT
  )
    throw Error("identity report belongs to a different certification run");
  if (phase !== BINDING_PHASES[report.samples.length])
    throw Error("missing or duplicate identity checkpoint");
  const first = report.samples[0];
  if (first && ["immutableRef", "imageId", "containerId"].some((k) => sample[k] !== first[k]))
    throw Error("candidate replaced during certification; rerun all tests");
  report.samples.push(sample);
  report.completedAt = sample.observedAt;
  report.passed = phase === "before-signing";
  mkdirSync("artifacts", { recursive: true });
  writeFileSync(path, JSON.stringify(report, null, 2) + "\n", { mode: 0o600 });
  return report;
}
