import { immutableRelease } from "./runtime-image-binding.mjs";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd(),
  art = resolve(root, "artifacts");
mkdirSync(art, { recursive: true });
const imageRef = process.env.RELEASE_IMAGE_REF || "";
const expectedDigest = process.env.RELEASE_IMAGE_DIGEST || "";
const commit = process.env.RELEASE_COMMIT || "";
const cosignKey = process.env.COSIGN_PRIVATE_KEY_FILE || "";
const cosignPub = process.env.COSIGN_PUBLIC_KEY_FILE || "";
const vulnSeverity = (process.env.SUPPLY_CHAIN_VULN_FAIL_SEVERITY || "high").toLowerCase();
const report = {
  format: "tareeq-v21.9-supply-chain-attestation-v1",
  startedAt: new Date().toISOString(),
  image: { ref: imageRef, expectedDigest },
  gitCommit: commit,
  checks: [],
  artifacts: {},
  passed: false,
};
const out = resolve(art, "supply-chain-attestation.json");
function fail(m) {
  throw new Error(m);
}
function cmdExists(c) {
  return spawnSync(c, ["--version"], { encoding: "utf8" }).status === 0;
}
function run(name, cmd, args, { capture = false, env = process.env } = {}) {
  const r = spawnSync(cmd, args, {
    cwd: root,
    encoding: capture ? "utf8" : undefined,
    stdio: capture ? ["ignore", "pipe", "pipe"] : "inherit",
    env,
    timeout: Number(process.env.SUPPLY_CHAIN_TIMEOUT_MS || 1200000),
  });
  report.checks.push({ name, exitCode: r.status, passed: !r.error && r.status === 0 });
  if (r.error || r.status !== 0)
    fail(
      `${name} failed (${r.status ?? r.error?.message})${capture && r.stderr ? `: ${r.stderr.trim()}` : ""}`,
    );
  return capture ? r.stdout.trim() : "";
}
const sha = (p) => createHash("sha256").update(readFileSync(p)).digest("hex");
function evidence(label, p) {
  if (!existsSync(p)) fail(`${label} missing: ${p}`);
  report.artifacts[label] = {
    path: p.replace(root + "/", ""),
    sha256: sha(p),
    bytes: readFileSync(p).length,
  };
}
try {
  const immutable = immutableRelease();
  if (!/^[a-f0-9]{40}$/i.test(commit)) fail("RELEASE_COMMIT must be a full Git SHA");
  if (!imageRef || imageRef.includes("@sha256:"))
    fail(
      "RELEASE_IMAGE_REF must be the registry repository/tag reference without an embedded digest",
    );
  if (!/^sha256:[a-f0-9]{64}$/i.test(expectedDigest))
    fail("RELEASE_IMAGE_DIGEST must be sha256:<64 hex>");
  for (const c of ["syft", "grype", "gitleaks", "cosign", "crane"])
    if (!cmdExists(c)) fail(`${c} is required for v21.9 certification`);
  if (!cosignKey || !existsSync(cosignKey)) fail("COSIGN_PRIVATE_KEY_FILE is required");
  if (!cosignPub || !existsSync(cosignPub)) fail("COSIGN_PUBLIC_KEY_FILE is required");
  const head = run("git-commit-identity", "git", ["rev-parse", "HEAD"], { capture: true });
  if (head !== commit) fail(`checked-out commit ${head} != RELEASE_COMMIT ${commit}`);
  const published = run("published-image-digest", "crane", ["digest", immutable], {
    capture: true,
  });
  if (published !== expectedDigest)
    fail(`published image digest ${published} != certified digest ${expectedDigest}`);
  report.image.publishedDigest = published;
  const sbomSpdx = resolve(art, "release-sbom.spdx.json"),
    sbomCdx = resolve(art, "release-sbom.cyclonedx.json");
  run("sbom-spdx", "syft", [immutable, "-o", `spdx-json=${sbomSpdx}`]);
  run("sbom-cyclonedx", "syft", [immutable, "-o", `cyclonedx-json=${sbomCdx}`]);
  evidence("sbomSpdx", sbomSpdx);
  evidence("sbomCycloneDx", sbomCdx);
  run("dependency-vulnerability-scan", "grype", [`sbom:${sbomCdx}`, "--fail-on", vulnSeverity]);
  run("secret-scan", "gitleaks", [
    "detect",
    "--source",
    ".",
    "--no-banner",
    "--redact",
    "--exit-code",
    "1",
  ]);
  run("oci-image-sign", "cosign", ["sign", "--yes", "--key", cosignKey, immutable]);
  run("oci-image-signature-verify", "cosign", ["verify", "--key", cosignPub, immutable]);
  const predicate = resolve(art, "release-provenance.json");
  const provenance = {
    _type: "https://in-toto.io/Statement/v1",
    subject: [{ name: imageRef, digest: { sha256: expectedDigest.slice(7) } }],
    predicateType: "https://slsa.dev/provenance/v1",
    predicate: {
      buildDefinition: {
        buildType: "https://tareeq.example/build/v21.9",
        externalParameters: { gitCommit: commit },
        resolvedDependencies: [
          {
            uri: `git+${process.env.RELEASE_REPOSITORY_URL || "unknown"}@${commit}`,
            digest: { sha1: commit },
          },
          { uri: "sbom:spdx", digest: { sha256: sha(sbomSpdx) } },
          { uri: "sbom:cyclonedx", digest: { sha256: sha(sbomCdx) } },
        ],
      },
      runDetails: {
        builder: { id: process.env.RELEASE_BUILDER_ID || "tareeq-release-pipeline" },
        metadata: {
          invocationId: process.env.RELEASE_BUILD_ID || "",
          startedOn: report.startedAt,
          finishedOn: new Date().toISOString(),
        },
      },
    },
  };
  writeFileSync(predicate, JSON.stringify(provenance, null, 2) + "\n");
  evidence("provenance", predicate);
  run("oci-provenance-attest", "cosign", [
    "attest",
    "--yes",
    "--key",
    cosignKey,
    "--type",
    "slsaprovenance",
    "--predicate",
    predicate,
    immutable,
  ]);
  run("oci-provenance-verify", "cosign", [
    "verify-attestation",
    "--key",
    cosignPub,
    "--type",
    "slsaprovenance",
    immutable,
  ]);
  report.completedAt = new Date().toISOString();
  report.passed = true;
  report.status = "passed";
  writeFileSync(out, JSON.stringify(report, null, 2) + "\n", { mode: 0o600 });
  console.log(`✅ v21.9 supply-chain attestation PASS — ${immutable}`);
} catch (e) {
  report.completedAt = new Date().toISOString();
  report.status = "failed";
  report.error = e instanceof Error ? e.message : String(e);
  writeFileSync(out, JSON.stringify(report, null, 2) + "\n", { mode: 0o600 });
  console.error(`❌ v21.9 supply-chain attestation FAIL — ${report.error}`);
  process.exit(1);
}
