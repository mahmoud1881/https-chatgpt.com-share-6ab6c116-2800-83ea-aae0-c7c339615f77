// Visible failure/empty-state containers are not successful journeys.
export function requireJourneySuccess(status, count) {
  if (status !== "success" || !/^\d+$/.test(String(count)) || Number(count) < 1) {
    throw new Error("Journey returned no usable route or an error");
  }
}
export async function assertJourneyResult(page, kind, timeout) {
  const result = page.locator(`[data-load-result="${kind}"]`);
  await result.waitFor({ state: "visible", timeout });
  requireJourneySuccess(
    await result.getAttribute("data-load-status"),
    await result.getAttribute("data-load-route-count"),
  );
}
