#!/usr/bin/env bash
# Create a persistent, locally verified full backup suitable for DR certification.
set -euo pipefail
umask 077
cd "$(dirname "$0")/.."

for binary in docker sha256sum openssl; do
  command -v "$binary" >/dev/null || { echo "Missing required binary: $binary" >&2; exit 2; }
done
[[ -s .env ]] || { echo 'Missing deploy/.env; populate it from .env.example with real runtime secrets.' >&2; exit 2; }

docker compose exec -T db pg_isready -U postgres -d postgres >/dev/null
mkdir -p backups/dr
stamp="$(date -u +%Y%m%dT%H%M%SZ)-$(openssl rand -hex 3)"
pending="backups/dr/.pending-$stamp"
final="backups/dr/$stamp"
mkdir "$pending"
cleanup() { [[ -d "$pending" ]] && rm -rf -- "$pending"; }
trap cleanup EXIT INT TERM

bash scripts/backup-database.sh "$pending"
required=(db.dump db-roles.sql db-role-names.txt db-metrics.txt recovery-point.json source-schema-fingerprint.json source-content-fingerprint.json)
for f in "${required[@]}"; do [[ -s "$pending/$f" ]] || { echo "Backup artifact missing/empty: $f" >&2; exit 1; }; done
(
  cd "$pending"
  sha256sum "${required[@]}" > SHA256SUMS
  sha256sum -c SHA256SUMS
)
mv -- "$pending" "$final"
trap - EXIT INT TERM
printf '%s\n' "$(cd "$final" && pwd)"
