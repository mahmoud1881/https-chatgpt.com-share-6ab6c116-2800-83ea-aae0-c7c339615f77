import { spawnSync } from 'node:child_process';
const run=(name,args)=>{console.log(`\n=== ${name} ===`);const r=spawnSync('node',args,{stdio:'inherit',env:process.env,timeout:Number(process.env.PRODUCTION_E2E_TIMEOUT_MS||7200000)});if(r.error||r.status!==0){console.error(`❌ ${name} failed; certification stopped.`);process.exit(r.status||1);}};
run('Production preflight',['deploy/scripts/production-preflight.mjs']);
run('Full signed production certification',['deploy/scripts/full-production-certification.mjs']);
run('Offline signed certificate verification',['deploy/scripts/verify-production-certification.mjs']);
console.log('\n✅ End-to-end production certification completed and verified.');
