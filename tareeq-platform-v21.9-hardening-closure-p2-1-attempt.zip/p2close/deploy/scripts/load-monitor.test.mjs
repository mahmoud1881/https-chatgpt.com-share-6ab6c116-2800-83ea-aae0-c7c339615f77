import { test } from "node:test";
import assert from "node:assert/strict";
import { summarizeLoad, assertWrittenRoute } from "./load-metrics.mjs";
import { incidentState, parsePostgresCounters, requireCounters } from "./monitor-validation.mjs";
import { fingerprint } from "./rollout-evidence.mjs";

const records = () =>
  ["search", "planner", "write"].flatMap((scenario) =>
    Array.from({ length: 100 }, () => ({ scenario, ok: true, ms: 100 })),
  );
test("load requires the full planned sample for every scenario", () => {
  assert.equal(summarizeLoad(records(), 1, 100).passed, true);
  assert.equal(summarizeLoad(records().slice(1), 1, 100).passed, false);
  assert.equal(summarizeLoad([], 1, 100).passed, false);
  assert.equal(
    summarizeLoad(
      records().filter((_, i) => i % 100 < 3),
      1,
      3,
    ).passed,
    false,
  );
});
test("one failing scenario cannot be hidden by the global error rate", () => {
  const input = records();
  input[0].ok = input[1].ok = false;
  const summary = summarizeLoad(input, 1, 100);
  assert.ok(summary.errorRate < 0.01);
  assert.equal(summary.scenarios.search.errorRate, 0.02);
  assert.equal(summary.passed, false);
});
test("p95 includes failed request durations and rejects invalid measurements", () => {
  const input = records();
  for (let i = 0; i < 6; i++) Object.assign(input[i], { ok: false, ms: 15000 });
  assert.equal(summarizeLoad(input, 1, 100).scenarios.search.p95Ms, 15000);
  for (const ms of [NaN, Infinity, -1]) {
    const bad = records();
    bad[0].ms = ms;
    assert.equal(summarizeLoad(bad, 1, 100).passed, false);
  }
});
test("write success requires matching owner, status, votes and identity on readback", () => {
  const expected = { id: "x", user_id: "u", title: "probe", status: "pending", confirmations: 0 };
  assert.doesNotThrow(() => assertWrittenRoute([expected], expected));
  for (const rows of [
    [],
    [expected, expected],
    [{ ...expected, user_id: "other" }],
    [{ ...expected, status: "approved" }],
    [{ ...expected, confirmations: 1 }],
  ])
    assert.throws(() => assertWrittenRoute(rows, expected));
});
test("invalid monitoring metrics cannot masquerade as healthy zero values", () => {
  assert.deepEqual(parsePostgresCounters("10|100|2|0|0"), [10, 100, 2, 0, 0]);
  for (const line of [
    "",
    "10|0|2|0|0",
    "10|100||0|0",
    "10|100|2|0",
    "NaN|100|2|0|0",
    "-1|100|2|0|0",
  ])
    assert.throws(() => parsePostgresCounters(line));
  assert.throws(() => requireCounters([NaN]));
  assert.throws(() => requireCounters([-1]));
});
test("new incidents and stale observations reset notification suppression", () => {
  const now = Date.parse("2026-09-24T12:00:00Z");
  const first = incidentState(["db"], {}, now, fingerprint);
  const previous = { ...first, at: new Date(now).toISOString(), notified: true };
  const continued = incidentState(["db"], previous, now + 120000, fingerprint);
  assert.equal(continued.consecutive, 2);
  assert.equal(continued.notified, true);
  const changed = incidentState(["db", "mail"], previous, now + 120000, fingerprint);
  assert.equal(changed.consecutive, 1);
  assert.equal(changed.notified, false);
  const next = incidentState(
    ["mail", "db"],
    { ...changed, at: new Date(now + 120000).toISOString() },
    now + 240000,
    fingerprint,
  );
  assert.equal(next.consecutive, 2);
  assert.equal(next.notified, false);
  assert.equal(incidentState(["db"], previous, now + 600000, fingerprint).notified, false);
  assert.equal(incidentState([], previous, now + 120000, fingerprint).consecutive, 0);
});
