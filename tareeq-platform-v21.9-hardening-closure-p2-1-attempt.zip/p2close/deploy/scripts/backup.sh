#!/usr/bin/env bash
# Encrypt a full Postgres/config backup and keep the verified copy on another host.
set -euo pipefail
cd "$(dirname "$0")/.."
umask 077

: "${BACKUP_SSH_TARGET:?Set BACKUP_SSH_TARGET (user@independent-host)}"
: "${BACKUP_REMOTE_DIR:?Set BACKUP_REMOTE_DIR (/srv/tareeq-backups)}"
: "${BACKUP_AGE_RECIPIENT:?Set BACKUP_AGE_RECIPIENT (age1... public key)}"
[[ "$BACKUP_SSH_TARGET" =~ ^[a-zA-Z0-9_-]+@[a-zA-Z0-9._-]+$ ]] || { echo 'Invalid SSH target' >&2; exit 2; }
[[ "$BACKUP_REMOTE_DIR" =~ ^/[a-zA-Z0-9._/-]+$ && "$BACKUP_REMOTE_DIR" != *..* ]] || {
  echo 'Invalid remote directory' >&2; exit 2;
}
[[ "$BACKUP_AGE_RECIPIENT" == age1* ]] || { echo 'Expected an age recipient' >&2; exit 2; }
for binary in docker age ssh scp sha256sum tar openssl; do command -v "$binary" >/dev/null || {
  echo "Missing $binary" >&2; exit 2;
}; done
[[ -s .env ]] || { echo 'Missing deploy/.env' >&2; exit 2; }

mkdir -p backups
tmp=$(mktemp -d backups/.pending.XXXXXXXX)
trap 'rm -rf -- "$tmp"' EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
stamp="$(date -u +%Y%m%dT%H%M%SZ)-$(openssl rand -hex 3)"
echo '▶ Dumping database and deployment configuration…'
tar -czf "$tmp/deploy-config.tar.gz" .env docker-compose.yml caddy scripts supabase
tar -C .. --exclude=./deploy/backups --exclude=./node_modules --exclude=./dist \
  --exclude=./.git -czf "$tmp/source-tree.tar.gz" .
docker compose exec -T db pg_isready -U postgres -d postgres >/dev/null
bash scripts/backup-database.sh "$tmp"
# A deployment/config edit during capture must not produce a mixed archive.
# Freeze deployments and role administration for the backup window.
tar -dzf "$tmp/deploy-config.tar.gz" >/dev/null
tar -C .. -dzf "$tmp/source-tree.tar.gz" >/dev/null
[[ -s "$tmp/db.dump" && -s "$tmp/db-roles.sql" && -s "$tmp/db-role-names.txt" && -s "$tmp/db-metrics.txt" && -s "$tmp/source-tree.tar.gz" ]] || {
  echo 'Dump or manifest is empty' >&2; exit 1;
}
(cd "$tmp" && sha256sum db.dump db-roles.sql db-role-names.txt deploy-config.tar.gz source-tree.tar.gz db-metrics.txt recovery-point.json source-schema-fingerprint.json source-content-fingerprint.json > SHA256SUMS)
tar -C "$tmp" -czf - db.dump db-roles.sql db-role-names.txt deploy-config.tar.gz source-tree.tar.gz db-metrics.txt recovery-point.json source-schema-fingerprint.json source-content-fingerprint.json SHA256SUMS \
  | age -r "$BACKUP_AGE_RECIPIENT" -o "$tmp/backup.tar.age"
[[ -s "$tmp/backup.tar.age" ]] || { echo 'Encrypted archive is empty' >&2; exit 1; }
(cd "$tmp" && sha256sum backup.tar.age > SHA256SUMS.encrypted)

remote="$BACKUP_REMOTE_DIR/$stamp"
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes "$BACKUP_SSH_TARGET" "mkdir -p -- '$remote.pending'"
scp -q -o BatchMode=yes -o StrictHostKeyChecking=yes "$tmp/backup.tar.age" "$tmp/SHA256SUMS.encrypted" \
  "$BACKUP_SSH_TARGET:$remote.pending/"
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes "$BACKUP_SSH_TARGET" \
  "cd '$remote.pending' && sha256sum -c SHA256SUMS.encrypted && test ! -e '$remote' && mv -- '$remote.pending' '$remote'"
echo "✅ Verified encrypted offsite backup: $BACKUP_SSH_TARGET:$remote"
