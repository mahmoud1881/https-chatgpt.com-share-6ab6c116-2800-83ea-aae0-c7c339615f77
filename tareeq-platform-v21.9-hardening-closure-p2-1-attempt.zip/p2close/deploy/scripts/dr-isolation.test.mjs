import test from "node:test";
import assert from "node:assert/strict";
import { createSandbox, isolationGuard, OWNER_LABEL } from "./dr-isolation.mjs";

function fixture() {
  const sandbox = createSandbox(
    {
      services: {
        db: {
          image: "postgres:15",
          privileged: true,
          ports: ["5432:5432"],
          volumes: ["/host:/host"],
          network_mode: "host",
          environment: { PASSWORD: "production" },
        },
      },
    },
    {},
  );
  const calls = [];
  const resources = { container: [], volume: [], network: [] };
  let failRemove = false,
    failList = false;
  function docker(args) {
    calls.push(args);
    const kind = args[0] === "ps" ? "container" : args[0];
    if (args.includes("inspect")) {
      const id = args.at(-1);
      const r = resources[kind].find((r) => r.id === id);
      if (!r) throw Error("missing resource");
      return JSON.stringify([
        kind === "container"
          ? {
              Config: { Labels: r.labels },
              HostConfig: { NetworkMode: "none", PortBindings: {} },
              Mounts: [{ Type: "volume", Name: sandbox.volume }],
              ...r.extra,
            }
          : { Labels: r.labels },
      ]);
    }
    if (args.includes("rm")) {
      if (failRemove) throw Error("removal failed");
      resources[kind] = resources[kind].filter((r) => r.id !== args.at(-1));
      return "";
    }
    if (failList) throw Error("daemon unavailable");
    const filters = args.flatMap((a, i) =>
      a === "--filter" ? [args[i + 1].slice(6).split("=")] : [],
    );
    return resources[kind]
      .filter((r) => filters.every(([k, v]) => r.labels[k] === v))
      .map((r) => r.id)
      .join("\n");
  }
  const labels = { [OWNER_LABEL]: sandbox.token, "com.docker.compose.project": sandbox.project };
  return {
    sandbox,
    calls,
    resources,
    guard: isolationGuard(sandbox, docker),
    labels,
    failRemove() {
      failRemove = true;
    },
    failList() {
      failList = true;
    },
  };
}

test("sandbox discards all production settings except the image", () => {
  const { sandbox } = fixture();
  const db = sandbox.config.services.db;
  assert.equal(db.network_mode, "none");
  assert.equal(db.privileged, undefined);
  assert.equal(db.ports, undefined);
  assert.equal(db.volumes.length, 1);
  assert.equal(db.volumes[0].type, "volume");
  assert.equal(db.environment.PASSWORD, undefined);
  assert.equal(sandbox.config.networks, undefined);
  assert.deepEqual(Object.keys(sandbox.config.services), ["db"]);
});
for (const name of [
  "DR_PROJECT_NAME",
  "DR_RESTORED_DATABASE_URL",
  "DR_TRAFFIC_STATE_FILE",
  "DR_KEEP_ISOLATED_ENV",
  "DR_SKIP_TELEMETRY_CERTIFICATION",
]) {
  test(`rejects ${name} override`, () =>
    assert.throws(
      () => createSandbox({ services: { db: { image: "postgres:15" } } }, { [name]: "production" }),
      /not supported/,
    ));
}
test("generates distinct ownership for simultaneous runs", () => {
  const a = fixture().sandbox,
    b = fixture().sandbox;
  assert.notEqual(a.project, b.project);
  assert.notEqual(a.token, b.token);
  assert.notEqual(a.volume, b.volume);
});
for (const kind of ["container", "volume", "network"]) {
  test(`rejects existing ${kind}, without cleanup`, () => {
    const f = fixture();
    f.resources[kind].push({
      id: "existing",
      labels: { "com.docker.compose.project": f.sandbox.project },
    });
    assert.throws(() => f.guard.begin(), /already has/);
    assert.equal(f.guard.cleanup().attempted, false);
    assert.ok(!f.calls.some((a) => a.includes("rm")));
  });
}
test("rejects unlabelled volume name collision", () => {
  const f = fixture();
  f.resources.volume.push({ id: f.sandbox.volume, labels: {} });
  assert.throws(() => f.guard.begin(), /already exists/);
  assert.equal(f.guard.cleanup().attempted, false);
});
test("daemon inspection failure is not interpreted as an empty project", () => {
  const f = fixture();
  f.failList();
  assert.throws(() => f.guard.begin(), /unavailable/);
  assert.equal(f.guard.cleanup().attempted, false);
});
test("partial startup cleans only both-label resources; excludes foreign resources", () => {
  const f = fixture();
  f.guard.begin();
  f.resources.container.push(
    { id: "created", labels: f.labels },
    { id: "foreign", labels: { "com.docker.compose.project": f.sandbox.project } },
  );
  f.resources.volume.push({ id: f.sandbox.volume, labels: f.labels });
  const r = f.guard.cleanup();
  assert.equal(r.errors.length, 0);
  assert.equal(r.removed.length, 2);
  assert.deepEqual(
    f.resources.container.map((r) => r.id),
    ["foreign"],
  );
  assert.ok(!f.calls.some((a) => a.includes("down") || a.includes("--remove-orphans")));
});
test("label change between inventory and deletion prevents removal", () => {
  const f = fixture();
  f.guard.begin();
  const docker = (args) =>
    args.includes("inspect")
      ? JSON.stringify([{ Config: { Labels: {} } }])
      : args[0] === "ps"
        ? "foreign"
        : "";
  // Separate preflight/cleanup implementation to simulate a concurrent label change.
  let started = false;
  const g = isolationGuard(f.sandbox, (args) => {
    if (args.includes("inspect")) return docker(args);
    if (args.includes("rm")) assert.fail("must not remove foreign container");
    return started && args[0] === "ps" ? "foreign" : "";
  });
  g.begin();
  started = true;
  assert.match(g.cleanup().errors[0], /foreign/);
});
test("cleanup failures are recorded", () => {
  const f = fixture();
  f.guard.begin();
  f.resources.container.push({ id: "created", labels: f.labels });
  f.failRemove();
  assert.match(f.guard.cleanup().errors[0], /removal failed/);
});
test("verifies actual container isolation before restoring", () => {
  const f = fixture();
  f.guard.begin();
  f.resources.container.push({ id: "db", labels: f.labels });
  f.resources.volume.push({ id: f.sandbox.volume, labels: f.labels });
  assert.equal(f.guard.verifyDatabase(), "db");
  f.resources.container[0].extra = { HostConfig: { NetworkMode: "host" } };
  assert.throws(() => f.guard.verifyDatabase(), /isolation/);
});
test("refuses bind mount in actual container even with ownership labels", () => {
  const f = fixture();
  f.guard.begin();
  f.resources.container.push({
    id: "db",
    labels: f.labels,
    extra: { Mounts: [{ Type: "bind", Source: "/production" }] },
  });
  assert.throws(() => f.guard.verifyDatabase(), /mount/);
});

import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, existsSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { spawnSync } from "node:child_process";
const certification = resolve("deploy/scripts/disaster-recovery-certification.mjs");

test("main script rejects supplied project before any Docker command", () => {
  const dir = mkdtempSync(join(tmpdir(), "dr-main-test-"));
  try {
    const result = spawnSync(process.execPath, [certification], {
      cwd: dir,
      env: { PATH: "", DR_PROJECT_NAME: "platform" },
      encoding: "utf8",
    });
    assert.equal(result.status, 1);
    const report = JSON.parse(
      readFileSync(join(dir, "artifacts/disaster-recovery-certification.json"), "utf8"),
    );
    assert.match(report.error, /DR_PROJECT_NAME/);
    assert.equal(report.cleanup.attempted, false);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
test("main script missing backup causes no cleanup", () => {
  const dir = mkdtempSync(join(tmpdir(), "dr-main-test-"));
  try {
    const result = spawnSync(process.execPath, [certification], {
      cwd: dir,
      env: { PATH: "" },
      encoding: "utf8",
    });
    assert.equal(result.status, 1);
    const report = JSON.parse(
      readFileSync(join(dir, "artifacts/disaster-recovery-certification.json"), "utf8"),
    );
    assert.match(report.error, /DR_BACKUP_DIR/);
    assert.equal(report.cleanup.attempted, false);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
test("main script cleans owned volume after partial Compose startup failure", () => {
  const dir = mkdtempSync(join(tmpdir(), "dr-main-test-"));
  try {
    const bin = join(dir, "bin"),
      backup = join(dir, "backup");
    mkdirSync(bin);
    mkdirSync(backup);
    for (const name of [
      "db.dump",
      "db-roles.sql",
      "db-role-names.txt",
      "SHA256SUMS",
      "db-metrics.txt",
    ])
      writeFileSync(join(backup, name), "fixture");
    writeFileSync(join(backup, "recovery-point.json"), JSON.stringify({format:"tareeq-backup-recovery-point-v1",captured_at:"2026-01-01T00:00:00.000Z"}));
    writeFileSync(join(backup, "source-schema-fingerprint.json"), "{}\n");
    writeFileSync(join(backup, "source-content-fingerprint.json"), JSON.stringify({format:"tareeq-db-content-fingerprint-v1",tables:[]}));
    writeFileSync(join(bin, "sha256sum"), "#!/bin/sh\nexit 0\n", { mode: 0o700 });
    writeFileSync(
      join(bin, "docker"),
      `#!${process.execPath}
const fs=require('node:fs');const args=process.argv.slice(2);
fs.appendFileSync('calls.jsonl',JSON.stringify(args)+'\\n');
const state=fs.existsSync('state.json')?JSON.parse(fs.readFileSync('state.json')):null;
if(args.includes('config'))console.log(JSON.stringify({services:{db:{image:'postgres:15'}}}));
else if(args.includes('up')){const config=JSON.parse(fs.readFileSync(args[args.indexOf('-f')+1]));fs.writeFileSync('state.json',JSON.stringify(config));process.exit(42);}
else if(args[0]==='volume'&&args.includes('ls')&&state)console.log(state.volumes.db_data.name);
else if(args.includes('inspect')&&state)console.log(JSON.stringify([{Labels:{...state.volumes.db_data.labels,'com.docker.compose.project':state.name}}]));
else if(args.includes('rm'))fs.writeFileSync('removed','yes');
`,
      { mode: 0o700 },
    );
    const result = spawnSync(process.execPath, [certification], {
      cwd: dir,
      env: { PATH: bin, DR_BACKUP_DIR: backup, DR_DISASTER_AT: "2026-01-01T00:00:01.000Z" },
      encoding: "utf8",
    });
    assert.equal(result.status, 1);
    const report = JSON.parse(
      readFileSync(join(dir, "artifacts/disaster-recovery-certification.json"), "utf8"),
    );
    assert.match(report.error, /exited 42/);
    assert.equal(report.cleanup.attempted, true);
    assert.equal(report.cleanup.errors.length, 0);
    assert.equal(report.cleanup.removed.length, 1);
    assert.equal(existsSync(join(dir, "removed")), true);
    const calls = readFileSync(join(dir, "calls.jsonl"), "utf8");
    assert.ok(!calls.includes("down"));
    assert.ok(!calls.includes("restore-old-traffic"));
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
