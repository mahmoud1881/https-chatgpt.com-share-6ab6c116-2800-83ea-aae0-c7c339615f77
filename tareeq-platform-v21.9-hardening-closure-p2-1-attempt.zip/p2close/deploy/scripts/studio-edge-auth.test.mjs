import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const caddy = readFileSync(new URL("../caddy/Caddyfile", import.meta.url), "utf8");
const compose = readFileSync(new URL("../docker-compose.yml", import.meta.url), "utf8");

test("Studio is authenticated at the public Caddy edge before reverse_proxy", () => {
  const block = caddy.slice(caddy.indexOf("{$STUDIO_DOMAIN}"));
  assert.match(block, /basic_auth\s*\{/);
  assert.match(block, /\{\$STUDIO_BASIC_AUTH_USER\}\s+\{\$STUDIO_BASIC_AUTH_HASH\}/);
  assert.ok(block.indexOf("basic_auth") < block.indexOf("reverse_proxy studio:3000"));
});

test("proxy fails closed when Studio edge credentials are missing", () => {
  assert.match(compose, /STUDIO_BASIC_AUTH_USER: \${STUDIO_BASIC_AUTH_USER:\?[^}]+}/);
  assert.match(compose, /STUDIO_BASIC_AUTH_HASH: \${STUDIO_BASIC_AUTH_HASH:\?[^}]+}/);
});
