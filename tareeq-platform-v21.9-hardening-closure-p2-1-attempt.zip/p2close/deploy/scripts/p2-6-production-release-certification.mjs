import { spawnSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();
const artifacts = resolve(root, "artifacts");
mkdirSync(artifacts, { recursive: true });
const out = resolve(artifacts, "p2-6-production-release-certification.json");
const prerequisites = {
  p2_1: "artifacts/p2-1-build-certification.json",
  p2_2: "artifacts/p2-2-runtime-integration.json",
  p2_3: "artifacts/p2-3-browser-runtime-certification.json",
  p2_4: "artifacts/p2-4-observability-slo-certification.json",
  p2_5: "artifacts/p2-5-chaos-dr-certification.json",
};
const report = {
  format: "tareeq-p2-6-production-release-certification-v1",
  stage: "P2-6",
  status: "RUNNING",
  accepted: false,
  startedAt: new Date().toISOString(),
  release: {
    gitCommit: process.env.RELEASE_COMMIT || null,
    imageDigest: process.env.RELEASE_IMAGE_DIGEST || null,
  },
  prerequisites: {},
  gates: [],
};
const save = () => writeFileSync(out, JSON.stringify(report, null, 2) + "\n", { mode: 0o600 });
function readPass(path) {
  if (!existsSync(path)) return { status: "MISSING", accepted: false };
  try {
    const x = JSON.parse(readFileSync(path, "utf8"));
    const accepted = x.accepted === true || x.passed === true || x.status === "PASS" || x.status === "passed";
    return { status: x.status ?? (accepted ? "PASS" : "NOT_ACCEPTED"), accepted };
  } catch { return { status: "INVALID", accepted: false }; }
}
function run(name, command, args) {
  const startedAt = new Date().toISOString();
  const r = spawnSync(command, args, { cwd: root, env: process.env, stdio: "inherit", timeout: Number(process.env.P2_6_GATE_TIMEOUT_MS || 1800000) });
  const gate = { name, startedAt, completedAt: new Date().toISOString(), exitCode: r.status, passed: !r.error && r.status === 0 };
  report.gates.push(gate); save();
  if (!gate.passed) throw Error(`${name} failed (${r.status ?? r.error?.message})`);
}
try {
  for (const [name, path] of Object.entries(prerequisites)) report.prerequisites[name] = { path, ...readPass(resolve(root, path)) };
  const blocked = Object.entries(report.prerequisites).filter(([, x]) => !x.accepted).map(([k]) => k);
  if (blocked.length) {
    report.status = "BLOCKED_BY_PREREQUISITE";
    report.blockedBy = blocked;
    report.completedAt = new Date().toISOString();
    save();
    console.error(`P2-6 blocked by: ${blocked.join(", ")}`);
    process.exit(75);
  }
  run("production-preflight", "node", ["deploy/scripts/production-preflight.mjs"]);
  run("full-production-certification", "node", ["deploy/scripts/full-production-certification.mjs"]);
  run("verify-production-certification", "node", ["deploy/scripts/verify-production-certification.mjs"]);
  const cert = JSON.parse(readFileSync(resolve(artifacts, "production-certification.json"), "utf8"));
  if (cert.status !== "PRODUCTION CERTIFIED" || cert.passed !== true) throw Error("signed production certificate did not prove PASS");
  const rollout = JSON.parse(readFileSync(resolve(artifacts, "progressive-delivery-evidence.json"), "utf8"));
  if (rollout.status !== "passed" || ![1,5,25,50,100].every((p) => rollout.decisions?.some((d) => d.percent === p && ["promote","complete"].includes(d.decision)))) throw Error("progressive rollout evidence incomplete");
  report.status = "PASS"; report.accepted = true;
  report.evidence = {
    preflight: "artifacts/production-preflight.json",
    signedCertification: "artifacts/production-certification.json",
    signature: "artifacts/production-certification.sig",
    progressiveDelivery: "artifacts/progressive-delivery-evidence.json",
  };
  report.completedAt = new Date().toISOString(); save();
  console.log("P2-6 PASS — production release certified");
} catch (e) {
  report.status = "FAIL"; report.accepted = false; report.error = e instanceof Error ? e.message : String(e); report.completedAt = new Date().toISOString(); save();
  console.error(`P2-6 FAIL — ${report.error}`); process.exit(1);
}
