import test from "node:test";
import assert from "node:assert/strict";
import { requirePromotionLoad, rehearsalBootstrap } from "./promotion-load.mjs";
import { summarizeLoad, loadLimits, scenarios } from "./load-metrics.mjs";
import { requireFunctionalRollback } from "./rollout-evidence.mjs";
import { loadPlan } from "./load-profile.mjs";
const now = Date.parse("2026-09-24T12:00:00Z"),
  revision = "a".repeat(40);
const site = "https://staging.example.com",
  api = "https://api.staging.example.com";
function report() {
  const plan = loadPlan;
  const ids = ["a", "b", "c", "d", "e"];
  return {
    schemaVersion: 2,
    coverage: {
      accountCount: 50,
      journeyIds: ids,
      journeyFingerprint: "f".repeat(64),
      categories: ["direct", "alias", "transfer", "long_distance"],
    },
    passed: true,
    cleanupPassed: true,
    releaseCommit: revision,
    site,
    api,
    startedAt: new Date(now - 600000).toISOString(),
    finishedAt: new Date(now - 1000).toISOString(),
    thresholds: { ...loadLimits },
    plan,
    stages: plan.map(({ users, rounds }) => ({
      ...summarizeLoad(
        scenarios.flatMap((scenario) =>
          Array.from({ length: users * rounds }, () => ({ scenario, ok: true, ms: 100 })),
        ),
        users,
        rounds,
      ),
      elapsedMs: 10000,
      operationsPerSecond: (users * rounds * 3) / 10,
      accountCount: 50,
      journeys: Object.fromEntries(
        ids.map((id) => [
          id,
          {
            search: { total: (users * rounds) / 5, errors: 0 },
            planner: { total: (users * rounds) / 5, errors: 0 },
          },
        ]),
      ),
      cache: {
        cold: { total: users * rounds, errors: 0, p95Ms: 100 },
        warm: { total: users * rounds, errors: 0, p95Ms: 100 },
      },
    })),
  };
}
const check = (r) => requirePromotionLoad(r, revision, site, api, now);
test("complete current load report is accepted", () => assert.doesNotThrow(() => check(report())));
test("wrong release, target, old report and incomplete cleanup are rejected", () => {
  for (const change of [
    { releaseCommit: "b".repeat(40) },
    { site: "https://other.example.com" },
    { cleanupPassed: false },
    { startedAt: new Date(now - 8 * 86400000).toISOString() },
    { finishedAt: new Date(now + 1000).toISOString() },
  ])
    assert.throws(() => check({ ...report(), ...change }));
});
test("passed flag cannot hide weakened limits, missing stages or scenario failures", () => {
  for (const mutate of [
    (r) => r.stages.pop(),
    (r) => (r.thresholds.errorRate = 0.5),
    (r) => (r.stages[0].scenarios.write.errors = 2),
    (r) => (r.stages[0].scenarios.search.p95Ms = 9000),
    (r) => (r.stages[0].scenarios.planner.total = 3),
  ]) {
    const r = report();
    mutate(r);
    assert.throws(() => check(r));
  }
});
test("rollback RTO and timestamp are independently enforced", () => {
  const r = {
    passed: true,
    stableImage: "s",
    candidateImage: "c",
    migrationFingerprint: "m",
    startedAt: new Date(now - 600000).toISOString(),
    elapsedSeconds: 120,
    rtoTargetSeconds: 300,
    functionalChecks: {
      search: true,
      planner: true,
      auth: true,
      writeReadback: true,
      cleanup: true,
    },
  };
  const checkRollback = (x) => requireFunctionalRollback(x, "s", "c", "m", now);
  assert.doesNotThrow(() => checkRollback(r));
  for (const change of [
    { elapsedSeconds: 301 },
    { elapsedSeconds: -1 },
    { elapsedSeconds: undefined },
    { rtoTargetSeconds: 900 },
    { startedAt: new Date(now).toISOString() },
  ])
    assert.throws(() => checkRollback({ ...r, ...change }));
});
test("bootstrap is explicit and restricted to first staging step", () => {
  assert.equal(rehearsalBootstrap(1, { SITE_URL: site }), false);
  assert.equal(rehearsalBootstrap(1, { SITE_URL: site, ROLLOUT_REHEARSAL_BOOTSTRAP: "yes" }), true);
  assert.throws(() =>
    rehearsalBootstrap(5, { SITE_URL: site, ROLLOUT_REHEARSAL_BOOTSTRAP: "yes" }),
  );
  assert.throws(() =>
    rehearsalBootstrap(1, {
      SITE_URL: "https://production.example.com",
      ROLLOUT_REHEARSAL_BOOTSTRAP: "yes",
    }),
  );
});

test("legacy or insufficiently diverse reports cannot pass", () => {
  for (const mutate of [
    (r) => (r.schemaVersion = 1),
    (r) => (r.coverage.accountCount = 1),
    (r) => (r.coverage.journeyIds = ["a"]),
    (r) => (r.stages[0].accountCount = 1),
    (r) => (r.stages[0].cache.cold.total = 0),
    (r) => (r.stages[0].operationsPerSecond = 999),
  ]) {
    const r = report();
    mutate(r);
    assert.throws(() => check(r));
  }
});
