import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {promotionConfig} from './promotion-policy.mjs';

const source=readFileSync(new URL('./runtime-chaos-certification.mjs', import.meta.url),'utf8');

test('runtime chaos defaults satisfy production promotion policy',()=>{
  assert.match(source,/CHAOS_CANARY_SECONDS\|\|'60'/);
  assert.match(source,/CHAOS_MIN_CANDIDATE_REQUESTS\|\|'20'/);
  assert.match(source,/CHAOS_MIN_STABLE_REQUESTS\|\|'20'/);
  assert.doesNotThrow(()=>promotionConfig({
    CANARY_SECONDS:'60',
    CANARY_MIN_CANDIDATE_REQUESTS:'20',
    CANARY_MIN_STABLE_REQUESTS:'20'
  }));
});

test('production policy still rejects the obsolete 12 second / 10 request chaos profile',()=>{
  assert.throws(()=>promotionConfig({
    CANARY_SECONDS:'12',
    CANARY_MIN_CANDIDATE_REQUESTS:'10',
    CANARY_MIN_STABLE_REQUESTS:'10'
  }),/outside permitted bounds/);
});
