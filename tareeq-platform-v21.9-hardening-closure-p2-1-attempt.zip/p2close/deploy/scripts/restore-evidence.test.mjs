import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import { requireRestoreEvidence, restoreChecks } from "./restore-evidence.mjs";
const now = Date.parse("2026-09-24T12:00:00Z");
const expected = {
  backupId: "20260924T110000Z-abcdef",
  sha256: "a".repeat(64),
  release: "b".repeat(40),
};
const report = () => ({
  schema_version: 2,
  status: "passed",
  backup_id: expected.backupId,
  backup_sha256: expected.sha256,
  restored_release: expected.release,
  isolated_project: "tareeqdr12345abcd",
  restore_host: "dr-host",
  started_at: new Date(now - 120000).toISOString(),
  measured_at: new Date(now).toISOString(),
  elapsed_seconds: 120,
  rto_target_seconds: 3600,
  checks: Object.fromEntries(restoreChecks.map((check) => [check, true])),
});
const check = (r) => requireRestoreEvidence(r, expected, now);
test("complete matching restore report is accepted", () =>
  assert.doesNotThrow(() => check(report())));
test("missing milestones and failed cleanup cannot authorize promotion", () => {
  for (const key of restoreChecks) {
    const r = report();
    r.checks[key] = false;
    assert.throws(() => check(r));
  }
  assert.throws(() => check({ ...report(), status: "cleanup_failed" }));
});
test("wrong backup, checksum, release and legacy reports are rejected", () => {
  for (const change of [
    { backup_id: "20260924T110000Z-aaaaaa" },
    { backup_sha256: "c".repeat(64) },
    { restored_release: "d".repeat(40) },
    { schema_version: 1 },
    { isolated_project: "production" },
  ])
    assert.throws(() => check({ ...report(), ...change }));
});
test("expired, future, inconsistent and over-budget evidence is rejected", () => {
  for (const change of [
    { measured_at: new Date(now + 60000).toISOString() },
    { measured_at: new Date(now - 8 * 86400000).toISOString() },
    { elapsed_seconds: 3601 },
    { elapsed_seconds: -1 },
    { rto_target_seconds: 7200 },
    { elapsed_seconds: 1 },
  ])
    assert.throws(() => check({ ...report(), ...change }));
});
test("report writer produces structured evidence without inventing completed checks", () => {
  const dir = mkdtempSync(join(tmpdir(), "restore-proof-"));
  try {
    const file = join(dir, "report.json");
    const result = spawnSync(
      process.execPath,
      [
        new URL("./restore-evidence.mjs", import.meta.url).pathname,
        file,
        expected.backupId,
        "failed",
        String(Math.floor(Date.now() / 1000) - 5),
        "3600",
        expected.sha256,
        expected.release,
        "tareeqdr12345abcd",
        "downloadChecksum",
      ],
      { encoding: "utf8" },
    );
    assert.equal(result.status, 0, result.stderr);
    const r = JSON.parse(readFileSync(file, "utf8"));
    assert.equal(r.checks.downloadChecksum, true);
    assert.equal(r.checks.cleanup, false);
    assert.throws(() => requireRestoreEvidence(r, expected));
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
