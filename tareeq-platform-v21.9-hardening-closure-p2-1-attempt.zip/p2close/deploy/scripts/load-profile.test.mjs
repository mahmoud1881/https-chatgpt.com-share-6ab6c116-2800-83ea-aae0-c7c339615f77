import test from "node:test";
import assert from "node:assert/strict";
import { validateLoadProfile, assignment, loadPlan } from "./load-profile.mjs";
const now = Date.parse("2026-09-24T12:00:00Z");
function fixture() {
  return {
    site: "https://staging.example.com",
    api: "https://api.staging.example.com",
    accounts: Array.from({ length: 50 }, (_, i) => ({
      email: `probe${i}@example.com`,
      password: "fixture-only",
    })),
    journeys: ["direct", "alias", "transfer", "long_distance", "direct"].map((category, i) => ({
      id: `j${i}`,
      from: `from${i}`,
      to: `to${i}`,
      category,
      evidence: "synthetic unit-test fixture",
      reviewedAt: new Date(now).toISOString(),
    })),
  };
}
test("profile accepts distinct accounts and reviewed diverse journeys without exposing credentials", () => {
  const p = fixture(),
    result = validateLoadProfile(p, p.site, p.api, now);
  assert.equal(result.accountCount, 50);
  assert.equal(result.journeyIds.length, 5);
  assert.ok(!JSON.stringify(result).includes("fixture-only"));
  assert.ok(!JSON.stringify(result).includes("@example.com"));
});
test("single account, repeated trips, stale references and target drift fail", () => {
  for (const mutate of [
    (p) => (p.accounts = p.accounts.slice(0, 1)),
    (p) => (p.accounts[1] = p.accounts[0]),
    (p) => (p.journeys[1] = p.journeys[0]),
    (p) => (p.journeys[0].reviewedAt = "2020-01-01"),
    (p) => (p.api = "https://production.example.com"),
    (p) => (p.journeys[2].category = "direct"),
  ]) {
    const p = fixture();
    mutate(p);
    assert.throws(() =>
      validateLoadProfile(p, "https://staging.example.com", "https://api.staging.example.com", now),
    );
  }
});
test("every stage exercises all accounts and journeys with both context modes", () => {
  const p = fixture();
  for (const { users, rounds } of loadPlan) {
    const accounts = new Set(),
      counts = new Map(),
      modes = new Set();
    for (let round = 0; round < rounds; round++) {
      const concurrent = new Set();
      for (let worker = 0; worker < users; worker++) {
        const a = assignment(worker, round, users, p.accounts.length, p.journeys);
        accounts.add(a.accountIndex);
        concurrent.add(a.accountIndex);
        modes.add(a.cold);
        counts.set(a.journey.id, (counts.get(a.journey.id) ?? 0) + 1);
      }
      assert.equal(concurrent.size, users);
    }
    assert.equal(accounts.size, 50);
    assert.equal(modes.size, 2);
    assert.equal(counts.size, 5);
    assert.ok([...counts.values()].every((n) => n >= 20));
  }
});
