import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

test('DR compares restored schema and content to source proofs captured with backup',()=>{
 const s=readFileSync('deploy/scripts/disaster-recovery-certification.mjs','utf8');
 for(const x of ['sourceSchemaSha256','restoredSchemaSha256','schemaIntegrity','sourceContentSha256','restoredContentSha256','contentIntegrity']) assert.ok(s.includes(x),x);
});
test('RPO uses database recovery point and declared disaster time, not file mtime',()=>{
 const s=readFileSync('deploy/scripts/disaster-recovery-certification.mjs','utf8');
 assert.ok(s.includes('recovery-point.json')); assert.ok(s.includes('DR_DISASTER_AT')); assert.ok(s.includes('rpoMeasuredSeconds'));
 assert.ok(!s.includes('mtimeMs'));
});
test('RTO clock is anchored to declared disaster time',()=>{
 const s=readFileSync('deploy/scripts/disaster-recovery-certification.mjs','utf8');
 assert.ok(s.includes('const began = disasterAt'));
});
