import { createHash } from "node:crypto";

export function assertStagingRelease(response, expected) {
  if (
    !/^[a-f0-9]{40}$/i.test(expected ?? "") ||
    response.headers.get("x-tareeq-release") !== expected
  )
    throw new Error("Public application release does not match RELEASE_COMMIT");
}

export function stagingContext(env) {
  if (!/^[a-f0-9]{40}$/i.test(env.RELEASE_COMMIT ?? ""))
    throw new Error("RELEASE_COMMIT must be a full source commit");
  const keys = [
    "RELEASE_COMMIT",
    "SITE_URL",
    "SUPABASE_PUBLIC_URL",
    "STUDIO_DOMAIN",
    "STAGING_EXPECTED_IPV4",
    "STAGING_TEST_EMAIL",
    "STAGING_OAUTH_PROVIDER",
    "STAGING_OAUTH_EXPECTED_HOST",
  ];
  const context = keys.map((key) => {
    if (!env[key]) throw new Error(`Missing ${key}`);
    return [key, env[key]];
  });
  return createHash("sha256").update(JSON.stringify(context)).digest("hex");
}

export function assertStagingProof(proof, env, now = Date.now()) {
  if (proof?.context !== stagingContext(env) || !proof?.id || env.STAGING_PROBE_ID !== proof.id)
    throw new Error(
      "Evidence belongs to another staging probe, target or release; start a new probe",
    );
  const started = Date.parse(proof.startedAt);
  if (!Number.isFinite(started) || started > now || now - started >= 3600000)
    throw new Error("Staging probe is expired or has an invalid start time");
  for (const key of ["STAGING_EMAIL_RECEIVED_AT", "STAGING_OAUTH_CALLBACK_AT"]) {
    const time = Date.parse(env[key]);
    if (!Number.isFinite(time) || time < started || time > now)
      throw new Error(`${key} must be observed during the current probe`);
  }
}
