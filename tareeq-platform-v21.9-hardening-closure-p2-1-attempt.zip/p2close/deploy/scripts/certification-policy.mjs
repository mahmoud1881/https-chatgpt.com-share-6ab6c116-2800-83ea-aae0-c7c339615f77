import { BINDING_PHASES } from "./runtime-image-binding.mjs";
import { createHash, createPublicKey, verify } from "node:crypto";
import { readFileSync, realpathSync, lstatSync } from "node:fs";
import { resolve, relative, isAbsolute, sep } from "node:path";
export const FORMAT = "tareeq-production-certification-v3";
export const MAX_AGE_MS = 24 * 60 * 60 * 1000;
// A rollout may legitimately span several 24–48h observation windows.
// Freshness is measured from completion; total certification duration is bounded separately.
export const MAX_CERT_DURATION_MS = 8 * 24 * 60 * 60 * 1000;
const SKEW = 60000;
export const GATES = [
  "supply-chain-attestation",
  "database-rls-and-schema-drift",
  "zero-downtime-migration-and-progressive-delivery",
  "telemetry-end-to-end",
  "runtime-chaos-recovery",
  "stateful-disaster-recovery",
];
export const EVIDENCE = {
  imageBinding: ["artifacts/runtime-image-binding.json", "tareeq-runtime-image-binding-v1"],
  supplyChain: [
    "artifacts/supply-chain-attestation.json",
    "tareeq-v21.9-supply-chain-attestation-v1",
  ],
  sbomSpdx: ["artifacts/release-sbom.spdx.json", null],
  sbomCycloneDx: ["artifacts/release-sbom.cyclonedx.json", null],
  provenance: ["artifacts/release-provenance.json", null],
  schemaDrift: ["artifacts/schema-drift-report.json", "tareeq-schema-drift-report-v1"],
  migrationSafety: ["artifacts/migration-safety-report.json", "tareeq-v20.9-migration-safety-v1"],
  productionMigration: [
    "artifacts/production-migration-transaction.json",
    "tareeq-v20.9-production-migration-v1",
  ],
  zeroDowntime: ["artifacts/zero-downtime-deployment.json", "tareeq-v21.0-zero-downtime-v1"],
  progressiveDelivery: [
    "artifacts/progressive-delivery-evidence.json",
    "tareeq-v21.3-observable-progressive-delivery-v2",
  ],
  telemetry: ["artifacts/telemetry-certification.json", "tareeq-v21.5-telemetry-certification-v1"],
  runtimeChaos: [
    "artifacts/runtime-chaos-certification.json",
    "tareeq-v21.6-runtime-chaos-certification-v1",
  ],
  disasterRecovery: [
    "artifacts/disaster-recovery-certification.json",
    "tareeq-v21.7-stateful-disaster-recovery-v1",
  ],
  migrationManifest: ["supabase/migration-integrity.json", "tareeq-migration-integrity-v1"],
};
export const sha = (b) => createHash("sha256").update(b).digest("hex");
export function canonical(x) {
  if (Array.isArray(x)) return `[${x.map(canonical).join(",")}]`;
  if (x && typeof x === "object")
    return `{${Object.keys(x)
      .sort()
      .map((k) => JSON.stringify(k) + ":" + canonical(x[k]))
      .join(",")}}`;
  return JSON.stringify(x);
}
const must = (ok, m) => {
  if (!ok) throw Error(m);
};
const object = (x) => x !== null && typeof x === "object" && !Array.isArray(x);
function keys(x, expected, label) {
  must(
    object(x) && Object.keys(x).sort().join("|") === [...expected].sort().join("|"),
    `${label}: schema keys mismatch`,
  );
}
const hex = (x) => typeof x === "string" && /^[a-f0-9]{64}$/.test(x);
const time = (x) => {
  must(
    typeof x === "string" &&
      /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(x) &&
      Number.isFinite(Date.parse(x)) &&
      new Date(x).toISOString() === x,
    "invalid timestamp",
  );
  return Date.parse(x);
};
function within(x, start, end) {
  const t = time(x);
  must(t >= start - SKEW && t <= end + SKEW, "evidence outside certification window");
  return t;
}
export function safeRead(root, path) {
  must(
    typeof path === "string" &&
      !isAbsolute(path) &&
      !path.split(/[\\/]/).some((x) => x === ".." || x === "." || !x),
    "unsafe evidence path",
  );
  const base = realpathSync(root);
  let cursor = base;
  for (const part of path.split("/")) {
    cursor = resolve(cursor, part);
    must(!lstatSync(cursor).isSymbolicLink(), "symlink evidence forbidden");
  }
  must(lstatSync(cursor).isFile(), "evidence is not a regular file");
  const rel = relative(base, realpathSync(cursor));
  must(!rel.startsWith(".." + sep) && !isAbsolute(rel), "evidence escapes bundle");
  return readFileSync(cursor);
}
export function loadTrust(root, env = process.env) {
  must(
    env.RELEASE_TRUSTED_PUBLIC_KEY_FILE && env.RELEASE_TRUSTED_KEY_ID,
    "independent trusted key file and key ID are required",
  );
  const file = realpathSync(env.RELEASE_TRUSTED_PUBLIC_KEY_FILE),
    base = realpathSync(root),
    rel = relative(base, file);
  must(
    rel === ".." || rel.startsWith(".." + sep) || isAbsolute(rel),
    "trusted key must be outside the evidence bundle",
  );
  const key = createPublicKey(readFileSync(file));
  must(key.asymmetricKeyType === "ed25519", "trusted key must be Ed25519");
  return {
    key,
    keyId: env.RELEASE_TRUSTED_KEY_ID,
    commit: env.RELEASE_COMMIT,
    digest: env.RELEASE_IMAGE_DIGEST,
  };
}
export function validateCertificate(cert, root, expected, now = Date.now()) {
  keys(
    cert,
    [
      "format",
      "runId",
      "status",
      "startedAt",
      "completedAt",
      "release",
      "runtimeGates",
      "evidence",
      "passed",
      "signature",
    ],
    "certificate",
  );
  must(
    cert.format === FORMAT && cert.status === "PRODUCTION CERTIFIED" && cert.passed === true,
    "unsupported or failed certificate",
  );
  must(typeof cert.runId === "string" && /^[a-f0-9-]{36}$/.test(cert.runId), "invalid run ID");
  const start = time(cert.startedAt),
    end = time(cert.completedAt);
  must(
    start <= end &&
      end <= now + SKEW &&
      now - end <= MAX_AGE_MS &&
      end - start <= MAX_CERT_DURATION_MS,
    "expired, future, overlong or unordered certificate",
  );
  keys(
    cert.release,
    [
      "gitCommit",
      "imageDigest",
      "schemaFingerprint",
      "sbomSpdxSha256",
      "sbomCycloneDxSha256",
      "provenanceSha256",
      "migrationManifestSha256",
    ],
    "release",
  );
  must(
    /^[a-f0-9]{40}$/.test(expected.commit || "") &&
      /^sha256:[a-f0-9]{64}$/.test(expected.digest || ""),
    "expected release identity required",
  );
  must(
    cert.release.gitCommit === expected.commit && cert.release.imageDigest === expected.digest,
    "wrong release identity",
  );
  for (const field of [
    "schemaFingerprint",
    "sbomSpdxSha256",
    "sbomCycloneDxSha256",
    "provenanceSha256",
    "migrationManifestSha256",
  ])
    must(hex(cert.release[field]), `invalid ${field}`);
  keys(cert.signature, ["algorithm", "keyId", "publicKeySha256", "detachedSignature"], "signature");
  must(
    cert.signature.algorithm === "Ed25519" &&
      cert.signature.keyId === expected.keyId &&
      hex(cert.signature.publicKeySha256) &&
      cert.signature.detachedSignature === "artifacts/production-certification.sig",
    "invalid signature metadata",
  );
  must(
    Array.isArray(cert.runtimeGates) && cert.runtimeGates.length === GATES.length,
    "incomplete runtime gates",
  );
  let previous = start;
  cert.runtimeGates.forEach((gate, i) => {
    keys(gate, ["name", "startedAt", "completedAt", "exitCode", "passed"], "gate");
    must(
      gate.name === GATES[i] && gate.exitCode === 0 && gate.passed === true,
      "failed, reordered or duplicate gate",
    );
    const a = within(gate.startedAt, start, end),
      b = within(gate.completedAt, start, end);
    must(a >= previous && b >= a && b <= end, "invalid gate chronology");
    previous = b;
  });
  keys(cert.evidence, Object.keys(EVIDENCE), "evidence");
  const docs = {};
  for (const [label, [path, format]] of Object.entries(EVIDENCE)) {
    const entry = cert.evidence[label];
    keys(entry, ["path", "sha256", "format", "completedAt"], "evidence descriptor");
    must(entry.path === path && hex(entry.sha256), "invalid evidence path or digest");
    const raw = safeRead(root, path);
    must(sha(raw) === entry.sha256, `${label}: evidence hash mismatch`);
    const d = JSON.parse(raw);
    must(object(d), `${label}: evidence must be an object`);
    docs[label] = d;
    must(
      entry.format === (d.format ?? null) && (!format || d.format === format),
      `${label}: unknown evidence format`,
    );
    const completed =
      label === "sbomSpdx"
        ? d.creationInfo?.created
        : label === "sbomCycloneDx"
          ? d.metadata?.timestamp
          : label === "provenance"
            ? d.predicate?.runDetails?.metadata?.finishedOn
            : label === "migrationManifest"
              ? null
              : d.completedAt;
    must(entry.completedAt === (completed ?? null), `${label}: timestamp mismatch`);
    if (label !== "migrationManifest") {
      // External SBOM generators may omit milliseconds; normalize only their ISO dates.
      const normalized =
        ["sbomSpdx", "sbomCycloneDx", "provenance"].includes(label) &&
        typeof completed === "string" &&
        /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{3})?Z$/.test(completed)
          ? new Date(completed).toISOString()
          : completed;
      const t = within(normalized, start, end);
      if (d.startedAt) {
        if (label === "progressiveDelivery") {
          const begun=time(d.startedAt);
          must(begun <= t && begun >= start - 8 * 24 * 60 * 60 * 1000, "progressive rollout exceeds resumable evidence horizon");
          must(d.releaseRef === `${docs.supplyChain?.image?.ref ?? ""}@${expected.digest}` || d.releaseRef === docs.zeroDowntime?.newRelease || d.releaseRef === `${process.env.RELEASE_IMAGE_REPOSITORY||""}@${expected.digest}`, "progressive rollout release mismatch");
        } else must(within(d.startedAt, start, end) <= t, "unordered evidence timestamps");
      }
    }
    must(
      d.passed !== false && !["failed", "aborted"].includes(d.status),
      `${label}: failed evidence`,
    );
  }
  for (const [label, field] of [
    ["sbomSpdx", "sbomSpdxSha256"],
    ["sbomCycloneDx", "sbomCycloneDxSha256"],
    ["provenance", "provenanceSha256"],
    ["migrationManifest", "migrationManifestSha256"],
  ])
    must(cert.evidence[label].sha256 === cert.release[field], `${label}: release hash mismatch`);
  const binding = docs.imageBinding;
  must(
    binding.passed === true &&
      binding.runId === cert.runId &&
      binding.gitCommit === expected.commit,
    "image binding run mismatch",
  );
  must(
    Array.isArray(binding.samples) && binding.samples.length === BINDING_PHASES.length,
    "incomplete image checkpoints",
  );
  const first = binding.samples[0];
  let observed = start;
  binding.samples.forEach((sample, i) => {
    keys(
      sample,
      ["phase", "immutableRef", "imageId", "containerId", "observedAt"],
      "image checkpoint",
    );
    must(
      sample.phase === BINDING_PHASES[i] &&
        sample.immutableRef === `${docs.supplyChain.image?.ref}@${expected.digest}`,
      "wrong immutable deployment image",
    );
    must(
      /^sha256:[a-f0-9]{64}$/.test(sample.imageId) && /^[a-f0-9]{64}$/.test(sample.containerId),
      "invalid runtime identity",
    );
    must(
      sample.imageId === first.imageId && sample.containerId === first.containerId,
      "container changed during tests",
    );
    const t = within(sample.observedAt, start, end);
    must(t >= observed, "unordered image observations");
    observed = t;
  });
  must(
    binding.completedAt === binding.samples.at(-1).observedAt,
    "image binding timestamp mismatch",
  );
  const deployment = cert.runtimeGates[2];
  must(
    time(binding.samples[0].observedAt) >= time(deployment.startedAt) &&
      time(binding.samples[1].observedAt) <= time(deployment.completedAt),
    "deployment image check outside gate",
  );
  for (let i = 3; i < 6; i++) {
    const gate = cert.runtimeGates[i],
      before = binding.samples[2 + (i - 3) * 2],
      after = binding.samples[3 + (i - 3) * 2];
    must(
      time(before.observedAt) <= time(gate.startedAt) &&
        time(after.observedAt) >= time(gate.completedAt),
      "image checks do not bracket tests",
    );
  }
  must(
    time(binding.samples.at(-1).observedAt) >= time(cert.runtimeGates.at(-1).completedAt),
    "signing check precedes tests",
  );
  must(
    docs.zeroDowntime.newRelease === first.immutableRef,
    "deployment release differs from certified image",
  );
  const sc = docs.supplyChain;
  must(
    sc.passed === true &&
      sc.gitCommit === expected.commit &&
      sc.image?.expectedDigest === expected.digest &&
      sc.image?.publishedDigest === expected.digest,
    "supply chain identity or result mismatch",
  );
  const checks = [
    "git-commit-identity",
    "published-image-digest",
    "sbom-spdx",
    "sbom-cyclonedx",
    "dependency-vulnerability-scan",
    "secret-scan",
    "oci-image-sign",
    "oci-image-signature-verify",
    "oci-provenance-attest",
    "oci-provenance-verify",
  ];
  must(
    Array.isArray(sc.checks) &&
      sc.checks.length === checks.length &&
      sc.checks.every((c, i) => c.name === checks[i] && c.passed === true && c.exitCode === 0),
    "incomplete supply-chain checks",
  );
  for (const label of ["sbomSpdx", "sbomCycloneDx", "provenance"])
    must(
      sc.artifacts?.[label]?.sha256 === cert.evidence[label].sha256,
      "supply-chain artifact hash mismatch",
    );
  must(
    docs.sbomSpdx.spdxVersion === "SPDX-2.3" &&
      Array.isArray(docs.sbomSpdx.packages) &&
      docs.sbomSpdx.packages.length > 0,
    "incomplete SPDX SBOM",
  );
  must(
    docs.sbomCycloneDx.bomFormat === "CycloneDX" &&
      Array.isArray(docs.sbomCycloneDx.components) &&
      docs.sbomCycloneDx.components.length > 0,
    "incomplete CycloneDX SBOM",
  );
  const p = docs.provenance;
  must(
    p._type === "https://in-toto.io/Statement/v1" &&
      p.predicateType === "https://slsa.dev/provenance/v1" &&
      p.subject?.length === 1 &&
      p.subject[0].digest?.sha256 === expected.digest.slice(7) &&
      p.predicate?.buildDefinition?.externalParameters?.gitCommit === expected.commit,
    "provenance release mismatch",
  );
  for (const [uri, label] of [
    ["sbom:spdx", "sbomSpdx"],
    ["sbom:cyclonedx", "sbomCycloneDx"],
  ])
    must(
      p.predicate.buildDefinition.resolvedDependencies?.some(
        (d) => d.uri === uri && d.digest?.sha256 === cert.evidence[label].sha256,
      ),
      "provenance SBOM mismatch",
    );
  const drift = docs.schemaDrift;
  must(
    drift.expectedSchemaSha256 === cert.release.schemaFingerprint &&
      Number.isInteger(drift.expectedMigrationCount) &&
      drift.expectedMigrationCount > 0,
    "schema fingerprint missing",
  );
  for (const target of ["staging", "production"])
    must(
      drift.targets?.[target]?.matches === true &&
        drift.targets[target].schemaSha256 === drift.expectedSchemaSha256 &&
        drift.targets[target].migrationCount === drift.expectedMigrationCount,
      "schema target mismatch",
    );
  must(
    object(docs.migrationManifest.migrations) &&
      Object.keys(docs.migrationManifest.migrations).length === drift.expectedMigrationCount &&
      Object.values(docs.migrationManifest.migrations).every(hex),
    "invalid migration manifest",
  );
  const safety = docs.migrationSafety;
  must(
    Array.isArray(safety.pending) &&
      safety.pendingCount === safety.pending.length &&
      safety.pending.every(
        (x) =>
          typeof x.file === "string" &&
          hex(x.sha256) &&
          ["backward-compatible", "lock-sensitive", "destructive"].includes(x.classification),
      ),
    "incomplete migration safety",
  );
  must(
    docs.productionMigration.trafficCutoverAllowed === true &&
      docs.productionMigration.postDeployMigrationCount === drift.expectedMigrationCount,
    "production migrations incomplete",
  );
  const zd = docs.zeroDowntime;
  must(
    zd.status === "passed" &&
      zd.trafficCutoverAllowed === true &&
      zd.databaseRollbackAttempted === false &&
      zd.recoveryMode === "roll-forward-only" &&
      Array.isArray(zd.phases),
    "zero downtime incomplete",
  );
  for (const phase of [
    "expand",
    "dual-release-schema-compatibility",
    "deploy-green-and-probe",
    "progressive-delivery",
    "full-cutover",
    "post-deploy-schema-fingerprint",
  ])
    must(
      zd.phases.filter((p) => p.phase === phase && p.status === "passed").length === 1,
      "missing successful deployment phase",
    );
  const pd = docs.progressiveDelivery;
  must(
    pd.status === "passed" &&
      JSON.stringify(pd.stages) === "[1,5,25,50,100]" &&
      Array.isArray(pd.decisions),
    "incomplete progressive delivery",
  );
  for (const percent of pd.stages)
    must(
      pd.decisions.some(
        (d) =>
          d.percent === percent &&
          d.decision === (percent === 100 ? "complete" : "promote") &&
          d.slo?.passed === true,
      ),
      "missing canary stage proof",
    );
  must(docs.telemetry.passed === true, "telemetry failed");
  for (const c of [
    "tempoReady",
    "prometheusReady",
    "syntheticRequest",
    "traceRetrievable",
    "appSpanMetrics",
    "databaseMetrics",
  ])
    must(docs.telemetry.checks?.[c] === true, "incomplete telemetry");
  const chaos = docs.runtimeChaos;
  must(
    chaos.passed === true &&
      chaos.telemetryCertification?.passed === true &&
      Array.isArray(chaos.scenarios) &&
      chaos.scenarios.length === 4,
    "incomplete chaos",
  );
  for (const mode of ["5xx", "latency", "db-outage", "external-failure"])
    must(
      chaos.scenarios.filter(
        (s) =>
          s.mode === mode &&
          s.passed === true &&
          s.detected === true &&
          s.incident === true &&
          s.stableRestored === true,
      ).length === 1,
      "missing chaos scenario",
    );
  const dr = docs.disasterRecovery;
  must(dr.passed === true && dr.scope !== "isolated-database", "full disaster recovery required");
  for (const c of [
    "backupIntegrity",
    "rpo",
    "cleanDatabaseStarted",
    "databaseRestore",
    "dataIntegrity",
    "schemaIntegrity",
    "servicesRestarted",
    "telemetryRecovered",
    "trafficRestored",
    "rto",
    "isolationVerified",
  ])
    must(dr.checks?.[c] === true, "incomplete recovery checks");
  must(
    dr.cleanup?.attempted === true &&
      Array.isArray(dr.cleanup.errors) &&
      dr.cleanup.errors.length === 0,
    "recovery cleanup not proven",
  );
  return cert;
}
export function verifyCertificate({ cert, signature, root, trust, now }) {
  must(trust.key?.asymmetricKeyType === "ed25519", "trusted Ed25519 key required");
  const fp = sha(trust.key.export({ type: "spki", format: "der" }));
  must(
    cert.signature?.publicKeySha256 === fp && cert.signature?.keyId === trust.keyId,
    "untrusted signing key",
  );
  must(
    typeof signature === "string" && /^[A-Za-z0-9+/]{86}==$/.test(signature.trim()),
    "invalid detached signature encoding",
  );
  must(
    verify(null, Buffer.from(canonical(cert)), trust.key, Buffer.from(signature.trim(), "base64")),
    "invalid certification signature",
  );
  return validateCertificate(cert, root, trust, now);
}
