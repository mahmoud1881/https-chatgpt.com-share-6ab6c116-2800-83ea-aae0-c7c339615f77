import { loadLimits, scenarios } from "./load-metrics.mjs";
import { loadPlan } from "./load-profile.mjs";

export function rehearsalBootstrap(target, env) {
  if (env.ROLLOUT_REHEARSAL_BOOTSTRAP !== "yes") return false;
  const site = new URL(env.SITE_URL);
  if (
    target !== 1 ||
    site.protocol !== "https:" ||
    !/^(staging|stage|test)[.-]/i.test(site.hostname)
  )
    throw new Error("Rehearsal bootstrap is restricted to the first staging-only step");
  return true;
}

export function requirePromotionLoad(report, revision, site, api, now = Date.now()) {
  const fail = () => {
    throw new Error(
      "Fresh complete load evidence for this release and staging targets is required",
    );
  };
  if (!/^[a-f0-9]{40}$/i.test(revision ?? "") || !site || !api) fail();
  const origin = (value) => {
    const url = new URL(value);
    if (url.protocol !== "https:" || url.username || url.password) fail();
    return url.origin;
  };
  const started = Date.parse(report?.startedAt),
    finished = Date.parse(report?.finishedAt);
  if (
    report?.passed !== true ||
    report.cleanupPassed !== true ||
    report.releaseCommit !== revision ||
    report.site !== origin(site) ||
    report.api !== origin(api) ||
    !Number.isFinite(started) ||
    !Number.isFinite(finished) ||
    finished < started ||
    finished > now ||
    now - started > 7 * 86400000
  )
    fail();
  if (!Object.entries(loadLimits).every(([key, value]) => report.thresholds?.[key] === value))
    fail();
  const plan = loadPlan;
  const coverage = report.coverage;
  if (
    report.schemaVersion !== 2 ||
    !Number.isInteger(coverage?.accountCount) ||
    coverage.accountCount < 50 ||
    !Array.isArray(coverage?.journeyIds) ||
    coverage.journeyIds.length < 5 ||
    coverage.journeyIds.length > 10 ||
    new Set(coverage.journeyIds).size !== coverage.journeyIds.length ||
    !/^[a-f0-9]{64}$/.test(coverage.journeyFingerprint ?? "") ||
    !["direct", "alias", "transfer", "long_distance"].every((c) => coverage.categories?.includes(c))
  )
    fail();
  if (
    !Array.isArray(report.stages) ||
    report.stages.length !== plan.length ||
    !Array.isArray(report.plan) ||
    report.plan.length !== plan.length
  )
    fail();
  plan.forEach(({ users, rounds }, index) => {
    const stage = report.stages[index],
      expected = users * rounds;
    if (
      report.plan[index]?.users !== users ||
      report.plan[index]?.rounds !== rounds ||
      stage?.users !== users ||
      stage.rounds !== rounds ||
      stage.operations !== expected * 3 ||
      stage.passed !== true
    )
      fail();
    for (const name of scenarios) {
      const metric = stage.scenarios?.[name];
      if (
        !metric ||
        metric.total !== expected ||
        !Number.isSafeInteger(metric.errors) ||
        metric.errors < 0 ||
        metric.errors > metric.total ||
        metric.errors / metric.total > loadLimits.errorRate ||
        !Number.isFinite(metric.p95Ms) ||
        metric.p95Ms < 0 ||
        metric.p95Ms > loadLimits[`${name}P95`]
      )
        fail();
    }
    if (
      !Number.isInteger(stage.accountCount) ||
      stage.accountCount < 50 ||
      stage.accountCount > coverage.accountCount ||
      !Number.isFinite(stage.elapsedMs) ||
      stage.elapsedMs <= 0 ||
      !Number.isFinite(stage.operationsPerSecond) ||
      Math.abs(stage.operationsPerSecond - stage.operations / (stage.elapsedMs / 1000)) > 0.01
    )
      fail();
    for (const name of ["search", "planner"]) {
      let total = 0,
        errors = 0;
      for (const id of coverage.journeyIds) {
        const metric = stage.journeys?.[id]?.[name];
        if (
          !Number.isSafeInteger(metric?.total) ||
          metric.total < 10 ||
          !Number.isSafeInteger(metric.errors) ||
          metric.errors < 0 ||
          metric.errors / metric.total > loadLimits.errorRate
        )
          fail();
        total += metric.total;
        errors += metric.errors;
      }
      if (total !== expected || errors !== stage.scenarios[name].errors) fail();
    }
    for (const kind of ["cold", "warm"]) {
      const metric = stage.cache?.[kind];
      if (
        !Number.isSafeInteger(metric?.total) ||
        metric.total <= 0 ||
        !Number.isSafeInteger(metric.errors) ||
        metric.errors < 0 ||
        metric.errors / metric.total > loadLimits.errorRate ||
        !Number.isFinite(metric.p95Ms) ||
        metric.p95Ms < 0 ||
        metric.p95Ms > 3000
      )
        fail();
    }
    if (stage.cache.cold.total + stage.cache.warm.total !== expected * 2) fail();
  });
}
