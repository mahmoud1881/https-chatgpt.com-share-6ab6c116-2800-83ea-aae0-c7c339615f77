import { randomUUID, randomBytes } from "node:crypto";

export const OWNER_LABEL = "org.tareeq.dr-run";
const PROJECT_LABEL = "com.docker.compose.project";
const lines = (s) => s.trim().split(/\s+/).filter(Boolean);

// A deliberately minimal database sandbox. Never reuse production mounts,
// networks, commands, credentials, published ports or dependency services.
export function createSandbox(source, env = process.env) {
  for (const key of [
    "DR_PROJECT_NAME",
    "DR_RESTORED_DATABASE_URL",
    "DR_TRAFFIC_STATE_FILE",
    "DR_KEEP_ISOLATED_ENV",
    "DR_SKIP_TELEMETRY_CERTIFICATION",
  ]) {
    if (env[key] !== undefined) throw Error(`${key} is not supported by isolated recovery`);
  }
  const image = source?.services?.db?.image;
  if (typeof image !== "string" || !image.trim() || image.startsWith("-"))
    throw Error("db image is required");
  const token = randomUUID();
  const project = `tareeqdr-${token}`;
  const labels = { [OWNER_LABEL]: token };
  const volume = `${project}_db_data`;
  return {
    token,
    project,
    volume,
    config: {
      name: project,
      services: {
        db: {
          image,
          network_mode: "none",
          restart: "no",
          labels: { [OWNER_LABEL]: token },
          environment: {
            POSTGRES_PASSWORD: randomBytes(32).toString("hex"),
            POSTGRES_DB: "postgres",
            JWT_SECRET: randomBytes(32).toString("hex"),
          },
          volumes: [
            {
              type: "volume",
              source: "db_data",
              target: "/var/lib/postgresql/data",
              volume: { nocopy: true },
            },
          ],
          healthcheck: {
            test: ["CMD", "pg_isready", "-U", "postgres", "-d", "postgres"],
            interval: "2s",
            timeout: "5s",
            retries: 60,
          },
        },
      },
      volumes: { db_data: { name: volume, labels } },
    },
  };
}

export function isolationGuard(sandbox, docker) {
  const filters = ["--filter", `label=${PROJECT_LABEL}=${sandbox.project}`];
  let attempted = false;
  const list = (kind, extra = []) =>
    lines(
      docker(
        kind === "container"
          ? ["ps", "-aq", ...filters, ...extra]
          : [kind, "ls", "-q", ...filters, ...extra],
      ),
    );
  function inspect(kind, id) {
    const value = JSON.parse(docker([kind, "inspect", id]));
    if (value.length !== 1) throw Error("ambiguous Docker resource");
    return value[0];
  }
  function owned(kind, id) {
    const resource = inspect(kind, id);
    const labels = kind === "container" ? resource.Config?.Labels : resource.Labels;
    if (labels?.[OWNER_LABEL] !== sandbox.token || labels?.[PROJECT_LABEL] !== sandbox.project)
      throw Error(`refusing foreign ${kind}: ${id}`);
    return resource;
  }
  return {
    preflight() {
      for (const kind of ["container", "volume", "network"]) {
        if (list(kind).length) throw Error(`project already has ${kind} resources`);
      }
      // Also detect a pre-existing physical volume without Compose labels.
      if (lines(docker(["volume", "ls", "-q"])).includes(sandbox.volume))
        throw Error("sandbox volume already exists");
    },
    begin() {
      this.preflight();
      attempted = true;
    },
    verifyDatabase() {
      const ids = list("container");
      if (ids.length !== 1) throw Error("expected exactly one isolated database");
      const db = owned("container", ids[0]);
      if (
        db.HostConfig?.NetworkMode !== "none" ||
        db.HostConfig?.Privileged ||
        Object.keys(db.HostConfig?.PortBindings || {}).length
      )
        throw Error("database isolation verification failed");
      if (
        db.Mounts?.length !== 1 ||
        db.Mounts[0].Type !== "volume" ||
        db.Mounts[0].Name !== sandbox.volume
      )
        throw Error("unexpected database mount");
      owned("volume", sandbox.volume);
      return ids[0];
    },
    cleanup() {
      const result = { attempted, removed: [], errors: [] };
      if (!attempted) return result;
      // Dual labels are necessary, including after a partially failed `up`.
      // Re-inspect immediately before removal; never use Compose down/orphans.
      for (const kind of ["container", "network", "volume"]) {
        let ids;
        try {
          ids = list(kind, ["--filter", `label=${OWNER_LABEL}=${sandbox.token}`]);
        } catch (e) {
          result.errors.push(e.message);
          continue;
        }
        for (const id of ids) {
          try {
            owned(kind, id);
            docker(kind === "container" ? ["container", "rm", "-f", id] : [kind, "rm", id]);
            result.removed.push({ kind, id });
          } catch (e) {
            result.errors.push(e.message);
          }
        }
      }
      return result;
    },
  };
}
