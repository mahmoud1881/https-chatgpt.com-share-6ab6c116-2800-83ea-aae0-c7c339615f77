import { readdirSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";

export function assertMigrationLedger(expected, applied) {
  if (!expected.length) throw new Error("No source migrations found");
  if (!Array.isArray(applied) || applied.some((name) => typeof name !== "string"))
    throw new Error("Invalid migration ledger response");
  const actual = new Set(applied);
  const wanted = new Set(expected);
  if (actual.size !== applied.length) throw new Error("Duplicate migration ledger entries");
  const missing = expected.filter((name) => !actual.has(name));
  const unexpected = applied.filter((name) => !wanted.has(name));
  if (missing.length || unexpected.length)
    throw new Error(
      `Migration ledger mismatch: ${missing.length} missing, ${unexpected.length} unexpected`,
    );
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const expected = readdirSync(new URL("../../supabase/migrations/", import.meta.url))
      .filter((name) => name.endsWith(".sql"))
      .sort();
    const result = spawnSync(
      "docker",
      [
        "compose",
        "exec",
        "-T",
        "db",
        "psql",
        "-X",
        "-U",
        "postgres",
        "-d",
        "postgres",
        "-v",
        "ON_ERROR_STOP=1",
        "-tAc",
        "SELECT COALESCE(json_agg(filename ORDER BY filename), '[]'::json) FROM platform_meta.applied_migrations",
      ],
      { cwd: fileURLToPath(new URL("../", import.meta.url)), encoding: "utf8", timeout: 20000 },
    );
    if (result.status !== 0) throw new Error("Cannot query PostgreSQL migration ledger");
    assertMigrationLedger(expected, JSON.parse(result.stdout.trim()));
    console.log(`All ${expected.length} source migrations are recorded in PostgreSQL`);
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
