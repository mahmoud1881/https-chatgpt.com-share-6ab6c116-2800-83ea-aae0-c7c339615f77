// One monitoring sample. Run from deploy/ on a staging host (no credentials are printed).
import { spawnSync } from "node:child_process";
import { mkdirSync, appendFileSync, readFileSync, writeFileSync } from "node:fs";
import { performance } from "node:perf_hooks";
import { fingerprint } from "./rollout-evidence.mjs";
import { requireCounters, parsePostgresCounters, incidentState } from "./monitor-validation.mjs";

const env = process.env;
const stateFile = "backups/monitor-state.json";
const logFile = "backups/monitor.jsonl";
mkdirSync("backups", { recursive: true, mode: 0o700 });
const sample = { at: new Date().toISOString(), checks: {}, alerts: [] };
let previous = { consecutive: 0 };
try {
  previous = JSON.parse(readFileSync(stateFile, "utf8"));
} catch {}
const previousEnd = Date.parse(previous.at);
const end = Date.parse(sample.at);
sample.windowStart = new Date(
  Number.isFinite(previousEnd) && previousEnd < end && end - previousEnd <= 300000
    ? previousEnd
    : end - 120000,
).toISOString();
let trafficState;
try {
  trafficState = JSON.parse(readFileSync("backups/rollout/traffic-state.json", "utf8"));
  sample.stateFingerprint = fingerprint(trafficState);
} catch {
  sample.alerts.push("Traffic state missing or invalid");
}
function command(binary, args) {
  const r = spawnSync(binary, args, { encoding: "utf8", timeout: 12000, maxBuffer: 1024 * 1024 });
  if (r.error || r.status !== 0) throw new Error(`${binary} exited ${r.status ?? r.error?.code}`);
  return r.stdout.trim();
}
function compose(...args) {
  return command("docker", ["compose", ...args]);
}
async function http(name, url) {
  const start = performance.now();
  try {
    const headers =
      name === "app"
        ? { "user-agent": "Tareeq-Probe/monitor" }
        : { apikey: env.VITE_SUPABASE_PUBLISHABLE_KEY || "" };
    const r = await fetch(url, { headers, signal: AbortSignal.timeout(7000) });
    sample.checks[name] = { ok: r.ok, status: r.status, ms: Math.round(performance.now() - start) };
    if (name === "rest") sample.checks[name].ok = r.ok && Array.isArray(await r.json());
    if (name === "app") {
      sample.checks.app.channel = r.headers.get("x-tareeq-channel");
      sample.checks.app.release = r.headers.get("x-tareeq-release");
    }
  } catch (e) {
    sample.checks[name] = { ok: false, error: e.name, ms: Math.round(performance.now() - start) };
  }
}
async function check() {
  if (!env.SITE_URL || !env.SUPABASE_PUBLIC_URL)
    throw new Error("Set SITE_URL and SUPABASE_PUBLIC_URL");
  const app = new URL(env.SITE_URL),
    api = new URL(env.SUPABASE_PUBLIC_URL);
  if (app.protocol !== "https:" || api.protocol !== "https:") throw new Error("HTTPS required");
  await Promise.all([
    http("app", app),
    http("auth", new URL("/auth/v1/health", api)),
    http("rest", new URL("/rest/v1/routes?select=id&limit=1", api)),
  ]);
  try {
    const stableId = compose("ps", "-q", "app");
    const stableImage = command("docker", ["inspect", "-f", "{{.Image}}", stableId]);
    if (stableImage !== trafficState?.stableImage)
      throw Error("Stable image changed; reinitialize rollout observation");
    const channel = sample.checks.app.channel;
    if (
      !["stable", "candidate"].includes(channel) ||
      (trafficState?.percent === 0 && channel !== "stable") ||
      (trafficState?.percent === 100 && channel !== "candidate")
    )
      throw Error("Public routing channel differs from active stage");
    const servedId =
      channel === "stable" ? stableId : compose("--profile", "canary", "ps", "-q", "candidate");
    const revision = command("docker", [
      "inspect",
      "-f",
      '{{index .Config.Labels "org.opencontainers.image.revision"}}',
      servedId,
    ]);
    sample.checks.app.identityOk =
      revision !== "unknown" &&
      /^[a-f0-9]{40}$/i.test(revision) &&
      sample.checks.app.release === revision;
    const lastProbe = previous.journey;
    if (
      previous.stateFingerprint === sample.stateFingerprint &&
      lastProbe &&
      Date.now() - Date.parse(lastProbe.at) >= 0 &&
      Date.now() - Date.parse(lastProbe.at) < 3600000 &&
      env.MONITOR_FORCE_JOURNEY_PROBE !== "yes"
    ) {
      sample.checks.journey = lastProbe;
    } else {
      const candidateId = compose("--profile", "canary", "ps", "-q", "candidate");
      const stableRevision = command("docker", [
        "inspect",
        "-f",
        '{{index .Config.Labels "org.opencontainers.image.revision"}}',
        stableId,
      ]);
      const candidateRevision = candidateId
        ? command("docker", [
            "inspect",
            "-f",
            '{{index .Config.Labels "org.opencontainers.image.revision"}}',
            candidateId,
          ])
        : "";
      const probe = spawnSync("node", ["scripts/public-journey-probe.mjs"], {
        encoding: "utf8",
        timeout: 90000,
        maxBuffer: 1024 * 1024,
        env: {
          ...env,
          EXPECTED_PERCENT: String(trafficState?.percent),
          EXPECTED_STABLE_REVISION: stableRevision,
          EXPECTED_CANDIDATE_REVISION: candidateRevision,
        },
      });
      try {
        sample.checks.journey = JSON.parse(probe.stdout.trim());
      } catch {
        sample.checks.journey = {
          at: new Date().toISOString(),
          ok: false,
          error: "Browser probe unavailable",
        };
      }
      if (probe.status !== 0 || probe.error) sample.checks.journey.ok = false;
    }
  } catch (e) {
    sample.checks.app.identityOk = false;
    sample.alerts.push(e.message);
  }
  try {
    const sql = `SELECT count(*), (SELECT setting::int FROM pg_settings WHERE name='max_connections'),
      count(*) FILTER (WHERE state='active'), count(*) FILTER (WHERE wait_event_type='Lock'),
      count(*) FILTER (WHERE state='active' AND now()-query_start > interval '30 seconds')
      FROM pg_stat_activity;`;
    const line = compose(
      "exec",
      "-T",
      "db",
      "psql",
      "-U",
      "postgres",
      "-d",
      "postgres",
      "-v",
      "ON_ERROR_STOP=1",
      "-tAc",
      sql,
    );
    const [connections, maximum, active, waiting, longRunning] = parsePostgresCounters(line);
    sample.checks.postgres = { ok: true, connections, maximum, active, waiting, longRunning };
    sample.checks.databaseBytes = Number(
      compose(
        "exec",
        "-T",
        "db",
        "psql",
        "-U",
        "postgres",
        "-d",
        "postgres",
        "-v",
        "ON_ERROR_STOP=1",
        "-tAc",
        "SELECT pg_database_size(current_database())",
      ),
    );
    requireCounters([sample.checks.databaseBytes]);
  } catch (e) {
    sample.checks.postgres = { ok: false, error: e.message };
  }
  try {
    const cid = compose("ps", "-q", "app");
    if (!cid) throw Error("App container absent");
    const stats = JSON.parse(
      command("docker", ["stats", "--no-stream", "--format", "{{json .}}", cid]).split("\n")[0],
    );
    sample.checks.appContainer = {
      ok: true,
      cpuPercent: Number(stats.CPUPerc?.replace("%", "")),
      memory: stats.MemUsage,
      memoryPercent: Number(stats.MemPerc?.replace("%", "")),
    };
    requireCounters([
      sample.checks.appContainer.cpuPercent,
      sample.checks.appContainer.memoryPercent,
    ]);
  } catch (e) {
    sample.checks.appContainer = { ok: false, error: e.message };
  }
  const services = ["app", "auth", "realtime"];
  try {
    const candidate = compose("--profile", "canary", "ps", "-q", "candidate");
    if (candidate) {
      services.push("candidate");
      sample.checks.candidate = {
        ok:
          command("docker", ["inspect", "-f", "{{.State.Health.Status}}", candidate]) === "healthy",
        image: command("docker", ["inspect", "-f", "{{.Image}}", candidate]),
      };
      sample.candidateImage = sample.checks.candidate.image;
      if (sample.candidateImage !== trafficState?.candidateImage)
        sample.alerts.push("Candidate image changed during observation");
    } else if (trafficState?.candidateImage || trafficState?.percent > 0)
      sample.checks.candidate = { ok: false };
  } catch {
    sample.checks.candidate = { ok: false };
  }
  for (const name of services) {
    try {
      const logs = compose(
        "logs",
        "--no-color",
        "--since",
        sample.windowStart,
        "--until",
        sample.at,
        name,
      );
      // Store counts only: never persist emails, tokens, URLs, or log lines.
      const pattern =
        name === "auth"
          ? /(smtp|mailer|send.?mail).*(error|fail|timeout)|(error|fail|timeout).*(smtp|mailer|send.?mail)/i
          : name === "realtime"
            ? /(error|exception|disconnect|crash)/i
            : /(\[server\] request failed|uncaughtException|unhandledRejection)/i;
      sample.checks[`${name}Errors`] = {
        ok: true,
        count: logs.split("\n").filter((s) => pattern.test(s)).length,
      };
      if (name === "app" || name === "candidate") {
        const requests = logs.split("\n").flatMap((line) => {
          const start = line.indexOf('{"event":"http_request"');
          if (start < 0) return [];
          try {
            const item = JSON.parse(line.slice(start)),
              at = Date.parse(item.at);
            return item.kind === "dynamic" &&
              !item.probe &&
              Number.isFinite(at) &&
              at >= Date.parse(sample.windowStart) &&
              at < Date.parse(sample.at)
              ? [item]
              : [];
          } catch {
            return [];
          }
        });
        const durations = requests
          .map((r) => r.durationMs)
          .filter(Number.isFinite)
          .sort((a, b) => a - b);
        sample.checks[`${name}Traffic`] = {
          requests: requests.length,
          errors: requests.filter((r) => r.status >= 500).length,
          p95Ms: durations.length ? durations[Math.ceil(durations.length * 0.95) - 1] : null,
        };
      }
    } catch (e) {
      sample.checks[`${name}Errors`] = { ok: false, error: e.message };
    }
  }
  try {
    const probe = spawnSync(
      "docker",
      ["compose", "exec", "-T", "app", "node", "-", "ws://kong:8000/realtime/v1/websocket"],
      {
        input: readFileSync("scripts/probe-realtime.mjs"),
        encoding: "utf8",
        timeout: 12000,
        maxBuffer: 1024 * 1024,
      },
    );
    sample.checks.realtime = { ok: probe.status === 0 && !probe.error };
  } catch {
    sample.checks.realtime = { ok: false };
  }
}
let fatal;
try {
  await check();
} catch (e) {
  fatal = e.message;
  sample.alerts.push(`monitor: ${fatal}`);
}
for (const name of [
  "app",
  "journey",
  "candidate",
  "auth",
  "rest",
  "postgres",
  "appContainer",
  "realtime",
  "appErrors",
  "candidateErrors",
  "authErrors",
  "realtimeErrors",
]) {
  if (sample.checks[name]?.ok === false) sample.alerts.push(`${name}: unavailable`);
}
if (sample.checks.app?.ms > 3000 || sample.checks.auth?.ms > 3000 || sample.checks.rest?.ms > 3000)
  sample.alerts.push("HTTP latency > 3 seconds");
if (
  sample.checks.postgres?.ok &&
  sample.checks.postgres.connections / sample.checks.postgres.maximum > 0.8
)
  sample.alerts.push("PostgreSQL connections > 80%");
if (sample.checks.postgres?.waiting > 5 || sample.checks.postgres?.longRunning > 5)
  sample.alerts.push("PostgreSQL lock waits or long queries > 5");
if (sample.checks.appContainer?.cpuPercent > 85) sample.alerts.push("App CPU > 85%");
if (sample.checks.appContainer?.memoryPercent > 85) sample.alerts.push("App memory > 85%");
if (
  sample.checks.appErrors?.count > 0 ||
  sample.checks.authErrors?.count > 0 ||
  sample.checks.realtimeErrors?.count > 0
)
  sample.alerts.push("New app, email or Realtime errors in recent logs");
if (
  sample.checks.appTraffic?.requests >= 20 &&
  sample.checks.appTraffic.errors / sample.checks.appTraffic.requests > 0.01
)
  sample.alerts.push("App HTTP 5xx rate > 1%");
if (sample.checks.appTraffic?.requests >= 20 && sample.checks.appTraffic.p95Ms > 3000)
  sample.alerts.push("App dynamic HTTP p95 > 3 seconds");
if (
  sample.checks.candidateTraffic?.requests >= 20 &&
  sample.checks.candidateTraffic.errors / sample.checks.candidateTraffic.requests > 0.01
)
  sample.alerts.push("Candidate HTTP 5xx rate > 1%");
if (sample.checks.candidateTraffic?.requests >= 20 && sample.checks.candidateTraffic.p95Ms > 3000)
  sample.alerts.push("Candidate dynamic HTTP p95 > 3 seconds");
if (sample.checks.candidateErrors?.count > 0) sample.alerts.push("Candidate application errors");
if (sample.checks.app?.identityOk !== true) sample.alerts.push("Public release identity mismatch");
appendFileSync(logFile, JSON.stringify(sample) + "\n", { mode: 0o600 });
const incident = incidentState(sample.alerts, previous, Date.parse(sample.at), fingerprint);
const { consecutive, incidentKey } = incident;
let notified = incident.notified;
if (consecutive >= 2) {
  console.error(`ALERT (${consecutive} checks): ${sample.alerts.join("; ")}`);
  if (!notified && env.ALERT_WEBHOOK_URL) {
    try {
      const target = new URL(env.ALERT_WEBHOOK_URL);
      if (target.protocol !== "https:") throw Error("Webhook must use HTTPS");
      const r = await fetch(target, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          text: `Tareeq staging incident (${sample.at}): ${sample.alerts.join("; ")}`,
        }),
        signal: AbortSignal.timeout(7000),
      });
      if (!r.ok) throw Error(`Webhook HTTP ${r.status}`);
      notified = true;
    } catch (e) {
      console.error(`Alert delivery failed: ${e.message}`);
    }
  }
  process.exitCode = 1; // systemd OnFailure / journal monitoring can notify operators.
} else
  console.log(sample.alerts.length ? "Monitoring warning (await second sample)" : "Monitoring OK");
writeFileSync(
  stateFile,
  JSON.stringify({
    consecutive,
    incidentKey,
    notified,
    at: sample.at,
    stateFingerprint: sample.stateFingerprint,
    journey: sample.checks.journey,
  }),
  { mode: 0o600 },
);
