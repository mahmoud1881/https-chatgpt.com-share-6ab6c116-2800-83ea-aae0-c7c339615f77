import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import {
  existsSync,
  mkdirSync,
  readFileSync,
  mkdtempSync,
  rmSync,
    writeFileSync,
} from "node:fs";
import { resolve, join } from "node:path";
import { tmpdir } from "node:os";
import { createSandbox, isolationGuard } from "./dr-isolation.mjs";

const root = process.cwd();
const rto = Number(process.env.DR_RTO_TARGET_SECONDS || 900);
const rpo = Number(process.env.DR_RPO_TARGET_SECONDS || 300);
const backupDir = process.env.DR_BACKUP_DIR || "";
const compose = process.env.DR_COMPOSE_FILE || "deploy/docker-compose.yml";
let sandbox, guard, tempDir;
let composeArgs;
const evidence = {
  format: "tareeq-v21.7-stateful-disaster-recovery-v1",
  startedAt: new Date().toISOString(),
  scope: "isolated-database",
  rtoTargetSeconds: rto,
  rpoTargetSeconds: rpo,
  backupDir,
  checks: {},
  passed: false,
};
mkdirSync("artifacts", { recursive: true });
function fail(m) {
  throw new Error(m);
}
function run(cmd, args, opts = {}) {
  const x = spawnSync(cmd, args, {
    cwd: opts.cwd || root,
    encoding: "utf8",
    stdio: opts.capture ? "pipe" : opts.input ? ["pipe", "inherit", "inherit"] : "inherit",
    env: { ...process.env, ...opts.env },
    timeout: opts.timeout || 600000,
    input: opts.input,
  });
  if (x.error) fail(`${cmd}: ${x.error.message}`);
  if (x.status !== 0)
    fail(
      `${cmd} ${args.join(" ")} exited ${x.status}${opts.capture ? `: ${(x.stderr || x.stdout).trim()}` : ""}`,
    );
  return (x.stdout || "").trim();
}
try {
  for (const key of [
    "DR_PROJECT_NAME",
    "DR_RESTORED_DATABASE_URL",
    "DR_TRAFFIC_STATE_FILE",
    "DR_KEEP_ISOLATED_ENV",
    "DR_SKIP_TELEMETRY_CERTIFICATION",
  ])
    if (process.env[key] !== undefined) fail(`${key} is not supported by isolated recovery`);
  if (!Number.isFinite(rto) || rto <= 0 || rto > 3600)
    fail("DR_RTO_TARGET_SECONDS must be 1..3600");
  if (!Number.isFinite(rpo) || rpo < 0 || rpo > 86400)
    fail("DR_RPO_TARGET_SECONDS must be 0..86400");
  if (!backupDir || !existsSync(backupDir))
    fail("DR_BACKUP_DIR pointing to a verified full backup is required");
  for (const f of ["db.dump", "db-roles.sql", "db-role-names.txt", "SHA256SUMS", "db-metrics.txt", "recovery-point.json", "source-schema-fingerprint.json", "source-content-fingerprint.json"])
    if (!existsSync(resolve(backupDir, f))) fail(`backup missing ${f}`);
  run("sha256sum", ["-c", "SHA256SUMS"], { cwd: resolve(backupDir) });
  evidence.checks.backupIntegrity = true;
  const recoveryPoint = JSON.parse(readFileSync(resolve(backupDir, "recovery-point.json"), "utf8"));
  const recoveryPointMs = Date.parse(recoveryPoint.captured_at);
  const disasterAt = process.env.DR_DISASTER_AT ? Date.parse(process.env.DR_DISASTER_AT) : NaN;
  if (recoveryPoint.format !== "tareeq-backup-recovery-point-v1" || !Number.isFinite(recoveryPointMs)) fail("invalid backup recovery point metadata");
  if (!Number.isFinite(disasterAt) || disasterAt < recoveryPointMs) fail("DR_DISASTER_AT must be an ISO timestamp at/after the backup recovery point");
  const dataLossWindow = Math.ceil((disasterAt - recoveryPointMs) / 1000);
  evidence.recoveryPointAt = new Date(recoveryPointMs).toISOString();
  evidence.disasterAt = new Date(disasterAt).toISOString();
  evidence.rpoMeasuredSeconds = dataLossWindow;
  evidence.checks.rpo = dataLossWindow <= rpo;
  if (!evidence.checks.rpo) fail(`RPO exceeded: ${dataLossWindow}s > ${rpo}s`);
  // RTO starts at the declared service-disruption/disaster timestamp, not when this script happens to start.
  const began = disasterAt;
  const source = JSON.parse(
    run("docker", ["compose", "-f", resolve(compose), "config", "--format", "json"], {
      capture: true,
    }),
  );
  sandbox = createSandbox(source);
  evidence.project = sandbox.project;
  tempDir = mkdtempSync(join(tmpdir(), "tareeq-dr-"));
  const configPath = join(tempDir, "compose.json");
  writeFileSync(configPath, JSON.stringify(sandbox.config), { mode: 0o600 });
  composeArgs = ["compose", "-p", sandbox.project, "-f", configPath];
  guard = isolationGuard(sandbox, (args) => run("docker", args, { capture: true }));
  guard.begin();
  run("docker", [
    ...composeArgs,
    "up",
    "-d",
    "--no-build",
    "--wait",
    "--wait-timeout",
    "180",
    "db",
  ]);
  evidence.databaseContainer = guard.verifyDatabase();
  evidence.checks.isolationVerified = true;
  evidence.checks.cleanDatabaseStarted = true;
  // Restore globals then custom dump into the clean cluster.
  const roles = readFileSync(resolve(backupDir, "db-roles.sql"));
  run(
    "docker",
    [
      ...composeArgs,
      "exec",
      "-T",
      "db",
      "psql",
      "-X",
      "-U",
      "postgres",
      "-d",
      "postgres",
      "-v",
      "ON_ERROR_STOP=1",
    ],
    { input: roles },
  );
  const dump = readFileSync(resolve(backupDir, "db.dump"));
  run(
    "docker",
    [
      ...composeArgs,
      "exec",
      "-T",
      "db",
      "pg_restore",
      "-U",
      "postgres",
      "-d",
      "postgres",
      "--clean",
      "--if-exists",
      "--exit-on-error",
    ],
    { input: dump, timeout: 900000 },
  );
  evidence.checks.databaseRestore = true;
  const expected = readFileSync(resolve(backupDir, "db-metrics.txt"), "utf8").trim();
  const actual = run(
    "docker",
    [
      ...composeArgs,
      "exec",
      "-T",
      "db",
      "psql",
      "-X",
      "-U",
      "postgres",
      "-d",
      "postgres",
      "-qAt",
      "-v",
      "ON_ERROR_STOP=1",
      "-c",
      "SELECT (SELECT count(*) FROM auth.users), (SELECT count(*) FROM public.routes), (SELECT count(*) FROM public.community_routes)",
    ],
    { capture: true },
  );
  evidence.dataCounts = { expected, actual };
  evidence.checks.dataIntegrity = actual === expected;
  if (!evidence.checks.dataIntegrity) fail("restored row-count integrity mismatch");
  // Catalog/schema proof against canonical SQL snapshot when psql endpoint is supplied for isolated DB.
  const fp = run(
    "docker",
    [
      ...composeArgs,
      "exec",
      "-T",
      "db",
      "psql",
      "-X",
      "-U",
      "postgres",
      "-d",
      "postgres",
      "-qAt",
      "-f",
      "/dev/stdin",
    ],
    { capture: true, input: readFileSync("scripts/schema-fingerprint.sql") },
  );
  JSON.parse(fp);
  const sourceSchema = readFileSync(resolve(backupDir, "source-schema-fingerprint.json"), "utf8").trim();
  JSON.parse(sourceSchema);
  evidence.sourceSchemaSha256 = createHash("sha256").update(sourceSchema).digest("hex");
  evidence.restoredSchemaSha256 = createHash("sha256").update(fp.trim()).digest("hex");
  evidence.checks.schemaIntegrity = evidence.restoredSchemaSha256 === evidence.sourceSchemaSha256;
  if (!evidence.checks.schemaIntegrity) fail("restored schema fingerprint differs from backup source schema");
  const sourceContent = JSON.parse(readFileSync(resolve(backupDir, "source-content-fingerprint.json"), "utf8"));
  const tableList = run("docker", [...composeArgs, "exec", "-T", "db", "psql", "-X", "-U", "postgres", "-d", "postgres", "-qAt", "-v", "ON_ERROR_STOP=1", "-c", "SELECT quote_ident(n.nspname)||'.'||quote_ident(c.relname) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE c.relkind='r' AND n.nspname IN ('public','auth') ORDER BY 1"], {capture:true}).split(/\n/).filter(Boolean);
  const restoredTables = [];
  for (const table of tableList) {
    const rows = run("docker", [...composeArgs, "exec", "-T", "db", "psql", "-X", "-U", "postgres", "-d", "postgres", "-qAt", "-v", "ON_ERROR_STOP=1", "-c", `COPY (SELECT row_to_json(t)::text FROM ${table} t ORDER BY row_to_json(t)::text COLLATE \"C\") TO STDOUT`], {capture:true});
    restoredTables.push({table, rows: rows === "" ? 0 : rows.split(/\n/).filter(Boolean).length, sha256:createHash("sha256").update(rows.trimEnd()).digest("hex")});
  }
  const restoredContent = {format:"tareeq-db-content-fingerprint-v1", tables:restoredTables};
  evidence.sourceContentSha256 = createHash("sha256").update(JSON.stringify(sourceContent)).digest("hex");
  evidence.restoredContentSha256 = createHash("sha256").update(JSON.stringify(restoredContent)).digest("hex");
  evidence.checks.contentIntegrity = evidence.restoredContentSha256 === evidence.sourceContentSha256;
  if (!evidence.checks.contentIntegrity) fail("restored database content fingerprint differs from backup source content");
  // Global telemetry/provider commands can target production. They are never run here.
  evidence.checks.telemetryRecovered = false;
  evidence.checks.trafficRestored = false;
  evidence.elapsedSeconds = Math.max(0, Math.ceil((Date.now() - began) / 1000));
  evidence.checks.rto = evidence.elapsedSeconds <= rto;
  if (!evidence.checks.rto) fail(`RTO exceeded: ${evidence.elapsedSeconds}s > ${rto}s`);
  evidence.databaseRecoveryPassed = true;
  evidence.blockedReasons = [
    "Full recovery certification requires isolated service, telemetry and traffic recovery evidence.",
  ];
} catch (e) {
  evidence.error = e instanceof Error ? e.message : String(e);
  evidence.elapsedSeconds =
    evidence.elapsedSeconds ?? Math.ceil((Date.now() - Date.parse(evidence.startedAt)) / 1000);
} finally {
  evidence.cleanup = guard ? guard.cleanup() : { attempted: false, removed: [], errors: [] };
  if (evidence.cleanup.errors.length) {
    evidence.passed = false;
    evidence.error = [evidence.error, "sandbox cleanup failed"].filter(Boolean).join("; ");
  }
  if (tempDir) rmSync(tempDir, { recursive: true, force: true });
  evidence.completedAt = new Date().toISOString();
  writeFileSync(
    "artifacts/disaster-recovery-certification.json",
    JSON.stringify(evidence, null, 2) + "\n",
    { mode: 0o600 },
  );
  console.log(JSON.stringify(evidence, null, 2));
}
if (!evidence.passed) process.exit(1);
