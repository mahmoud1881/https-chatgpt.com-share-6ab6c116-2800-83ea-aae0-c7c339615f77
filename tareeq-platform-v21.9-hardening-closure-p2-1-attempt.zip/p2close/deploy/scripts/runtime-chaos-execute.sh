#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/../.."
fail(){ echo "runtime-chaos bootstrap: $*" >&2; exit 2; }
command -v docker >/dev/null || fail "Docker is required"
docker compose version >/dev/null 2>&1 || fail "Docker Compose v2 is required"
[[ -f deploy/.env ]] || fail "deploy/.env is required (copy deploy/.env.example and supply real certification credentials)"
: "${CHAOS_CERTIFICATION_TOKEN:?CHAOS_CERTIFICATION_TOKEN (>=24 chars) is required}"
(( ${#CHAOS_CERTIFICATION_TOKEN} >= 24 )) || fail "CHAOS_CERTIFICATION_TOKEN must be >=24 chars"
export TELEMETRY_PUBLIC_PROBE_URL="${TELEMETRY_PUBLIC_PROBE_URL:-http://127.0.0.1:3000/}"
export TEMPO_URL="${TEMPO_URL:-http://127.0.0.1:3200}"
export PROMETHEUS_URL="${PROMETHEUS_URL:-http://127.0.0.1:9090}"
# Start the observability prerequisites explicitly. Never silently skip telemetry certification.
docker compose --env-file deploy/.env -f deploy/docker-compose.yml up -d db kong otel-collector tempo postgres-exporter prometheus app
wait_http(){ local name="$1" url="$2"; for _ in $(seq 1 60); do if curl -fsS --max-time 3 "$url" >/dev/null 2>&1; then echo "✓ $name ready"; return 0; fi; sleep 2; done; fail "$name not ready: $url"; }
wait_http tempo "$TEMPO_URL/ready"
wait_http prometheus "$PROMETHEUS_URL/-/ready"
wait_http application "$TELEMETRY_PUBLIC_PROBE_URL"
# pg_up is a hard prerequisite; give exporter/scrape a short convergence window.
for _ in $(seq 1 30); do
  body="$(curl -fsS --get --data-urlencode 'query=pg_up' "$PROMETHEUS_URL/api/v1/query" 2>/dev/null || true)"
  if node -e 'const j=JSON.parse(process.argv[1]);process.exit(j.status==="success"&&j.data?.result?.some(x=>Number(x.value?.[1])===1)?0:1)' "$body" 2>/dev/null; then echo '✓ postgres exporter ready'; break; fi
  sleep 2
  [[ $_ -lt 30 ]] || fail "Prometheus pg_up never became 1"
done
node deploy/scripts/runtime-chaos-certification.mjs
