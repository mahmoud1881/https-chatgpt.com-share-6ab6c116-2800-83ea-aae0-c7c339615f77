import { writeFileSync } from "node:fs";
import { hostname } from "node:os";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
export const restoreChecks = [
  "downloadChecksum",
  "archiveChecksum",
  "databaseRestore",
  "rowCounts",
  "roles",
  "services",
  "auth",
  "realtime",
  "cleanup",
];

export function requireRestoreEvidence(report, expected, now = Date.now()) {
  const age = now - Date.parse(report?.measured_at);
  const start = Date.parse(report?.started_at);
  if (
    !/^[a-f0-9]{64}$/i.test(expected.sha256 ?? "") ||
    !/^[a-f0-9]{40}$/i.test(expected.release ?? "") ||
    !/^[0-9]{8}T[0-9]{6}Z-[a-f0-9]{6}$/.test(expected.backupId ?? "") ||
    report?.schema_version !== 2 ||
    report.status !== "passed" ||
    report.backup_id !== expected.backupId ||
    report.backup_sha256 !== expected.sha256 ||
    report.restored_release !== expected.release ||
    !Number.isFinite(age) ||
    age < 0 ||
    age > 7 * 86400000 ||
    !Number.isFinite(start) ||
    !Number.isFinite(report.elapsed_seconds) ||
    report.elapsed_seconds < 0 ||
    !Number.isInteger(report.rto_target_seconds) ||
    report.rto_target_seconds <= 0 ||
    report.rto_target_seconds > 3600 ||
    report.elapsed_seconds > report.rto_target_seconds ||
    Math.abs((Date.parse(report.measured_at) - start) / 1000 - report.elapsed_seconds) > 1 ||
    !/^tareeqdr[0-9]+[a-f0-9]{4}$/.test(report.isolated_project ?? "") ||
    !report.restore_host ||
    !restoreChecks.every((check) => report.checks?.[check] === true)
  )
    throw new Error(
      "Complete recent isolated restore evidence matching the selected backup and release is required",
    );
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const [
    output,
    backup_id,
    status,
    start,
    rto,
    backup_sha256,
    restored_release,
    isolated_project,
    completed,
  ] = process.argv.slice(2);
  const end = Date.now(),
    began = Number(start) * 1000;
  const checks = new Set(completed.split(","));
  const report = {
    schema_version: 2,
    backup_id,
    status,
    backup_sha256,
    restored_release,
    isolated_project,
    started_at: new Date(began).toISOString(),
    measured_at: new Date(end).toISOString(),
    elapsed_seconds: Math.floor((end - began) / 1000),
    rto_target_seconds: Number(rto),
    restore_host: hostname(),
    checks: Object.fromEntries(restoreChecks.map((check) => [check, checks.has(check)])),
  };
  writeFileSync(output, JSON.stringify(report, null, 2) + "\n", { mode: 0o600 });
}
