import {mkdirSync,writeFileSync,readFileSync,existsSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const stage=Number(process.env.CANARY_PERCENT||0), decision=process.env.INCIDENT_DECISION||'abort';
const deploymentId=process.env.DEPLOYMENT_ID||'unknown', correlationId=process.env.CORRELATION_ID||`${deploymentId}:stage-${stage}`;
function dockerLogs(service){const r=spawnSync('docker',['compose','--project-directory','deploy','--profile','canary','logs','--no-color','--tail',String(Number(process.env.INCIDENT_LOG_LINES||500)),service],{encoding:'utf8',timeout:30000});return r.status===0?r.stdout:`<unavailable: ${(r.stderr||r.error?.message||'').trim()}>`;}
let slo=null;const sf=`artifacts/canary-stage-${stage}.json`;if(existsSync(sf))try{slo=JSON.parse(readFileSync(sf,'utf8'));}catch{}
const candidateLogs=dockerLogs('candidate'), stableLogs=dockerLogs('app');
const traceRe=/\b[0-9a-f]{32}\b/gi;const traceIds=[...new Set([...(candidateLogs.match(traceRe)||[]),...(stableLogs.match(traceRe)||[]),...(JSON.stringify(slo||{}).match(traceRe)||[])])].slice(0,500);
const classify=(text)=>({database:(text.match(/(?:postgres|database|supabase).*(?:error|fail|timeout)|(?:error|fail|timeout).*(?:postgres|database|supabase)/gi)||[]).length,external:(text.match(/(?:fetch|upstream|external|api|oauth|smtp|network).*(?:error|fail|timeout)|(?:error|fail|timeout).*(?:fetch|upstream|external|api|oauth|smtp|network)/gi)||[]).length,application:(text.match(/\b(?:error|exception|fatal|unhandled|5\d\d)\b/gi)||[]).length});
const cc=classify(candidateLogs),sc=classify(stableLogs);const degraded={};for(const k of Object.keys(cc))degraded[k]={candidate:cc[k],stable:sc[k],delta:cc[k]-sc[k]};
const bundle={format:'tareeq-v21.3-incident-evidence-v1',deploymentId,correlationId,stagePercent:stage,decision,createdAt:new Date().toISOString(),traceIds,slo,degraded,problems:slo?.problems||[],timeline:{stageStartedAt:slo?.startedAt||null,stageCompletedAt:slo?.completedAt||null,incidentCreatedAt:new Date().toISOString()},logs:{candidate:candidateLogs,stable:stableLogs}};
mkdirSync(`artifacts/incidents/${deploymentId}`,{recursive:true});const out=`artifacts/incidents/${deploymentId}/stage-${stage}-${decision}.json`;writeFileSync(out,JSON.stringify(bundle,null,2)+'\n');console.log(`✓ incident evidence: ${out}`);
