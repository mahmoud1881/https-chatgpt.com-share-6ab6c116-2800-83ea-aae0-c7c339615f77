#!/usr/bin/env bash
# Interactive bootstrap for the FULL self-hosted stack:
#   - App (TanStack Start)
#   - Postgres + GoTrue + PostgREST + Realtime + postgres-meta + Studio + Kong
#
# Generates all secrets locally. No *.supabase.co dependency.
set -euo pipefail
cd "$(dirname "$0")/.."

if [[ -f .env ]]; then
  read -rp "⚠️  .env already exists. Overwrite? [y/N] " yn
  [[ "$yn" =~ ^[Yy]$ ]] || { echo "Aborted."; exit 1; }
  cp .env ".env.backup.$(date +%s)"
fi

command -v openssl >/dev/null || { echo "❌ openssl is required"; exit 1; }
command -v docker >/dev/null || { echo "❌ docker is required to generate the Studio bcrypt credential"; exit 1; }

# ---------------------------------------------------------------------
# Public hostname validation.
#
# VITE_SUPABASE_URL is baked into the browser JS bundle at build time.
# It MUST be the public hostname served by Caddy (the reverse proxy) —
# NEVER the internal service name (`kong`, `db`, `localhost`, etc.),
# because the browser resolves it from the end user's machine.
#
# Rules enforced:
#   - non-empty
#   - contains a dot (FQDN-like)      → rejects "kong", "localhost"
#   - no scheme, no path, no port     → rejects "https://x", "x/y", "x:8000"
#   - not a reserved internal name    → rejects db|kong|auth|rest|realtime|meta|studio|app
#   - no whitespace, lowercase only where possible
# ---------------------------------------------------------------------
validate_public_host() {
  local label="$1" value="$2"
  local reserved='^(kong|db|auth|rest|realtime|meta|studio|app|caddy|localhost)$'
  if [[ -z "$value" ]]; then
    echo "❌ $label is required." >&2; return 1
  fi
  if [[ "$value" == *"://"* || "$value" == */* || "$value" == *:* ]]; then
    echo "❌ $label must be a bare hostname, not a URL or host:port. Got: $value" >&2; return 1
  fi
  if [[ "$value" != *.* ]]; then
    echo "❌ $label must be a fully-qualified domain (needs a dot). Got: $value" >&2
    echo "   The browser must reach this host over the public internet — internal names like 'kong' will not work." >&2
    return 1
  fi
  if [[ "$value" =~ [[:space:]] ]]; then
    echo "❌ $label contains whitespace." >&2; return 1
  fi
  if [[ "${value,,}" =~ $reserved ]]; then
    echo "❌ $label uses a reserved internal service name ($value). Use a public hostname behind Caddy." >&2; return 1
  fi
  return 0
}

echo "▶ Self-Host Deploy Kit bootstrap (full stack)"
echo ""
echo "  ⚠ These three hostnames are PUBLIC — they must have DNS A records"
echo "    pointing at this server. They are baked into the app bundle at"
echo "    build time and cannot be changed without a rebuild."
echo ""

while :; do
  read -rp "  App domain     (e.g. app.example.com): " APP_DOMAIN
  validate_public_host "App domain" "$APP_DOMAIN" && break
done
while :; do
  read -rp "  API subdomain  [api.${APP_DOMAIN}]:    " API_DOMAIN
  API_DOMAIN=${API_DOMAIN:-api.${APP_DOMAIN}}
  validate_public_host "API subdomain" "$API_DOMAIN" && break
done
while :; do
  read -rp "  Studio subdom. [studio.${APP_DOMAIN}]: " STUDIO_DOMAIN
  STUDIO_DOMAIN=${STUDIO_DOMAIN:-studio.${APP_DOMAIN}}
  validate_public_host "Studio subdomain" "$STUDIO_DOMAIN" && break
done
read -rp "  Email for Let's Encrypt SSL: " LE_EMAIL

APP_URL="https://${APP_DOMAIN}"
SUPABASE_PUBLIC_URL="https://${API_DOMAIN}"   # external Caddy URL — used by the browser
# Note: server-side containers reach Supabase via http://kong:8000 (set in compose).

echo ""
echo "  About to bake into the browser bundle:"
echo "    VITE_SUPABASE_URL = ${SUPABASE_PUBLIC_URL}"
echo "  Rebuilding the app image is required if this ever changes."
read -rp "  Confirm? [y/N] " confirm
[[ "$confirm" =~ ^[Yy]$ ]] || { echo "Aborted."; exit 1; }


# --- HS256 JWT signer (pure bash + openssl) --------------------------
b64url() { openssl base64 -A | tr '+/' '-_' | tr -d '='; }
sign_jwt() {
  local secret="$1" payload="$2"
  local header='{"alg":"HS256","typ":"JWT"}'
  local h; h=$(printf '%s' "$header"  | b64url)
  local p; p=$(printf '%s' "$payload" | b64url)
  local sig
  sig=$(printf '%s.%s' "$h" "$p" \
        | openssl dgst -binary -sha256 -hmac "$secret" \
        | b64url)
  printf '%s.%s.%s' "$h" "$p" "$sig"
}

echo "▶ Generating secrets…"
POSTGRES_PASSWORD=$(openssl rand -hex 24)
JWT_SECRET=$(openssl rand -hex 32)                       # HS256 signing key (min 32 bytes)
REALTIME_SECRET_KEY_BASE=$(openssl rand -hex 32)
RATE_LIMIT_SALT=$(openssl rand -hex 32)
ROLLOUT_COOKIE_SECRET=$(openssl rand -hex 32)
DASHBOARD_USERNAME=admin
DASHBOARD_PASSWORD=$(openssl rand -hex 12)
# Caddy receives only the bcrypt verifier. Keep the cleartext credential for Studio/Kong.
STUDIO_BASIC_AUTH_USER=${DASHBOARD_USERNAME}
STUDIO_BASIC_AUTH_HASH=$(docker run --rm caddy:2.8-alpine caddy hash-password --plaintext "$DASHBOARD_PASSWORD")
[[ "$STUDIO_BASIC_AUTH_HASH" == '$2a$'* || "$STUDIO_BASIC_AUTH_HASH" == '$2b$'* || "$STUDIO_BASIC_AUTH_HASH" == '$2y$'* ]] || { echo "❌ failed to generate Studio bcrypt credential" >&2; exit 1; }
PROJECT_ID=$(openssl rand -hex 8)

IAT=$(date +%s)
EXP=$(( IAT + 60*60*24*365*10 ))                          # 10 years

ANON_PAYLOAD="{\"role\":\"anon\",\"iss\":\"supabase\",\"iat\":${IAT},\"exp\":${EXP}}"
SERVICE_PAYLOAD="{\"role\":\"service_role\",\"iss\":\"supabase\",\"iat\":${IAT},\"exp\":${EXP}}"
ANON_KEY=$(sign_jwt "$JWT_SECRET" "$ANON_PAYLOAD")
SERVICE_KEY=$(sign_jwt "$JWT_SECRET" "$SERVICE_PAYLOAD")

cat > .env <<EOF
# Generated $(date -u +%FT%TZ) by bootstrap.sh — DO NOT COMMIT
# ---- Domains ---------------------------------------------------------
APP_DOMAIN=${APP_DOMAIN}
API_DOMAIN=${API_DOMAIN}
STUDIO_DOMAIN=${STUDIO_DOMAIN}
STUDIO_BASIC_AUTH_USER=${STUDIO_BASIC_AUTH_USER}
STUDIO_BASIC_AUTH_HASH=${STUDIO_BASIC_AUTH_HASH}
LETSENCRYPT_EMAIL=${LE_EMAIL}
SITE_URL=${APP_URL}
VITE_AUTH_PROVIDER=supabase
RATE_LIMIT_SALT=${RATE_LIMIT_SALT}
ROLLOUT_COOKIE_SECRET=${ROLLOUT_COOKIE_SECRET}
SUPABASE_PUBLIC_URL=${SUPABASE_PUBLIC_URL}

# ---- App -------------------------------------------------------------
NODE_ENV=production
APP_PORT=3000

# ---- Postgres --------------------------------------------------------
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}

# ---- JWT / Supabase keys --------------------------------------------
JWT_SECRET=${JWT_SECRET}
REALTIME_SECRET_KEY_BASE=${REALTIME_SECRET_KEY_BASE}
SUPABASE_SERVICE_ROLE_KEY=${SERVICE_KEY}

# ---- Client build args (must NOT contain *.supabase.co) --------------
VITE_SUPABASE_URL=${SUPABASE_PUBLIC_URL}
VITE_SUPABASE_PUBLISHABLE_KEY=${ANON_KEY}
VITE_SUPABASE_PROJECT_ID=${PROJECT_ID}

# ---- Realtime --------------------------------------------------------
# external_id used to seed _realtime.tenants. Must match what the client
# uses (supabase-js derives it from the API host / apikey JWT).
REALTIME_TENANT=realtime-dev

# Set SMTP and one OAuth provider before running staging-verify.sh.
AUTH_AUTOCONFIRM=false
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASS=
SMTP_ADMIN_EMAIL=
SMTP_SENDER_NAME=Tareeq
GOOGLE_ENABLED=false
GOOGLE_CLIENT_ID=
GOOGLE_SECRET=
GITHUB_ENABLED=false
GITHUB_CLIENT_ID=
GITHUB_SECRET=

# ---- Studio dashboard basic auth ------------------------------------
DASHBOARD_USERNAME=${DASHBOARD_USERNAME}
DASHBOARD_PASSWORD=${DASHBOARD_PASSWORD}
EOF

chmod 600 .env

echo ""
echo "✅ .env generated."
echo ""
echo "  App:     ${APP_URL}"
echo "  API:     ${SUPABASE_PUBLIC_URL}"
echo "  Studio:  https://${STUDIO_DOMAIN}   (user: ${DASHBOARD_USERNAME} / pass: ${DASHBOARD_PASSWORD})"
echo ""
echo "Next:"
echo "  1) Point DNS A records for ${APP_DOMAIN}, ${API_DOMAIN}, ${STUDIO_DOMAIN} at this server."
echo "  2) ./scripts/deploy.sh"
