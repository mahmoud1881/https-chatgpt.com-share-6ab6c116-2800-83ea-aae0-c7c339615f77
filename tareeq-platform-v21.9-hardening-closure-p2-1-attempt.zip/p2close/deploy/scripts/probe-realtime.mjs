// Dependency-free Phoenix channel probe: an HTTP 101 alone is not sufficient.
import { createHash, randomBytes } from "node:crypto";
import { connect as tcp } from "node:net";
import { connect as tls } from "node:tls";

const endpoint = process.argv[2];
const key = process.env.VITE_SUPABASE_PUBLISHABLE_KEY;
if (!endpoint || !key) {
  console.error(
    "Usage: VITE_SUPABASE_PUBLISHABLE_KEY=<anon JWT> node probe-realtime.mjs <ws(s)://.../realtime/v1/websocket>",
  );
  process.exit(2);
}
const url = new URL(endpoint);
if (!["ws:", "wss:"].includes(url.protocol)) throw new Error("WebSocket URL required");
url.searchParams.set("apikey", key);
url.searchParams.set("vsn", "1.0.0");
const host = url.hostname;
const port = Number(url.port || (url.protocol === "wss:" ? 443 : 80));
const nonce = randomBytes(16).toString("base64");
const expected = createHash("sha1")
  .update(nonce + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11")
  .digest("base64");
const topic = `realtime:staging-probe-${randomBytes(6).toString("hex")}`;
const socket =
  url.protocol === "wss:"
    ? tls({ host, port, servername: host, rejectUnauthorized: true })
    : tcp({ host, port });
const timeout = setTimeout(() => finish(new Error("Realtime join timed out")), 12000);
let settled = false;
let headerDone = false;
let buffer = Buffer.alloc(0);
function finish(error) {
  if (settled) return;
  settled = true;
  clearTimeout(timeout);
  socket.destroy();
  if (error) {
    console.error(`Realtime FAIL: ${error.message}`);
    process.exitCode = 1;
  } else console.log("Realtime OK: WebSocket upgraded and Phoenix channel joined");
}
function sendJoin() {
  const body = Buffer.from(
    JSON.stringify({
      topic,
      event: "phx_join",
      payload: {
        config: { broadcast: { self: false }, presence: { key: "" } },
        access_token: key,
      },
      ref: "1",
    }),
  );
  const mask = randomBytes(4);
  const length = body.length;
  const prefix =
    length < 126
      ? Buffer.from([0x81, 0x80 | length])
      : Buffer.from([0x81, 0xfe, (length >> 8) & 255, length & 255]);
  const data = Buffer.alloc(length);
  for (let i = 0; i < length; i++) data[i] = body[i] ^ mask[i % 4];
  socket.write(Buffer.concat([prefix, mask, data]));
}
socket.on("error", finish);
socket.on("close", () => {
  if (!settled) finish(new Error("socket closed before channel joined"));
});
socket.on(url.protocol === "wss:" ? "secureConnect" : "connect", () => {
  socket.write(
    `GET ${url.pathname}${url.search} HTTP/1.1\r\nHost: ${host}${url.port ? `:${port}` : ""}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: ${nonce}\r\n\r\n`,
  );
});
socket.on("data", (chunk) => {
  if (settled) return;
  buffer = Buffer.concat([buffer, chunk]);
  if (!headerDone) {
    const end = buffer.indexOf("\r\n\r\n");
    if (end < 0) return;
    const headers = buffer.subarray(0, end).toString("utf8");
    const accept = headers.match(/^sec-websocket-accept:[ \t]*([^\r\n]+)/im)?.[1]?.trim();
    if (!/^HTTP\/1\.[01] 101\b/.test(headers) || accept !== expected) {
      finish(new Error("WebSocket upgrade or accept header rejected"));
      return;
    }
    buffer = buffer.subarray(end + 4);
    headerDone = true;
    sendJoin();
  }
  while (buffer.length >= 2) {
    const opcode = buffer[0] & 15;
    const masked = Boolean(buffer[1] & 128);
    let size = buffer[1] & 127;
    let offset = 2;
    if (size === 126) {
      if (buffer.length < 4) return;
      size = buffer.readUInt16BE(2);
      offset = 4;
    } else if (size === 127) {
      finish(new Error("unexpected oversized frame"));
      return;
    }
    if (masked) {
      finish(new Error("server sent masked frame"));
      return;
    }
    if (buffer.length < offset + size) return;
    const payload = buffer.subarray(offset, offset + size).toString("utf8");
    buffer = buffer.subarray(offset + size);
    if (opcode === 8) {
      finish(new Error("server closed channel"));
      return;
    }
    if (opcode !== 1) continue;
    let message;
    try {
      message = JSON.parse(payload);
    } catch {
      continue;
    }
    if (message.topic === topic && message.ref === "1" && message.event === "phx_reply") {
      finish(message.payload?.status === "ok" ? null : new Error("channel join rejected"));
      return;
    }
  }
});
