import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { createServer } from "node:net";
import { spawn } from "node:child_process";
import { once } from "node:events";

test("runtime identity comes from the image stamp despite environment/worker overrides", async () => {
  const dir = mkdtempSync(join(tmpdir(), "tareeq-release-"));
  const reservation = createServer();
  reservation.listen(0, "127.0.0.1");
  await once(reservation, "listening");
  const port = reservation.address().port;
  await new Promise((done) => reservation.close(done));
  const stamp = "a".repeat(40);
  mkdirSync(join(dir, "dist/server"), { recursive: true });
  mkdirSync(join(dir, "dist/client"), { recursive: true });
  writeFileSync(join(dir, ".release-commit"), stamp);
  writeFileSync(
    join(dir, "dist/server/index.mjs"),
    'export default {fetch(){return new Response("ok",{headers:{"X-Tareeq-Release":"worker-value","X-Tareeq-Channel":"candidate"}})}}',
  );
  const child = spawn(process.execPath, [resolve("deploy/app/server.mjs")], {
    cwd: dir,
    env: {
      ...process.env,
      PORT: String(port),
      HOST: "127.0.0.1",
      RELEASE_COMMIT: "b".repeat(40),
      RELEASE_CHANNEL: "stable",
      DIST_DIR: join(dir, "dist"),
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  try {
    let response;
    for (let attempt = 0; attempt < 100; attempt++) {
      try {
        response = await fetch(`http://127.0.0.1:${port}/`);
        break;
      } catch {
        await new Promise((done) => setTimeout(done, 25));
      }
    }
    assert.ok(response?.ok, "runtime did not start");
    assert.equal(response.headers.get("x-tareeq-release"), stamp);
    assert.equal(response.headers.get("x-tareeq-channel"), "stable");
  } finally {
    if (child.exitCode === null && child.signalCode === null) {
      const exited = once(child, "exit");
      child.kill();
      await exited;
    }
    rmSync(dir, { recursive: true, force: true });
  }
});
