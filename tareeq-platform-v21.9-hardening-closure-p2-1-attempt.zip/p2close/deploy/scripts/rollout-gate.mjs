import {promotionConfig,requireMailOAuth} from './promotion-policy.mjs';
// Inspect reviewed journey evidence and live operational signals before increasing exposure.
import { readFileSync, mkdirSync, writeFileSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { resolve } from "node:path";
import { requirePromotionLoad, rehearsalBootstrap } from "./promotion-load.mjs";
import { requireRestoreEvidence } from "./restore-evidence.mjs";
import {
  fingerprint,
  currentSamples,
  assertStateBoundGate,
  requireFunctionalRollback,
} from "./rollout-evidence.mjs";

const target = /^(1|5|25|50|100)$/.test(process.argv[2]||'')?Number(process.argv[2]):NaN;
const evidenceFile = process.argv[3];
if (![1, 5, 25, 50, 100].includes(target) || !evidenceFile) {
  console.error(
    "Usage: node scripts/rollout-gate.mjs <1|5|25|50|100> <reviewed-observations.json>",
  );
  process.exit(2);
}
const problems = [];
let mailOAuthReview;
try{promotionConfig();mailOAuthReview=requireMailOAuth();}catch(e){problems.push(`Promotion policy: ${e.message}`);}
try {
  const file = process.env.ROLLOUT_RESTORE_REPORT;
  if (!file) throw Error("Set ROLLOUT_RESTORE_REPORT to the isolated restore report");
  requireRestoreEvidence(JSON.parse(readFileSync(file, "utf8")), {
    backupId: process.env.ROLLOUT_RESTORE_BACKUP_ID,
    sha256: process.env.ROLLOUT_RESTORE_BACKUP_SHA256,
    release: process.env.ROLLOUT_RESTORE_RELEASE,
  });
} catch (e) {
  problems.push(`Restore evidence: ${e.message}`);
}
try {
  const file = process.env.ROLLOUT_LOAD_REPORT;
  if (!file) throw Error("Set ROLLOUT_LOAD_REPORT to the completed staging load report");
  requirePromotionLoad(
    JSON.parse(readFileSync(file, "utf8")),
    process.env.RELEASE_COMMIT,
    process.env.ROLLOUT_LOAD_SITE_URL,
    process.env.ROLLOUT_LOAD_API_URL,
  );
} catch (e) {
  problems.push(`Load evidence: ${e.message}`);
}
const data = { targetPercent: target, checkedAt: new Date().toISOString(), checks: {mailOAuthReview:mailOAuthReview??null} };
let trafficState;
try {
  const state = JSON.parse(readFileSync("backups/rollout/traffic-state.json", "utf8"));
  trafficState = state;
  data.stateFingerprint = fingerprint(state);
  data.stableImage = state.stableImage;
  const stages = [0, 1, 5, 25, 50, 100];
  if (stages[stages.indexOf(state.percent) + 1] !== target)
    problems.push("Cannot skip rollout stages");
  const elapsed = Date.now() - Date.parse(state.changedAt);
  if (!Number.isFinite(elapsed) || elapsed < (state.percent === 50 ? 48 : 24) * 3600000)
    problems.push("Current stage has not completed its minimum observation window");
  data.previousPercent = state.percent;
} catch {
  problems.push("Initialize closed-trial traffic state first");
}
function command(bin, args, opts = {}) {
  if(bin==="docker"&&args[0]==="compose")args=["compose","-p","platform","-f","docker-compose.yml",...args.slice(1)];
  const r = spawnSync(bin, args, { encoding: "utf8", timeout: 20000, ...opts });
  if (r.status !== 0 || r.error) throw Error(`${bin} failed (${r.status ?? r.error?.code})`);
  return r.stdout.trim();
}
try {
  const ledger = command("docker", [
    "compose",
    "exec",
    "-T",
    "db",
    "psql",
    "-X",
    "-U",
    "postgres",
    "-d",
    "postgres",
    "-v",
    "ON_ERROR_STOP=1",
    "-tAc",
    "SELECT string_agg(filename,',' ORDER BY filename) FROM platform_meta.applied_migrations",
  ]);
  if (!ledger) throw Error("Empty migration ledger");
  data.migrationFingerprint = fingerprint(ledger);
} catch (e) {
  problems.push(`Migration state: ${e.message}`);
}
try {
  const reference = JSON.parse(readFileSync(resolve(evidenceFile), "utf8"));
  const age = Date.now() - Date.parse(reference.captured_at);
  if (!Number.isFinite(age) || age < 0 || age > 24 * 3600000)
    problems.push("Trip review older than 24 hours");
  if (!process.env.RELEASE_COMMIT || reference.deployed_commit !== process.env.RELEASE_COMMIT)
    problems.push("Trip review does not match RELEASE_COMMIT");
  const benchmark = command("node", [
    "../scripts/evaluate-trip-benchmark.mjs",
    "../benchmarks/trips/core-eg.v1.json",
    resolve(evidenceFile),
  ]);
  data.checks.reviewedTrips =
    benchmark.split("\n").find((line) => line.startsWith("Reviewed")) || "passed";
} catch (e) {
  problems.push(`Reviewed trip benchmark: ${e.message}`);
}
try {
  const sql = `SELECT count(*),count(*) FILTER (WHERE result_status IN ('no_route','no_from','no_to','no_from_and_to'))
    FROM public.search_logs WHERE created_at >= now()-interval '24 hours';`;
  const line = command("docker", [
    "compose",
    "exec",
    "-T",
    "db",
    "psql",
    "-U",
    "postgres",
    "-d",
    "postgres",
    "-v",
    "ON_ERROR_STOP=1",
    "-tAc",
    sql,
  ]);
  const [searches, empty] = line.split("|").map(Number);
  const complaintsSql = `SELECT (SELECT count(*) FROM public.route_corrections WHERE created_at>=now()-interval '24 hours'),
    (SELECT count(*) FROM public.route_requests WHERE created_at>=now()-interval '24 hours');`;
  const [corrections, requests] = command("docker", [
    "compose",
    "exec",
    "-T",
    "db",
    "psql",
    "-U",
    "postgres",
    "-d",
    "postgres",
    "-v",
    "ON_ERROR_STOP=1",
    "-tAc",
    complaintsSql,
  ])
    .split("|")
    .map(Number);
  if (![searches, empty, corrections, requests].every(Number.isFinite))
    throw Error("Invalid DB counts");
  data.checks.quality = { searches, empty, corrections, requests };
  if (searches < (target === 1 ? 20 : 100))
    problems.push("Insufficient real searches in the last 24 hours");
  if (searches && empty / searches > 0.25) problems.push("Unresolved journey search rate >25%");
  if (searches && (corrections + requests) / searches > 0.02)
    problems.push("New correction/request reports >2 per 100 searches");
} catch (e) {
  problems.push(`Database quality counters: ${e.message}`);
}
try {
  const samples = currentSamples(
    readFileSync("backups/monitor.jsonl", "utf8")
      .trim()
      .split("\n")
      .map((s) => JSON.parse(s)),
    trafficState,
    trafficState?.candidateImage,
  );
  const recent = samples.filter((s) => Date.now() - Date.parse(s.at) < 30 * 60000);
  const requests = samples.reduce((n, s) => n + (s.checks.appTraffic?.requests || 0), 0);
  const errors = samples.reduce((n, s) => n + (s.checks.appTraffic?.errors || 0), 0);
  data.checks.monitor = {
    samples: samples.length,
    requests,
    errors,
    recentAlerts: recent.filter((s) => s.alerts?.length).length,
  };
  if (samples.length < 10 || recent.length < 5)
    problems.push("Insufficient fresh monitoring coverage");
  if (recent.some((s) => s.alerts?.length)) problems.push("Unresolved monitoring alerts");
  if (recent.some((s) => s.checks.app?.ok !== true || s.checks.app?.identityOk !== true))
    problems.push("Live public route health/release identity failed");
  if (
    !recent.some(
      (s) =>
        s.checks.journey?.ok === true &&
        s.checks.journey.search === true &&
        s.checks.journey.planner === true &&
        Date.now() - Date.parse(s.checks.journey.at) >= 0 &&
        Date.now() - Date.parse(s.checks.journey.at) < 3600000,
    )
  )
    problems.push("Fresh public browser search/planner evidence required");
  if (requests < 20 || errors / requests > 0.01)
    problems.push("Application 5xx rate or traffic sample failed");
  const candidateSamples = samples.filter((s) => s.checks.candidate?.ok === true);
  const candidateRequests = candidateSamples.reduce(
    (n, s) => n + (s.checks.candidateTraffic?.requests || 0),
    0,
  );
  const candidateErrors = candidateSamples.reduce(
    (n, s) => n + (s.checks.candidateTraffic?.errors || 0),
    0,
  );
  data.checks.candidateTraffic = {
    samples: candidateSamples.length,
    requests: candidateRequests,
    errors: candidateErrors,
    images: [...new Set(candidateSamples.map((s) => s.checks.candidate.image))],
  };
  if (
    candidateSamples.length < 10 ||
    candidateRequests < 20 ||
    candidateErrors / candidateRequests > 0.01
  )
    problems.push("Candidate-specific health and traffic evidence incomplete or failing");
} catch (e) {
  problems.push(`Monitoring report: ${e.message}`);
}
try {
  const review = JSON.parse(readFileSync("backups/rollout/safety-review.json", "utf8"));
  const age = Date.now() - Date.parse(review.reviewedAt);
  if (!Number.isFinite(age) || age < 0 || age > 24 * 3600000 || !review.reviewer)
    problems.push("Missing fresh named safety review");
  if (review.unresolvedUnsafeJourneys !== 0 || review.criticalIncidents !== 0)
    problems.push("Safety review reports unsafe journeys or critical incidents");
  if (review.schemaBackwardCompatible !== true)
    problems.push("Old/new application schema compatibility not approved");
  if (
    review.stateFingerprint !== data.stateFingerprint ||
    review.candidateImage !== trafficState?.candidateImage ||
    review.stableImage !== data.stableImage
  )
    problems.push("Safety review does not match current stage/images");
  if (!data.migrationFingerprint || review.migrationFingerprint !== data.migrationFingerprint)
    problems.push("Safety review does not match current migrations");
  data.checks.safety = {
    reviewer: review.reviewer,
    reviewedAt: review.reviewedAt,
    unresolvedUnsafeJourneys: review.unresolvedUnsafeJourneys,
    criticalIncidents: review.criticalIncidents,
  };
} catch (e) {
  problems.push(`Safety review: ${e.message}`);
}
try {
  const id = command("docker", ["compose", "--profile", "canary", "ps", "-q", "candidate"]);
  const state = command("docker", ["inspect", "-f", "{{.State.Health.Status}}", id]);
  if (state !== "healthy") problems.push("Candidate container is not healthy");
  data.candidateImage = command("docker", ["inspect", "-f", "{{.Image}}", id]);
  const stableId = command("docker", ["compose", "ps", "-q", "app"]);
  const stableImage = command("docker", ["inspect", "-f", "{{.Image}}", stableId]);
  assertStateBoundGate(
    data,
    trafficState,
    stableImage,
    data.candidateImage,
    readFileSync("caddy/rollout.caddy", "utf8"),
  );
  const revision = command("docker", [
    "inspect",
    "-f",
    '{{index .Config.Labels "org.opencontainers.image.revision"}}',
    id,
  ]);
  if (
    !process.env.RELEASE_COMMIT ||
    revision !== process.env.RELEASE_COMMIT ||
    revision === "unknown"
  )
    problems.push("Candidate image revision does not match RELEASE_COMMIT");
  if (data.checks.candidateTraffic?.images?.some((image) => image !== data.candidateImage))
    problems.push("Monitoring includes a different candidate image");
  data.checks.rehearsalBootstrap = rehearsalBootstrap(target, process.env);
  if (data.checks.rehearsalBootstrap)
    data.checks.bootstrapSite = new URL(process.env.SITE_URL).origin;
  if (!data.checks.rehearsalBootstrap) {
    const rollback = JSON.parse(readFileSync("backups/rollout/rollback-rehearsal.json", "utf8"));
    requireFunctionalRollback(
      rollback,
      stableImage,
      data.candidateImage,
      data.migrationFingerprint,
    );
  }
} catch (e) {
  problems.push(`Candidate image: ${e.message}`);
}
data.problems = problems;
data.passed = problems.length === 0;
mkdirSync("backups/rollout", { recursive: true, mode: 0o700 });
writeFileSync("backups/rollout/latest-gate.json", JSON.stringify(data, null, 2), { mode: 0o600 });
console.log(
  data.passed ? `PASS: candidate may receive ${target}%` : `BLOCKED: ${problems.join("; ")}`,
);
if (!data.passed) process.exitCode = 1;
