import { test } from "node:test";
import assert from "node:assert/strict";
import { stagingContext, assertStagingProof, assertStagingRelease } from "./staging-evidence.mjs";
import { assertMigrationLedger } from "./check-migration-ledger.mjs";

const now = Date.parse("2026-09-23T12:00:00Z");
test("HTTP success cannot substitute for the deployed release identity", () => {
  const expected = "a".repeat(40);
  assert.doesNotThrow(() =>
    assertStagingRelease(
      new Response("ok", { headers: { "X-Tareeq-Release": expected } }),
      expected,
    ),
  );
  for (const release of ["", "unknown", "b".repeat(40)])
    assert.throws(() =>
      assertStagingRelease(
        new Response("ok", { headers: { "X-Tareeq-Release": release } }),
        expected,
      ),
    );
});
const env = {
  RELEASE_COMMIT: "a".repeat(40),
  SITE_URL: "https://staging.example.com",
  SUPABASE_PUBLIC_URL: "https://api.staging.example.com",
  STUDIO_DOMAIN: "studio.staging.example.com",
  STAGING_EXPECTED_IPV4: "192.0.2.1",
  STAGING_TEST_EMAIL: "probe@example.com",
  STAGING_OAUTH_PROVIDER: "google",
  STAGING_OAUTH_EXPECTED_HOST: "accounts.google.com",
  STAGING_PROBE_ID: "current-run",
  STAGING_EMAIL_RECEIVED_AT: "2026-09-23T11:55:00Z",
  STAGING_OAUTH_CALLBACK_AT: "2026-09-23T11:56:00Z",
};
const proof = {
  id: env.STAGING_PROBE_ID,
  context: stagingContext(env),
  startedAt: "2026-09-23T11:50:00Z",
};
test("current staging observations are accepted", () =>
  assert.doesNotThrow(() => assertStagingProof(proof, env, now)));
test("evidence cannot move between releases, targets, users or probes", () => {
  for (const [key, value] of Object.entries({
    RELEASE_COMMIT: "b".repeat(40),
    SITE_URL: "https://production.example.com",
    SUPABASE_PUBLIC_URL: "https://other.example.com",
    STAGING_TEST_EMAIL: "other@example.com",
    STAGING_PROBE_ID: "old-run",
    STAGING_OAUTH_PROVIDER: "github",
  }))
    assert.throws(() => assertStagingProof(proof, { ...env, [key]: value }, now));
});
test("incomplete, old, future and expired attestations fail", () => {
  for (const time of [undefined, "invalid", "2026-09-23T11:49:00Z", "2026-09-23T12:01:00Z"])
    assert.throws(() =>
      assertStagingProof(proof, { ...env, STAGING_EMAIL_RECEIVED_AT: time }, now),
    );
  assert.throws(() => assertStagingProof(proof, env, now + 3600000));
  assert.throws(() => stagingContext({ ...env, RELEASE_COMMIT: "unknown" }));
});
test("all source migrations are required; empty, partial and foreign ledgers fail", () => {
  assert.doesNotThrow(() => assertMigrationLedger(["a.sql", "b.sql"], ["b.sql", "a.sql"]));
  for (const ledger of [[], ["a.sql"], ["a.sql", "b.sql", "c.sql"], ["a.sql", "a.sql"], null])
    assert.throws(() => assertMigrationLedger(["a.sql", "b.sql"], ledger));
  assert.throws(() => assertMigrationLedger([], []));
});
