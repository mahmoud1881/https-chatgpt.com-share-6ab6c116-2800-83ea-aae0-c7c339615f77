import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  immutableRelease,
  inspectCandidate,
  checkpoint,
  BINDING_PHASES,
} from "./runtime-image-binding.mjs";
function fixture() {
  const env = {
    RELEASE_IMAGE_REF: "registry.example/team/app",
    RELEASE_IMAGE_DIGEST: "sha256:" + "a".repeat(64),
    RELEASE_COMMIT: "b".repeat(40),
    CERTIFICATION_RUN_ID: "run-123",
  };
  const ref = immutableRelease(env),
    id = "c".repeat(64),
    imageId = "sha256:" + "d".repeat(64);
  const image = { Id: imageId, RepoDigests: [ref] },
    container = {
      Id: id,
      Image: imageId,
      Config: {
        Image: ref,
        Labels: {
          "com.docker.compose.project": "platform",
          "com.docker.compose.service": "candidate",
        },
      },
      State: { Running: true },
      Mounts: [],
    };
  let ids = id;
  const calls = [];
  const run = (args) => {
    calls.push(args);
    if (args.includes("ps")) return ids;
    if (args[0] === "image") return JSON.stringify([image]);
    return JSON.stringify([container]);
  };
  return { env, ref, image, container, run, calls, setIds: (s) => (ids = s) };
}
test("single immutable reference shared by scanner and deployment", () => {
  const f = fixture();
  assert.equal(
    immutableRelease({ ...f.env, NEW_RELEASE: f.ref, CANDIDATE_APP_IMAGE: f.ref }),
    f.ref,
  );
});
for (const ref of [
  "app:latest",
  "registry.example/app:tag",
  "registry.example/app@sha256:abc",
  "registry.example/app;touch file",
  "registry.example/../app",
])
  test(`reject mutable or unsafe repository ${ref}`, () =>
    assert.throws(() => immutableRelease({ ...fixture().env, RELEASE_IMAGE_REF: ref })));
for (const key of ["NEW_RELEASE", "CANDIDATE_APP_IMAGE"])
  test(`reject divergent ${key}`, () =>
    assert.throws(() => immutableRelease({ ...fixture().env, [key]: "app:latest" }), /differs/));
test("actual matching running candidate accepted", () => {
  const f = fixture();
  assert.equal(inspectCandidate(f.env, f.run).imageId, f.image.Id);
});
for (const [name, mutate] of [
  ["wrong container image ID", (f) => (f.container.Image = "sha256:" + "e".repeat(64))],
  ["tagged container configuration", (f) => (f.container.Config.Image = "app:latest")],
  ["repository digest absent", (f) => (f.image.RepoDigests = [])],
  ["stopped container", (f) => (f.container.State.Running = false)],
  [
    "wrong compose service",
    (f) => (f.container.Config.Labels["com.docker.compose.service"] = "app"),
  ],
  [
    "wrong compose project",
    (f) => (f.container.Config.Labels["com.docker.compose.project"] = "other"),
  ],
  ["filesystem override", (f) => (f.container.Mounts = [{ Type: "bind", Destination: "/app" }])],
  ["missing candidate", (f) => f.setIds("")],
  ["multiple candidates", (f) => f.setIds("c".repeat(64) + "\n" + "e".repeat(64))],
])
  test(`reject ${name}`, () => {
    const f = fixture();
    mutate(f);
    assert.throws(() => inspectCandidate(f.env, f.run));
  });
test("Docker errors cannot pass identity check", () =>
  assert.throws(
    () =>
      inspectCandidate(fixture().env, () => {
        throw Error("daemon down");
      }),
    /daemon down/,
  ));
test("all nine checkpoints recorded with same actual container", () => {
  const f = fixture(),
    dir = mkdtempSync(join(tmpdir(), "image-binding-")),
    path = join(dir, "report.json");
  try {
    for (const phase of BINDING_PHASES) checkpoint(phase, { ...f, path });
    const report = JSON.parse(readFileSync(path));
    assert.equal(report.passed, true);
    assert.equal(report.samples.length, 9);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
test("replacing candidate with same image still requires retesting", () => {
  const f = fixture(),
    dir = mkdtempSync(join(tmpdir(), "image-binding-")),
    path = join(dir, "report.json");
  try {
    checkpoint(BINDING_PHASES[0], { ...f, path });
    f.container.Id = "e".repeat(64);
    f.setIds(f.container.Id);
    assert.throws(() => checkpoint(BINDING_PHASES[1], { ...f, path }), /replaced/);
    assert.equal(JSON.parse(readFileSync(path)).passed, false);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
test("missing initial checkpoint cannot be bypassed by signing", () => {
  const f = fixture(),
    dir = mkdtempSync(join(tmpdir(), "image-binding-")),
    path = join(dir, "report.json");
  try {
    assert.throws(() => checkpoint("before-signing", { ...f, path }), /missing/);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
