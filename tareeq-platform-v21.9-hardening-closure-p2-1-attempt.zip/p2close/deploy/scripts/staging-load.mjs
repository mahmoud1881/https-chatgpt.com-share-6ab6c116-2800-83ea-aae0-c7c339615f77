// Browser journeys plus an authenticated public write. Run against disposable staging only.
import { chromium } from "@playwright/test";
import { mkdirSync, writeFileSync, readFileSync } from "node:fs";
import { randomUUID } from "node:crypto";
import { performance } from "node:perf_hooks";
import { assertJourneyResult } from "./load-result.mjs";
import { loadLimits, summarizeLoad, assertWrittenRoute } from "./load-metrics.mjs";
import { assertStagingRelease } from "./staging-evidence.mjs";

import { loadPlan, validateLoadProfile, assignment } from "./load-profile.mjs";
const env = process.env;
const site = new URL(env.SITE_URL || "");
const api = new URL(env.SUPABASE_PUBLIC_URL || "");
if (
  site.protocol !== "https:" ||
  api.protocol !== "https:" ||
  !/staging|stage|test/i.test(site.hostname)
) {
  throw new Error("Only HTTPS staging/test hosts are allowed");
}
for (const key of [
  "VITE_SUPABASE_PUBLISHABLE_KEY",
  "LOAD_PROFILE_FILE",
  "TAREEQ_STAGING_LOAD_CLEANUP_API_KEY",
  "TAREEQ_STAGING_LOAD_CLEANUP_TOKEN",
]) {
  if (!env[key]) throw new Error(`Missing ${key}`);
}
if (!/^[a-f0-9]{40}$/i.test(env.RELEASE_COMMIT ?? ""))
  throw new Error("Set RELEASE_COMMIT before measuring load");
const profile = JSON.parse(readFileSync(env.LOAD_PROFILE_FILE, "utf8"));
const coverage = validateLoadProfile(profile, site.origin, api.origin);
const stages = loadPlan;
const limits = loadLimits;
const report = {
  schemaVersion: 2,
  coverage,
  workload: "closed-loop-browser-and-authenticated-write",
  startedAt: new Date().toISOString(),
  site: site.origin,
  api: api.origin,
  releaseCommit: env.RELEASE_COMMIT,
  plan: stages,
  thresholds: limits,
  stages: [],
};
const anon = env.VITE_SUPABASE_PUBLISHABLE_KEY;
const headers = { apikey: anon, "content-type": "application/json" };
const deadline = 15000;
const marker = `load-${randomUUID()}`;
const created = new Set();
let sessions = [];

async function login(account) {
  const r = await fetch(new URL("/auth/v1/token?grant_type=password", api), {
    method: "POST",
    headers,
    body: JSON.stringify({ email: account.email, password: account.password }),
    signal: AbortSignal.timeout(deadline),
  });
  const body = await r.json();
  if (!r.ok || !body.access_token || !body.user?.id)
    throw new Error("Staging test account login failed");
  return { token: body.access_token, userId: body.user.id };
}
async function writeJourney({ userId, token }, iteration) {
  const id = randomUUID();
  // Client INSERT mirrors the public community write; a service key is used only to clean up.
  const row = {
    id,
    user_id: userId,
    title: `${marker}-${iteration}`,
    from_area: "اختبار",
    to_area: "حمل",
    country: "eg",
    status: "pending",
    confirmations: 0,
  };
  // Register before the request: if the response is lost after commit, cleanup still runs.
  created.add(id);
  const r = await fetch(new URL("/rest/v1/community_routes", api), {
    method: "POST",
    headers: { ...headers, Authorization: `Bearer ${token}`, Prefer: "return=minimal" },
    body: JSON.stringify(row),
    signal: AbortSignal.timeout(deadline),
  });
  if (r.status !== 201) throw new Error(`Public write HTTP ${r.status}`);
  const readUrl = new URL("/rest/v1/community_routes", api);
  readUrl.searchParams.set("id", `eq.${id}`);
  readUrl.searchParams.set("select", "id,user_id,title,status,confirmations");
  const readback = await fetch(readUrl, {
    headers: { ...headers, Authorization: `Bearer ${token}` },
    signal: AbortSignal.timeout(deadline),
  });
  if (!readback.ok) throw new Error(`Public readback HTTP ${readback.status}`);
  assertWrittenRoute(await readback.json(), row);
}
async function cleanup() {
  if (!created.size) return;
  const ids = [...created];
  const cleanupHeaders = {
    apikey: env.TAREEQ_STAGING_LOAD_CLEANUP_API_KEY,
    Authorization: `Bearer ${env.TAREEQ_STAGING_LOAD_CLEANUP_TOKEN}`,
    "content-type": "application/json",
  };
  for (let offset = 0; offset < ids.length; offset += 50) {
    const batch = ids.slice(offset, offset + 50);
    const r = await fetch(new URL("/rest/v1/rpc/cleanup_staging_load_routes", api), {
      method: "POST",
      headers: cleanupHeaders,
      body: JSON.stringify({ p_ids: batch, p_marker: marker }),
      signal: AbortSignal.timeout(deadline),
    });
    if (!r.ok) throw new Error(`Cleanup RPC HTTP ${r.status}`);
    const result = await r.json();
    const removed = Array.isArray(result) ? result[0]?.removed_count : result?.removed_count;
    if (Number(removed) !== batch.length) throw new Error("Cleanup RPC did not remove the full test batch");
  }
}

async function browserJourney(page, scenario, journey) {
  if (scenario === "search") {
    const response = await page.goto(site.href, {
      waitUntil: "domcontentloaded",
      timeout: deadline,
    });
    assertStagingRelease({ headers: new Headers(await response.allHeaders()) }, env.RELEASE_COMMIT);
    await page.getByRole("searchbox", { name: "نقطة البداية" }).fill(journey.from);
    await page.getByRole("searchbox", { name: "نقطة الوصول" }).fill(journey.to);
    await page.getByRole("button", { name: "ابحث الآن" }).click();
    await page
      .getByRole("button", { name: "ابحث الآن" })
      .waitFor({ state: "visible", timeout: deadline });
    // A search result must appear; a spinner disappearing alone is not success.
    await assertJourneyResult(page, "structured", deadline);
  } else {
    const response = await page.goto(new URL("/planner", site).href, {
      waitUntil: "domcontentloaded",
      timeout: deadline,
    });
    assertStagingRelease({ headers: new Headers(await response.allHeaders()) }, env.RELEASE_COMMIT);
    await page.getByPlaceholder("مثال: رمسيس، التحرير…").fill(journey.from);
    await page.getByPlaceholder("مثال: العتبة، مصر الجديدة…").fill(journey.to);
    await page.getByRole("button", { name: "ابحث", exact: true }).click();
    await assertJourneyResult(page, "planner", deadline);
  }
}
async function main() {
  const response = await fetch(site, { signal: AbortSignal.timeout(deadline) });
  if (!response.ok) throw new Error("Staging application unavailable");
  assertStagingRelease(response, env.RELEASE_COMMIT);
  // Bound authentication setup concurrency; tokens remain in memory only.
  for (let offset = 0; offset < profile.accounts.length; offset += 5)
    sessions.push(...(await Promise.all(profile.accounts.slice(offset, offset + 5).map(login))));
  if (new Set(sessions.map((s) => s.userId)).size !== sessions.length)
    throw new Error("Different account entries resolved to the same authenticated user");
  const browser = await chromium.launch({ headless: true });
  try {
    for (const { users, rounds } of stages) {
      const records = [];
      const stageStarted = performance.now();
      const accountsUsed = new Set();
      const contexts = await Promise.all(Array.from({ length: users }, () => browser.newContext()));
      try {
        const workers = await Promise.allSettled(
          contexts.map(async (ctx, idx) => {
            let page = await ctx.newPage();
            for (let round = 0; round < rounds; round++) {
              const selected = assignment(idx, round, users, sessions.length, profile.journeys);
              accountsUsed.add(selected.accountIndex);
              // Cold means a fresh browser context, not a cold server/database cache.
              if (selected.cold) {
                await ctx.close();
                ctx = await browser.newContext();
                contexts[idx] = ctx;
                page = await ctx.newPage();
              }
              for (const scenario of ["search", "planner", "write"]) {
                const start = performance.now();
                try {
                  if (scenario === "write")
                    await writeJourney(sessions[selected.accountIndex], `${users}-${idx}-${round}`);
                  else await browserJourney(page, scenario, selected.journey);
                  records.push({
                    scenario,
                    journeyId: selected.journey.id,
                    cache: selected.cold ? "cold" : "warm",
                    ms: Math.round(performance.now() - start),
                    ok: true,
                  });
                } catch (error) {
                  records.push({
                    scenario,
                    journeyId: selected.journey.id,
                    cache: selected.cold ? "cold" : "warm",
                    ms: Math.round(performance.now() - start),
                    ok: false,
                    error: String(error.message).slice(0, 180),
                  });
                }
              }
            }
          }),
        );
        if (workers.some((worker) => worker.status === "rejected"))
          throw new Error("A load worker failed before completing its samples");
      } finally {
        await Promise.all(contexts.map((ctx) => ctx.close()));
      }
      const summary = summarizeLoad(records, users, rounds, limits);
      summary.elapsedMs = Math.round(performance.now() - stageStarted);
      summary.operationsPerSecond = records.length / (summary.elapsedMs / 1000);
      summary.accountCount = accountsUsed.size;
      summary.journeys = Object.fromEntries(
        profile.journeys.map((j) => [
          j.id,
          Object.fromEntries(
            ["search", "planner"].map((name) => {
              const rows = records.filter((r) => r.journeyId === j.id && r.scenario === name);
              return [name, { total: rows.length, errors: rows.filter((r) => !r.ok).length }];
            }),
          ),
        ]),
      );
      summary.cache = Object.fromEntries(
        ["cold", "warm"].map((kind) => {
          const rows = records.filter((r) => r.cache === kind && r.scenario !== "write");
          const durations = rows.map((r) => r.ms).sort((a, b) => a - b);
          return [
            kind,
            {
              total: rows.length,
              errors: rows.filter((r) => !r.ok).length,
              p95Ms: durations[Math.ceil(durations.length * 0.95) - 1] ?? null,
            },
          ];
        }),
      );
      summary.passed =
        summary.passed &&
        summary.accountCount >= 50 &&
        Object.values(summary.cache).every(
          (m) =>
            m.total > 0 &&
            m.errors / m.total <= limits.errorRate &&
            m.p95Ms !== null &&
            m.p95Ms <= 3000,
        ) &&
        Object.values(summary.journeys).every((j) =>
          Object.values(j).every((m) => m.total >= 10 && m.errors / m.total <= limits.errorRate),
        );
      report.stages.push(summary);
      console.log(
        `Stage ${users} users: ${summary.passed ? "PASS" : "FAIL"}; errors ${(summary.errorRate * 100).toFixed(1)}%`,
      );
      if (!summary.passed) break; // Stop before increasing load on a struggling staging host.
    }
  } finally {
    await browser.close();
  }
}
let error;
try {
  await main();
} catch (e) {
  error = e;
}
try {
  await cleanup();
  report.cleanupPassed = true;
} catch (e) {
  error = e;
  report.cleanupPassed = false;
  report.cleanupError = e.message;
}
report.finishedAt = new Date().toISOString();
report.passed =
  !error && report.stages.length === stages.length && report.stages.every((s) => s.passed);
mkdirSync("backups/load-reports", { recursive: true, mode: 0o700 });
const output = `backups/load-reports/${marker}.json`;
writeFileSync(output, JSON.stringify(report, null, 2), { mode: 0o600 });
console.log(`Report: ${output}`);
if (error) console.error(`Load test failed: ${error.message}`);
if (!report.passed) process.exitCode = 1;
