import { test } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { createServer } from "node:net";
import { spawn } from "node:child_process";

async function probe(replyStatus) {
  const server = createServer((socket) => {
    let buffer = Buffer.alloc(0);
    let upgraded = false;
    socket.on("data", (chunk) => {
      buffer = Buffer.concat([buffer, chunk]);
      if (!upgraded) {
        const end = buffer.indexOf("\r\n\r\n");
        if (end < 0) return;
        const key = buffer
          .subarray(0, end)
          .toString()
          .match(/^Sec-WebSocket-Key:\s*([^\r\n]+)/im)?.[1];
        assert.ok(key);
        const accept = createHash("sha1")
          .update(key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11")
          .digest("base64");
        socket.write(
          `HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${accept}\r\n\r\n`,
        );
        buffer = buffer.subarray(end + 4);
        upgraded = true;
      }
      if (buffer.length < 8) return;
      const shortLength = buffer[1] & 127;
      const offset = shortLength === 126 ? 8 : 6;
      const size = shortLength === 126 ? buffer.readUInt16BE(2) : shortLength;
      if (buffer.length < offset + size) return;
      const mask = buffer.subarray(offset - 4, offset);
      const decoded = Buffer.alloc(size);
      for (let i = 0; i < size; i++) decoded[i] = buffer[offset + i] ^ mask[i % 4];
      const request = JSON.parse(decoded.toString());
      assert.equal(request.event, "phx_join");
      const body = Buffer.from(
        JSON.stringify({
          topic: request.topic,
          ref: request.ref,
          event: "phx_reply",
          payload: { status: replyStatus, response: {} },
        }),
      );
      socket.write(Buffer.concat([Buffer.from([0x81, body.length]), body]));
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  try {
    return await new Promise((resolve, reject) => {
      const child = spawn(
        process.execPath,
        [
          new URL("./probe-realtime.mjs", import.meta.url).pathname,
          `ws://127.0.0.1:${server.address().port}/realtime/v1/websocket`,
        ],
        {
          env: { ...process.env, VITE_SUPABASE_PUBLISHABLE_KEY: "test-anon" },
        },
      );
      let output = "";
      child.stdout.on("data", (x) => {
        output += x;
      });
      child.stderr.on("data", (x) => {
        output += x;
      });
      child.once("error", reject);
      child.once("exit", (code) => resolve({ code, output }));
    });
  } finally {
    server.close();
  }
}

test("Realtime gate requires a successful Phoenix join", async () => {
  const ok = await probe("ok");
  assert.equal(ok.code, 0, ok.output);
  const rejected = await probe("error");
  assert.equal(rejected.code, 1, rejected.output);
});
