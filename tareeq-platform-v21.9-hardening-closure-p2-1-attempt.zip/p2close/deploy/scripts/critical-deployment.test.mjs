import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, readFileSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { spawnSync } from "node:child_process";
const root = resolve(import.meta.dirname, "../..");
function scratch(fn) {
  const dir = mkdtempSync(join(tmpdir(), "tareeq-security-"));
  try {
    fn(dir);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}
test("Kong renders JWTs without eval or unresolved placeholders", () =>
  scratch((dir) => {
    const output = join(dir, "kong.yml");
    const r = spawnSync("sh", ["deploy/supabase/kong-entrypoint.sh"], {
      cwd: root,
      env: {
        ...process.env,
        SUPABASE_ANON_KEY: "anon.payload.signature",
        SUPABASE_SERVICE_KEY: "service.payload.signature",
        KONG_RENDER_ONLY: "true",
        KONG_TEMPLATE_PATH: join(root, "deploy/supabase/kong.yml"),
        KONG_DECLARATIVE_CONFIG: output,
      },
      encoding: "utf8",
    });
    assert.equal(r.status, 0, r.stderr);
    const text = readFileSync(output, "utf8");
    assert.ok(text.includes("anon.payload.signature"));
    assert.ok(text.includes("service.payload.signature"));
    assert.ok(!text.includes("${"));
  }));
test("Kong rejects unsafe substitution values", () =>
  scratch((dir) => {
    const r = spawnSync("sh", ["deploy/supabase/kong-entrypoint.sh"], {
      cwd: root,
      env: {
        ...process.env,
        SUPABASE_ANON_KEY: "$(touch malicious)",
        SUPABASE_SERVICE_KEY: "a.b.c",
        KONG_RENDER_ONLY: "true",
        KONG_DECLARATIVE_CONFIG: join(dir, "out"),
      },
    });
    assert.equal(r.status, 2);
  }));
test("roles preparation tolerates only duplicate CREATE, preserving ALTER and GRANT", () =>
  scratch((dir) => {
    writeFileSync(join(dir, "names"), "anon\nauthenticator\n");
    writeFileSync(
      join(dir, "roles"),
      "CREATE ROLE anon;\nALTER ROLE anon WITH NOLOGIN;\nGRANT anon TO authenticator;\n",
    );
    const r = spawnSync(
      "bash",
      ["deploy/scripts/prepare-roles.sh", join(dir, "roles"), join(dir, "names")],
      { cwd: root, encoding: "utf8" },
    );
    assert.equal(r.status, 0, r.stderr);
    assert.match(r.stdout, /EXCEPTION WHEN duplicate_object THEN NULL/);
    assert.match(r.stdout, /ALTER ROLE anon WITH NOLOGIN;/);
    assert.match(r.stdout, /GRANT anon TO authenticator;/);
    assert.doesNotMatch(r.stdout, /WHEN OTHERS/);
  }));
test("unreviewed role identifiers fail closed", () =>
  scratch((dir) => {
    writeFileSync(join(dir, "names"), "multi line role\n");
    writeFileSync(join(dir, "roles"), 'CREATE ROLE "multi line role";\n');
    assert.equal(
      spawnSync(
        "bash",
        ["deploy/scripts/prepare-roles.sh", join(dir, "roles"), join(dir, "names")],
        { cwd: root },
      ).status,
      2,
    );
  }));
function snapshotCase(dir, changeRoles = false, failDump = false, extra = {}) {
  const fixture=readFileSync(join(root,'deploy/scripts/test-fixtures/backup-docker.cjs'),'utf8');
  writeFileSync(join(dir,'docker'),`#!${process.execPath}\n${fixture}`,{mode:0o700});
  const result=spawnSync('bash',[join(root,'deploy/scripts/backup-database.sh'),dir],{
    cwd: extra.TEST_CWD || root,
    env:{...process.env,PATH:`${dir}:${process.env.PATH}`,BACKUP_FIXTURE_DIR:dir,CHANGE_ROLES:changeRoles?'1':'0',FAIL_DUMP:failDump?'1':'0',...extra},
    encoding:'utf8',timeout:10000,
  });
  assert.equal(result.error,undefined,`Backup must exit without timeout: ${result.error?.message}`);
  return result;
}
test("snapshot helper passes snapshot to dump and saves same-session metrics", () =>
  scratch((dir) => {
    const r = snapshotCase(dir);
    assert.equal(r.status, 0, r.stderr);
    assert.equal(readFileSync(join(dir, "db-metrics.txt"), "utf8"), "2|3|4\n");
  }));
test('snapshot helper writes recovery point, schema and content before dumping',()=>scratch(dir=>{
 const r=snapshotCase(dir);assert.equal(r.status,0,r.stderr);
 assert.equal(JSON.parse(readFileSync(join(dir,'recovery-point.json'))).captured_at,'2026-09-24 12:00:00+00');
 assert.equal(JSON.parse(readFileSync(join(dir,'source-schema-fingerprint.json'))).objects[0].name,'routes');
 const content=JSON.parse(readFileSync(join(dir,'source-content-fingerprint.json')));
 assert.deepEqual(content.tables.map(t=>[t.table,t.rows]),[['auth.users',1],['public.routes',1]]);
 assert.ok(content.tables.every(t=>/^[a-f0-9]{64}$/.test(t.sha256)));
 const events=readFileSync(join(dir,'events.jsonl'),'utf8').trim().split('\n').map(x=>JSON.parse(x).kind);
 assert.deepEqual(events,['snapshot','recovery-point','schema','tables','content','content','dump','commit']);
}));
test('snapshot helper resolves paths when called from another directory',()=>scratch(dir=>{
 const r=snapshotCase(dir,false,false,{TEST_CWD:dir});assert.equal(r.status,0,r.stderr);
}));
for(const [variable,code] of [['FAIL_SCHEMA',7],['FAIL_CONTENT',1]])test(`snapshot helper stops on ${variable}`,()=>scratch(dir=>{
 const r=snapshotCase(dir,false,false,{[variable]:'1'});assert.equal(r.status,code,r.stderr);
 const events=readFileSync(join(dir,'events.jsonl'),'utf8');assert.ok(!events.includes('"dump"'));assert.ok(!events.includes('"commit"'));
}));
test("snapshot helper rejects concurrent role changes", () =>
  scratch((dir) => {
    const r = snapshotCase(dir, true);
    assert.equal(r.status, 1, r.stderr);
  }));
test("snapshot helper fails on pg_dump errors", () =>
  scratch((dir) => {
    const r = snapshotCase(dir, false, true);
    assert.equal(r.status, 4, r.stderr);
  }));
test("health and restore checks avoid constant-folded division by zero", () => {
  for (const file of ["health.sh", "restore-rehearsal.sh"]) {
    const text = readFileSync(join(root, "deploy/scripts", file), "utf8");
    assert.doesNotMatch(text, /1\s*\/\s*0/);
    assert.match(text, /== t/);
  }
});
