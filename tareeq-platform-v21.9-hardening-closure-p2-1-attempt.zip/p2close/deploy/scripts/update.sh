#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "▶ Backup before update..."
./scripts/backup.sh

echo "▶ Pulling latest code (if this is a git checkout)..."
git pull --ff-only 2>/dev/null || echo "  (skipped, not a git repo)"

echo "▶ Rebuild + restart..."
if ! ./scripts/deploy.sh; then
  echo "❌ Deploy failed. Do not overwrite the database automatically."
  echo "Read ROLLOUT_RUNBOOK.md: check migration compatibility, then roll back traffic or apply a forward fix."
  exit 1
fi
echo "✅ Updated."
