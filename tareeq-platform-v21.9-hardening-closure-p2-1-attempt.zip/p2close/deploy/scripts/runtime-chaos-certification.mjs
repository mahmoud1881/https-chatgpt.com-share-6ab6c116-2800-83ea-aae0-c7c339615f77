import {spawnSync} from 'node:child_process';
import {existsSync,readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
const token=process.env.CHAOS_CERTIFICATION_TOKEN||'';if(token.length<24)throw Error('CHAOS_CERTIFICATION_TOKEN (>=24 chars) is required; runtime certification is fail-closed');
const deploymentId=process.env.DEPLOYMENT_ID||`runtime-cert-${randomUUID()}`, correlationId=process.env.CORRELATION_ID||deploymentId;process.env.DEPLOYMENT_ID=deploymentId;process.env.CORRELATION_ID=correlationId;
const scenarios=['5xx','latency','db-outage','external-failure'];const evidence={format:'tareeq-v21.6-runtime-chaos-certification-v1',deploymentId,correlationId,startedAt:new Date().toISOString(),telemetryCertification:null,scenarios:[],passed:false};mkdirSync('artifacts',{recursive:true});
function runNode(file,env={},expect=0,timeout=180000){const r=spawnSync('node',[file],{stdio:'inherit',env:{...process.env,...env},timeout});return r.status===expect;}
function provider(phase,env={},expect=0){const r=spawnSync('node',['deploy/scripts/provider-selfhost.mjs',phase],{stdio:'inherit',env:{...process.env,...env},timeout:180000});return r.status===expect;}
// Prove OTLP -> Tempo, spanmetrics -> Prometheus, and postgres-exporter before injecting failures.
if(!runNode('deploy/scripts/telemetry-certification.mjs')){writeFileSync('artifacts/runtime-chaos-certification.json',JSON.stringify(evidence,null,2)+'\n');process.exit(1);}evidence.telemetryCertification=JSON.parse(readFileSync('artifacts/telemetry-certification.json','utf8'));
for(const mode of scenarios){const stage=1, env={CANARY_PERCENT:String(stage),CANARY_SECONDS:process.env.CHAOS_CANARY_SECONDS||'60',CANARY_PROBE_INTERVAL_MS:process.env.CHAOS_PROBE_INTERVAL_MS||'300',CANARY_MIN_CANDIDATE_REQUESTS:process.env.CHAOS_MIN_CANDIDATE_REQUESTS||'20',CANARY_MIN_STABLE_REQUESTS:process.env.CHAOS_MIN_STABLE_REQUESTS||'20',CHAOS_MODE:mode,CHAOS_CERTIFICATION_TOKEN:token};
  const item={mode,startedAt:new Date().toISOString(),detected:false,incident:false,stableRestored:false};
  if(!provider('shift-canary',env)){evidence.scenarios.push({...item,error:'failed to enter canary'});break;}
  // A successful SLO check under an injected fault is a certification failure.
  item.detected=provider('observe-canary',env,1);
  if(item.detected){provider('incident-evidence',{...env,INCIDENT_DECISION:'abort'});const incident=`artifacts/incidents/${deploymentId}/stage-${stage}-abort.json`;item.incident=existsSync(incident);if(item.incident)item.incidentEvidence=incident;}
  item.stableRestored=provider('restore-old-traffic',env);try{const state=JSON.parse(readFileSync('deploy/backups/rollout/traffic-state.json','utf8'));item.stableRestored=item.stableRestored&&state.percent===0;}catch{item.stableRestored=false;}
  item.completedAt=new Date().toISOString();item.passed=item.detected&&item.incident&&item.stableRestored;evidence.scenarios.push(item);if(!item.passed)break;
}
evidence.passed=evidence.telemetryCertification?.passed===true&&evidence.scenarios.length===scenarios.length&&evidence.scenarios.every(x=>x.passed);evidence.completedAt=new Date().toISOString();writeFileSync('artifacts/runtime-chaos-certification.json',JSON.stringify(evidence,null,2)+'\n');console.log(JSON.stringify(evidence,null,2));if(!evidence.passed)process.exit(1);
