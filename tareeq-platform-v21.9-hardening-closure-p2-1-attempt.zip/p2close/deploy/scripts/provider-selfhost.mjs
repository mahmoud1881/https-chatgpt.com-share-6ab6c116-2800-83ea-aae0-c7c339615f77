import { immutableRelease, inspectCandidate, COMPOSE_ARGS } from "./runtime-image-binding.mjs";
import { spawnSync } from "node:child_process";
import { readFileSync, writeFileSync, mkdirSync, renameSync } from "node:fs";
const phase = process.argv[2];
if (!phase) throw Error("phase required");
function run(bin, args, opts = {}) {
  const r = spawnSync(bin, args, {
    cwd:opts.cwd,
    encoding: "utf8",
    timeout: opts.timeout || 120000,
    stdio: opts.stdio || "pipe",
    env: { ...process.env, ...opts.env },
  });
  if (r.error || r.status !== 0)
    throw Error(`${bin} ${args.join(" ")} failed: ${(r.stderr || r.error?.message || "").trim()}`);
  return (r.stdout || "").trim();
}
const dc = (...a) => run("docker", [...COMPOSE_ARGS, ...a]);
function health(name) {
  const id = dc("--profile", "canary", "ps", "-q", name);
  if (!id) throw Error(`${name} container missing`);
  const h = run("docker", ["inspect", "-f", "{{.State.Health.Status}}", id]);
  if (h !== "healthy") throw Error(`${name} is ${h}`);
  return id;
}
function shift(percent) {
 if(![0,1,5,25,50,100].includes(percent))throw Error('Invalid traffic percentage');
 run(process.execPath,['scripts/rollout-traffic.mjs',String(percent)],{cwd:'deploy',stdio:'inherit',timeout:240000});
}
function imageExists(ref) {
  run("docker", ["image", "inspect", ref]);
}
switch (phase) {
  case "compatibility-old":
    imageExists(process.env.RELEASE || process.env.OLD_RELEASE);
    health("app");
    break;
  case "compatibility-new": {
    const ref = immutableRelease();
    if (process.env.RELEASE && process.env.RELEASE !== ref) throw Error("RELEASE mismatch");
    run("docker", ["pull", ref]);
    imageExists(ref);
    break;
  }
  case "deploy-green": {
    const ref = immutableRelease();
    if (process.env.RELEASE && process.env.RELEASE !== ref) throw Error("RELEASE mismatch");
    run("docker", ["pull", ref]);
    run(
      "docker",
      [...COMPOSE_ARGS, "up", "-d", "--no-deps", "--no-build", "--pull", "never", "candidate"],
      { env: { CANDIDATE_APP_IMAGE: ref }, stdio: "inherit" },
    );
    health("candidate");
    inspectCandidate();
    break;
  }
  case "readiness-green":
    inspectCandidate();
    health("candidate");
    run("curl", ["-fsS", "--max-time", "7", "http://127.0.0.1:3300/"]);
    break;
  case "synthetic-green": {
    inspectCandidate();
    health("candidate");
    for (let i = 0; i < 10; i++)
      run("curl", [
        "-fsS",
        "--max-time",
        "7",
        "-H",
        "User-Agent: Tareeq-Synthetic/v21.1",
        "http://127.0.0.1:3300/",
      ]);
    break;
  }
  case "shift-canary":
    if(!/^(1|5|25|50|100)$/.test(process.env.CANARY_PERCENT||''))throw Error('CANARY_PERCENT required');
    shift(Number(process.env.CANARY_PERCENT));
    break;
  case "observe-canary":
    run("node", ["deploy/scripts/live-canary-slo.mjs"], {
      stdio: "inherit",
      timeout: (Number(process.env.CANARY_SECONDS || 300) + 60) * 1000,
    });
    run("node", ["deploy/scripts/telemetry-slo-gate.mjs"], { stdio: "inherit", timeout: 60000 });
    break;
  case "incident-evidence":
    run("node", ["deploy/scripts/incident-evidence.mjs"], { stdio: "inherit", timeout: 60000 });
    break;
  case "progressive-delivery":
    run("node", ["deploy/scripts/progressive-delivery.mjs"], {
      stdio: "inherit",
      timeout: Number(process.env.PROGRESSIVE_TIMEOUT_MS || 3600000),
    });
    break;
  case "shift-full":
    shift(100);
    break;
  case "drain-old":
    dc("stop", "app");
    break;
  case "verify-old-drained": {
    const id = dc("ps", "-q", "app");
    if (id) {
      const running = run("docker", ["inspect", "-f", "{{.State.Running}}", id]);
      if (running === "true") throw Error("old app still running");
    }
    break;
  }
  case "restore-old-traffic": {
    dc("up", "-d", "--no-deps", "app");
    health("app");
    shift(0);
    break;
  }
  default:
    throw Error(`unsupported provider phase: ${phase}`);
}
console.log(`✓ self-host provider phase ${phase}`);
