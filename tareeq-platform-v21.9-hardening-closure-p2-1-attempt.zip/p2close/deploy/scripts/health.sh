#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

failures=0
check() {
  local name="$1"
  shift
  if "$@" >/dev/null 2>&1; then
    printf '  ✅ %-16s OK\n' "$name"
  else
    printf '  ❌ %-16s FAIL\n' "$name"
    failures=$((failures + 1))
  fi
}

service_running() {
  local container status
  container=$(docker compose ps -q "$1")
  [[ -n "$container" ]] || return 1
  [[ $(docker inspect -f '{{.State.Running}}' "$container") == true ]] || return 1
  # Require a healthy result if the image defines a Docker healthcheck.
  status=$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$container")
  [[ "$status" == healthy || "$status" == none ]]
}

echo '▶ Container status:'
docker compose ps
echo '▶ Health probes:'
for service in db auth rest realtime meta studio kong app proxy; do
  check "$service running" service_running "$service"
done

check 'PostgreSQL' docker compose exec -T db pg_isready -U postgres -d postgres
check 'Migration ledger' node scripts/check-migration-ledger.mjs
tenant=$(sed -n 's/^REALTIME_TENANT=//p' .env | tail -n 1)
tenant_query() {
  local result
  result=$(docker compose exec -T db psql -X -U postgres -d postgres -v ON_ERROR_STOP=1 -v "tenant=$tenant" -tA <<'SQL'
SELECT EXISTS (SELECT 1 FROM _realtime.tenants WHERE external_id = :'tenant');
SQL
  ) || return 1
  [[ "$result" == t ]]
}
if [[ "$tenant" =~ ^[a-zA-Z0-9_-]+$ ]]; then
  check 'Realtime tenant' tenant_query
else
  echo '  ❌ Realtime tenant  Invalid or missing REALTIME_TENANT in deploy/.env'
  failures=$((failures + 1))
fi
check 'App HTTP' docker compose exec -T app wget -qO- http://127.0.0.1:3000/
# Exercise the actual gateway from the application network with the anon key.
check 'Auth via Kong' docker compose exec -T app node -e \
  'fetch("http://kong:8000/auth/v1/health", {headers:{apikey:process.env.VITE_SUPABASE_PUBLISHABLE_KEY}}).then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))'
check 'REST via Kong' docker compose exec -T app node -e \
  'fetch("http://kong:8000/rest/v1/", {headers:{apikey:process.env.VITE_SUPABASE_PUBLISHABLE_KEY}}).then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))'
check 'Auth settings' docker compose exec -T app node -e \
  'fetch("http://kong:8000/auth/v1/settings", {headers:{apikey:process.env.VITE_SUPABASE_PUBLISHABLE_KEY}}).then(async r=>{const j=await r.json();process.exit(r.ok&&j.external?0:1)}).catch(()=>process.exit(1))'
# Run the channel probe inside app's network, using its existing anon JWT.
check 'Realtime channel' docker compose exec -T app node - ws://kong:8000/realtime/v1/websocket < scripts/probe-realtime.mjs

if (( failures > 0 )); then
  printf '❌ %d health probe(s) failed.\n' "$failures" >&2
  exit 1
fi
echo '✅ All health probes passed.'
