// Disposable staging account only. Exercises the public stable UI and Auth/RLS.
import { chromium } from "@playwright/test";
import { randomUUID } from "node:crypto";
import { assertJourneyResult } from "./load-result.mjs";
const env = process.env,
  site = new URL(env.SITE_URL),
  api = new URL(env.SUPABASE_PUBLIC_URL);
if (
  site.protocol !== "https:" ||
  api.protocol !== "https:" ||
  !/^(staging|stage|test)[.-]/i.test(site.hostname)
)
  throw Error("HTTPS staging only");
for (const key of [
  "STAGING_TEST_EMAIL",
  "STAGING_TEST_PASSWORD",
  "VITE_SUPABASE_PUBLISHABLE_KEY",
  "EXPECTED_STABLE_REVISION",
])
  if (!env[key]) throw Error(`Missing ${key}`);
const checks = { search: false, planner: false, auth: false, writeReadback: false, cleanup: false };
const headers = { apikey: env.VITE_SUPABASE_PUBLISHABLE_KEY, "content-type": "application/json" };
const request = (path, options = {}) =>
  fetch(new URL(path, api), {
    ...options,
    headers: { ...headers, ...options.headers },
    signal: AbortSignal.timeout(15000),
  });
let browser, token, createdId;
try {
  const auth = await request("/auth/v1/token?grant_type=password", {
    method: "POST",
    body: JSON.stringify({ email: env.STAGING_TEST_EMAIL, password: env.STAGING_TEST_PASSWORD }),
  });
  const session = await auth.json();
  if (!auth.ok || !session.access_token || !session.user?.id)
    throw Error("Restored app Auth login failed");
  token = session.access_token;
  const user = await request("/auth/v1/user", { headers: { Authorization: `Bearer ${token}` } });
  if (!user.ok || (await user.json()).id !== session.user.id)
    throw Error("Session verification failed");
  checks.auth = true;
  browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ userAgent: "Tareeq-Probe/rollback" });
  for (const surface of ["search", "planner"]) {
    const response = await page.goto(new URL(surface === "search" ? "/" : "/planner", site).href, {
      waitUntil: "domcontentloaded",
      timeout: 15000,
    });
    if (
      !response?.ok() ||
      response.headers()["x-tareeq-channel"] !== "stable" ||
      response.headers()["x-tareeq-release"] !== env.EXPECTED_STABLE_REVISION
    )
      throw Error("Public page did not serve the retained stable revision");
    if (surface === "search") {
      await page.getByRole("searchbox", { name: "نقطة البداية" }).fill("رمسيس");
      await page.getByRole("searchbox", { name: "نقطة الوصول" }).fill("العتبة");
      await page.getByRole("button", { name: "ابحث الآن" }).click();
    } else {
      await page.getByPlaceholder("مثال: رمسيس، التحرير…").fill("رمسيس");
      await page.getByPlaceholder("مثال: العتبة، مصر الجديدة…").fill("العتبة");
      await page.getByRole("button", { name: "ابحث", exact: true }).click();
    }
    await assertJourneyResult(page, surface === "search" ? "structured" : "planner", 15000);
    checks[surface] = true;
  }
  createdId = randomUUID(); // register before POST so response loss still gets cleanup
  const row = {
    id: createdId,
    user_id: session.user.id,
    title: `rollback-${createdId}`,
    from_area: "اختبار",
    to_area: "استعادة",
    country: "eg",
    status: "pending",
    confirmations: 0,
  };
  const insert = await request("/rest/v1/community_routes", {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, Prefer: "return=minimal" },
    body: JSON.stringify(row),
  });
  if (insert.status !== 201) throw Error("Authenticated write failed");
  const read = await request(
    `/rest/v1/community_routes?id=eq.${createdId}&select=id,title,status`,
    { headers: { Authorization: `Bearer ${token}` } },
  );
  const data = await read.json();
  if (!read.ok || data.length !== 1 || data[0].title !== row.title || data[0].status !== "pending")
    throw Error("Authenticated readback failed");
  checks.writeReadback = true;
} finally {
  try {
    if (createdId) {
      const deleted = await request(`/rest/v1/community_routes?id=eq.${createdId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      const read = await request(`/rest/v1/community_routes?id=eq.${createdId}&select=id`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!deleted.ok || !read.ok || (await read.json()).length !== 0)
        throw Error("Rollback fixture cleanup failed");
    }
    checks.cleanup = true;
  } finally {
    if (browser) await browser.close();
  }
}
console.log(JSON.stringify(checks));
