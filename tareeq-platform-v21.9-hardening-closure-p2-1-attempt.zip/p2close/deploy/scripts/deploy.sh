#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

[[ -f .env ]] || { echo "❌ .env not found. Run ./scripts/bootstrap.sh first."; exit 1; }
release_revision=${RELEASE_COMMIT:-$(sed -n 's/^RELEASE_COMMIT=//p' .env | tail -n 1)}
if [[ ! "$release_revision" =~ ^[a-fA-F0-9]{40}$ ]]; then
  echo 'Set RELEASE_COMMIT to the full 40-character source commit before deployment.' >&2
  exit 2
fi
export RELEASE_COMMIT="$release_revision"
if grep -q 'candidate:' caddy/rollout.caddy 2>/dev/null ||
   [[ -n "$(docker compose --profile canary ps -q candidate)" ]]; then
  echo '❌ Active canary: return traffic to 0 and stop candidate before a full deployment. See ROLLOUT_RUNBOOK.md.' >&2
  exit 2
fi

# Guard: refuse to deploy with a *.supabase.co URL in .env.
./scripts/check-no-cloud.sh .env

echo "▶ Pulling images…"
docker compose pull --ignore-pull-failures

echo "▶ Building app image…"
docker compose build app
image_revision=$(docker compose run --rm --no-deps --entrypoint cat app /app/.release-commit | tr -d '\r\n')
[[ "$image_revision" == "$RELEASE_COMMIT" ]] || { echo 'Built image revision differs from deployment source' >&2; exit 1; }

# Drift guard: the VITE_SUPABASE_URL baked into the image at build time
# must match the current .env. Otherwise the browser hits the wrong host.
BAKED=$(docker compose run --rm --no-deps --entrypoint sh app \
  -c 'cat /app/.built-with-api-url 2>/dev/null || true' | tr -d '\r\n')
# shellcheck disable=SC1091
CURRENT=$(grep -E '^VITE_SUPABASE_URL=' .env | cut -d= -f2-)
if [[ -n "$BAKED" && "$BAKED" != "$CURRENT" ]]; then
  echo "❌ VITE_SUPABASE_URL drift detected."
  echo "     baked into image : $BAKED"
  echo "     current in .env  : $CURRENT"
  echo "   Rebuild with: docker compose build --no-cache app"
  exit 1
fi


echo "▶ Starting database…"
docker compose up -d db
echo "▶ Waiting for postgres to be healthy…"
for i in $(seq 1 30); do
  status=$(docker inspect --format '{{.State.Health.Status}}' \
    "$(docker compose ps -q db)" 2>/dev/null || echo starting)
  [[ "$status" == healthy ]] && break
  sleep 2
done
[[ "${status:-}" == healthy ]] || { echo "❌ db failed to become healthy"; exit 1; }

# Apply app migrations exactly once, in lexical filename order.
# The previous implementation replayed every migration on every deploy, which
# is unsafe because ordinary CREATE TABLE/ALTER TABLE migrations are not
# inherently idempotent. Keep deployment state in a private schema so it does
# not become a public application table and does not weaken the RLS gate.
if compgen -G "../supabase/migrations/*.sql" > /dev/null; then
  echo "▶ Applying pending migrations from ../supabase/migrations/ …"
  docker compose exec -T db psql -v ON_ERROR_STOP=1 -U postgres -d postgres <<'SQL' >/dev/null
CREATE SCHEMA IF NOT EXISTS platform_meta;
CREATE TABLE IF NOT EXISTS platform_meta.applied_migrations (
  filename text PRIMARY KEY,
  applied_at timestamptz NOT NULL DEFAULT now()
);
SQL

  for f in ../supabase/migrations/*.sql; do
    name=$(basename "$f")
    applied=$(docker compose exec -T db psql -U postgres -d postgres -tAc \
      "SELECT 1 FROM platform_meta.applied_migrations WHERE filename = '$name'" | tr -d '[:space:]')
    if [[ "$applied" == "1" ]]; then
      echo "  ✓ $name (already applied)"
      continue
    fi
    echo "  → $name"
    # Apply the migration AND record it as applied in ONE psql invocation /
    # ONE transaction (\i runs the file inside the session's current
    # transaction, unlike a separate `-f` call). Without this, "migration
    # succeeds, then the INSERT into applied_migrations fails" (dropped
    # connection, Docker hiccup, disk full for WAL at that exact moment,
    # etc.) leaves the DDL applied but unrecorded — set -e aborts this
    # script immediately when that happens, so it's not silent, but a
    # naive retry re-runs the same migration file, and most migrations in
    # this repo are NOT written to be idempotent (plain CREATE TABLE/ALTER
    # TABLE/CREATE POLICY without IF NOT EXISTS / DROP ... IF EXISTS
    # first), so the retry itself fails with "already exists" and the
    # deploy is stuck at that migration until someone manually repairs
    # platform_meta.applied_migrations. Wrapping both statements in one
    # transaction makes that split-brain state impossible: either both
    # commit together, or neither does and the plain retry just works.
    docker compose exec -T db \
      psql -v ON_ERROR_STOP=1 -U postgres -d postgres \
      -v migration_name="$name" <<SQL >/dev/null
BEGIN;
\i /migrations/$name
INSERT INTO platform_meta.applied_migrations(filename) VALUES (:'migration_name');
COMMIT;
SQL
  done
else
  echo "ℹ️  No SQL migrations found — skipping."
fi

echo "▶ Starting remaining services…"
docker compose up -d

# Seed the Realtime tenant so subscriptions work.
# Realtime runs its Ecto migrations on first boot (creating _realtime.*),
# so we wait briefly for the schema, then upsert the tenant.
echo "▶ Seeding Realtime tenant…"
# shellcheck disable=SC1091
set -a; . ./.env; set +a
: "${REALTIME_TENANT:=realtime-dev}"
for i in $(seq 1 30); do
  ready=$(docker compose exec -T db psql -U postgres -d postgres -tAc \
    "SELECT 1 FROM information_schema.schemata WHERE schema_name='_realtime'" 2>/dev/null || true)
  [[ "$ready" == "1" ]] && break
  sleep 2
done
if [[ "${ready:-}" == "1" ]]; then
  docker compose exec -T db psql -v ON_ERROR_STOP=1 \
      -U postgres -d postgres \
      -v jwt_secret="$JWT_SECRET" \
      -v tenant="$REALTIME_TENANT" \
      -c "SELECT set_config('seed.pg_pass', '$POSTGRES_PASSWORD', false)" \
      -f /supabase/seed-realtime.sql >/dev/null
  echo "  → tenant '$REALTIME_TENANT' upserted"
  docker compose restart realtime >/dev/null
else
  echo "❌ _realtime schema never appeared — deployment is incomplete." >&2
  exit 1
fi

echo ""
echo "▶ Verifying the full stack…"
for i in $(seq 1 30); do
  if ./scripts/health.sh > /dev/null 2>&1; then
    echo "✅ Deployed and health probes passed."
    exit 0
  fi
  sleep 2
done
./scripts/health.sh
echo "❌ Deployment health probes failed." >&2
exit 1
