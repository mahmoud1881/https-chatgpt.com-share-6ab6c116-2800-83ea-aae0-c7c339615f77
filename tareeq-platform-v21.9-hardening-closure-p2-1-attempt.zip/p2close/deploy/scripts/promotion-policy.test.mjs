import test from 'node:test';
import assert from 'node:assert/strict';
import {promotionConfig,freshPromotionGate,requireMailOAuth} from './promotion-policy.mjs';
import {spawnSync} from 'node:child_process';
import {mkdtempSync,rmSync,readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve} from 'node:path';
test('fixed ordered production stages and bounded defaults',()=>assert.deepEqual(promotionConfig({}).stages,[1,5,25,50,100]));
for(const v of ['-1','NaN','Infinity','','1.5','4',' 1','1e2'])test(`invalid holds ${JSON.stringify(v)} rejected`,()=>assert.throws(()=>promotionConfig({PROGRESSIVE_MAX_HOLDS:v})));
for(const v of ['100','1,25,100','1,5,5,25,50,100','5,1,25,50,100',''])test(`invalid stages ${JSON.stringify(v)} rejected`,()=>assert.throws(()=>promotionConfig({PROGRESSIVE_STAGES:v})));
for(const [key,value] of [['CANARY_SECONDS','0'],['CANARY_SECONDS_25','NaN'],['CANARY_MAX_5XX_RATE','1'],['CANARY_MIN_CANDIDATE_REQUESTS','1'],['CANARY_MAX_DB_ERRORS','2'],['PROGRESSIVE_STAGE_TIMEOUT_MS','-1'],['CANARY_PERCENT','100.0'],['ROLLOUT_REHEARSAL_BOOTSTRAP','maybe']])test(`reject invalid/weakened ${key}`,()=>assert.throws(()=>promotionConfig({[key]:value})));
test('zero holds allowed; no negative-loop bypass',()=>assert.equal(promotionConfig({PROGRESSIVE_MAX_HOLDS:'0'}).maxHolds,0));
test('promotion requires reviewed trip evidence before running any command',()=>{let called=false;assert.throws(()=>freshPromotionGate(1,{},()=>{called=true}),/TRIP/);assert.equal(called,false)});
test('every promotion re-runs canonical gate',()=>{const calls=[];const run=(...args)=>{calls.push(args);return {status:0}};freshPromotionGate(1,{ROLLOUT_TRIP_EVIDENCE:'/review.json'},run);freshPromotionGate(5,{ROLLOUT_TRIP_EVIDENCE:'/review.json'},run);assert.equal(calls.length,2);assert.equal(calls[0][1][0],'scripts/rollout-gate.mjs')});
test('gate failure cannot authorize routing',()=>assert.throws(()=>freshPromotionGate(1,{ROLLOUT_TRIP_EVIDENCE:'/review.json'},()=>({status:1})),/rejected/));
test('missing signed mailbox/OAuth evidence rejected',()=>assert.throws(()=>requireMailOAuth({}),/mailbox/));
test('negative holds cannot produce successful progressive report (real controller)',()=>{
 const dir=mkdtempSync(resolve(tmpdir(),'promotion-test-'));try{
 const r=spawnSync(process.execPath,[resolve('deploy/scripts/progressive-delivery.mjs')],{cwd:dir,env:{PATH:'',PROGRESSIVE_MAX_HOLDS:'-1'},encoding:'utf8'});
 assert.equal(r.status,1);const report=JSON.parse(readFileSync(resolve(dir,'artifacts/progressive-delivery-evidence.json')));assert.equal(report.status,'blocked');assert.equal(report.decisions.length,0);
 }finally{rmSync(dir,{recursive:true,force:true})}
});

import {mkdirSync,writeFileSync} from 'node:fs';
test('cached PASS cannot bypass new evidence at real traffic entrypoint',()=>{
 const dir=mkdtempSync(resolve(tmpdir(),'promotion-entry-'));
 const id='c'.repeat(64),imageId='sha256:'+'d'.repeat(64),digest='sha256:'+'a'.repeat(64),ref=`registry.example/app@${digest}`;
 try {
  mkdirSync(resolve(dir,'bin'));mkdirSync(resolve(dir,'backups/rollout'),{recursive:true});mkdirSync(resolve(dir,'caddy'));
  writeFileSync(resolve(dir,'caddy/rollout.caddy'),'UNCHANGED');
  writeFileSync(resolve(dir,'backups/rollout/latest-gate.json'),JSON.stringify({passed:true,targetPercent:100}));
  writeFileSync(resolve(dir,'bin/docker'),`#!${process.execPath}\nconst a=process.argv.slice(2);if(a.includes('ps'))console.log('${id}');else if(a[0]==='image')console.log(JSON.stringify([{Id:'${imageId}',RepoDigests:['${ref}']}]));else if(a[0]==='container')console.log(JSON.stringify([{Id:'${id}',Image:'${imageId}',State:{Running:true},Config:{Image:'${ref}',Labels:{'com.docker.compose.project':'platform','com.docker.compose.service':'candidate'}},Mounts:[]}]));else if(a.includes('inspect'))console.log('${imageId}');else process.exit(88);\n`,{mode:0o700});
  const r=spawnSync(process.execPath,[resolve('deploy/scripts/rollout-traffic.mjs'),'100'],{cwd:dir,env:{PATH:resolve(dir,'bin'),RELEASE_IMAGE_REF:'registry.example/app',RELEASE_IMAGE_DIGEST:digest},encoding:'utf8'});
  assert.equal(r.status,1);assert.match(r.stderr,/ROLLOUT_TRIP_EVIDENCE/);assert.equal(readFileSync(resolve(dir,'caddy/rollout.caddy'),'utf8'),'UNCHANGED');
 }finally{rmSync(dir,{recursive:true,force:true})}
});
