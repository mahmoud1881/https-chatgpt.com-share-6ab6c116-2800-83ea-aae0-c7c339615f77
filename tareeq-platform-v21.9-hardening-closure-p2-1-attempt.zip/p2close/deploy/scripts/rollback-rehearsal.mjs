// Run from deploy/ on staging only. Routes back to the retained stable app, not an old database.
import { spawnSync } from "node:child_process";
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { fingerprint } from "./rollout-evidence.mjs";
const site = new URL(process.env.SITE_URL || "");
if (site.protocol !== "https:" || !/^(staging|stage|test)[.-]/i.test(site.hostname))
  throw Error("Staging host required");
if (process.env.ROLLBACK_SCHEMA_COMPATIBLE !== "yes")
  throw Error("First verify old app compatibility with the current database schema");
const state = JSON.parse(readFileSync("backups/rollout/traffic-state.json", "utf8"));
if (!(state.percent > 0)) throw Error("Run while staging has candidate exposure >0");
const started = Date.now();
const report = { startedAt: new Date(started).toISOString(), passed: false, rtoTargetSeconds: 300 };
function run(bin, args) {
  const r = spawnSync(bin, args, { encoding: "utf8", timeout: 240000, maxBuffer: 1024 * 1024 });
  if (r.status !== 0 || r.error) throw Error(`${bin} check failed`);
  return r.stdout.trim();
}
function migrations() {
  return run("docker", [
    "compose",
    "exec",
    "-T",
    "db",
    "psql",
    "-U",
    "postgres",
    "-d",
    "postgres",
    "-v",
    "ON_ERROR_STOP=1",
    "-tAc",
    "SELECT string_agg(filename,',' ORDER BY filename) FROM platform_meta.applied_migrations",
  ]);
}
try {
  const before = migrations();
  report.migrationFingerprint = fingerprint(before);
  report.stableImage = run("docker", [
    "inspect",
    "-f",
    "{{.Image}}",
    run("docker", ["compose", "ps", "-q", "app"]),
  ]);
  report.candidateImage = run("docker", [
    "inspect",
    "-f",
    "{{.Image}}",
    run("docker", ["compose", "--profile", "canary", "ps", "-q", "candidate"]),
  ]);
  run("node", ["scripts/rollout-traffic.mjs", "0"]);
  run("bash", ["scripts/health.sh"]);
  const r = await fetch(site, {
    signal: AbortSignal.timeout(15000),
    headers: { "cache-control": "no-cache" },
  });
  if (!r.ok || r.headers.get("x-tareeq-channel") !== "stable")
    throw Error("Public endpoint did not confirm stable app");
  const stableId = run("docker", ["compose", "ps", "-q", "app"]);
  process.env.EXPECTED_STABLE_REVISION = run("docker", [
    "inspect",
    "-f",
    '{{index .Config.Labels "org.opencontainers.image.revision"}}',
    stableId,
  ]);
  report.functionalChecks = JSON.parse(run("node", ["scripts/functional-rollback-probe.mjs"]));
  if (
    !["search", "planner", "auth", "writeReadback", "cleanup"].every(
      (k) => report.functionalChecks[k] === true,
    )
  )
    throw Error("Functional rollback checks incomplete");
  if (report.stableImage !== run("docker", ["inspect", "-f", "{{.Image}}", stableId]))
    throw Error("Stable image changed during rehearsal");
  if (before !== migrations()) throw Error("Migration ledger changed during application rollback");
  report.elapsedSeconds = Math.ceil((Date.now() - started) / 1000);
  if (report.elapsedSeconds > report.rtoTargetSeconds)
    throw Error("Application rollback exceeded 300 seconds");
  report.passed = true;
} catch (e) {
  report.error = e.message;
  process.exitCode = 1;
} finally {
  report.elapsedSeconds = Math.ceil((Date.now() - started) / 1000);
  mkdirSync("backups/rollout", { recursive: true, mode: 0o700 });
  writeFileSync("backups/rollout/rollback-rehearsal.json", JSON.stringify(report, null, 2), {
    mode: 0o600,
  });
  console.log(
    `Rollback rehearsal ${report.passed ? "PASS" : "FAIL"} (${report.elapsedSeconds}s). Stable routing is retained.`,
  );
}
