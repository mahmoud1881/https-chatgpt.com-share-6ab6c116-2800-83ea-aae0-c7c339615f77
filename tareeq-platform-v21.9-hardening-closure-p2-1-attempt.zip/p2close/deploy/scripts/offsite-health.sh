#!/usr/bin/env bash
# Check that a recent encrypted backup is present and intact on the other host.
set -euo pipefail
: "${BACKUP_SSH_TARGET:?Missing BACKUP_SSH_TARGET}"
: "${BACKUP_REMOTE_DIR:?Missing BACKUP_REMOTE_DIR}"
: "${BACKUP_MAX_AGE_HOURS:=26}"
[[ "$BACKUP_SSH_TARGET" =~ ^[a-zA-Z0-9_-]+@[a-zA-Z0-9._-]+$ ]] || exit 2
[[ "$BACKUP_REMOTE_DIR" =~ ^/[a-zA-Z0-9._/-]+$ && "$BACKUP_REMOTE_DIR" != *..* ]] || exit 2
[[ "$BACKUP_MAX_AGE_HOURS" =~ ^[1-9][0-9]*$ ]] || exit 2
command -v ssh >/dev/null || exit 2
remote_result=$(ssh -o BatchMode=yes -o StrictHostKeyChecking=yes "$BACKUP_SSH_TARGET" \
  "find '$BACKUP_REMOTE_DIR' -mindepth 2 -maxdepth 2 -name SHA256SUMS.encrypted -printf '%h\n' | grep -E '/[0-9]{8}T[0-9]{6}Z-[a-f0-9]{6}\$' | sort | tail -n 1")
id=${remote_result##*/}
[[ "$id" =~ ^([0-9]{8}T[0-9]{6}Z)-[a-f0-9]{6}$ ]] || {
  echo '❌ No dated offsite backup found' >&2; exit 1;
}
created=$(date -u -d "${BASH_REMATCH[1]:0:8} ${BASH_REMATCH[1]:9:2}:${BASH_REMATCH[1]:11:2}:${BASH_REMATCH[1]:13:2} UTC" +%s)
now=$(date -u +%s)
age=$((now - created))
(( age >= 0 && age <= BACKUP_MAX_AGE_HOURS * 3600 )) || {
  echo "❌ Latest offsite backup $id is outside the ${BACKUP_MAX_AGE_HOURS}h window" >&2; exit 1;
}
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes "$BACKUP_SSH_TARGET" \
  "cd '$remote_result' && sha256sum -c SHA256SUMS.encrypted" >/dev/null
echo "✅ Offsite backup $id: encrypted file verified, age $((age / 3600))h"
