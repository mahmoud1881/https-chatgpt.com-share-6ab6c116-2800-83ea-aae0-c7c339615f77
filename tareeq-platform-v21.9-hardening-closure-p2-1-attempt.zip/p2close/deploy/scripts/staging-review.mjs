import { readFileSync, lstatSync } from "node:fs";
import { dirname, join } from "node:path";
import { createHash, createPublicKey, verify } from "node:crypto";
import { assertStagingProof } from "./staging-evidence.mjs";

function readEvidence(path, maximum) {
  const stat = lstatSync(path);
  if (!stat.isFile() || stat.size < 1 || stat.size > maximum)
    throw new Error("Evidence must be a nonempty regular file within the size limit");
  return readFileSync(path);
}
export function validateStagingReview(manifestPath, proof, env, now = Date.now()) {
  assertStagingProof(proof, env, now);
  if (!env.STAGING_REVIEW_PUBLIC_KEY_FILE || !env.STAGING_REVIEWER_ID)
    throw new Error("Configure the independently trusted reviewer public key and identity");
  const bytes = readEvidence(manifestPath, 65536);
  const signature = readEvidence(`${manifestPath}.sig`, 1024);
  const key = createPublicKey(readEvidence(env.STAGING_REVIEW_PUBLIC_KEY_FILE, 16384));
  if (key.asymmetricKeyType !== "ed25519" || !verify(null, bytes, key, signature))
    throw new Error("Evidence review signature is invalid");
  const manifest = JSON.parse(bytes.toString("utf8"));
  const review = manifest.review;
  if (
    manifest.schemaVersion !== 1 ||
    manifest.probeId !== proof.id ||
    manifest.context !== proof.context ||
    manifest.releaseCommit !== env.RELEASE_COMMIT ||
    review?.decision !== "approved" ||
    review.reviewer !== env.STAGING_REVIEWER_ID ||
    typeof manifest.collector !== "string" ||
    !manifest.collector.trim() ||
    review.reviewer.trim().toLowerCase() === manifest.collector.trim().toLowerCase()
  )
    throw new Error("Approved independent review for the current probe and release is required");
  const reviewed = Date.parse(review.reviewedAt);
  if (!Number.isFinite(reviewed) || reviewed > now || reviewed < Date.parse(proof.startedAt))
    throw new Error("Review time is outside the current probe");
  if (!Array.isArray(manifest.artifacts) || manifest.artifacts.length !== 2)
    throw new Error("Attach mailbox and completed OAuth evidence");
  const receipts = [];
  for (const [kind, timeKey] of [
    ["mailbox", "STAGING_EMAIL_RECEIVED_AT"],
    ["oauth", "STAGING_OAUTH_CALLBACK_AT"],
  ]) {
    const matches = manifest.artifacts.filter((a) => a.kind === kind);
    if (matches.length !== 1) throw new Error(`Exactly one ${kind} artifact is required`);
    const artifact = matches[0];
    if (
      !/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,80}\.(png|jpg|pdf|eml|json)$/.test(artifact.file ?? "") ||
      !/^[a-f0-9]{64}$/.test(artifact.sha256 ?? "") ||
      Date.parse(artifact.observedAt) !== Date.parse(env[timeKey]) ||
      reviewed < Date.parse(artifact.observedAt)
    )
      throw new Error(`Invalid ${kind} evidence metadata`);
    const body = readEvidence(join(dirname(manifestPath), artifact.file), 20 * 1024 * 1024);
    const digest = createHash("sha256").update(body).digest("hex");
    if (digest !== artifact.sha256) throw new Error(`${kind} evidence changed after review`);
    receipts.push({ kind, sha256: digest, observedAt: artifact.observedAt });
  }
  if (
    manifest.artifacts[0].file === manifest.artifacts[1].file ||
    receipts[0].sha256 === receipts[1].sha256
  )
    throw new Error("Mailbox and OAuth require separate evidence artifacts");
  return {
    probeId: proof.id,
    context: proof.context,
    releaseCommit: env.RELEASE_COMMIT,
    reviewer: review.reviewer,
    reviewedAt: review.reviewedAt,
    manifestSha256: createHash("sha256").update(bytes).digest("hex"),
    artifacts: receipts,
  };
}
