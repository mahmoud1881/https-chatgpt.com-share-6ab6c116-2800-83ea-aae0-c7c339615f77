import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { loadTrust, verifyCertificate } from "./certification-policy.mjs";
try {
  const args = process.argv.slice(2);
  if (args.length > 2)
    throw Error("Bundled public key arguments are no longer accepted; configure independent trust");
  const root = resolve(process.env.CERTIFICATION_BUNDLE_ROOT || process.cwd());
  const trust = loadTrust(root);
  const cert = JSON.parse(
    readFileSync(resolve(root, args[0] || "artifacts/production-certification.json"), "utf8"),
  );
  const signature = readFileSync(
    resolve(root, args[1] || "artifacts/production-certification.sig"),
    "utf8",
  );
  verifyCertificate({ cert, signature, root, trust });
  console.log(
    `Production certification verified: ${cert.release.gitCommit} ${cert.release.imageDigest}`,
  );
} catch (e) {
  console.error(`NOT VERIFIED: ${e.message}`);
  process.exitCode = 1;
}
