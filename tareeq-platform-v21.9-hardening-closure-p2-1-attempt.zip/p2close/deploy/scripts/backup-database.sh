#!/usr/bin/env bash
# Internal helper: hold an exported snapshot until pg_dump completes.
set -euo pipefail
umask 077
destination=${1:?Expected existing private backup directory}
[[ -d "$destination" ]] || exit 2
destination=$(cd "$destination" && pwd)
script_dir=$(cd "$(dirname "$0")" && pwd)
cd "$script_dir/.."
roles_sql="SELECT md5(coalesce((SELECT string_agg(row_to_json(r)::text, ',' ORDER BY oid) FROM pg_authid r), '') || coalesce((SELECT string_agg(row_to_json(m)::text, ',' ORDER BY roleid, member) FROM pg_auth_members m), ''))"
coproc SNAPSHOT { exec docker compose exec -T db psql -X -qAt -U postgres -d postgres -v ON_ERROR_STOP=1; }
snapshot_pid=$SNAPSHOT_PID
snapshot_read=${SNAPSHOT[0]}
snapshot_write=${SNAPSHOT[1]}
cleanup_snapshot() {
  if [[ -n "${snapshot_pid:-}" ]]; then
    kill "$snapshot_pid" 2>/dev/null || true
    wait "$snapshot_pid" 2>/dev/null || true
  fi
}
trap cleanup_snapshot EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
printf 'BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY;\nSELECT pg_export_snapshot();\n' >&"$snapshot_write"
IFS= read -r -t 60 snapshot <&"$snapshot_read"
[[ "$snapshot" =~ ^[0-9A-Fa-f]+-[0-9A-Fa-f]+-[0-9]+$ ]] || { echo 'Invalid exported snapshot' >&2; exit 1; }
printf '%s;\n' 'SELECT (SELECT count(*) FROM auth.users), (SELECT count(*) FROM public.routes), (SELECT count(*) FROM public.community_routes)' >&"$snapshot_write"
IFS= read -r -t 300 metrics <&"$snapshot_read"
[[ "$metrics" =~ ^[0-9]+\|[0-9]+\|[0-9]+$ ]] || exit 1
printf '%s\n' "$metrics" > "$destination/db-metrics.txt"
# Capture the logical recovery point and source-state proofs from the SAME exported snapshot.
# RPO must be measured from this database-derived timestamp, never filesystem mtime.
printf 'SELECT clock_timestamp();\n' >&"$snapshot_write"
IFS= read -r -t 60 recovery_point <&"$snapshot_read"
[[ "$recovery_point" == *T* || "$recovery_point" == *-* ]] || { echo 'Invalid database recovery point' >&2; exit 1; }
printf '{"format":"tareeq-backup-recovery-point-v1","captured_at":"%s"}\n' "$recovery_point" > "$destination/recovery-point.json"
# Canonical schema fingerprint in the same snapshot.
{ printf "BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY; SET TRANSACTION SNAPSHOT '%s';\n" "$snapshot"; cat ../scripts/schema-fingerprint.sql; printf '\nCOMMIT;\n'; } \
  | docker compose exec -T db psql -X -qAt -U postgres -d postgres -v ON_ERROR_STOP=1 \
  > "$destination/source-schema-fingerprint.json"
node scripts/database-state-fingerprint.mjs source "$snapshot" > "$destination/source-content-fingerprint.json"
printf '%s;\n' "$roles_sql" >&"$snapshot_write"
IFS= read -r -t 60 roles_before <&"$snapshot_read"
[[ "$roles_before" =~ ^[0-9a-f]{32}$ ]] || exit 1
docker compose exec -T db pg_dump -U postgres -d postgres --format=custom --snapshot="$snapshot" > "$destination/db.dump"
docker compose exec -T db pg_dumpall -U postgres --globals-only > "$destination/db-roles.sql"
docker compose exec -T db psql -X -U postgres -d postgres -v ON_ERROR_STOP=1 -tAc \
  "SELECT rolname FROM pg_roles WHERE rolname NOT LIKE 'pg_%' ORDER BY rolname COLLATE \"C\"" > "$destination/db-role-names.txt"
# pg_dumpall cannot import a snapshot. Freeze role administration during
# backup and reject observed changes in roles/passwords/memberships.
roles_after=$(docker compose exec -T db psql -X -U postgres -d postgres -v ON_ERROR_STOP=1 -tAc "$roles_sql")
[[ "$roles_before" == "$roles_after" ]] || { echo 'Roles changed during backup; archive rejected' >&2; exit 1; }
printf 'COMMIT;\n\\q\n' >&"$snapshot_write"
wait "$snapshot_pid"
snapshot_pid=
