import test from "node:test";
import assert from "node:assert/strict";
import { trafficConfig, validateGate } from "./rollout-traffic.mjs";
test("rollback removes candidate, including existing sticky sessions", () => {
  assert.equal(trafficConfig(0), "reverse_proxy app:{$APP_PORT}\n");
  assert.equal(trafficConfig(100), "reverse_proxy candidate:{$APP_PORT}\n");
});
test("percentages are bounded and use positive weights", () => {
  assert.match(trafficConfig(1), /weighted_round_robin 99 1/);
  assert.match(trafficConfig(5), /weighted_round_robin 95 5/);
  assert.throws(() => trafficConfig(80));
  assert.throws(() => trafficConfig(NaN));
});
test("promotion requires fresh evidence tied to the exact candidate", () => {
  const now = Date.now(),
    gate = {
      passed: true,
      targetPercent: 5,
      candidateImage: "sha256:test",
      checkedAt: new Date(now).toISOString(),
    };
  assert.doesNotThrow(() => validateGate(gate, 5, "sha256:test", now));
  assert.throws(() => validateGate(gate, 25, "sha256:test", now));
  assert.throws(() => validateGate(gate, 5, "sha256:different", now));
  assert.throws(() => validateGate(gate, 5, "sha256:test", now + 3600001));
  assert.throws(() => validateGate({ ...gate, passed: false }, 5, "sha256:test", now));
});
