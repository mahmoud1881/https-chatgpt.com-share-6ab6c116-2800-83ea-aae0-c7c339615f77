import {spawnSync} from 'node:child_process';
import {mkdirSync,writeFileSync,readFileSync,rmSync,existsSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
import {promotionConfig} from './promotion-policy.mjs';

const evidencePath='artifacts/progressive-delivery-evidence.json';
const statePath='deploy/backups/rollout/traffic-state.json';
const releaseRef=process.env.CANDIDATE_APP_IMAGE||process.env.NEW_RELEASE||'';
function loadJson(path){try{return JSON.parse(readFileSync(path,'utf8'))}catch{return null}}
const prior=loadJson(evidencePath);
const traffic=loadJson(statePath);
const resumable=prior?.format==='tareeq-v21.3-observable-progressive-delivery-v2' && prior?.releaseRef===releaseRef && ['pending','running'].includes(prior?.status);
const deploymentId=resumable?prior.deploymentId:(process.env.DEPLOYMENT_ID||`deploy-${randomUUID()}`);
const correlationId=resumable?prior.correlationId:(process.env.CORRELATION_ID||deploymentId);
process.env.DEPLOYMENT_ID=deploymentId;process.env.CORRELATION_ID=correlationId;
const evidence=resumable?prior:{format:'tareeq-v21.3-observable-progressive-delivery-v2',deploymentId,correlationId,releaseRef,startedAt:new Date().toISOString(),stages:[1,5,25,50,100],decisions:[],status:'running'};
mkdirSync('artifacts',{recursive:true});
const save=()=>writeFileSync(evidencePath,JSON.stringify(evidence,null,2)+'\n');
let timeout;
function run(phase,env={}){const r=spawnSync(process.execPath,['deploy/scripts/provider-selfhost.mjs',phase],{stdio:'inherit',env:{...process.env,...env},timeout});return !r.error&&r.status===0;}
function waitMsFor(percent){return (percent===50?48:24)*3600000;}
try {
 const config=promotionConfig();timeout=config.timeout; evidence.status='running'; delete evidence.completedAt; delete evidence.error; save();
 let current=loadJson(statePath)?.percent;
 if(![0,1,5,25,50,100].includes(current))throw Error('Canonical rollout traffic state is missing or invalid');
 if(current===100){evidence.status='passed';evidence.completedAt=new Date().toISOString();save();process.exit(0)}
 for(const percent of config.stages){
  current=loadJson(statePath)?.percent;
  if(percent<=current)continue;
  const expectedPrevious=[0,1,5,25,50][config.stages.indexOf(percent)];
  if(current!==expectedPrevious)throw Error(`Rollout state ${current}% cannot resume toward ${percent}%`);
  const changedAt=Date.parse(loadJson(statePath)?.changedAt||'');
  const remaining=waitMsFor(current)-(Date.now()-changedAt);
  if(current>0 && Number.isFinite(remaining) && remaining>0){
    evidence.status='pending'; evidence.pending={currentPercent:current,nextPercent:percent,eligibleAt:new Date(changedAt+waitMsFor(current)).toISOString()}; save(); process.exitCode=75; break;
  }
  const env={CANARY_PERCENT:String(percent),CANARY_SECONDS:process.env[`CANARY_SECONDS_${percent}`]||String(config.seconds)};
  if(!run('shift-canary',env))throw Error(`Stage ${percent} blocked by unified promotion gate`);
  let passed=false;
  for(let attempt=1;attempt<=config.maxHolds+1;attempt++){
   const path=`artifacts/canary-stage-${percent}.json`;rmSync(path,{force:true});const began=Date.now();
   const ok=run('observe-canary',env);let slo;try{slo=JSON.parse(readFileSync(path,'utf8'))}catch{}
   passed=ok&&slo?.passed===true&&slo.stagePercent===percent&&slo.deploymentId===deploymentId&&Date.parse(slo.startedAt)>=began&&Date.parse(slo.completedAt)>=Date.parse(slo.startedAt)&&Date.parse(slo.completedAt)<=Date.now();
   const decision=passed?(percent===100?'complete':'promote'):(attempt<=config.maxHolds?'hold':'abort');
   evidence.decisions.push({percent,attempt,decision,at:new Date().toISOString(),slo:slo||null});save();
   if(passed)break; run('incident-evidence',{...env,INCIDENT_DECISION:decision});
  }
  if(!passed){const restored=run('restore-old-traffic');throw Error(`Stage ${percent} failed; rollback ${restored?'completed':'FAILED'}`)}
  delete evidence.pending;
  if(percent<100){const s=loadJson(statePath);evidence.status='pending';evidence.pending={currentPercent:percent,nextPercent:config.stages[config.stages.indexOf(percent)+1],eligibleAt:new Date(Date.parse(s.changedAt)+waitMsFor(percent)).toISOString()};save();process.exitCode=75;break;}
 }
 if(loadJson(statePath)?.percent===100){evidence.status='passed';delete evidence.pending;evidence.completedAt=new Date().toISOString();save();}
}catch(e){evidence.status='blocked';evidence.error=e.message;evidence.completedAt=new Date().toISOString();save();process.exitCode=1;}
