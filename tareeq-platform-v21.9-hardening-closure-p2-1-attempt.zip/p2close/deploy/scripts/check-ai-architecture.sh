#!/usr/bin/env sh
# check-ai-architecture.sh
# Guard: enforce the "Release gates" section of RELEASE_READINESS.md —
#   "A release must contain no server-side AI provider URL, provider
#    secret, AI gateway SDK, or server-side embedding call."
#
# Used by .github/workflows/ci.yml. Scans tracked source files only
# (never node_modules/.git/build output). Exits 0 when clean, 1 on the
# first category of violation found (all violations are still listed).
#
# POSIX sh only (no bashisms).

set -eu

status=0

# --- 1. Known AI-provider SDK / gateway packages must not appear as deps ---
# These are dependencies that would indicate a server-side (or SDK-mediated)
# AI provider integration, as opposed to the direct browser fetch() calls
# this release uses for Gemini. @huggingface/transformers and @mlc-ai/web-llm
# are intentionally excluded — they power the browser-local embeddings /
# local LLM features and are not remote AI provider gateways.
DENY_PACKAGES='"openai"|"@google/generative-ai"|"@google-cloud/aiplatform"|"@anthropic-ai/sdk"|"@ai-sdk/"|"^ai"\s*:|"@vercel/ai"|ai-gateway'

if [ -f package.json ]; then
  if grep -InE "$DENY_PACKAGES" package.json >/dev/null 2>&1; then
    echo "::error file=package.json::Found a denylisted AI provider/gateway SDK dependency."
    grep -InE "$DENY_PACKAGES" package.json || true
    status=1
  fi
fi

# --- 2. No server-side AI provider secrets referenced anywhere in tracked code ---
# The client-side Gemini key lives only in the browser's localStorage
# (see src/lib/gemini/client.ts) — it must never be read from process.env
# or a server secret store.
# A word boundary plus a negative lookahead on GEMINI_API_KEY matters here:
# src/lib/gemini/client.ts intentionally throws internal error *codes* named
# GEMINI_API_KEY_REQUIRED / GEMINI_API_KEY_INVALID — those are not env-var
# reads and must not trip this guard. `(?!_)` excludes them while still
# catching a bare `process.env.GEMINI_API_KEY` or similar. This needs -P
# (PCRE); GNU grep on ubuntu-latest runners supports it.
SECRET_PATTERN='\bOPENAI_API_KEY\b|\bANTHROPIC_API_KEY\b|\bGOOGLE_AI_API_KEY\b|\bLOVABLE_API_KEY\b|\bAI_GATEWAY_(URL|KEY|TOKEN)\b|\bGEMINI_API_KEY\b(?!_)'

hits=$(grep -RInP "$SECRET_PATTERN" \
  --exclude-dir=node_modules \
  --exclude-dir=.git \
  --exclude-dir=.output \
  --exclude-dir=dist \
  --exclude=bun.lock \
  --exclude=check-ai-architecture.sh \
  . 2>/dev/null || true)

if [ -n "$hits" ]; then
  echo "::error::Found a server-side AI provider secret reference in tracked files."
  printf '%s\n' "$hits"
  status=1
fi

# --- 3. No server/edge-function directory may call an AI provider ---
# Any directory that looks like a serverless/edge function root (Supabase
# functions, API routes, etc.) must not import or fetch an AI provider SDK
# or endpoint. src/routes/api is the platform's own API layer; it must stay
# AI-free per the release gate.
AI_ENDPOINT_PATTERN='generativelanguage\.googleapis\.com|api\.openai\.com|api\.anthropic\.com'

for dir in supabase/functions src/routes/api; do
  [ -d "$dir" ] || continue
  hits=$(grep -RInE "$AI_ENDPOINT_PATTERN" "$dir" 2>/dev/null || true)
  if [ -n "$hits" ]; then
    echo "::error::Found a server-side AI provider endpoint call inside $dir."
    printf '%s\n' "$hits"
    status=1
  fi
done

if [ "$status" -eq 0 ]; then
  echo "✅ check-ai-architecture: no server-side AI provider secrets, SDKs, or calls detected."
fi

exit "$status"
