import {spawnSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {validateStagingReview} from './staging-review.mjs';
export const PROMOTION_STAGES=[1,5,25,50,100];
export function numberSetting(env,key,fallback,min,max,integer=false){
 const raw=env[key]===undefined?String(fallback):env[key];
 if(typeof raw!=='string'||!/^\d+(?:\.\d+)?$/.test(raw))throw Error(`${key}: invalid number`);
 const n=Number(raw);if(!Number.isFinite(n)||n<min||n>max||(integer&&!Number.isInteger(n)))throw Error(`${key}: outside permitted bounds`);return n;
}
export function promotionConfig(env=process.env){
 if(env.PROGRESSIVE_STAGES!==undefined&&env.PROGRESSIVE_STAGES!=='1,5,25,50,100')throw Error('Cannot skip or reorder promotion stages');
 if(env.ROLLOUT_REHEARSAL_BOOTSTRAP!==undefined&&!['yes','no'].includes(env.ROLLOUT_REHEARSAL_BOOTSTRAP))throw Error('Invalid rehearsal bootstrap value');
 const maxHolds=numberSetting(env,'PROGRESSIVE_MAX_HOLDS',1,0,3,true);
 const timeout=numberSetting(env,'PROGRESSIVE_STAGE_TIMEOUT_MS',900000,60000,3600000,true);
 const seconds=numberSetting(env,'CANARY_SECONDS',60,60,3600,true);
 for(const p of PROMOTION_STAGES)numberSetting(env,`CANARY_SECONDS_${p}`,seconds,60,3600,true);
 for(const [k,d,min,max,int] of [
 ['CANARY_PROBE_INTERVAL_MS',500,100,1000,true],['CANARY_MAX_5XX_RATE',.01,0,.01],
 ['CANARY_MAX_P95_MS',3000,1,3000],['CANARY_MAX_P99_MS',5000,1,5000],
 ['CANARY_MAX_DB_ERRORS',0,0,0,true],['CANARY_MAX_RELATIVE_ERROR_DELTA',.005,0,.005],
 ['CANARY_MAX_RELATIVE_P95_RATIO',1.25,1,1.25],['CANARY_ERROR_BUDGET_OBJECTIVE',.99,.99,.99999],
 ['CANARY_MAX_BURN_RATE',2,0,2],['CANARY_MIN_CANDIDATE_REQUESTS',20,20,100000,true],['CANARY_MIN_STABLE_REQUESTS',20,20,100000,true]
 ])numberSetting(env,k,d,min,max,int);
 if(env.CANARY_PERCENT!==undefined&&!/^(1|5|25|50|100)$/.test(env.CANARY_PERCENT))throw Error('Invalid canary stage');
 return {stages:PROMOTION_STAGES,maxHolds,timeout,seconds};
}
export function requireMailOAuth(env=process.env){
 if(!env.STAGING_EVIDENCE_MANIFEST)throw Error('Signed mailbox/OAuth evidence required for every promotion');
 const proof=JSON.parse(readFileSync('backups/staging-probe.json','utf8'));
 return validateStagingReview(env.STAGING_EVIDENCE_MANIFEST,proof,env);
}
// Called inside the traffic mutation lock; cached gate reports never authorize a new shift.
export function freshPromotionGate(percent,env=process.env,run=spawnSync){
 promotionConfig(env);
 if(!PROMOTION_STAGES.includes(percent))throw Error('Invalid promotion stage');
 if(!env.ROLLOUT_TRIP_EVIDENCE)throw Error('ROLLOUT_TRIP_EVIDENCE is required');
 const result=run(process.execPath,['scripts/rollout-gate.mjs',String(percent),resolve(env.ROLLOUT_TRIP_EVIDENCE)],{env,stdio:'inherit',timeout:180000});
 if(result.error||result.status!==0)throw Error('Fresh unified rollout gate rejected promotion');
}
