import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const mode = process.argv[2];
const snapshot = process.argv[3] || '';
if (!['source','restored'].includes(mode)) throw new Error('usage: database-state-fingerprint.mjs source [snapshot] | restored');
function psql(sql) {
  const prefix = snapshot ? `BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY; SET TRANSACTION SNAPSHOT '${snapshot.replaceAll("'", "''")}'; ` : '';
  const x = spawnSync('docker', ['compose','exec','-T','db','psql','-X','-U','postgres','-d','postgres','-qAt','-v','ON_ERROR_STOP=1','-c', `${prefix}${sql}${snapshot ? '; COMMIT' : ''}`], {encoding:'utf8', maxBuffer: 1024*1024*256});
  if (x.error || x.status !== 0) throw new Error((x.stderr || x.error?.message || 'psql failed').trim());
  return x.stdout;
}
const tables = psql("SELECT quote_ident(n.nspname)||'.'||quote_ident(c.relname) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE c.relkind='r' AND n.nspname IN ('public','auth') ORDER BY 1").trim().split(/\n/).filter(Boolean);
const manifest=[];
for (const table of tables) {
  const rows = psql(`COPY (SELECT row_to_json(t)::text FROM ${table} t ORDER BY row_to_json(t)::text COLLATE \"C\") TO STDOUT`);
  const normalized=rows.trimEnd();
  manifest.push({table, rows: normalized === '' ? 0 : normalized.split('\n').filter(Boolean).length, sha256:createHash('sha256').update(normalized).digest('hex')});
}
process.stdout.write(JSON.stringify({format:'tareeq-db-content-fingerprint-v1', tables:manifest}, null, 2)+'\n');
