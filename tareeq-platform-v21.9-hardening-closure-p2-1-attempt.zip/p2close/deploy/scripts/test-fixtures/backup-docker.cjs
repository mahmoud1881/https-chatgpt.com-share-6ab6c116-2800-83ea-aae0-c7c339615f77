// Protocol fixture, not a PostgreSQL implementation. Unknown requests fail closed.
const fs = require('node:fs');
const path = require('node:path');
const args = process.argv.slice(2);
const dir = process.env.BACKUP_FIXTURE_DIR;
const holder = path.join(dir, 'snapshot-open');
const snapshot = '00000003-00000001-1';
function event(kind) { fs.appendFileSync(path.join(dir, 'events.jsonl'), JSON.stringify({kind})+'\n'); }
function fail(message,code=91) { console.error(message); process.exit(code); }
function requireSnapshot(sql) {
 if(!fs.existsSync(holder))fail('snapshot holder was closed early');
 if(!sql.includes(`SET TRANSACTION SNAPSHOT '${snapshot}';`))fail('invalid SQL snapshot literal');
}
if(args.includes('pg_dump')) {
 if(!fs.existsSync(holder)||!args.includes(`--snapshot=${snapshot}`))fail('dump not using live snapshot');
 event('dump');if(process.env.FAIL_DUMP==='1')process.exit(4);console.log('custom-dump');
} else if(args.includes('pg_dumpall'))console.log('CREATE ROLE anon;');
else if(args.includes('-c')) {
 const sql=args[args.indexOf('-c')+1];requireSnapshot(sql);
 if(sql.includes('FROM pg_class')){event('tables');console.log('auth.users\npublic.routes');}
 else if(sql.includes('COPY (SELECT row_to_json')){
  event('content');if(process.env.FAIL_CONTENT==='1')process.exit(8);
  console.log(sql.includes('auth.users')?'{"id":"user-1"}':'{"id":"route-1"}');
 }else fail('unknown SQL command');
} else if(args.includes('-tAc')) {
 const sql=args.at(-1);
 if(sql.includes('md5('))console.log((process.env.CHANGE_ROLES==='1'?'b':'a').repeat(32));
 else if(sql.includes('SELECT rolname'))console.log('anon');
 else fail('unknown scalar query');
} else if(args.includes('-qAt')) {
 let schema=false,schemaSql='';
 const rl=require('node:readline').createInterface({input:process.stdin});
 rl.on('line',line=>{
  if(line.includes('SET TRANSACTION SNAPSHOT'))schema=true;
  if(schema){schemaSql+=line+'\n';return;}
  if(line.includes('pg_export_snapshot')){fs.writeFileSync(holder,'open');event('snapshot');console.log(snapshot);}
  else if(line.includes('clock_timestamp')){event('recovery-point');console.log('2026-09-24 12:00:00+00');}
  else if(line.includes('count(*)'))console.log('2|3|4');
  else if(line.includes('md5('))console.log('a'.repeat(32));
  else if(line==='COMMIT;'){event('commit');fs.rmSync(holder,{force:true});}
  else if(line==='\\q'){rl.close();process.stdin.destroy();}
  else if(line.startsWith('BEGIN ')){}
  else fail('unknown interactive query: '+line);
 });
 rl.on('close',()=>{
  if(schema){requireSnapshot(schemaSql);event('schema');if(process.env.FAIL_SCHEMA==='1')process.exit(7);console.log(JSON.stringify({format:'tareeq-schema-fingerprint-v1',objects:[{kind:'table',name:'routes',detail:{}}]}));}
 });
} else fail('unknown Docker invocation');
