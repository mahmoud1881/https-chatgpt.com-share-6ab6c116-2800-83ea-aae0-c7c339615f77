#!/usr/bin/env bash
# Boot the production image and require its own HTTP endpoint to respond.
set -euo pipefail

image="${1:-platform-app:latest}"
container=$(docker run -d --env NODE_ENV=production \
  --env SUPABASE_URL=http://127.0.0.1:1 \
  --env SUPABASE_PUBLISHABLE_KEY=ci-placeholder \
  "$image")
cleanup() { docker rm -f "$container" >/dev/null 2>&1 || true; }
trap cleanup EXIT

for attempt in $(seq 1 60); do
  state=$(docker inspect -f '{{.State.Status}}' "$container")
  if [[ "$state" != running ]]; then
    echo "❌ Image exited before serving HTTP (state: $state)." >&2
    docker logs "$container" >&2
    exit 1
  fi
  if docker exec "$container" wget -qO- http://127.0.0.1:3000/ >/dev/null 2>&1; then
    docker exec "$container" test -d /app/public/data
    echo '✅ Production image serves HTTP and contains public data.'
    exit 0
  fi
  sleep 2
done

echo '❌ Production image did not serve HTTP within 120 seconds.' >&2
docker logs "$container" >&2
exit 1
