#!/usr/bin/env bash
# Only duplicate CREATE ROLE is tolerated; ALTER/GRANT failures remain fatal.
# Conservative role names make wrapping pg_dumpall statements unambiguous.
set -euo pipefail
source_sql=${1:?roles dump}
names=${2:?role names manifest}
[[ -s "$source_sql" && -s "$names" ]] || exit 2
if LC_ALL=C grep -qEv '^[A-Za-z_][A-Za-z0-9_]*$' "$names"; then
  echo 'Unsupported role identifier; require reviewed manual restore' >&2
  exit 2
fi
if grep '^CREATE ROLE' "$source_sql" | grep -qEv '^CREATE ROLE ("[A-Za-z_][A-Za-z0-9_]*"|[A-Za-z_][A-Za-z0-9_]*);$'; then
  echo 'Unsupported CREATE ROLE syntax; refusing permissive restore' >&2
  exit 2
fi
sed -E 's/^(CREATE ROLE ("[A-Za-z_][A-Za-z0-9_]*"|[A-Za-z_][A-Za-z0-9_]*);)$/DO $restore_role$ BEGIN \1 EXCEPTION WHEN duplicate_object THEN NULL; END $restore_role$;/' "$source_sql"
