// Read-only browser probe of the actual HTTPS route, including deployed JS.
import { chromium } from "@playwright/test";
import { assertJourneyResult } from "./load-result.mjs";
const site = new URL(process.env.SITE_URL);
if (site.protocol !== "https:") throw Error("HTTPS required");
const percent = Number(process.env.EXPECTED_PERCENT);
const expected = {
  stable: process.env.EXPECTED_STABLE_REVISION,
  candidate: process.env.EXPECTED_CANDIDATE_REVISION,
};
const browser = await chromium.launch({ headless: true });
const result = { at: new Date().toISOString(), ok: false, search: false, planner: false };
try {
  const page = await browser.newPage({ userAgent: "Tareeq-Probe/journey" });
  const errors = [];
  page.on("pageerror", () => errors.push("page error"));
  for (const surface of ["search", "planner"]) {
    const response = await page.goto(new URL(surface === "search" ? "/" : "/planner", site).href, {
      waitUntil: "domcontentloaded",
      timeout: 15000,
    });
    const headers = response?.headers() ?? {},
      channel = headers["x-tareeq-channel"];
    if (
      !response?.ok() ||
      !["stable", "candidate"].includes(channel) ||
      (percent === 0 && channel !== "stable") ||
      (percent === 100 && channel !== "candidate") ||
      !/^[a-f0-9]{40}$/i.test(expected[channel] ?? "") ||
      headers["x-tareeq-release"] !== expected[channel]
    )
      throw Error("Public release identity failed");
    if (surface === "search") {
      await page.getByRole("searchbox", { name: "نقطة البداية" }).fill("رمسيس");
      await page.getByRole("searchbox", { name: "نقطة الوصول" }).fill("العتبة");
      await page.getByRole("button", { name: "ابحث الآن" }).click();
    } else {
      await page.getByPlaceholder("مثال: رمسيس، التحرير…").fill("رمسيس");
      await page.getByPlaceholder("مثال: العتبة، مصر الجديدة…").fill("العتبة");
      await page.getByRole("button", { name: "ابحث", exact: true }).click();
    }
    await assertJourneyResult(page, surface === "search" ? "structured" : "planner", 15000);
    result[surface] = true;
  }
  if (errors.length) throw Error("Browser runtime errors");
  result.ok = true;
} catch (error) {
  result.error = error.message;
  process.exitCode = 1;
} finally {
  await browser.close();
}
console.log(JSON.stringify(result));
