import { createHash } from "node:crypto";
export const loadPlan = [
  { users: 1, rounds: 100 },
  { users: 10, rounds: 20 },
  { users: 25, rounds: 8 },
  { users: 50, rounds: 4 },
];
export function validateLoadProfile(profile, site, api, now = Date.now()) {
  if (profile?.site !== site || profile?.api !== api)
    throw Error("Load profile targets differ from configured staging targets");
  const accounts = profile.accounts;
  if (
    !Array.isArray(accounts) ||
    accounts.length < 50 ||
    accounts.length > 200 ||
    accounts.some(
      (a) =>
        typeof a.email !== "string" ||
        !a.email.includes("@") ||
        typeof a.password !== "string" ||
        !a.password,
    )
  )
    throw Error("Supply 50–200 dedicated test accounts in the private profile");
  if (new Set(accounts.map((a) => a.email.trim().toLowerCase())).size !== accounts.length)
    throw Error("Test accounts must be distinct");
  const journeys = profile.journeys;
  if (
    !Array.isArray(journeys) ||
    journeys.length < 5 ||
    journeys.length > 10 ||
    journeys.some(
      (j) =>
        !/^[a-zA-Z0-9_-]{1,40}$/.test(j.id ?? "") ||
        typeof j.from !== "string" ||
        !j.from.trim() ||
        j.from.length > 200 ||
        typeof j.to !== "string" ||
        !j.to.trim() ||
        j.to.length > 200 ||
        j.from === j.to ||
        typeof j.evidence !== "string" ||
        !j.evidence.trim() ||
        !Number.isFinite(Date.parse(j.reviewedAt)) ||
        now - Date.parse(j.reviewedAt) < 0 ||
        now - Date.parse(j.reviewedAt) > 30 * 86400000,
    )
  )
    throw Error("Supply 5–10 distinct successful journeys with recent review evidence");
  if (
    new Set(journeys.map((j) => j.id)).size !== journeys.length ||
    new Set(journeys.map((j) => JSON.stringify([j.from.trim(), j.to.trim()]))).size !==
      journeys.length ||
    !["direct", "alias", "transfer", "long_distance"].every((c) =>
      journeys.some((j) => j.category === c),
    )
  )
    throw Error(
      "Journey coverage must include distinct direct, alias, transfer and long-distance cases",
    );
  return {
    accountCount: accounts.length,
    journeyIds: journeys.map((j) => j.id),
    journeyFingerprint: createHash("sha256").update(JSON.stringify(journeys)).digest("hex"),
    categories: [...new Set(journeys.map((j) => j.category))],
  };
}
export function assignment(worker, round, users, accountCount, journeys) {
  const sequence = round * users + worker;
  return {
    accountIndex: sequence % accountCount,
    journey: journeys[sequence % journeys.length],
    cold: round % 2 === 0,
  };
}
