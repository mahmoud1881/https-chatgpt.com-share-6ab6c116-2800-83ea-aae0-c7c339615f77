import { immutableRelease, checkpoint } from "./runtime-image-binding.mjs";
import { spawnSync } from "node:child_process";
import { createHash, randomUUID, createPrivateKey, createPublicKey, sign } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { FORMAT, EVIDENCE, loadTrust, validateCertificate } from "./certification-policy.mjs";

const root = process.cwd(),
  art = resolve(root, "artifacts");
mkdirSync(art, { recursive: true });
const commit = process.env.RELEASE_COMMIT || "";
const imageDigest = process.env.RELEASE_IMAGE_DIGEST || "";
const keyFile = process.env.RELEASE_SIGNING_PRIVATE_KEY_FILE || "";
const keyId = process.env.RELEASE_SIGNING_KEY_ID || "";
const cert = {
  format: FORMAT,
  runId: randomUUID(),
  status: "CERTIFICATION_RUNNING",
  startedAt: new Date().toISOString(),
  release: { gitCommit: commit, imageDigest },
  runtimeGates: [],
  evidence: {},
  passed: false,
};
const out = resolve(art, "production-certification.json"),
  sigOut = resolve(art, "production-certification.sig"),
  pubOut = resolve(art, "production-certification-public-key.pem");
function fail(m) {
  throw new Error(m);
}
function run(name, cmd, args = []) {
  const bound = [
    "telemetry-end-to-end",
    "runtime-chaos-recovery",
    "stateful-disaster-recovery",
  ].includes(name);
  if (bound) checkpoint(`before-${name}`);
  const began = new Date().toISOString();
  const r = spawnSync(cmd, args, {
    cwd: root,
    stdio: "inherit",
    env: process.env,
    timeout: Number(process.env.PRODUCTION_CERT_GATE_TIMEOUT_MS || 1800000),
  });
  const gate = {
    name,
    startedAt: began,
    completedAt: new Date().toISOString(),
    exitCode: r.status,
    passed: !r.error && r.status === 0,
  };
  cert.runtimeGates.push(gate);
  if (bound) checkpoint(`after-${name}`);
  if (r.error || r.status !== 0) fail(`${name} failed (${r.status ?? r.error?.message})`);
}
const shaFile = (p) => createHash("sha256").update(readFileSync(p)).digest("hex");
function addEvidence(label, path, requiredPass) {
  if (!existsSync(path)) fail(`${label} evidence missing: ${path}`);
  const raw = readFileSync(path);
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    fail(`${label} evidence is not valid JSON`);
  }
  if (
    requiredPass &&
    !(
      parsed.passed === true ||
      parsed.status === "passed" ||
      parsed.status === "completed" ||
      parsed.targets?.production?.matches === true
    )
  )
    fail(`${label} evidence does not prove PASS`);
  cert.evidence[label] = {
    path: path.replace(root + "/", ""),
    sha256: createHash("sha256").update(raw).digest("hex"),
    format: parsed.format ?? null,
    completedAt:
      label === "sbomSpdx"
        ? (parsed.creationInfo?.created ?? null)
        : label === "sbomCycloneDx"
          ? (parsed.metadata?.timestamp ?? null)
          : label === "provenance"
            ? (parsed.predicate?.runDetails?.metadata?.finishedOn ?? null)
            : (parsed.completedAt ?? null),
  };
  return parsed;
}
function canonical(x) {
  if (Array.isArray(x)) return `[${x.map(canonical).join(",")}]`;
  if (x && typeof x === "object")
    return `{${Object.keys(x)
      .sort()
      .map((k) => JSON.stringify(k) + ":" + canonical(x[k]))
      .join(",")}}`;
  return JSON.stringify(x);
}
try {
  rmSync(sigOut, { force: true });
  rmSync(pubOut, { force: true });
  const trust = loadTrust(root);
  const immutable = immutableRelease();
  process.env.NEW_RELEASE = immutable;
  process.env.CANDIDATE_APP_IMAGE = immutable;
  process.env.CERTIFICATION_RUN_ID = cert.runId;
  const signingKey = createPrivateKey(readFileSync(keyFile));
  if (
    signingKey.asymmetricKeyType !== "ed25519" ||
    keyId !== trust.keyId ||
    !createPublicKey(signingKey)
      .export({ type: "spki", format: "der" })
      .equals(trust.key.export({ type: "spki", format: "der" }))
  )
    fail("signing key does not match independent trust");
  if (!/^[a-f0-9]{40}$/i.test(commit)) fail("RELEASE_COMMIT must be a full 40-hex Git commit");
  if (!/^sha256:[a-f0-9]{64}$/i.test(imageDigest))
    fail("RELEASE_IMAGE_DIGEST must be an immutable sha256:<64 hex> digest");
  if (!keyFile || !existsSync(keyFile)) fail("RELEASE_SIGNING_PRIVATE_KEY_FILE is required");
  if (!keyId) fail("RELEASE_SIGNING_KEY_ID is required");
  const head = spawnSync("git", ["rev-parse", "HEAD"], { cwd: root, encoding: "utf8" });
  if (head.status === 0 && head.stdout.trim() !== commit)
    fail(`RELEASE_COMMIT ${commit} does not match checked-out HEAD ${head.stdout.trim()}`);
  // Remove prior run outputs so an old report cannot satisfy this run.
  for (const [label,[path]] of Object.entries(EVIDENCE))
    if (path.startsWith("artifacts/") && label !== "progressiveDelivery") rmSync(resolve(root, path), { force: true });
  // Runtime gates are deliberately executed, not inferred from static evidence.
  run("supply-chain-attestation", "node", ["deploy/scripts/supply-chain-attestation.mjs"]);
  run("database-rls-and-schema-drift", "node", ["scripts/run-release-database-gate.mjs"]);
  run("zero-downtime-migration-and-progressive-delivery", "node", [
    "scripts/zero-downtime-deploy.mjs",
  ]);
  run("telemetry-end-to-end", "node", ["deploy/scripts/telemetry-certification.mjs"]);
  run("runtime-chaos-recovery", "node", ["deploy/scripts/runtime-chaos-certification.mjs"]);
  run("stateful-disaster-recovery", "node", ["deploy/scripts/disaster-recovery-certification.mjs"]);
  addEvidence("supplyChain", resolve(art, "supply-chain-attestation.json"), true);
  addEvidence("sbomSpdx", resolve(art, "release-sbom.spdx.json"), false);
  addEvidence("sbomCycloneDx", resolve(art, "release-sbom.cyclonedx.json"), false);
  addEvidence("provenance", resolve(art, "release-provenance.json"), false);
  const drift = addEvidence("schemaDrift", resolve(art, "schema-drift-report.json"), true);
  addEvidence("migrationSafety", resolve(art, "migration-safety-report.json"), false);
  addEvidence("productionMigration", resolve(art, "production-migration-transaction.json"), false);
  addEvidence("zeroDowntime", resolve(art, "zero-downtime-deployment.json"), true);
  addEvidence("progressiveDelivery", resolve(art, "progressive-delivery-evidence.json"), true);
  addEvidence("telemetry", resolve(art, "telemetry-certification.json"), true);
  addEvidence("runtimeChaos", resolve(art, "runtime-chaos-certification.json"), true);
  addEvidence("disasterRecovery", resolve(art, "disaster-recovery-certification.json"), true);
  cert.release.schemaFingerprint = drift.expectedSchemaSha256;
  cert.release.sbomSpdxSha256 = shaFile(resolve(art, "release-sbom.spdx.json"));
  cert.release.sbomCycloneDxSha256 = shaFile(resolve(art, "release-sbom.cyclonedx.json"));
  cert.release.provenanceSha256 = shaFile(resolve(art, "release-provenance.json"));
  if (!/^[a-f0-9]{64}$/i.test(cert.release.schemaFingerprint || ""))
    fail("canonical schema fingerprint missing/invalid");
  addEvidence("migrationManifest", resolve(root, "supabase/migration-integrity.json"), false);
  cert.release.migrationManifestSha256 = shaFile(
    resolve(root, "supabase/migration-integrity.json"),
  );
  cert.completedAt = new Date().toISOString();
  cert.passed = true;
  cert.status = "PRODUCTION CERTIFIED";
  const privateKey = createPrivateKey(readFileSync(keyFile));
  if (privateKey.asymmetricKeyType !== "ed25519") fail("release signing key must be Ed25519");
  const publicKey = createPublicKey(privateKey);
  const publicPem = publicKey.export({ type: "spki", format: "pem" });
  const publicFingerprint = createHash("sha256")
    .update(publicKey.export({ type: "spki", format: "der" }))
    .digest("hex");
  cert.signature = {
    algorithm: "Ed25519",
    keyId,
    publicKeySha256: publicFingerprint,
    detachedSignature: "artifacts/production-certification.sig",
  };
  checkpoint("before-signing");
  addEvidence("imageBinding", resolve(art, "runtime-image-binding.json"), true);
  cert.completedAt = new Date().toISOString();
  validateCertificate(cert, root, trust);
  const payload = Buffer.from(canonical(cert));
  const signature = sign(null, payload, privateKey);
  writeFileSync(out, JSON.stringify(cert, null, 2) + "\n", { mode: 0o600 });
  writeFileSync(sigOut, signature.toString("base64") + "\n", { mode: 0o600 });
  writeFileSync(pubOut, publicPem, { mode: 0o644 });
  console.log(`\n✅ PRODUCTION CERTIFIED — signed manifest ${shaFile(out)}`);
} catch (e) {
  cert.status = "NOT CERTIFIED";
  cert.passed = false;
  cert.completedAt = new Date().toISOString();
  cert.error = e instanceof Error ? e.message : String(e);
  writeFileSync(out, JSON.stringify(cert, null, 2) + "\n", { mode: 0o600 });
  console.error(`\n❌ NOT CERTIFIED — ${cert.error}`);
  process.exit(1);
}
