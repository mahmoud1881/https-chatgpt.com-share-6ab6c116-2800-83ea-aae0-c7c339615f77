import { createHash } from "node:crypto";
export const fingerprint = (value) =>
  createHash("sha256")
    .update(typeof value === "string" ? value : JSON.stringify(value))
    .digest("hex");
export const stages = [0, 1, 5, 25, 50, 100];
export function assertStateBoundGate(
  gate,
  state,
  stableImage,
  candidateImage,
  routing,
  now = Date.now(),
) {
  if (
    !state?.changedAt ||
    !Number.isFinite(Date.parse(state.changedAt)) ||
    !stages.includes(state.percent)
  )
    throw Error("Invalid traffic state");
  if (
    gate.stateFingerprint !== fingerprint(state) ||
    gate.previousPercent !== state.percent ||
    gate.stableImage !== stableImage ||
    state.stableImage !== stableImage ||
    state.candidateImage !== candidateImage ||
    state.routingFingerprint !== fingerprint(routing) ||
    stages[stages.indexOf(state.percent) + 1] !== gate.targetPercent
  )
    throw Error("Gate does not match current stage, images or routing");
  if (Date.parse(gate.checkedAt) < Date.parse(state.changedAt) || Date.parse(state.changedAt) > now)
    throw Error("Gate predates traffic state");
}
export function currentSamples(samples, state, candidateImage, now = Date.now()) {
  const seen = new Set();
  let lastEnd = 0;
  return samples
    .filter((s) => s.stateFingerprint === fingerprint(state) && s.candidateImage === candidateImage)
    .sort((a, b) => Date.parse(a.windowStart) - Date.parse(b.windowStart))
    .filter((s) => {
      const start = Date.parse(s.windowStart),
        end = Date.parse(s.at);
      if (
        !Number.isFinite(start) ||
        !Number.isFinite(end) ||
        end > now ||
        now - end >= 3600000 ||
        start < Date.parse(state.changedAt) ||
        end <= start ||
        end - start > 300000 ||
        start < lastEnd ||
        seen.has(s.at)
      )
        return false;
      seen.add(s.at);
      lastEnd = end;
      return true;
    });
}
export function requireFunctionalRollback(
  report,
  stableImage,
  candidateImage,
  ledger,
  now = Date.now(),
) {
  const age = now - Date.parse(report.startedAt);
  const required = ["search", "planner", "auth", "writeReadback", "cleanup"];
  if (
    report.passed !== true ||
    report.stableImage !== stableImage ||
    report.candidateImage !== candidateImage ||
    report.migrationFingerprint !== ledger ||
    !Number.isFinite(report.elapsedSeconds) ||
    report.elapsedSeconds < 0 ||
    report.rtoTargetSeconds !== 300 ||
    report.elapsedSeconds > report.rtoTargetSeconds ||
    Date.parse(report.startedAt) + report.elapsedSeconds * 1000 > now + 1000 ||
    !Number.isFinite(age) ||
    age < 0 ||
    age > 7 * 86400000 ||
    !required.every((k) => report.functionalChecks?.[k] === true)
  )
    throw Error("Current images/schema need a successful functional rollback rehearsal");
}
