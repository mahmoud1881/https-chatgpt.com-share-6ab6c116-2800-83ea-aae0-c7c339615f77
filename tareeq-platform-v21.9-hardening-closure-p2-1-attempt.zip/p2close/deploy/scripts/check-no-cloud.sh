#!/usr/bin/env sh
# check-no-cloud.sh
# Guard: fail if any *.supabase.co URL leaks into deploy env files or the
# current shell environment. Used by .github/workflows/ci.yml in two modes:
#
#   1) With file arguments:
#        deploy/scripts/check-no-cloud.sh deploy/.env deploy/.env.example ...
#      -> greps each existing file for https?://<host>.supabase.co
#
#   2) With no arguments:
#        sh deploy/scripts/check-no-cloud.sh
#      -> scans the current process environment (VITE_SUPABASE_URL, etc.)
#
# Exits 0 when clean, 1 on the first hit. POSIX sh only (no bashisms).

set -eu

PATTERN='https?://[A-Za-z0-9.-]+\.supabase\.co'
status=0

if [ "$#" -gt 0 ]; then
  for f in "$@"; do
    [ -z "${f:-}" ] && continue
    if [ ! -f "$f" ]; then
      # Missing files are not an error — the workflow globs optimistically.
      continue
    fi
    if grep -InE "$PATTERN" "$f" >/dev/null 2>&1; then
      echo "::error file=$f::Found *.supabase.co reference in $f"
      grep -InE "$PATTERN" "$f" || true
      status=1
    fi
  done
else
  # Env-var mode: inspect the known VITE_SUPABASE_* keys plus a generic sweep.
  for var in VITE_SUPABASE_URL VITE_SUPABASE_PUBLISHABLE_KEY VITE_SUPABASE_PROJECT_ID SUPABASE_URL SUPABASE_ANON_KEY SUPABASE_SERVICE_ROLE_KEY; do
    # POSIX indirect expansion
    val=$(eval "printf '%s' \"\${$var:-}\"")
    [ -z "$val" ] && continue
    if printf '%s' "$val" | grep -qE "$PATTERN"; then
      echo "::error::Environment variable $var contains a *.supabase.co URL"
      status=1
    fi
  done
fi

if [ "$status" -eq 0 ]; then
  echo "✅ check-no-cloud: no *.supabase.co references detected."
fi

exit "$status"
