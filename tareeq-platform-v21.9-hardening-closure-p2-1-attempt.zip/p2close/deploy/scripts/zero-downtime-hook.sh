#!/usr/bin/env bash
set -euo pipefail
phase="${1:?phase required}"
# v21.1 default provider: the repository's self-hosted Docker Compose + Caddy stack.
# Set ZD_PROVIDER=custom to use explicit per-phase commands instead.
provider="${ZD_PROVIDER:-selfhost}"
if [[ "$provider" == "selfhost" ]]; then
  exec node deploy/scripts/provider-selfhost.mjs "$phase"
fi
echo 'Custom promotion providers are disabled; use the unified selfhost gate.' >&2
exit 78
