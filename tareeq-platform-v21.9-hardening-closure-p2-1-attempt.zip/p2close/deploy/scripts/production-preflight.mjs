import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const root=process.cwd(), artifacts=resolve(root,'artifacts'); mkdirSync(artifacts,{recursive:true});
const out=resolve(artifacts,'production-preflight.json');
const report={format:'tareeq-v21.9-production-preflight-v1',startedAt:new Date().toISOString(),checks:[],passed:false};
const add=(name,passed,detail)=>{report.checks.push({name,passed,detail}); if(!passed) report.passed=false;};
const secret=(name,{file=false,pattern=null}={})=>{const v=process.env[name]||''; let ok=!!v; if(ok&&file) ok=existsSync(v); if(ok&&pattern) ok=pattern.test(v); add(`env:${name}`,ok,ok?(file?'configured file':'configured'):'missing/invalid'); return ok;};
const tool=(name,args=['--version'])=>{const r=spawnSync(name,args,{encoding:'utf8',timeout:15000}); const ok=!r.error&&r.status===0; add(`tool:${name}`,ok,ok?'available':'not available'); return ok;};
async function http(name,url,path='/'){if(!url){add(name,false,'URL missing');return;} try{const r=await fetch(new URL(path,url),{signal:AbortSignal.timeout(8000)});add(name,r.ok,`HTTP ${r.status}`);}catch(e){add(name,false,e instanceof Error?e.message:String(e));}}
function pg(name,url){if(!url){add(name,false,'URL missing');return;} const r=spawnSync('psql',[url,'-v','ON_ERROR_STOP=1','-Atqc','select 1'],{encoding:'utf8',timeout:15000});add(name,!r.error&&r.status===0,!r.error&&r.status===0?'connected':'connection failed');}
try{
 report.passed=true;
 for(const t of ['git','docker','psql','supabase','syft','grype','gitleaks','cosign','crane']) tool(t);
 secret('STAGING_DATABASE_URL'); secret('PRODUCTION_DATABASE_URL');
 secret('SUPABASE_SERVICE_ROLE_KEY');
 secret('RELEASE_COMMIT',{pattern:/^[a-f0-9]{40}$/i});
 secret('RELEASE_IMAGE_REF'); secret('RELEASE_IMAGE_DIGEST',{pattern:/^sha256:[a-f0-9]{64}$/i});
 secret('COSIGN_PRIVATE_KEY_FILE',{file:true}); secret('COSIGN_PUBLIC_KEY_FILE',{file:true});
 secret('RELEASE_SIGNING_PRIVATE_KEY_FILE',{file:true}); secret('RELEASE_SIGNING_KEY_ID');
 secret('BACKUP_RESTORE_EVIDENCE_FILE',{file:true}); secret('DR_BACKUP_DIR',{file:true}); secret('DR_DISASTER_AT');
 secret('STABLE_PROBE_URL'); secret('CANDIDATE_PROBE_URL'); secret('TELEMETRY_PUBLIC_PROBE_URL');
 secret('TEMPO_URL'); secret('PROMETHEUS_URL'); secret('OTEL_EXPORTER_OTLP_ENDPOINT');
 pg('staging-database-connectivity',process.env.STAGING_DATABASE_URL); pg('production-database-connectivity',process.env.PRODUCTION_DATABASE_URL);
 await http('stable-endpoint',process.env.STABLE_PROBE_URL); await http('candidate-endpoint',process.env.CANDIDATE_PROBE_URL);
 await http('telemetry-public-probe',process.env.TELEMETRY_PUBLIC_PROBE_URL);
 await http('tempo-ready',process.env.TEMPO_URL,'/ready'); await http('prometheus-ready',process.env.PROMETHEUS_URL,'/-/ready');
 if(process.env.RELEASE_IMAGE_REF&&process.env.RELEASE_IMAGE_DIGEST&&tool('crane')){const immutable=`${process.env.RELEASE_IMAGE_REF}@${process.env.RELEASE_IMAGE_DIGEST}`;const r=spawnSync('crane',['digest',immutable],{encoding:'utf8',timeout:30000});add('registry-image-digest',!r.error&&r.status===0&&r.stdout.trim()===process.env.RELEASE_IMAGE_DIGEST,!r.error&&r.status===0?'registry digest checked':'registry lookup failed');}
 report.passed=report.checks.every(x=>x.passed); report.status=report.passed?'passed':'failed';
}catch(e){report.passed=false;report.status='failed';report.error=e instanceof Error?e.message:String(e);}finally{report.completedAt=new Date().toISOString();writeFileSync(out,JSON.stringify(report,null,2)+'\n',{mode:0o600});}
console.log(`${report.passed?'✅':'❌'} Production preflight ${report.status.toUpperCase()} — ${report.checks.filter(x=>!x.passed).length} failure(s)`); if(!report.passed)process.exit(1);
