#!/usr/bin/env bash
# Usage: ./scripts/restore.sh <backup-folder>
#
# Restores both halves of a backup.sh backup:
#   1. deploy-config.tar.gz  -> .env, docker-compose.yml, caddy/, scripts/
#   2. db-roles.sql + db.dump -> the actual Postgres data, into the `db`
#      container via psql/pg_restore.
#
# Config-only archives are rejected before any file is changed.
set -euo pipefail
cd "$(dirname "$0")/.."

SRC="${1:-}"
[[ "${RESTORE_OVERWRITE_ACK:-}" == replace-existing-database ]] || {
  echo 'Blocked: this legacy restore overwrites data. Review ROLLOUT_RUNBOOK.md and set RESTORE_OVERWRITE_ACK=replace-existing-database only for an approved recovery.' >&2
  exit 2
}
[[ -n "$SRC" ]] || { echo "Usage: $0 <backups/YYYY-MM-DD-HHMM>"; exit 1; }

if [[ ! -d "$SRC" ]]; then
  echo "❌ Not found: $SRC"; exit 1
fi

ARCHIVE="$SRC/deploy-config.tar.gz"
[[ -f "$ARCHIVE" ]] || { echo "❌ Backup archive not found: $ARCHIVE"; exit 1; }
DB_DUMP="$SRC/db.dump"
DB_ROLES="$SRC/db-roles.sql"
ROLE_NAMES="$SRC/db-role-names.txt"
[[ -s "$DB_DUMP" && -s "$DB_ROLES" ]] || {
  echo "❌ Full database dump and roles are required; no config-only restore." >&2; exit 1;
}
[[ -s "$SRC/SHA256SUMS" && -s "$ROLE_NAMES" ]] || { echo 'Missing integrity/roles manifests' >&2; exit 1; }
(cd "$SRC" && sha256sum -c SHA256SUMS)
umask 077
strict_roles=$(mktemp)
trap 'rm -f -- "$strict_roles"' EXIT
bash scripts/prepare-roles.sh "$DB_ROLES" "$ROLE_NAMES" > "$strict_roles"

echo "▶ Restoring deployment config from $ARCHIVE"
tar xzf "$ARCHIVE" -C .

echo "▶ Bringing up the db container..."
docker compose up -d db
echo "  waiting for db to be healthy..."
for i in $(seq 1 30); do
  docker compose exec -T db pg_isready -U postgres -d postgres >/dev/null 2>&1 && break
  sleep 2
done
docker compose exec -T db pg_isready -U postgres -d postgres >/dev/null 2>&1 || {
  echo "❌ db never became healthy — aborting restore."; exit 1;
}

if [[ -f "$DB_ROLES" ]]; then
  echo "▶ Restoring roles/globals from $DB_ROLES"
  docker compose exec -T db psql -X -U postgres -d postgres -v ON_ERROR_STOP=1 < "$strict_roles" >/dev/null
else
  echo "⚠️  No db-roles.sql in $SRC — restoring data only. If this is a fresh cluster, restore will likely fail on missing owners/grants."
fi

echo "▶ Restoring database from $DB_DUMP (this replaces existing data — --clean --if-exists)"
docker compose exec -T db pg_restore -U postgres -d postgres --clean --if-exists --exit-on-error < "$DB_DUMP"

echo "✅ Restore complete (config + database). Restart the app with: docker compose up -d --build"
