// Node adapter shim for the Cloudflare-Worker-shaped build output.
// The build (@lovable.dev/vite-tanstack-config → nitro cloudflare preset) emits
// `dist/server/index.mjs` with `export default { fetch(req, env, ctx) }` and expects
// `env.ASSETS.fetch()` to serve /dist/client/*. We replace ASSETS with local disk I/O
// and adapt Node req/res <-> Web Request/Response.

import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { createReadStream } from "node:fs";
import { join, extname, normalize, sep, resolve } from "node:path";
import { Readable } from "node:stream";

const DIST_DIR = process.env.DIST_DIR
  ? resolve(process.env.DIST_DIR)
  : resolve(process.cwd(), "dist");
const worker = (await import(new URL(`file://${DIST_DIR}/server/index.mjs`).href)).default;

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || "0.0.0.0";
const CLIENT_DIR = join(DIST_DIR, "client");
// Image identity must not change when env_file is edited for the next release.
const RELEASE_ID = (
  await readFile(join(process.cwd(), ".release-commit"), "utf8").catch(
    () => process.env.RELEASE_COMMIT || "unknown",
  )
).trim();

// ---------------------------------------------------------------------------
// Security headers (CSP / HSTS / etc.)
//
// This process sets these headers on every response so they apply even
// without a reverse proxy in front of it (e.g. running the container
// directly, or behind a bare load balancer). deploy/caddy/Caddyfile ALSO
// sets the same headers — and because Caddy's `header` directive replaces a same-named response header
// regardless of origin, Caddy's copy is what actually reaches the browser
// in the standard docker-compose deployment, not this file's. The two only
// stay in sync today because deploy/scripts/bootstrap.sh derives
// SUPABASE_PUBLIC_URL from the same API_DOMAIN Caddy's Caddyfile uses (see
// the comment there) — this file's dynamic derivation below is what
// applies when this server runs without Caddy in front of it, and is kept
// here so that path is still correctly hardened, not because it's
// guaranteed to win over Caddy's copy when both are present.
//
// connect-src for the self-hosted Supabase origin is derived at runtime from
// SUPABASE_PUBLIC_URL / VITE_SUPABASE_URL (same env vars docker-compose.yml
// already injects — see deploy/scripts/bootstrap.sh) rather than a hardcoded
// domain, for the same reason src/routes/__root.tsx reads it dynamically:
// this project must never bake in one specific backend's hostname.
function supabaseOrigin() {
  const url = process.env.SUPABASE_PUBLIC_URL || process.env.VITE_SUPABASE_URL;
  if (!url) return null;
  try {
    return new URL(url).origin;
  } catch {
    return null;
  }
}

function buildCsp() {
  const extraConnect = [supabaseOrigin()].filter(Boolean).join(" ");
  return [
    "default-src 'self'",
    "base-uri 'self'",
    "object-src 'none'",
    "frame-ancestors 'none'",
    "form-action 'self'",
    // 'unsafe-inline' on script-src is required today: TanStack Start's SSR
    // output includes its own inline hydration/streaming-barrier <script>
    // tags (verified in the actual rendered HTML), plus the per-page
    // <script type="application/ld+json"> structured-data blocks in
    // __root.tsx / route.$routeId.tsx / stop.$stopId.tsx whose content
    // varies per request. Neither can be pinned to a static hash, and a
    // nonce-based CSP would require threading a per-request nonce through
    // the SSR pipeline — a larger change than this header hardening pass.
    "script-src 'self' 'unsafe-inline'",
    // 'unsafe-inline' on style-src is required because React inline
    // `style={{...}}` props (used across the app) render as inline
    // `style="..."` attributes, which CSP's style-src also gates.
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob: https://a.tile.openstreetmap.org https://b.tile.openstreetmap.org https://c.tile.openstreetmap.org",
    "font-src 'self' data:",
    "worker-src 'self' blob:",
    // Third-party origins the browser calls directly (see BYOK_CLIENT_SIDE.md
    // for Gemini; nominatim/photon power address search; the wss:// hosts are
    // the public MQTT-over-WebSocket brokers in src/lib/free-realtime.ts).
    `connect-src 'self' https://generativelanguage.googleapis.com https://nominatim.openstreetmap.org https://photon.komoot.io wss://broker.emqx.io:8084 wss://broker.hivemq.com:8884${extraConnect ? " " + extraConnect : ""}`,
    "upgrade-insecure-requests",
  ].join("; ");
}

const CSP = buildCsp();

function applySecurityHeaders(res) {
  res.setHeader(
    "X-Tareeq-Channel",
    process.env.RELEASE_CHANNEL === "candidate" ? "candidate" : "stable",
  );
  res.setHeader("X-Tareeq-Release", RELEASE_ID);
  res.setHeader("Content-Security-Policy", CSP);
  // Browsers only honor HSTS on responses actually received over HTTPS, so
  // it's safe to always send this even when this process itself is plain
  // HTTP behind a TLS-terminating proxy (Caddy/Traefik) — it has no effect
  // until the outer connection is HTTPS. No `preload` here: that requires a
  // deliberate one-way submission to hstspreload.org that operators should
  // opt into themselves once they're sure the domain is fully HTTPS-only.
  res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  // geolocation=(self) stays enabled: NearbyView, live-tracking, and
  // navigate.tsx all use navigator.geolocation for real transit features.
  res.setHeader(
    "Permissions-Policy",
    "geolocation=(self), camera=(), microphone=(), payment=(), usb=()",
  );
}

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".avif": "image/avif",
  ".ico": "image/x-icon",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".txt": "text/plain; charset=utf-8",
  ".map": "application/json; charset=utf-8",
};

async function tryStaticFile(pathname) {
  // منع path traversal
  const rel = normalize(decodeURIComponent(pathname)).replace(/^([/\\])+/, "");
  if (rel.split(sep).includes("..")) return null;
  const abs = join(CLIENT_DIR, rel);
  try {
    const s = await stat(abs);
    if (s.isFile()) return abs;
  } catch {
    /* not found */
  }
  return null;
}

// بديل env.ASSETS.fetch من Cloudflare Workers
const assetsBinding = {
  async fetch(request) {
    const url = new URL(request.url);
    const abs = await tryStaticFile(url.pathname);
    if (!abs) return new Response("Not Found", { status: 404 });
    const ext = extname(abs).toLowerCase();
    const body = await readFile(abs);
    const headers = { "content-type": MIME[ext] || "application/octet-stream" };
    if (url.pathname.startsWith("/assets/") || /\.[0-9a-f]{8,}\./i.test(url.pathname)) {
      headers["cache-control"] = "public, max-age=31536000, immutable";
    }
    return new Response(body, { status: 200, headers });
  },
};

function nodeToWebRequest(req) {
  const proto = req.headers["x-forwarded-proto"] || "http";
  const host = req.headers["x-forwarded-host"] || req.headers.host || `localhost:${PORT}`;
  const url = `${proto}://${host}${req.url}`;
  const method = req.method || "GET";
  const headers = new Headers();
  for (const [k, v] of Object.entries(req.headers)) {
    if (Array.isArray(v)) v.forEach((x) => headers.append(k, x));
    else if (v != null) headers.set(k, String(v));
  }
  const init = { method, headers };
  if (method !== "GET" && method !== "HEAD") {
    init.body = Readable.toWeb(req);
    init.duplex = "half";
  }
  return new Request(url, init);
}

async function writeWebResponse(webRes, res) {
  res.statusCode = webRes.status;
  webRes.headers.forEach((value, key) => res.setHeader(key, value));
  res.setHeader("X-Tareeq-Release", RELEASE_ID);
  res.setHeader(
    "X-Tareeq-Channel",
    process.env.RELEASE_CHANNEL === "candidate" ? "candidate" : "stable",
  );
  if (!webRes.body) return res.end();
  const nodeStream = Readable.fromWeb(webRes.body);
  nodeStream.pipe(res);
  nodeStream.on("error", () => res.end());
}

const server = createServer(async (req, res) => {
  const started = performance.now();
  // v21.6 controlled failure injection. This is deliberately candidate-only,
  // requires an operator-provided secret, and is activated per synthetic request.
  const chaosToken = process.env.CHAOS_CERTIFICATION_TOKEN || "";
  const requestedChaos = String(req.headers["x-tareeq-chaos-mode"] || "").toLowerCase();
  const suppliedChaosToken = String(req.headers["x-tareeq-chaos-token"] || "");
  const chaosAllowed = process.env.RELEASE_CHANNEL === "candidate" && chaosToken.length >= 24 && suppliedChaosToken === chaosToken;
  if (requestedChaos && chaosAllowed) {
    const supported = new Set(["5xx", "latency", "db-outage", "external-failure"]);
    if (!supported.has(requestedChaos)) { res.writeHead(400, {"content-type":"text/plain"}); return res.end("Unsupported chaos mode"); }
    console.error(JSON.stringify({event:"chaos_injection",mode:requestedChaos,category:requestedChaos === "db-outage" ? "database" : requestedChaos === "external-failure" ? "external" : "application",at:new Date().toISOString()}));
    if (requestedChaos === "latency") await new Promise(r => setTimeout(r, Number(process.env.CHAOS_LATENCY_MS || 4500)));
    else {
      const status = requestedChaos === "external-failure" ? 502 : requestedChaos === "db-outage" ? 503 : 500;
      res.writeHead(status,{"content-type":"application/json","cache-control":"no-store"});
      return res.end(JSON.stringify({error:"certification fault injected",mode:requestedChaos}));
    }
  }
  let requestKind = "dynamic";
  // Emit only method/status/elapsed time. Paths may contain private search terms.
  res.once("finish", () => {
    console.log(
      JSON.stringify({
        event: "http_request",
        method: req.method,
        at: new Date().toISOString(),
        probe: /^(Wget|Tareeq-Probe)\//i.test(req.headers["user-agent"] || ""),
        kind: requestKind,
        status: res.statusCode,
        durationMs: Math.round(performance.now() - started),
      }),
    );
  });
  try {
    applySecurityHeaders(res);

    // 1) خدمة الملفات الساكنة من dist/client أولاً
    const pathname = (req.url || "/").split("?")[0];
    if (req.method === "GET" || req.method === "HEAD") {
      const abs = await tryStaticFile(pathname);
      if (abs) {
        requestKind = "static";
        const ext = extname(abs).toLowerCase();
        res.setHeader("content-type", MIME[ext] || "application/octet-stream");
        if (pathname.startsWith("/assets/") || /\.[0-9a-f]{8,}\./i.test(pathname)) {
          res.setHeader("cache-control", "public, max-age=31536000, immutable");
        }
        if (req.method === "HEAD") {
          res.statusCode = 200;
          return res.end();
        }
        return createReadStream(abs).pipe(res);
      }
    }

    // 2) تمرير للخادم (SSR / server functions / server routes)
    const webReq = nodeToWebRequest(req);
    const env = { ASSETS: assetsBinding, ...process.env };
    const ctx = { waitUntil: () => {}, passThroughOnException: () => {} };
    const webRes = await worker.fetch(webReq, env, ctx);
    if (!webRes) {
      res.statusCode = 204;
      return res.end();
    }
    await writeWebResponse(webRes, res);
  } catch (err) {
    console.error("[server] request failed:", err);
    if (!res.headersSent) {
      res.writeHead(500, { "content-type": "text/plain; charset=utf-8" });
    }
    res.end("Internal Server Error");
  }
});

server.listen(PORT, HOST, () => {
  console.log(`[server] listening on http://${HOST}:${PORT}`);
});

for (const sig of ["SIGINT", "SIGTERM"]) {
  process.on(sig, () => server.close(() => process.exit(0)));
}
