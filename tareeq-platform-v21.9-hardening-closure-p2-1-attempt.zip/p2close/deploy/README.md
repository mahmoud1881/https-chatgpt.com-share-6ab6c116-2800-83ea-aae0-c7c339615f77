# Self-Host Deploy Kit

نشر المنصة **بالكامل** على سيرفرك الخاص — بما في ذلك قاعدة البيانات وطبقة
المصادقة والـ Realtime — بدون أي اعتماد على `*.supabase.co` أو خدمات
سحابية خارجية.

## ما يعمل داخل الحاويات

| Service   | الصورة | الدور |
|-----------|---------|-------|
| `db`       | `supabase/postgres` | قاعدة البيانات + الامتدادات |
| `auth`     | `supabase/gotrue`   | تسجيل الدخول والجلسات |
| `rest`     | `postgrest/postgrest` | Data API (PostgREST) |
| `realtime` | `supabase/realtime` | القنوات المباشرة (live / pulse) |
| `meta`     | `supabase/postgres-meta` | فحص السكيمة |
| `studio`   | `supabase/studio`   | لوحة تحكم القاعدة |
| `kong`     | `kong`              | API Gateway لتوجيه `/auth /rest /realtime` |
| `app`      | يُبنى محليًا | تطبيق TanStack Start |
| `proxy`    | `caddy`             | SSL تلقائي (Let's Encrypt) |

## المتطلبات

- سيرفر Linux مع Docker 24+ و Docker Compose v2 و `openssl`.
- ثلاثة سجلات DNS من نوع A تشير إلى IP السيرفر:
  - `app.example.com` — التطبيق
  - `api.example.com` — بوابة Supabase (Kong)
  - `studio.example.com` — لوحة تحكم القاعدة
- فتح البورتات 80 و 443.

## التثبيت

```bash
git clone <repo-url> platform && cd platform/deploy
./scripts/bootstrap.sh      # يولّد .env: POSTGRES_PASSWORD, JWT_SECRET,
                            # ANON_KEY و SERVICE_ROLE_KEY (JWT مُوقّع HS256)،
                            # كلمة مرور Studio، إلخ.
./scripts/deploy.sh          # يبني الصور، يشغّل db، يُطبّق كل الـ migrations
                            # من ../supabase/migrations، ثم يشغّل باقي الـ stack.
```

بعد النشر:
- `https://app.example.com`     → التطبيق
- `https://api.example.com`     → API (يستخدمه العميل تلقائيًا عبر `VITE_SUPABASE_URL`)
- `https://studio.example.com`  → Studio (Basic Auth بالبيانات المولّدة في `.env`)

## الأوامر اليومية

```bash
./scripts/logs.sh
./scripts/health.sh
./scripts/backup.sh           # نسخة مشفرة وموثقة على مضيف مستقل
./scripts/restore-rehearsal.sh "$BACKUP_ID"
./scripts/update.sh           # git pull + rebuild + rerun migrations
```

`deploy.sh` now waits for the stack health probes and exits nonzero when any
required service fails. `health.sh` checks the containers, a real PostgreSQL
query, Auth/REST, the application HTTP endpoint, and a Realtime channel join.
For a clean staging
deployment, provision a new host and new database volume, run `bootstrap.sh`
and `deploy.sh`, then keep the CI run URL and the successful health output with
the deployed commit. These probes do not replace an authenticated login flow,
external DNS/TLS, mailbox delivery, OAuth callback, or an isolated restore rehearsal.

On the fresh staging host, run `./scripts/staging-verify.sh` after `deploy.sh`.
It rejects missing configuration and insecure endpoints, then probes the
public HTTPS app, Auth and REST URLs as well as the internal stack. Record its
exit code together with the CI run and the deployed commit. Do not reuse a
production database or run a fresh-volume rehearsal against production data.

## التحقق والتعافي في staging

اتبع [دليل التجربة التشغيلية](STAGING_RUNBOOK.md) لنشر staging جديد وفحص
PostgreSQL وAuth وREST وقناة Realtime، والتحقق من DNS/TLS وتسليم رسالة بريد
ومسار OAuth مكتمل. لا يشكل قبول طلب إرسال البريد أو بدء إعادة توجيه OAuth
إثباتًا على وصول الرسالة أو نجاح العودة إلى التطبيق.

`backup.sh` ينشئ تفريغ PostgreSQL والإعدادات ويشفّر الحزمة بمفتاح `age` عام
ثم يرفعها إلى مضيف SSH مستقل ويتحقق من سلامة النسخة هناك. لا يحتفظ
بنسخة احتياطية ناجحة على خادم التطبيق. فعّل المؤقت اليومي بعد تجهيز
`/etc/platform/backup.env` ومفاتيح SSH المثبتة مسبقًا:

```bash
sudo cp systemd/platform-backup.service systemd/platform-backup.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now platform-backup.timer
journalctl -u platform-backup.service -n 50
```

شغّل `restore-rehearsal.sh <backup-id>` لاستعادة البيانات والإعدادات في مشروع
Compose منفصل مؤقت وقياس مدة تنزيل النسخة واستعادة قاعدة البيانات وإقلاع
خدمات التطبيق. يحفظ تقرير JSON في `deploy/backups/rehearsals/` وينظف المشروع
المؤقت بعد التجربة. لا تشغّل `restore.sh` على بيانات فعلية دون خطة استعادة
محددة؛ إنه يستبدل قاعدة البيانات الحالية.

## ملاحظات أمنية

- `.env` يحتوي على `JWT_SECRET` و `SUPABASE_SERVICE_ROLE_KEY` — لا تُرفَع لأي repo.
- `service_role` يتجاوز RLS: استخدمه فقط داخل server functions/webhooks.
- Studio مكشوف على subdomain مستقل بـ Basic Auth. للأمان الأقصى: أزل
  `studio` من `docker-compose.yml` أو قيّده بـ VPN/IP allowlist.
- CI (`.github/workflows/ci.yml`) يمنع تسريب أي `*.supabase.co` في
  ملفات النشر عبر `scripts/check-no-cloud.sh`.

## التمييز عن النسخة السابقة من الـ README

النسخة القديمة قالت "لا توجد مفاتيح خلفية خارجية" لكن الكود كان يعتمد
فعليًا على `*.supabase.co`. هذه النسخة تُصلح التناقض: تشغّل Supabase
كاملًا داخل الـ stack المحلي، فتصبح العبارة صحيحة تقنيًا لا مجرد ادّعاء.
