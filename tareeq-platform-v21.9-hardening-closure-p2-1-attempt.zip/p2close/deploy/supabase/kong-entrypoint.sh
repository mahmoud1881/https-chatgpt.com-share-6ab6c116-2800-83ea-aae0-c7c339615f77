#!/bin/sh
# Render only the two allowlisted JWT values, never eval arbitrary config.
set -eu
umask 077
: "${SUPABASE_ANON_KEY:?Missing anonymous JWT}"
: "${SUPABASE_SERVICE_KEY:?Missing service JWT}"
for value in "$SUPABASE_ANON_KEY" "$SUPABASE_SERVICE_KEY"; do
  printf '%s' "$value" | grep -Eq '^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$' || {
    echo 'Kong requires a three-segment JWT; refusing unsafe substitution' >&2
    exit 2
  }
done
template=${KONG_TEMPLATE_PATH:-/var/lib/kong/kong.template.yml}
output=${KONG_DECLARATIVE_CONFIG:-/tmp/kong-rendered.yml}
sed -e "s/\${SUPABASE_ANON_KEY}/$SUPABASE_ANON_KEY/g" \
    -e "s/\${SUPABASE_SERVICE_KEY}/$SUPABASE_SERVICE_KEY/g" "$template" > "$output"
if grep -q '\${' "$output"; then
  echo 'Unresolved Kong configuration placeholder' >&2
  exit 2
fi
[ "${KONG_RENDER_ONLY:-false}" = true ] && exit 0
exec /docker-entrypoint.sh kong docker-start
