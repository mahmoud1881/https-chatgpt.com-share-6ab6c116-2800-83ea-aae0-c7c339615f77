-- Seed the default tenant for supabase/realtime v2.
-- Realtime performs its Ecto migrations on container start (creating the
-- _realtime schema). Without a row in _realtime.tenants, every subscribe
-- request is rejected as "unknown tenant" and the client hangs silently.
--
-- This script is idempotent: safe to run on every deploy.
-- Expects psql vars:  :jwt_secret  (API_JWT_SECRET / JWT_SECRET)
--                     :tenant      (external_id, e.g. 'realtime-dev' or your project ref)

\set ON_ERROR_STOP on

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.schemata WHERE schema_name = '_realtime') THEN
    RAISE EXCEPTION '_realtime schema missing — start the realtime container once so it runs its migrations, then re-run this seed.';
  END IF;
END $$;

-- Tenant row
INSERT INTO _realtime.tenants (
  id, name, external_id, jwt_secret,
  max_concurrent_users, max_events_per_second, max_bytes_per_second,
  max_channels_per_client, max_joins_per_second,
  postgres_cdc_default, inserted_at, updated_at
)
VALUES (
  gen_random_uuid(),
  :'tenant',
  :'tenant',
  :'jwt_secret',
  200, 100, 100000, 100, 100,
  'postgres_cdc_rls',
  now(), now()
)
ON CONFLICT (external_id) DO UPDATE
  SET jwt_secret = EXCLUDED.jwt_secret,
      updated_at = now();

-- Postgres CDC extension binding (points realtime at the local db).
INSERT INTO _realtime.extensions (
  id, type, settings, tenant_external_id, inserted_at, updated_at
)
SELECT
  gen_random_uuid(),
  'postgres_cdc_rls',
  jsonb_build_object(
    'db_host',      'db',
    'db_name',      'postgres',
    'db_user',      'supabase_admin',
    'db_password',  current_setting('seed.pg_pass', true),
    'db_port',      '5432',
    'region',       'local',
    'poll_interval_ms', 100,
    'poll_max_record_bytes', 1048576,
    'ssl_enforced', false
  ),
  :'tenant',
  now(), now()
WHERE NOT EXISTS (
  SELECT 1 FROM _realtime.extensions
  WHERE tenant_external_id = :'tenant' AND type = 'postgres_cdc_rls'
);
