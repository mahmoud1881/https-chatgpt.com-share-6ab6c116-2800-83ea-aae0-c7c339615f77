-- Bootstrap Supabase roles that GoTrue, PostgREST, and Realtime expect.
-- Runs once when the postgres data volume is first initialised.
-- Password is injected from POSTGRES_PASSWORD via psql \set below.

\set pg_pass `echo "$POSTGRES_PASSWORD"`

-- Core Supabase roles
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'supabase_admin') THEN
    CREATE ROLE supabase_admin LOGIN SUPERUSER CREATEDB CREATEROLE REPLICATION BYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'supabase_auth_admin') THEN
    CREATE ROLE supabase_auth_admin LOGIN CREATEROLE NOINHERIT;
  END IF;
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'authenticator') THEN
    CREATE ROLE authenticator NOINHERIT LOGIN NOREPLICATION;
  END IF;
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'anon') THEN
    CREATE ROLE anon NOLOGIN NOINHERIT;
  END IF;
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'authenticated') THEN
    CREATE ROLE authenticated NOLOGIN NOINHERIT;
  END IF;
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'service_role') THEN
    CREATE ROLE service_role NOLOGIN NOINHERIT BYPASSRLS;
  END IF;
END $$;

ALTER ROLE supabase_admin      WITH PASSWORD :'pg_pass';
ALTER ROLE supabase_auth_admin WITH PASSWORD :'pg_pass';
ALTER ROLE authenticator       WITH PASSWORD :'pg_pass';

GRANT anon, authenticated, service_role TO authenticator;

-- Auth schema owned by supabase_auth_admin (GoTrue manages its tables here).
CREATE SCHEMA IF NOT EXISTS auth AUTHORIZATION supabase_auth_admin;
GRANT USAGE ON SCHEMA auth TO anon, authenticated, service_role;

-- Public schema privileges expected by PostgREST.
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;

-- Extensions required by Supabase services.
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgjwt";
