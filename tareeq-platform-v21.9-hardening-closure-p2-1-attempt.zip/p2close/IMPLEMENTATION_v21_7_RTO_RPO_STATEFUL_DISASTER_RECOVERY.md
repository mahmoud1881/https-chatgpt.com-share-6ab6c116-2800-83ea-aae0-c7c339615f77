# v21.7 — RTO/RPO & Stateful Disaster Recovery Certification

This release adds a fail-closed disaster-recovery certification gate. `recovery:certify` requires a verified full PostgreSQL backup, computes actual backup age as RPO evidence, restores roles and the custom database dump into a unique isolated Docker Compose project, verifies critical row counts and a canonical schema fingerprint, restarts the complete stack, re-runs end-to-end telemetry certification, restores Stable traffic, and measures elapsed recovery time against the configured RTO.

## Safety invariants

- Recovery testing never intentionally overwrites the production Compose project; a unique `tareeqdr...` project is mandatory.
- Backup checksum verification, `db.dump`, role globals and captured data metrics are mandatory.
- RPO is measured from backup artifact age (`DR_RPO_TARGET_SECONDS`).
- RTO is measured from the start of destructive isolated recovery through proven Stable traffic restoration (`DR_RTO_TARGET_SECONDS`).
- Schema and critical data counts must match after restore.
- Telemetry must recover end-to-end unless an explicit non-production-only skip is set.
- Production certification fails if any proof is absent or either RTO/RPO target is exceeded.
- Evidence is written to `artifacts/disaster-recovery-certification.json`.

Static invariant enforcement is wired into `release:gate` through `security:recovery:dr`. The live DR exercise is intentionally separate because it requires Docker, a real full backup, telemetry endpoints, and provider routing; it must be executed by the production certification pipeline with those dependencies present.

## Recovery proof correction (v21.9 baseline patch)

Recovery certification now binds every integrity assertion to the isolated restored database. The backup captures, from the same exported PostgreSQL snapshot, a database-derived recovery-point timestamp, canonical schema fingerprint, and deterministic per-table content fingerprints for `public` and `auth`. The DR run recomputes schema/content proofs inside its owned isolated Compose database and requires exact SHA-256 equality with those source proofs.

RPO is no longer inferred from `db.dump` filesystem mtime. It is measured as `DR_DISASTER_AT - recovery-point.captured_at`. RTO is anchored at the declared disruption timestamp (`DR_DISASTER_AT`) and ends only at the recovery checkpoint reached by the certification run. This prevents script-start time and copied-file timestamps from producing misleading RPO/RTO results.
