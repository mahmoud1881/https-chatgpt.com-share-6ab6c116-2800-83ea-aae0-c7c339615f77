import { test, expect } from '@playwright/test';
test('public legal CTAs are navigable and not dead anchors', async ({page})=>{
  await page.goto('/challenges');
  await expect(page.getByRole('link',{name:'سياسة الخصوصية'})).toHaveAttribute('href','/privacy');
  await expect(page.getByRole('link',{name:'الشروط'})).toHaveAttribute('href','/terms');
  await expect(page.getByRole('button',{name:/ابدأ التحدي/}).first()).toBeDisabled();
});
test('wallet actions are explicitly unavailable instead of fake-success', async ({page})=>{
  await page.goto('/card');
  await expect(page.getByRole('button',{name:/Apple Wallet/})).toBeDisabled();
  await expect(page.getByRole('button',{name:/Google Wallet/})).toBeDisabled();
});
