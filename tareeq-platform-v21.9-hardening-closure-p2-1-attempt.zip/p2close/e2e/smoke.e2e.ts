import { expect, test } from "@playwright/test";

for (const route of ["/capital-train", "/lrt", "/trains"]) {
  test(`transport page renders after pricing removal: ${route}`, async ({ page }) => {
    const response = await page.goto(route);
    expect(response?.ok()).toBe(true);
    if (route === "/trains") {
      await expect(page.getByRole("heading", { name: "🚆 القطارات", exact: true })).toBeVisible();
    } else {
      await expect(page.locator("main")).toBeVisible();
    }
    await expect(page.getByText("الأرخص", { exact: true })).toHaveCount(0);
  });
}

test("homepage loads for an anonymous visitor", async ({ page }) => {
  await page.goto("/");
  await expect(page).toHaveTitle(/مواصلات/);
});

test("a browsing route (metro) does not require login", async ({ page }) => {
  await page.goto("/metro");
  // Should render the page itself, not bounce to the auth gate.
  await expect(page).not.toHaveURL(/\/auth/);
});

test("metro journey between line 3 branches changes at Kit-Kat", async ({ page }) => {
  await page.goto("/metro");
  await page.getByLabel("من", { exact: true }).fill("السودان");
  await page.getByLabel("إلى", { exact: true }).fill("جامعة القاهرة");
  await expect(page.getByText("الخط 3a", { exact: false }).first()).toBeVisible();
  await expect(page.getByText("الخط 3b", { exact: false }).first()).toBeVisible();
  await expect(page.getByText(/🔄.*الكيت كات/).first()).toBeVisible();
});

test("a gated 'use' route (nearby) redirects an anonymous visitor to /auth", async ({ page }) => {
  await page.goto("/nearby");
  await page.waitForURL(/\/auth(\?|$)/, { timeout: 10_000 });
  await expect(page.getByRole("button", { name: /جوجل/ })).toBeVisible();
});
