import { expect, test, type Page } from '@playwright/test';

const proxy=process.env.P1_STATE_PROXY_URL;
function req(name:string,v:string|undefined){if(!v) throw new Error(`P1-3 prerequisite missing: ${name}`);return v;}
async function mode(page:Page,value:string){
  const base=req('P1_STATE_PROXY_URL',proxy);
  const r=await page.request.post(`${base.replace(/\/$/,'')}/mode`,{data:{mode:value}});
  expect(r.ok(),`state proxy rejected mode ${value}`).toBeTruthy();
}
async function stats(page:Page){
  const base=req('P1_STATE_PROXY_URL',proxy);
  const r=await page.request.get(`${base.replace(/\/$/,'')}/stats`); expect(r.ok()).toBeTruthy(); return r.json();
}

test.describe('P1-3 state integrity',()=>{
  test.afterEach(async({page})=>{if(proxy) await mode(page,'healthy').catch(()=>{});});

  test('double-submit produces at most one admin mutation',async({page})=>{
    req('E2E_ADMIN_EMAIL',process.env.E2E_ADMIN_EMAIL); req('E2E_ADMIN_PASSWORD',process.env.E2E_ADMIN_PASSWORD);
    await mode(page,'count-mutations'); await page.goto('/admin/route-requests');
    const action=page.getByRole('button',{name:/مراجعة|نشر|رفض|ربط/i}).first();
    await expect(action).toBeVisible();
    await action.dblclick();
    const s=await stats(page); expect(s.mutations??0).toBeLessThanOrEqual(1);
  });

  test('stale response cannot overwrite a newer journey search',async({page})=>{
    await mode(page,'reorder-search-responses'); await page.goto('/planner');
    const inputs=page.locator('input'); expect(await inputs.count()).toBeGreaterThanOrEqual(2);
    await inputs.nth(0).fill('A'); await inputs.nth(1).fill('B'); await page.locator('form').first().press('Enter');
    await inputs.nth(0).fill('C'); await inputs.nth(1).fill('D'); await page.locator('form').first().press('Enter');
    await expect(page.locator('body')).toContainText(/C|D/,{timeout:20000});
    const body=await page.locator('body').innerText(); expect(body).not.toMatch(/stale-result-A-B/i);
  });

  test('refresh and back-forward preserve a coherent route/deep-link state',async({page})=>{
    await page.goto('/planner'); const original=page.url(); await page.reload(); expect(page.url()).toBe(original);
    await page.goto('/explore'); await page.goBack(); expect(page.url()).toContain('/planner'); await page.goForward(); expect(page.url()).toContain('/explore');
  });

  test('session interruption during a protected operation fails closed',async({page})=>{
    req('E2E_USER_EMAIL',process.env.E2E_USER_EMAIL); req('E2E_USER_PASSWORD',process.env.E2E_USER_PASSWORD);
    await mode(page,'expire-session'); await page.goto('/nearby');
    await expect(page).toHaveURL(/\/auth|\/nearby/,{timeout:15000});
    const body=await page.locator('body').innerText(); expect(body).not.toMatch(/تم.*بنجاح|successfully saved/i);
  });

  test('concurrent mutation resolves to one consistent final state',async({page})=>{
    req('E2E_ADMIN_EMAIL',process.env.E2E_ADMIN_EMAIL); req('E2E_ADMIN_PASSWORD',process.env.E2E_ADMIN_PASSWORD);
    await mode(page,'conflicting-mutations'); await page.goto('/admin/route-requests');
    const s=await stats(page); expect(s.partialState??false).toBeFalsy(); expect(s.finalStates??1).toBe(1);
  });
});
