import { expect, test, type Page } from "@playwright/test";

const ADMIN_EMAIL=process.env.E2E_ADMIN_EMAIL;
const ADMIN_PASSWORD=process.env.E2E_ADMIN_PASSWORD;
const PENDING=process.env.P1_PENDING_ROUTE_TOKEN;
const REJECTED=process.env.P1_REJECTED_ROUTE_TOKEN;
const APPROVED_UNPUBLISHED=process.env.P1_APPROVED_UNPUBLISHED_ROUTE_TOKEN;
const PUBLISHED=process.env.P1_PUBLISHED_ROUTE_TOKEN;

function req(name:string,v:string|undefined){if(!v) throw new Error(`P1-1 prerequisite missing: ${name}`);return v;}
async function signIn(page:Page){
  await page.goto('/auth?redirect=%2Fadmin%2Fdata-review');
  await page.getByLabel('البريد الإلكتروني').fill(req('E2E_ADMIN_EMAIL',ADMIN_EMAIL));
  await page.getByLabel('كلمة المرور').fill(req('E2E_ADMIN_PASSWORD',ADMIN_PASSWORD));
  await page.getByRole('button',{name:'دخول',exact:true}).click();
  await page.waitForURL(/\/admin\/data-review/,{timeout:15000});
}
async function searchBoth(page:Page,token:string){
  await page.goto('/planner');
  const body1=await page.locator('body').innerText();
  await page.goto('/explore');
  const body2=await page.locator('body').innerText();
  return {planner:body1.includes(token),explore:body2.includes(token)};
}

test.describe('P1-1 data lifecycle',()=>{
  test('pending is absent from Planner and Explore',async({page})=>{
    const r=await searchBoth(page,req('P1_PENDING_ROUTE_TOKEN',PENDING)); expect(r).toEqual({planner:false,explore:false});
  });
  test('rejected is absent from Planner and Explore',async({page})=>{
    const r=await searchBoth(page,req('P1_REJECTED_ROUTE_TOKEN',REJECTED)); expect(r).toEqual({planner:false,explore:false});
  });
  test('approved but unpublished is absent from Planner and Explore',async({page})=>{
    const r=await searchBoth(page,req('P1_APPROVED_UNPUBLISHED_ROUTE_TOKEN',APPROVED_UNPUBLISHED)); expect(r).toEqual({planner:false,explore:false});
  });
  test('published active route is visible through the canonical journey surfaces',async({page})=>{
    const token=req('P1_PUBLISHED_ROUTE_TOKEN',PUBLISHED);
    await page.goto(`/planner?p1_route=${encodeURIComponent(token)}`);
    await expect(page.locator('body')).toContainText(token,{timeout:15000});
    await page.goto(`/explore?p1_route=${encodeURIComponent(token)}`);
    await expect(page.locator('body')).toContainText(token,{timeout:15000});
  });
  test('provenance and trust survive publication',async({page})=>{
    const token=req('P1_PUBLISHED_ROUTE_TOKEN',PUBLISHED);
    await page.goto(`/planner?p1_route=${encodeURIComponent(token)}`);
    const body=await page.locator('body').innerText();
    expect(body).toMatch(/موثّق|verified/i);
    expect(body).not.toMatch(/قيد المراجعة|mixed/i);
  });
  test('revoked route disappears after lifecycle invalidation',async({page})=>{
    await signIn(page);
    // Runtime fixture orchestration is intentionally external: the runner must revoke the
    // dedicated P1 fixture between setup and this assertion and invalidate caches/indexes.
    const token=req('P1_REVOKED_ROUTE_TOKEN',process.env.P1_REVOKED_ROUTE_TOKEN);
    const r=await searchBoth(page,token); expect(r).toEqual({planner:false,explore:false});
  });
});
