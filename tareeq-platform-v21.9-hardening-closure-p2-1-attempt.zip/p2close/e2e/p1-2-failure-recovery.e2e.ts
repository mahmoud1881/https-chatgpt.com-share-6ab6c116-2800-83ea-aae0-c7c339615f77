import { expect, test, type Page } from '@playwright/test';

const proxy=process.env.P1_FAILURE_PROXY_URL;
function req(name:string,v:string|undefined){if(!v) throw new Error(`P1-2 prerequisite missing: ${name}`);return v;}
async function mode(page:Page,value:string){
  const base=req('P1_FAILURE_PROXY_URL',proxy);
  const r=await page.request.post(`${base.replace(/\/$/,'')}/mode`,{data:{mode:value}});
  expect(r.ok(),`failure proxy rejected mode ${value}`).toBeTruthy();
}
async function recover(page:Page){await mode(page,'healthy');}
async function assertNoFabricatedVerified(page:Page){
  const body=await page.locator('body').innerText();
  expect(body).not.toMatch(/verified.*fallback|fallback.*verified/i);
}

test.describe('P1-2 failure and recovery',()=>{
  test.afterEach(async({page})=>{if(proxy) await recover(page).catch(()=>{});});

  test('API timeout terminates loading and exposes recovery without fabricated journey',async({page})=>{
    await mode(page,'timeout'); await page.goto('/planner');
    await expect(page.getByText(/إعادة المحاولة|حاول مرة أخرى|استغرق/i).first()).toBeVisible({timeout:20000});
    await assertNoFabricatedVerified(page);
  });

  test('network/backend outage fails safely and recovers after retry',async({page})=>{
    await mode(page,'offline'); await page.goto('/explore');
    await expect(page.locator('body')).toContainText(/تعذّر|خطأ|إعادة المحاولة|حاول/i,{timeout:20000});
    await assertNoFabricatedVerified(page); await recover(page); await page.reload();
    await expect(page.locator('body')).not.toContainText(/خطأ غير متوقع/,{timeout:15000});
  });

  test('malformed response is not promoted to a trusted journey',async({page})=>{
    await mode(page,'malformed'); await page.goto('/planner');
    await expect(page.locator('body')).toContainText(/تعذّر|خطأ|إعادة المحاولة|لا توجد/i,{timeout:20000});
    await assertNoFabricatedVerified(page);
  });

  test('empty result is a terminal empty state rather than perpetual loading',async({page})=>{
    await mode(page,'empty'); await page.goto('/explore');
    await expect(page.locator('body')).toContainText(/لا توجد|لم نجد|جرّب|حاول/i,{timeout:20000});
    await expect(page.locator('body')).not.toContainText(/جارٍ التحميل/,{timeout:2000});
  });

  test('transient failure can recover to healthy Planner and Explore surfaces',async({page})=>{
    await mode(page,'error'); await page.goto('/planner');
    await expect(page.locator('body')).toContainText(/تعذّر|خطأ|إعادة المحاولة|حاول/i,{timeout:20000});
    await recover(page); await page.reload();
    await page.goto('/explore'); await expect(page.locator('body')).toBeVisible();
  });

  test('admin mutation dependency failure does not report success',async({page})=>{
    req('E2E_ADMIN_EMAIL',process.env.E2E_ADMIN_EMAIL); req('E2E_ADMIN_PASSWORD',process.env.E2E_ADMIN_PASSWORD);
    await mode(page,'db-outage'); await page.goto('/admin/data-review');
    const body=await page.locator('body').innerText();
    expect(body).not.toMatch(/تم.*بنجاح|successfully approved/i);
  });
});
