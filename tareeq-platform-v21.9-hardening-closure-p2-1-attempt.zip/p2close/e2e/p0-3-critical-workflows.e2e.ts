import { expect, test, type Page } from "@playwright/test";

const USER_EMAIL = process.env.E2E_USER_EMAIL;
const USER_PASSWORD = process.env.E2E_USER_PASSWORD;
const ADMIN_EMAIL = process.env.E2E_ADMIN_EMAIL;
const ADMIN_PASSWORD = process.env.E2E_ADMIN_PASSWORD;

function requireCredential(name: string, value: string | undefined): string {
  if (!value) throw new Error(`P0-3 prerequisite missing: ${name}`);
  return value;
}

async function signIn(page: Page, email: string, password: string, redirect = "/") {
  await page.goto(`/auth?redirect=${encodeURIComponent(redirect)}`);
  await page.getByLabel("البريد الإلكتروني").fill(email);
  await page.getByLabel("كلمة المرور").fill(password);
  await page.getByRole("button", { name: "دخول", exact: true }).click();
  await page.waitForURL((url) => !url.pathname.startsWith("/auth"), { timeout: 15_000 });
}

async function plannerSearch(page: Page, from: string, to: string) {
  await page.goto("/planner");
  await page.getByPlaceholder("مثال: رمسيس، التحرير…").fill(from);
  await page.getByPlaceholder("مثال: العتبة، مصر الجديدة…").fill(to);
  await page.getByRole("button", { name: "ابحث", exact: true }).click();
  await expect(page.locator('[data-load-result="planner"]')).toBeVisible({ timeout: 15_000 });
}

test.describe("P0-3 auth/session", () => {
  test("anonymous protected deep-link redirects to auth and preserves destination", async ({ page }) => {
    await page.goto("/nearby?source=p03");
    await page.waitForURL(/\/auth\?/, { timeout: 10_000 });
    const url = new URL(page.url());
    expect(url.searchParams.get("redirect")).toContain("/nearby");
  });

  test("login returns to protected destination; refresh survives; logout revokes", async ({ page }) => {
    const email = requireCredential("E2E_USER_EMAIL", USER_EMAIL);
    const password = requireCredential("E2E_USER_PASSWORD", USER_PASSWORD);
    await signIn(page, email, password, "/nearby");
    await expect(page).toHaveURL(/\/nearby/);
    await page.reload();
    await expect(page).toHaveURL(/\/nearby/);
    const logout = page.getByRole("button", { name: "تسجيل الخروج" });
    await expect(logout).toBeVisible();
    await logout.click();
    await page.goto("/nearby");
    await page.waitForURL(/\/auth(\?|$)/, { timeout: 10_000 });
  });

  test("invalidated local session cannot retain protected access", async ({ page, context }) => {
    const email = requireCredential("E2E_USER_EMAIL", USER_EMAIL);
    const password = requireCredential("E2E_USER_PASSWORD", USER_PASSWORD);
    await signIn(page, email, password, "/nearby");
    await context.clearCookies();
    await page.evaluate(() => localStorage.clear());
    await page.reload();
    await page.waitForURL(/\/auth(\?|$)/, { timeout: 10_000 });
  });
});

test.describe("P0-3 canonical journey", () => {
  test("planner journey opens route details and survives direct deep-link refresh", async ({ page }) => {
    await plannerSearch(page, "رمسيس", "التحرير");
    const route = page.locator('a[href^="/route/"]').first();
    await expect(route).toBeVisible();
    const href = await route.getAttribute("href");
    expect(href).toMatch(/^\/route\//);
    await route.click();
    await expect(page).toHaveURL(/\/route\//);
    const routeUrl = page.url();
    await page.reload();
    expect(page.url()).toBe(routeUrl);
    await expect(page.locator("main")).toBeVisible();
  });

  test("planner and explore expose the same canonical trust semantics", async ({ page }) => {
    await plannerSearch(page, "رمسيس", "التحرير");
    const plannerText = await page.locator('[data-load-result="planner"]').innerText();
    const plannerVerified = plannerText.includes("موثّق");
    const plannerReview = plannerText.includes("قيد المراجعة");

    await page.goto("/explore");
    const input = page.getByPlaceholder("اكتب بلغتك: ازاي اروح من مادي لرمسيس؟");
    await input.fill("ازاي اروح من رمسيس للتحرير؟");
    await page.getByRole("button", { name: "بحث", exact: true }).click();
    await expect(page.getByText(/رمسيس.*التحرير|التحرير.*رمسيس/).first()).toBeVisible({ timeout: 15_000 });
    const body = await page.locator("body").innerText();
    if (plannerVerified && !plannerReview) expect(body).toContain("موثّق");
    if (plannerReview) expect(body).toMatch(/قيد المراجعة|مختلط/);
  });
});

test.describe("P0-3 admin authorization and review lifecycle", () => {
  test("anonymous admin access is denied", async ({ page }) => {
    await page.goto("/admin/data-review");
    await page.waitForURL(/\/auth(\?|$)/, { timeout: 10_000 });
  });

  test("authenticated non-admin is denied", async ({ page }) => {
    const email = requireCredential("E2E_USER_EMAIL", USER_EMAIL);
    const password = requireCredential("E2E_USER_PASSWORD", USER_PASSWORD);
    await signIn(page, email, password, "/");
    await page.goto("/admin/data-review");
    await page.waitForURL((url) => url.pathname === "/", { timeout: 10_000 });
  });

  test("admin is allowed and review queue supports approve/reject without auto-publish", async ({ page }) => {
    const email = requireCredential("E2E_ADMIN_EMAIL", ADMIN_EMAIL);
    const password = requireCredential("E2E_ADMIN_PASSWORD", ADMIN_PASSWORD);
    await page.addInitScript(() => localStorage.setItem("USE_LAYER_4_ADMIN_REVIEW", "true"));
    await signIn(page, email, password, "/admin/data-review");
    await expect(page).toHaveURL(/\/admin\/data-review/);
    await expect(page.getByRole("heading", { name: /مراجعة البيانات/ }).first()).toBeVisible();
    await expect(page.getByText(/لا يتم تطبيق أي اقتراح على الجداول الأصلية/)).toBeVisible();
    await page.getByRole("button", { name: "Review Queue" }).click();
    await expect(page.getByText(/Review Queue|قائمة المراجعة/).first()).toBeVisible();
  });
});
