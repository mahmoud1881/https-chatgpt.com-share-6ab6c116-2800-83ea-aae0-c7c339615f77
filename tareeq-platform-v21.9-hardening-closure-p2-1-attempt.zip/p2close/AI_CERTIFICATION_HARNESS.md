# Tareeq Unified AI Certification Harness

The harness is outside the production request path. It performs synthetic routing/failure-injection certification for Local AI, Jev, GPT-OSS 120B, Gemini 3.8, evidence, rate limits and cost governance.

Hard boundary: synthetic/mock PASS never grants runtime PASS or authoritative truth. Real runtime observations remain null until executed against real device/provider infrastructure.

Current local non-regression gate: P3 + control-plane/v1 + extension isolation + AI runtime + adapters + AI harness.

## Dual-mode certification
The harness has two strictly separated evidence channels:
- `SYNTHETIC`: deterministic/mock fault-injection certification.
- `RUNTIME`: real provider probes using server-side credentials.

Synthetic PASS can never satisfy a runtime observation. Missing credentials preserve `executed=false`, `observed=null`, and `passed=null`. Real provider reachability also does not grant end-to-end acceptance; E2E evidence and Control Plane prerequisites remain required.

Commands:
- `npm run ai:harness:runtime`
- `npm run ai:harness:dual`
- `npm run ai:harness:dual:test`
- `npm run ai:harness:dual:non-regression`
