> Updated trust requirements: see `docs/operations/certification-trust.md`. Verification now requires an independently provisioned external key and expected release identity; v1 certificates are rejected.

# v21.8 — Full Production Certification Orchestrator & Signed Release Evidence

`npm/bun run production:certify` is the only path in this release that emits `status: "PRODUCTION CERTIFIED"`.
It is fail-closed and executes the live Database/RLS + schema-drift gate, zero-downtime migration/progressive-delivery deployment, end-to-end telemetry certification, runtime chaos/recovery certification, and stateful DR/RTO/RPO certification.

The resulting `artifacts/production-certification.json` binds the certification to the full Git SHA (`RELEASE_COMMIT`), immutable OCI image digest (`RELEASE_IMAGE_DIGEST`), canonical production schema fingerprint, migration-integrity manifest SHA-256, and SHA-256 of every runtime evidence document. It is signed with an Ed25519 private key supplied via `RELEASE_SIGNING_PRIVATE_KEY_FILE`; the private key is never copied into the project or artifacts. The detached Base64 signature is written to `artifacts/production-certification.sig`, and the public key is exported for offline verification.

Required release inputs include the existing runtime-gate credentials plus `RELEASE_COMMIT`, `RELEASE_IMAGE_DIGEST`, `RELEASE_SIGNING_PRIVATE_KEY_FILE`, and `RELEASE_SIGNING_KEY_ID`. Verification is offline with `bun run production:verify`.

A failed or incomplete runtime gate writes `NOT CERTIFIED` and exits non-zero. Static gates alone cannot create a production certification.
