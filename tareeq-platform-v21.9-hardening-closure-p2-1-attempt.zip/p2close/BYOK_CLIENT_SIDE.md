# Client-Side Gemini: user-owned API only

## Current architecture

The user-facing AI planner no longer extracts a route and then runs a platform-local route engine.

The flow is:

`User -> Tareeq UI -> Browser -> Gemini Interactions API -> Browser -> Tareeq UI`

The browser sends the user's own Gemini API key directly to Google. Tareeq does not proxy the request and does not supply an AI key.

## Gemini capabilities enabled

The browser calls the Gemini Interactions API with:

- `google_search` for fresh web-grounded information and citations.
- `url_context` for URLs the user asks Gemini to inspect.
- `code_execution` for calculations/data reasoning when Gemini decides it is useful.
- high thinking level and a large output budget for detailed answers.

The application explicitly instructs Gemini not to use Tareeq's local transit graph, local route engine, station data, local embeddings, or any other platform data for the AI answer.

## Data policy for the AI planner

No Tareeq transit data is supplied to Gemini.

No local route engine is called by `/ai-planner`.

No local embedding model is called by `/ai-planner`.

No Lovable AI gateway is called by `/ai-planner`.

Conversation history is kept only in browser `sessionStorage` and the Interactions requests use `store: false`.

## Important billing/security note

The platform does not buy or provide Gemini tokens. Usage is charged/limited according to the Google project and key owned by the user. A client-side API key is inherently visible to the user/device; Google recommends treating keys as secrets and warns against embedding a platform-owned key in production client code.
