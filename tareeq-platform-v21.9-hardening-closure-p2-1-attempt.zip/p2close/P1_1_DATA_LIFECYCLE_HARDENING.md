# P1-1 Data Lifecycle Hardening

This artifact is built directly on the P0-3 E2E baseline. P0 remains a non-regression gate.

## Implemented
- P1-1 lifecycle Playwright suite for pending, rejected, approved-but-unpublished, published, provenance/trust, and revocation/invalidation scenarios.
- Contract tests that enforce active-only canonical journey lifecycle and evidence-bearing review records.
- A static P1-1 gate and separate readiness evidence artifact.
- Package scripts: `test:p1-1:contracts`, `test:p1-1:static`, `test:p1-1`, `test:p1-1:portable`.

## Executed in this build environment
- P0-3 structural/static gate: PASS.
- P1-1 contract tests: 3/3 PASS.
- P1-1 static gate: 6/6 PASS.
- Portable application/data/source gates: PASS.
- Data review tests: 5/5 PASS.
- Quarantined records: 196; leaked into active dataset: 0.

## Not executed
P0-3 and P1-1 runtime Playwright are not marked PASS. They require the real application/Supabase runtime, credentials, browser dependencies, and dedicated lifecycle fixtures. The artifact therefore remains `accepted: false` until those runtime suites pass.
