# Tareeq AI Runtime v1

Frozen routing order: deterministic core -> on-device/local AI -> Jev decision observation -> GPT-OSS 120B reasoning -> Gemini 3.8 independent escalation/verification -> Control Plane derived decision.

## Implemented adapters
- Jev: `POST https://api.typesafe.ai/v1/systemone`, bearer `TYPESAFE_API_KEY`, default model `jev-latest`.
- Groq: OpenAI-compatible `/chat/completions`, bearer `GROQ_API_KEY`, model `openai/gpt-oss-120b`, JSON response mode.
- Gemini: REST `generateContent`, `GEMINI_API_KEY`, model `gemini-3.8-flash`, used only as verification/escalation observation.
- Local device AI: capability bridge `__TAREEQ_LOCAL_AI__.infer`; unavailable devices fail closed/fall back through the router.

Provider output is observation only. Providers cannot write VERIFIED_PASS, CLOSED, CERTIFIED, authorization, or execute privileged tools.

## Certification
`npm run ai:runtime:non-regression` validates P3/control-plane/extension baseline plus AI contracts/adapters.
`npm run ai:runtime:certify` writes local certification evidence.
`npm run ai:runtime:certify:runtime` writes fail-closed runtime readiness. Credential presence never becomes PASS and all unexecuted observations remain null.

P2-1 remains independent and NOT CERTIFIED until its real Bun 1.4.0 build runner succeeds.

## Unified AI Certification Harness boundary
The AI harness is certification-only and is deliberately outside the production request path. It may create synthetic runs, inject provider/evidence/budget failures, capture synthetic evidence and request certification observations. It cannot serve production traffic, mutate production evidence, bypass authorization, approve deployments, change provider policy, write VERIFIED_PASS/CLOSED/CERTIFIED, or convert mock success into runtime success.

Commands:
- `npm run ai:harness:test`
- `npm run ai:harness:certify`
- `npm run ai:harness:non-regression`

The harness artifact keeps every real runtime observation `null` until a real provider/device execution occurs.
