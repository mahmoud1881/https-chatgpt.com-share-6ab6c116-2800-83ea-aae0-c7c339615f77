# v21.5 — Production Telemetry Stack & SLO-Based Release Certification

Implemented an OTLP production telemetry path: application -> OpenTelemetry Collector -> Tempo, with span-derived application metrics exported to Prometheus, PostgreSQL metrics from postgres-exporter, and Grafana provisioned with Prometheus/Tempo data sources.

`telemetry:certify` is fail-closed: it requires Collector/Tempo/Prometheus availability, sends a W3C trace test request, proves the exact trace can be retrieved from Tempo, proves application span metrics are queryable in Prometheus, and proves `pg_up == 1`. Evidence is written to `artifacts/telemetry-certification.json`.

Progressive delivery now requires both the existing active-probe SLO and `telemetry-slo-gate.mjs`, so promote/hold/abort cannot rely only on local probes. The backend gate requires live span metrics and database telemetry.

Production certification still requires running the stack and `npm run telemetry:certify`; static configuration alone is not runtime certification.
