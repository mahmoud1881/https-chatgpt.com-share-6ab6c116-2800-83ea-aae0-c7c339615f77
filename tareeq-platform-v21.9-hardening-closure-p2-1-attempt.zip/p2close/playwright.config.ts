import { defineConfig, devices } from "@playwright/test";

// Real release-gate config: builds and serves the actual production bundle
// (not the dev server) so e2e runs against what would actually ship.
//
// testDir is deliberately its own top-level folder (e2e/, not colocated
// under src/) so Playwright's own test discovery never touches the
// *.test.ts(x) files vitest owns — running `playwright test` with no
// testDir previously scanned the whole repo, picked up vitest's test
// files too, and both runners' global `expect` collided
// ("Cannot redefine property: Symbol($$jest-matchers-object)").
export default defineConfig({
  testDir: "./e2e",
  testMatch: /.*\.e2e\.ts/,
  timeout: 30_000,
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  reporter: process.env.CI ? "github" : "list",
  use: {
    baseURL: "http://127.0.0.1:4173",
    trace: "on-first-retry",
  },
  webServer: {
    // Build once, then serve the real output — mirrors what the Docker
    // image actually runs, unlike testing against `vite dev`.
    command: "bun run build && PORT=4173 HOST=127.0.0.1 node deploy/app/server.mjs",
    url: "http://127.0.0.1:4173",
    reuseExistingServer: !process.env.CI,
    timeout: 180_000,
  },
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
});
