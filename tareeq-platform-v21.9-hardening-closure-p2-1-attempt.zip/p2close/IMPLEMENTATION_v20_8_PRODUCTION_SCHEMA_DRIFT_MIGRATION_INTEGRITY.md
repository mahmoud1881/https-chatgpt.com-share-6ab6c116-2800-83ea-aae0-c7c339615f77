# v20.8 — Production Schema Drift & Migration Integrity Gate

## Implemented
- Added an immutable SHA-256 manifest for all 121 migration files (`supabase/migration-integrity.json`). Existing migration hashes cannot be re-blessed by the update helper; schema changes must be appended as new migrations.
- Added a deterministic PostgreSQL catalog snapshot covering public tables/RLS/ACLs, columns/defaults, constraints, indexes, RLS policies and roles, functions (definition, SECURITY DEFINER, proconfig/search_path, ACL), views, triggers, enum/domain types, and installed extensions.
- Added a release-only remote drift gate that compares both staging and production against a fresh from-zero ephemeral Supabase database built from Git migrations.
- Remote `supabase_migrations.schema_migrations` ledgers must exactly equal Git's ordered migration versions. Missing and out-of-band migration versions fail the release.
- Staging and production semantic schema SHA-256 fingerprints must exactly match the ephemeral Git-derived baseline. Manual DDL, policy, grant, function, trigger, view, constraint, index, column, or RLS changes fail the release.
- Drift checks are read-only against staging/production. On mismatch, canonical expected/actual snapshots are emitted under `artifacts/` for diagnosis.
- `release:gate` is fail-closed: Docker, Supabase CLI, psql, `STAGING_DATABASE_URL`, and `PRODUCTION_DATABASE_URL` are mandatory. It starts a clean local Supabase, replays migrations, reruns the v20.7 authorization proof, compares remote ledgers/schema fingerprints, and tears local state down.

## Release command
```sh
STAGING_DATABASE_URL='postgresql://...' \
PRODUCTION_DATABASE_URL='postgresql://...' \
bun run release:gate
```

## Adding a legitimate migration
Create a new timestamped SQL migration; do not edit an existing one. Then append its hash:
```sh
node scripts/update-migration-integrity.mjs
```
The helper refuses to update the manifest if any already-recorded migration changed.

## Proof boundary
A green v20.8 gate proves that the application-owned PostgreSQL surface represented by the catalog fingerprint and the migration version ledger match Git at check time. It intentionally does not fingerprint row data, Supabase-managed internal schemas, object ownership, extension versions, or infrastructure outside PostgreSQL.
