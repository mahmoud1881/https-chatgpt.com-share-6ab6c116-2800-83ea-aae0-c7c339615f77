# Unified Workflow Gate

This gate freezes P0-1/P0-2/P0-3 and P1-1..P1-4 as one release workflow boundary.

- `npm run workflow:gate:local` executes all portable/static/contract non-regression gates. If they pass, it writes `artifacts/unified-workflow-readiness.json` with `status: RUNTIME_PENDING` and exits 75.
- `npm run workflow:gate:runtime` first re-runs every local gate, then executes the five Playwright runtime suites. It exits 0 only if every local and runtime suite executes and passes.
- Any local or runtime failure is fail-closed and exits non-zero.

`IMPLEMENTED`, `EXECUTED`, `PASSED`, and `ACCEPTED` remain distinct. A test file existing on disk is never runtime evidence.

## v2 evidence hardening

The unified gate now executes P0-1 and P0-2 contract suites explicitly before P0-3/P1 checks. Runtime-only invariants are represented as `{ required, observed, evidence }`; `observed` remains `null` until the relevant runtime suites execute successfully. Compiler/build readiness is a separate gate containing compiler-config, TypeScript, ESLint, Vitest, and the production build.

Commands:
- `npm run workflow:gate:local` — local contracts/static/data evidence only; returns 75 as `BUILD_PENDING` when green.
- `npm run workflow:gate:build` — local + compiler/test/build; returns 75 as `RUNTIME_PENDING` when green.
- `npm run workflow:gate:runtime` — local + compiler/test/build + Playwright runtime; returns 0 only when all are green.
