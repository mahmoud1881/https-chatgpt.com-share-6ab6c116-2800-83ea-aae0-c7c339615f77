# v20.5 — Admin Authorization Hardening & Endpoint Security Audit

## Implemented

- Added `scripts/audit-admin-security.mjs` as a fail-closed static security gate.
- Inventories every detected `createServerFn` with method, gate (`admin` / `auth` / `public`), service-role usage, and admin-sensitivity into `artifacts/endpoint-security-inventory.json`.
- Fails when an admin-sensitive endpoint is not structurally protected by `requireSupabaseAdmin`.
- Fails on direct `SUPABASE_SERVICE_ROLE_KEY` reads outside the canonical `client.server.ts` boundary.
- Fails on static imports of the service-role client from client-shippable `*.functions.ts` files.
- Verifies the raw HTTP admin-session guard delegates role decisions to canonical `hasAdminRole`.
- Audits migration history for surviving public tables created without observed RLS enablement (and accounts for later dropped tables).
- Added the security audit to `release:gate`, before typecheck/build/E2E.
- Added Vitest regression coverage that executes the repository-wide audit.

## Service-role boundary hardening

Two unrelated hashing paths previously reused `SUPABASE_SERVICE_ROLE_KEY` as a salt. That coupling was removed. Production now requires `RATE_LIMIT_SALT` and/or `REQUEST_FINGERPRINT_SALT`; `.env.example` documents both as independent server-only secrets.

The route-verification fingerprint also no longer trusts `cf-connecting-ip` / `x-forwarded-for` directly. It uses the centralized `callerIp()` trust policy, which only accepts the ingress-controlled `x-real-ip` when `TRUST_PROXY_HEADERS=true`.

## Audit result for this snapshot

Static audit result: **PASS**.

Detected server functions: **69**
- Admin-gated: **52**
- Authenticated-user gated: **5**
- Public: **12**

The generated JSON inventory is retained in the release artifact for review/diffing.

## Scope / evidence limits

This is structural/static evidence. It does not prove the deployed database has exactly the migration state in this repository, and it does not replace runtime authorization tests against a real Supabase environment. The production release gate still requires its normal typecheck, lint, unit, build, E2E, data, and Docker checks.
