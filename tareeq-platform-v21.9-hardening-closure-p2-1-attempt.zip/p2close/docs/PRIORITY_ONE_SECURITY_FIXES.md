# Priority-one security fixes — 2026-09-23

## Included

- A restrictive authenticated INSERT policy requires the current owner, pending
  status and zero confirmations. The DB supplies auth.uid() when owner is omitted.
- The add-route UI validates the current user, supplies user_id, always releases
  its submitting state, inserts the saved record into local state and subscribes
  to the Egyptian feed instead of deriving a country from the route pathname.
- Shared MQTT events contain only record IDs. Before dispatching to consumers,
  records are fetched through the normal RLS client or the privacy-preserving
  traffic RPC. Missing, malformed, wrong-country and inaccessible rows are dropped.
  Vehicle events only invalidate a view; they carry no trusted location data.
- Anonymous dedicated-channel receiving is disabled; that unused API must not be
  used for trip sharing until an authenticated transport is implemented.
- Old question/answer cache keys are retired. Anonymous hints are bounded to one
  fetch per topic every two seconds and four concurrent reads; offline publish
  queues are capped at 100. MQTT remains best-effort: hints can be dropped, and
  verified records remain community reports, not independently verified facts.
- Rate identities no longer vary with browser/language headers. Only validated
  X-Real-IP from an explicitly trusted ingress is used. Caddy overwrites it from
  the socket peer for stable and canary traffic; CF and XFF cannot override it.
  Limiter transport errors fail closed.

## Deployment requirements and tradeoffs

Apply the new migration and deploy the Caddy configuration with the app. Never
expose the app port directly while TRUST_PROXY_HEADERS=true. If another proxy/CDN
sits before Caddy, its socket IP is deliberately shared by users until a separate
trusted-proxy design is configured and tested; do not re-enable raw CF/XFF trust.
IP quotas can group users behind NAT. Anonymous MQTT flooding can delay live
refreshes, but cannot supply displayed records. Reload retrieves authoritative
data. This is not a replacement for server-side abuse limits on the API itself.

## Evidence and remaining gates

Executed locally: 10 Node tests passed (6 new hint-verification tests and 4 existing
deployment tests); no-transit-pricing guard passed. SQL behavioral regression is
added to CI for valid insertion plus forged status, confirmations and owner.
Vitest regression cases cover forged headers, changing browser/language, rejected
limiter promises and disabling dedicated-channel inbound claims.

NOT executed locally: SQL integration, Vitest, full typecheck/build, Docker/Caddy
adaptation or live staging. This environment has no project node_modules, Bun,
Docker or psql. These are release blockers until CI and staging provide evidence.
The other findings in the audit remain outside this priority-one patch.
