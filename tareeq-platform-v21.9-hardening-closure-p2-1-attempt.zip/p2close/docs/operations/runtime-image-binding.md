# Bind certification to the deployed image

The certification pipeline now accepts one application image identity:

```
RELEASE_IMAGE_REF=registry.example/team/tareeq
RELEASE_IMAGE_DIGEST=sha256:<64 lowercase hex characters>
```

`RELEASE_IMAGE_REF` is an untagged registry/repository. The orchestrator derives `registry/repository@sha256:...` and sets both `NEW_RELEASE` and `CANDIDATE_APP_IMAGE` to it. Conflicting explicit values fail before runtime gates. Supply-chain registry lookup, SBOM scans, image signing, attestations, and candidate deployment all use that immutable reference. The old stable image remains a separate rollback target.

The self-host provider pulls this exact reference and starts the candidate with `--no-build --pull never`. It uses the explicit project `platform` and the repository's Compose file. Custom providers are not sufficient by themselves: certification still inspects that actual Compose candidate and fails if it is missing or different. Standalone zero-downtime runs additionally require a unique `CERTIFICATION_RUN_ID`; the full orchestrator creates it automatically.

Each live observation requires exactly one running candidate, correct Compose project/service labels, exact configured immutable image reference, a matching Docker image ID, and that reference in the local image's `RepoDigests`. Mounts that could replace image contents are rejected. This correctly compares a registry manifest/index digest through Docker's image metadata, rather than incorrectly assuming it equals Docker's local config image ID.

Nine ordered checkpoints are required:

1. After deploying the candidate, before readiness/synthetic/progressive tests.
2. After deployment tests.
3. Before and after telemetry certification.
4. Before and after chaos certification.
5. Before and after disaster recovery certification.
6. Immediately before certificate validation/signing.

Every checkpoint must see the same image ID AND container ID. Even replacing a container with the same image requires a fresh full test run. Readiness/synthetic hooks and candidate traffic shifts also inspect identity. Database-only gates before candidate deployment do not purport to test the application image.

`artifacts/runtime-image-binding.json` is the 14th required evidence file. The certificate hashes it. The strict v3 verifier checks its run/release identity, all nine observations, their chronology around runtime gates, and consistency with supply-chain and deployment evidence. v1/v2 certificates must be regenerated. A missing observation, Docker error, mutable tag, conflicting image, wrong container, changed container, or absent repository digest fails closed.

22 simulated Docker tests and four additional certificate-policy rejection tests cover the new behavior. No live Docker deployment or certification was executed here. The existing isolated-DR restriction still blocks full production certification until full recovery evidence exists.

These are point-in-time Docker observations, not continuous monitoring or proof against a privileged operator changing a container between observations. Protect the Docker daemon, verifier code, trust configuration and certification workspace; do not run overlapping certification jobs against the same candidate. Image identity also does not prove that every externally configured HTTP probe reached that container; endpoint-to-container routing proof remains a separate operational requirement.
