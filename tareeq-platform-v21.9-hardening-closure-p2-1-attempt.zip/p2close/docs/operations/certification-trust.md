# Independent certificate trust — v31.9 safety update

The v3 verifier no longer trusts `production-certification-public-key.pem` supplied by the artifact producer. Provision an Ed25519 public key and its identifier independently in a protected CI configuration, outside the bundle directory. Obtain that key through the release authority's approved channel; do not copy an unverified key out of the bundle to establish trust. Protect verifier code, expected release inputs and trust configuration from artifact authors. Key rotation changes that independently managed configuration; a bundled key cannot rotate trust.

Required verifier inputs:

```
RELEASE_TRUSTED_PUBLIC_KEY_FILE=/etc/tareeq/trust/release.pem
RELEASE_TRUSTED_KEY_ID=release-key-2026
RELEASE_COMMIT=<expected lowercase full Git SHA>
RELEASE_IMAGE_DIGEST=sha256:<expected lowercase image digest>
CERTIFICATION_BUNDLE_ROOT=/absolute/path/to/bundle
npm run production:verify
```

Set these as environment variables in the protected verification job. The bundle root contains `artifacts/` and `supabase/migration-integrity.json`. Expected commit and image digest must come from the deployment request, not from parsing the submitted certificate. Optional positional arguments remain manifest and detached-signature paths; the former third public-key argument is rejected. There is no bundled-key fallback.

The signer additionally requires its existing private-key file and signing-key identifier, and checks they match independently configured trust BEFORE runtime gates. It deletes stale detached signatures and report outputs. The same validation policy runs before signing and during verification.

## Enforced acceptance rules

- Only the strict `tareeq-production-certification-v3` envelope is accepted, with exact keys for the certificate, release, signature metadata, runtime gates and evidence descriptors. Previous certificates require regeneration.
- All six named runtime gates must succeed in order. All 14 required evidence entries and their files must exist. Fixed bundle-relative paths, regular files and no symlink components are required.
- Every file's SHA-256 is recomputed from its actual bytes. SBOM, provenance, schema and migration-manifest hashes are cross-checked against their related release records.
- The externally expected commit/image identity, Ed25519 trusted key, key ID, signature and signing-key fingerprint must agree.
- Certificates expire 24 hours after the run starts. Future timestamps beyond 60 seconds, invalid dates and inconsistent ordering fail. Generated evidence timestamps must fall inside the signed run window, allowing 60 seconds of clock skew. Filesystem modification time is not a freshness source. The static migration manifest is content-bound rather than assigned an invented generation time.
- Evidence content is checked for the required supply-chain checks, SBOM/provenance identity, both database schema targets, migration results, deployment phases, five successful canary stages, telemetry checks, four chaos scenarios and full disaster recovery including cleanup.
- Unknown/missing formats, failed evidence and skipped DR telemetry cannot certify production. The previous isolated-database DR patch continues to block a full production certificate.

Schema and migration-safety producers now emit completion timestamps. The deployment phase writer also correctly records progressive-delivery success as a string instead of mistakenly storing the phase detail object as its status.

## Verification and limits

35 automated trust-policy tests cover a valid certificate/CLI invocation and rejection of self-signed substitution, absent trust, bundled trust, tampering, missing files/fields/gates, path traversal/symlinks, expired/future evidence, wrong release, skipped checks and partial recovery. These tests use synthetic evidence and generated test keys; they are not production certification.

The policy validates signed evidence and its required structure. It does not independently replay runtime probes, prove that a trusted signer reported events honestly, or prove uninterrupted identity between Docker observations. The runtime image checks are described in `runtime-image-binding.md`. No production keys were generated or installed, and no runtime deployment was executed by this patch.
