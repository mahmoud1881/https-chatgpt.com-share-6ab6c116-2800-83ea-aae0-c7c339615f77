# Recovery isolation safety patch — v21.9

## Operational behavior

`DR_BACKUP_DIR=/absolute/verified/backup npm run recovery:certify`

Use a dedicated staging Docker daemon and trusted backup/image. This patch does not authorize running a live drill against production. The command now creates a random `tareeqdr-<UUID>` project; callers cannot supply a project name or external database endpoint. It checks containers (including stopped containers), networks, and volumes before starting, and separately checks the physical volume name for collisions. Docker inspection errors stop the operation.

The rendered source Compose configuration supplies only the database image. A private temporary Compose file defines one database, fresh credentials, one newly named local volume, no published ports, and `network_mode: none`. Production bind mounts, startup commands, credentials, dependency services, and initialization mounts are not copied. This deliberately changes bootstrap behavior: backups must contain the required roles/schema, and incompatible globals or image defaults may cause a strict restore failure. SQL and dump input now reaches the container over piped stdin.

Before restore, the script inspects actual container ownership, network mode, ports, privilege flag and mounts, and checks volume ownership. Configuration intent alone is not considered proof of isolation.

`DR_PROJECT_NAME`, `DR_RESTORED_DATABASE_URL`, `DR_TRAFFIC_STATE_FILE`, `DR_KEEP_ISOLATED_ENV`, and `DR_SKIP_TELEMETRY_CERTIFICATION` are rejected when set, including empty values. Remove old overrides before invoking the command.

## Cleanup

No initial `compose down`, volume deletion, or orphan removal is performed. Cleanup begins only after preflight passes and startup is attempted. It finds resources carrying BOTH this run's random ownership label and its Compose project label, re-inspects ownership, and removes individual resources. This also covers a partially failed startup. It does not force-delete volumes. Cleanup failures are included in the final JSON and prevent success. The private configuration is removed afterward.

The evidence file is `artifacts/disaster-recovery-certification.json`. Review `project`, `databaseContainer`, `cleanup.removed`, and `cleanup.errors`. If cleanup fails, investigate those exact resources; do not run broad cleanup against the production Compose file. Concurrent administrators with control of the Docker daemon are outside this ownership-label safety model.

## Certification limit — intentional fail closed

The production-targeting telemetry and traffic-provider commands have been removed from this drill. Full certification remains `passed: false` with a nonzero exit code. A completed database drill records `databaseRecoveryPassed: true`; this is NOT a full disaster-recovery certificate. Isolated services, telemetry and traffic recovery must be implemented and demonstrated before full certification can pass. Existing RPO based on dump mtime, schema fingerprint without reference comparison, storage recovery and real restoration timing remain separate open validation gaps.

## Verification performed

20 automated tests, using in-memory Docker simulation and fake command executables; no real Docker daemon or PostgreSQL restoration was run. Tests cover production-name overrides, project/resource collisions, stopped-container inventory, unavailable Docker, partial startup, changed ownership, foreign resources, cleanup errors, actual-network/mount verification, and main-script preflight failures. Run:

```
node scripts/disaster-recovery-static-gate.mjs
```

A live drill on a separate staging daemon remains required before operational acceptance. No journey pricing was introduced.
