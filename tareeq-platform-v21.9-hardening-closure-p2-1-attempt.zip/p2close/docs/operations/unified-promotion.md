# Unified promotion policy

All supported positive traffic shifts now enter `deploy/scripts/rollout-traffic.mjs`, including self-host provider `shift-canary`, `shift-full`, progressive delivery and direct CLI use. The provider no longer writes Caddy routing itself. Custom hook providers and alternate zero-downtime configurations are rejected. The sole traffic state is `deploy/backups/rollout/traffic-state.json`; the v21.1 alternate state is no longer authoritative. Initialize/review the canonical closed-trial state; an existing legacy state does not automatically authorize promotion.

Inside the traffic lock, the entrypoint inspects the immutable candidate and executes a NEW `rollout-gate.mjs` evaluation. A previously saved PASS is insufficient. Existing current-state/image/routing/migration checks then run before Caddy changes. The gate includes:

- Fresh full load evidence for the expected release and staging targets, with the existing account, trip and scenario coverage requirements.
- Reviewed Egyptian journey benchmark evidence for the release, enforcing existing acceptance/safety criteria.
- Mailbox AND completed OAuth attachments, rehashed and verified against an independently signed reviewer manifest for the current staging probe. Timestamps alone or an old receipt do not suffice. The signed review receipt is retained in the gate report.
- Existing restore evidence, observation windows, monitoring, safety review and functional rollback conditions.

Required additional input: `ROLLOUT_TRIP_EVIDENCE` points to the reviewed journey observations. Use absolute paths for evidence and reviewer keys when calling from the project root, since the canonical traffic command runs from `deploy/`. Supply all existing `ROLLOUT_LOAD_*`, restore and staging-review environment inputs. Mail/OAuth uses `deploy/backups/staging-probe.json`, `STAGING_EVIDENCE_MANIFEST`, the external reviewer key/identity and matching staging context; the existing one-hour probe validity applies at every increase.

Run individual promotions from `deploy/`, after satisfying the current observation window:

```
node scripts/rollout-traffic.mjs 1
# Later, with renewed/reviewed evidence and the next window complete:
node scripts/rollout-traffic.mjs 5
```

Only adjacent `0 → 1 → 5 → 25 → 50 → 100` transitions pass. Existing 24-hour windows (48 hours at 50%) are preserved. A quick progressive-controller invocation therefore stops with a non-success result when the next window is not complete; it does not certify a multi-day rollout as a short test. A resumable multi-day certification workflow is still needed before the current full-production orchestrator can certify that entire sequence. DR certification remains independently blocked as previously documented.

Rollback to 0 remains available without promotion evidence. It uses the same routing implementation and state and invalidates old approvals. Rollback is not permission to jump back to the previous exposure level.

Numeric options are validated before use: exact ordered stage list, holds 0–3, finite bounded timeouts/durations, at least 20 observations per cohort, and no relaxed error/latency/DB-error thresholds. Empty strings, negative numbers, NaN, Infinity, fractional counts, unknown percentages and invalid bootstrap values fail. Existing staging bootstrap does not bypass load, trips or mail/OAuth checks. Chaos scripts with previously reduced 12-second/10-request settings will be blocked by these production policy bounds; chaos rehearsal needs its own properly isolated workflow, not a production-promotion exception.

Each stage shifts once; holds repeat observation only. A fresh stage SLO file must match the current deployment, percent and observation interval. Missing/stale SLO files and an empty execution loop cannot produce success. Exhausted SLO retries attempt rollback and report failure.

Verification: 29 new policy/entrypoint tests, including real subprocess execution with mocked Docker to prove cached PASS cannot change routing without new evidence. Existing load, reviewed-mail, state binding and rollback tests remain included. No live Docker traffic or production deployment was changed.
