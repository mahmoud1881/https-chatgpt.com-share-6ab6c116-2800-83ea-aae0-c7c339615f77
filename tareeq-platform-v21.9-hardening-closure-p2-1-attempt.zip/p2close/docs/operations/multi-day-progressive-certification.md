# Multi-day progressive rollout and 24-hour certification

The progressive rollout is intentionally resumable across the mandatory observation windows. The canonical traffic state remains at the current percentage while the controller exits with code 75 (`pending`); pending is not a rollout failure and must not trigger traffic rollback.

Stages remain strictly adjacent: `0 -> 1 -> 5 -> 25 -> 50 -> 100`. The next promotion is eligible only after 24 hours at 1%, 5%, and 25%, and after 48 hours at 50%. The progressive evidence file is retained between certification invocations and is bound to the immutable candidate image. A different image cannot resume the prior rollout.

The signed production certificate is still valid for only 24 hours. Its clock starts on the final certification invocation, after the multi-day rollout becomes eligible to reach 100%. Historical progressive evidence may begin before that 24-hour certificate window, but it must complete inside the current certification window, remain release-bound, and be no older than the bounded resumable horizon enforced by the verifier. All other runtime evidence remains subject to the ordinary 24-hour certification window.

Operationally, rerun `npm run production:certify:e2e` after each `eligibleAt`. Exit 75 means wait/resume; exit 1 means a real failure; exit 0 on the final invocation produces the signed certificate after the remaining runtime gates pass.
