# Priority two — deployment and recovery fixes

This patch retains priority-one security fixes. It does not certify production
readiness or claim a live staging/restore run.

## Changes

- Kong renders only the two validated JWT placeholders before startup, without
  shell eval. Missing/unsafe values or unresolved placeholders stop startup.
  The rendered file is private, and the template remains read-only.
- Verify, OAuth authorize/callback and JWKS use separate public services, without
  inherited key-auth/ACL. Each upstream URL preserves its endpoint after prefix
  stripping. Other Auth endpoints retain gateway key-auth/ACL and GoTrue's own
  token/role authorization. CORS anchors reside in valid service configuration.
- SQL health/restore probes return booleans and require exactly `t`; SQL errors
  remain fatal. No constant `1/0` branches remain in these probes.
- pg_dump and row-count verification share one exported repeatable-read snapshot.
  The exporting session remains open until the dump finishes. Failed dumps or
  detected changes to roles/passwords/memberships reject the backup.
- Source/config archives are compared with the live files before encryption;
  a concurrent deployment edit rejects the capture. Freeze deployments and role
  administration during backup. pg_dumpall global objects cannot share the data
  snapshot: the catalog comparison detects observed changes, not every possible
  administrative change/reversal, so the freeze is still required.
- Restore tolerates duplicate CREATE ROLE only; ALTER/GRANT and other SQL errors
  stop it. Original object ownership is restored rather than reassigned to the
  restore user, preserving SECURITY DEFINER ownership and privilege semantics.
  Unusual role identifiers require a reviewed manual restore and fail closed.
- The legacy overwrite restore also verifies checksums before changing config.
  Its explicit overwrite acknowledgement remains mandatory.
- CI adds a real Kong 2.8.1 container against an echo upstream, checking public
  endpoint routing, retained query strings and accepted/rejected gateway keys.
  Application build depends on this job. This routing test does not prove OAuth
  provider login: the staging provider callback/mailbox checks remain required.

## Validation

18 local Node tests passed: eight new deployment regressions, six priority-one
hint tests, and four existing rollout/Realtime tests. New backup tests simulate
Docker/psql IO and verify snapshot propagation, metrics, role drift rejection and
dump failure propagation. Shell and Node syntax and YAML parsing were checked.
The no-transit-pricing guard passed; no pricing feature was introduced.

Not run here: Docker/Kong integration, PostgreSQL integration, full app build,
real OAuth callback, offsite transfer, full restore or measured RTO. Docker,
psql and project dependencies are absent. Run CI and the existing staging and
restore-rehearsal gates before allowing visitors. Database dumps cover this
stack's database and archived source/config; do not infer coverage for external
object stores or services not configured in this Compose project.

Implementation references:
- https://github.com/supabase/supabase/blob/master/docker/volumes/api/kong.yml
- https://www.postgresql.org/docs/16/backup-dump.html
- https://www.postgresql.org/docs/17/app-pg-dumpall.html

Next audit priorities remain: reference journey certification, load-test success
criteria and residual pricing (priority three); live rollout monitoring and
functional rollback (priority four).
