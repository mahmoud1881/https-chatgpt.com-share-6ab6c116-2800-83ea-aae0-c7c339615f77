# Phase five — actual integrated verification

This report supersedes earlier statements that local dependencies/build/browser
checks were unavailable. The original roadmap had four priorities; phase five
integrates and verifies their combined changes.

## Executed successfully

| Check | Actual result |
| --- | --- |
| Locked dependency installation | Bun 1.4.0, frozen lockfile, 932 packages; lockfile unchanged |
| TypeScript | `tsc --noEmit` passed |
| ESLint | Zero errors; 12 existing nonblocking Fast Refresh warnings |
| Vitest | 370 tests passed across 44 files |
| Production build | Client and SSR/Nitro outputs built successfully |
| Production Node adapter + Chromium | Seven E2E tests passed: homepage, public metro, branch transfer, anonymous auth gate, capital train, LRT and trains |
| Deployment/security regressions | 33 Node tests passed, including immutable image release identity |
| Pricing guard | Passed across 68 active surfaces and datasets |

Build/E2E used placeholder API configuration, not a live Supabase backend.
The browser tests establish rendering/local journey behavior and login gating;
they do not establish database/Auth-provider/mail/Realtime integration.

## Defects fixed

- Removed orphan JSX markup left in capital-train, LRT and trains after pricing
  removal. Removed the remaining payment section on LRT and repaired its section.
- Fixed ESLint/Prettier errors without suppressing the rules.
- Stable Compose builds now receive RELEASE_COMMIT. deploy.sh requires the full
  source commit and compares it with the image stamp before deployment proceeds.
  The stamp is baked into the image; changing the runtime environment or worker
  response headers cannot impersonate a different release/channel. CI stamps
  Docker images with the checked-out GitHub SHA.
- Playwright now serves the actual production Node adapter instead of Vite's
  preview path, matching the Docker runtime behavior.
- Added regression coverage for the repaired transport pages and release identity.
- Removed 238 byte-equivalent logical route records (canonical full-record
  comparison). No distinct route/stop sequence was merged or guessed. The source
  graph now contains 3,569 records. A reproducible dry-run/write helper is included.

## Blocking findings — not waived

Data validation still exits with failure: 96 route-ID groups conflict. Seventy
groups differ in mode; 26 differ in stop sequence (10 also differ in declared
stop count). There are also six orphan references using the placeholder “—”.
These need source review and a deliberate identifier/import correction. Merely
renaming IDs, selecting an arbitrary first record or lowering validation would
hide the problem rather than establish correct journeys. The current full data
report is public/data/eg/validation_report.json.

The 20 core reference journeys still need independent review and deployed
observations; their certification gate remains blocked. Prior operator-source
dates were not reverified during this code-focused phase.

Docker and psql remain unavailable locally. No Docker image runtime, migration
replay, live staging, actual OAuth/email/TLS/DNS verification, load measurement,
offsite recovery or timed rollback is claimed. CI itself was edited but was not
run remotely. Full release readiness remains blocked by these missing results
and the conflicting data. There is no evidence-based 100% readiness claim.

Generated dependency/build/browser caches and test output directories are excluded
from the delivered source archive. The passing production build preceded the
exact-record deduplication; the latter changes only static JSON, which was then
loaded by the production server during the passing browser run.
