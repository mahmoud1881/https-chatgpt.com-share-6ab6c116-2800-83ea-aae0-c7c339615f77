# Priority three — implementation and evidence status

## Implemented

- Benchmark certification requires independent reference review, fresh dates,
  boarding/direction/alighting/transfer details, reviewed aliases, and separate
  evidence for search and planner. Results bind to the full deployed commit,
  dataset revision and reference SHA-256. The threshold remains 19/20 and zero
  unsafe/fabricated instructions. Missing evidence is a failure, never a pass.
- Added a Playwright evidence capture command. It records screenshots and visible
  instructions while leaving human verdicts pending. It has not run here.
- Load checks require a successful result with one or more routes. Rendering an
  empty/error container fails. Browser user-agent variation was removed; rate
  limiting is not bypassed to get a better load score.
- Removed the cheapest preference, related examples, SEO claims and translation
  entries. Removed monetary clauses from 44 minibus records and regenerated the
  compact equivalent without changing route IDs or stops.
- The pricing guard now scans all public JSON datasets and reference JSON files,
  plus additional UI/SEO/translation surfaces. The phrase meaning taxi drivers is
  explicitly allowed because it is an operator category, not a price.
- A new migration removes client access to historical community price columns and
  excludes them from write permissions. Historical storage remains for recovery;
  new product code does not read/write it. Existing legacy personal-route views
  are restricted only when present; they do not exist in fresh migration history.
- CI includes benchmark and load-result regression tests and SQL privilege checks.

## Actual findings and validation

Nine new Node tests passed, including threshold boundaries, unsafe instructions,
changed references, missing/stale evidence, false load success and compact-data
equivalence. Together with earlier regression suites, 27 tests passed locally.
The expanded no-pricing check and Node syntax checks passed.

The static graph measure found forward candidates for 17/18 applicable cases.
T17 still has no candidate; T19 is a reverse-direction sentinel and T20 needs
transfer review. These are graph coverage results, not correctness or safety.
All 20 core references remain pending independent review. The evaluator correctly
exits with failure for the shipped observation template. The eight supplemental
metro references retain their previously recorded review dates; no new operator
or field validation is claimed in this patch.

Not executed: full app build/Vitest/Playwright, SQL migration integration, real
staging load or independently reviewed trip certification. The environment lacks
project dependencies and Docker/PostgreSQL tools. Priority three's code changes
are delivered; its operational acceptance gate remains open until those results
and the independent references exist. Do not represent readiness as 100%.
