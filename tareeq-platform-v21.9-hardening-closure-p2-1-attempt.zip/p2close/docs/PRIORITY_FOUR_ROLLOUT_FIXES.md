# Priority four — rollout and functional rollback

## Changes

- Traffic state now records stable/candidate image IDs and the routing-file
  fingerprint. Promotion gates bind to that exact state, previous percentage,
  image pair and current migration ledger. Replaying a gate after rollback,
  swapping the stable image, skipping a stage, changing migrations or changing
  the routing file fails closed. Emergency 0% routing still bypasses promotion
  evidence and does not migrate or restore the database.
- Safety reviews bind to the same state/image pair/migration ledger. Rollback
  reports must match both images and the ledger, not only the candidate image.
- Monitoring checks the public HTTPS response's release/channel against the
  actual image revision and exposure stage. Missing expected candidates alert.
  Log windows use the previous sample boundary and current boundary; request
  timestamps make intervals half-open. Gates ignore overlapping/duplicate
  windows, earlier-stage samples, wrong images, future dates and stale samples.
- Wget health checks and designated browser/HTTP probes are excluded from HTTP
  traffic totals. These totals are operational samples, not authenticated user
  analytics; user-agent filtering does not establish a person's identity.
- An hourly read-only Playwright check exercises search and planner through the
  public proxy, verifies release identity, requires nonempty routes and fails on
  browser runtime errors. Cached evidence lasts at most one hour and is discarded
  on state change. MONITOR_FORCE_JOURNEY_PROBE=yes forces a new check. This cadence
  respects the existing per-IP quota; do not bypass rate limits for probes.
- Rollback rehearsal now requires public stable search/planner, password login,
  session verification, an authenticated insert/readback and deletion verification.
  A unique staging fixture uses the test account's own permissions; no service
  key is needed. Existing health probes cover REST/Auth/Realtime as well. The
  report fails if any functional step, cleanup, image check or ledger check fails,
  or if the 300-second total recovery target is exceeded.

## Operator requirements

Install the project's locked dependencies and Playwright Chromium on the monitor
and rehearsal host before enabling these probes (`bun install --frozen-lockfile`
from project root, then `bunx playwright install --with-deps chromium`). Provision
the retained stable image with release labels, result markers and timestamped
HTTP logs from this instrumentation before testing an actual subsequent candidate.
An older uninstrumented image cannot provide these new readiness proofs.

Initialize a new closed trial with `node scripts/rollout-traffic.mjs 0` after both
images are present. Old state/monitor/gate files do not satisfy the new contract.
Use `fingerprint(state)` exported by `rollout-evidence.mjs` for `stateFingerprint`;
copy actual `stableImage`/`candidateImage` from state into the reviewed safety
record. Include `migrationFingerprint` from the current gate report. A blocked
gate still records the current fingerprint so it can be independently reviewed.
Never fill safety booleans automatically. Rerun the gate after the signed review.

Functional rehearsal requires SITE_URL, SUPABASE_PUBLIC_URL,
VITE_SUPABASE_PUBLISHABLE_KEY, STAGING_TEST_EMAIL and STAGING_TEST_PASSWORD.
Use a disposable confirmed account on staging. The existing schema-compatibility
acknowledgement remains required. The rehearsal leaves traffic at 0%; a new gate
and observation window are required before exposing the candidate again.

Migration fingerprints cover the applied filename ledger, not arbitrary manual
DDL. Freeze deployments and direct schema changes during observation/rehearsal.
The existing runbook's expand/migrate/contract and isolated recovery procedure
remains mandatory for irreversible migrations. No script automatically restores
an older database, invents compatibility approval or accepts data loss.

## Validation status

Five new policy tests passed, covering exact image/state binding, gate replay,
stage skipping, duplicate/overlapping/stale monitoring and incomplete rollback.
Together with previous regressions: 32 local Node tests passed. Node syntax,
workflow YAML and the no-pricing guard also passed.

Not executed here: browser journeys, Docker/Caddy routing, live alert delivery,
PostgreSQL writes or timed functional rollback. They need staging, credentials
and installed runtime dependencies. Code changes do not establish 100% readiness.
